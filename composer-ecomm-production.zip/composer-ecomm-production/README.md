# composer-ecomm

In COMPOSER-ECOMM, the only reason we create a new branch is for a PR when we want to merge code into the PRODUCTION branch.  If any of the branches below are not for a PR to merge with PRODUCTION, please delete them immediately.  

 

As a reminder, ALL development in COMPOSER-ECOMM happens in the DEVELOPMENT branch.  When you have completed your development, create a branch off of PRODUCTION, copy over only your changes to this new branch and immediately raise a PR.
