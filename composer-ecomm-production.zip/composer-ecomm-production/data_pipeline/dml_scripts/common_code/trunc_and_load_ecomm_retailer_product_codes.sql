DROP TABLE IF EXISTS `{{params.ECOMM_DLF}}`.processed.ecomm_retailer_product_codes;

CREATE TABLE `{{params.ECOMM_DLF}}`.processed.ecomm_retailer_product_codes
PARTITION BY RANGE_BUCKET(host_key, GENERATE_ARRAY(0, 500, 10))
CLUSTER BY host, chain_nm, banner_nm, fiscal_year_nbr
OPTIONS(
  friendly_name="eCommerce customer product code table",  
  description="Table to store customer codes",
  labels =
    [
      ("category", "product_catalog"),
      ("data_classification", "confidential_internal_2b"),
      ("rls", "skip-rls")
    ]
) AS

WITH
date_range AS (
    SELECT 
      DISTINCT
      DATE_SUB(SAFE_CAST(fiscal_week_begin_dt AS DATE), INTERVAL 1 YEAR) AS start_date, -- Go back one fiscal year
      SAFE_CAST(x.fiscal_week_begin_dt AS DATE) AS end_date -- Get the fiscal_week_begin_dt for today
    FROM `edw-prd-e567f9.enterprise.dim_date`  x
    WHERE SAFE_CAST(x.fiscal_dt AS STRING FORMAT 'YYYY-MM-DD') = SAFE_CAST(CURRENT_DATE() AS STRING FORMAT 'YYYY-MM-DD') 
),
fiscal_years AS (
    SELECT
        DISTINCT d.fiscal_year_nbr,
        d.fiscal_dt
    FROM `edw-prd-e567f9.enterprise.dim_date` d
    WHERE
        d.language_cd = 'EN'
        AND SAFE_CAST(fiscal_week_begin_dt AS DATE) BETWEEN (SELECT start_date FROM date_range) AND (SELECT end_date FROM date_range) 
)
SELECT
  DISTINCT
  ABS(FARM_FINGERPRINT(lower(dsp.host_nm))) AS host_key,
  CASE lower(dsp.host_nm)
    WHEN 'www.instacart.com' THEN 'INSTACART'
    WHEN 'www.amazon.com' THEN 'AMAZON'
    WHEN 'redsky.target.com' THEN 'TARGET'
    WHEN 'api.samsclub.com' THEN 'SAMS CLUB'
    WHEN 'www.walmart.com' THEN 'WALMART'
    WHEN 'www.kroger.com' THEN 'KROGER'
  ELSE 
    lower(dsp.host_nm) 
  END AS customer_parent,
  lower(dsp.host_nm) AS host,
  `{{params.ECOMM_DLF}}`.transient.remove_special_chars(ds.banner_nm) AS banner_nm,
  `{{params.ECOMM_DLF}}`.transient.remove_special_chars(ds.chain_nm) as chain_nm,
  dsp.upc_cd AS provided_upc,
  `{{params.ECOMM_DLF}}`.transient.generate_upc_check_digit(CAST(SAFE_CAST(dsp.upc_cd as int64) AS STRING)) ean_upc_derived_cd,  
  dsp.sku_cd provided_retailer_product_cd, 
  IF(lower(dsp.host_nm) = 'www.amazon.com', dsp.sku_cd, REGEXP_REPLACE(dsp.sku_cd, '[^0-9]', '')) AS derived_retailer_product_cd,
  fy.fiscal_year_nbr 
  --ds.channel_in_store,
  --dsp.channel_method_desc
FROM
fiscal_years fy INNER JOIN
   `edw-prd-e567f9.srm.datasembly_store_price_fact` dsp on fy.fiscal_dt = SAFE_CAST(dsp.report_dt AS DATE)
INNER JOIN
  `edw-prd-e567f9.srm.dim_datasembly_store` ds
ON
  dsp.banner_id = ds.banner_id
  AND dsp.store_id = ds.store_id
WHERE 
  (dsp.upc_cd IS NOT NULL AND dsp.sku_cd IS NOT NULL)
  AND lower(dsp.host_nm) IN (
    'www.instacart.com',
    'www.amazon.com',
    'redsky.target.com',
    'api.samsclub.com',
    'www.walmart.com',
    'www.kroger.com'
  )
  QUALIFY ROW_NUMBER() OVER (PARTITION BY dsp.host_nm, dsp.upc_cd ORDER BY fiscal_year_nbr desc) = 1
