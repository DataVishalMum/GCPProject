--DECLARE ORDER_DATE DATE DEFAULT DATE_SUB(CURRENT_DATE(), INTERVAL 6 MONTH);

DROP TABLE IF EXISTS `{{params.ECOMM_DLF}}`.processed.ecomm_product_catalog_v3;

CREATE OR REPLACE TABLE `{{params.ECOMM_DLF}}`.processed.ecomm_product_catalog_v3
PARTITION BY RANGE_BUCKET(customer_parent_key, GENERATE_ARRAY(0, 500, 10))
CLUSTER BY customer_parent, customer_cd, material_cd, material_type_cd
OPTIONS(
  friendly_name="eCommerce product catalog",  
  description="Common table for all things Material for eCommerce",
  labels =
    [
      ("category", "product_catalog"),
      ("data_classification", "confidential_internal_2b")
    ]
) AS

WITH 
/*
fiscal_years AS (
    SELECT 
        d.fiscal_year_nbr,
        d.language_cd
    FROM `edw-prd-e567f9.enterprise.dim_date` d 
    WHERE 
        d.fiscal_year_nbr 
        BETWEEN EXTRACT(YEAR FROM DATE_SUB(CURRENT_DATE(), INTERVAL 1 YEAR)) AND EXTRACT(YEAR FROM CURRENT_DATE())
    AND d.language_cd = 'EN'
    GROUP BY d.fiscal_year_nbr, d.language_cd
),
*/
date_range AS (
    SELECT 
      DISTINCT
      DATE_SUB(SAFE_CAST(fiscal_week_begin_dt AS DATE), INTERVAL 1 YEAR) AS start_date, -- Go back one fiscal year
      SAFE_CAST(x.fiscal_week_begin_dt AS DATE) AS end_date -- Get the fiscal_week_begin_dt for today
    FROM `edw-prd-e567f9.enterprise.dim_date`  x
    WHERE SAFE_CAST(x.fiscal_dt AS STRING FORMAT 'YYYY-MM-DD') = SAFE_CAST(CURRENT_DATE() AS STRING FORMAT 'YYYY-MM-DD') 
),
fiscal_years AS (
    SELECT
        DISTINCT d.fiscal_year_nbr
    FROM `edw-prd-e567f9.enterprise.dim_date` d
    WHERE
        d.language_cd = 'EN'
        AND SAFE_CAST(fiscal_week_begin_dt AS DATE) BETWEEN (SELECT start_date FROM date_range) AND (SELECT end_date FROM date_range) 
),
distinct_materials AS (
    SELECT DISTINCT
        m.material_cd,
        m.current_flg,
        m.source_type_cd,
        m.material_type_cd,   
        m.ean_category_cd,
        m.ci_launch_type_cd,
        m.ci_launch_type_desc,
        m.material_nbr,
        m.product_in_out_seasonal_flg,
        m.special_pack_sales_seasonal_flg,
        m.base_product_cd,
        m.base_product_nbr,
        m.base_product_desc,
        m.conversion_base_product_cd,
        m.base_product_cd AS material_base_product_cd,
        m.base_product_ean_upc_cd,
        m.base_uom_to_eqc_fctr,
        m.base_uom_to_ecv_fctr,
        m.gmi_division_cd, 
        m.gmi_division_desc,
        m.ean_upc_cd,
        m.ean_upc_derived_cd,
        m.upc_package_prefix_cd,
        CASE WHEN REGEXP_CONTAINS(m.ean_upc_derived_cd, r'^(0\d{12})$') THEN m.ean_upc_derived_cd ELSE NULL END AS ean_13_digit_retail_upc,
        m.start_ship_dt as ipp_start_dt,
        IF(SAFE_CAST(m.start_ship_dt AS DATE) IS NOT NULL AND EXTRACT(YEAR FROM m.start_ship_dt) < 9999, DATE_ADD(m.start_ship_dt, INTERVAL 83 DAY), NULL) AS ipp_end_dt,
        m.size_dimension_txt,
        m.material_short_desc,
        m.sls_hier_sub_category_desc,
        m.sls_hier_category_desc,
        m.sls_hier_division_desc,
        m.sls_hier_accrual_group_cd,
        m.sls_hier_ppg_cd,
        m.sls_hier_accrual_group_desc,
        m.sls_hier_ppg_desc,
        m.sls_hier_sub_category_cd,
        m.sls_hier_category_cd,
        m.sls_hier_division_cd,
        m.bph1_hier_bph10_desc,
        m.bph1_hier_bph20_desc,
        m.bph1_hier_bph30_desc,
        m.bph1_hier_bph40_desc,
        m.bph1_hier_bph50_desc,
        m.bph1_hier_bph60_desc,
        m.bph1_hier_bph70_desc,
        m.gph_hier_top_cd,
        m.gph_hier_family_cd,
        m.gph_hier_category_cd,
        m.gph_hier_flavor_format_cd,
        m.gph_hier_package_size_cd,
        m.gph_hier_top_desc,
        m.gph_hier_family_desc,
        m.gph_hier_category_desc,
        m.gph_hier_flavor_format_desc,
        m.gph_hier_package_size_desc,
        m.gross_weight_uom_qty, 
        m.net_weight_uom_qty,
        m.weight_uom_cd,
        m.brand_cd,
        m.brand_desc,
        m.sub_brand_desc,
        m.language_cd
    FROM `edw-prd-e567f9.enterprise.dim_material` m
    WHERE m.language_cd = 'EN' AND  m.material_type_cd in ('HAWA', 'FINI', 'CNPK', 'FERT', 'NPD')
),
material_with_parent as (
    (
        SELECT
            fini.*,
            fini.material_cd as parent_material_cd
        FROM distinct_materials fini 
        WHERE fini.material_type_cd <> 'CNPK' 
    ) UNION DISTINCT (
        SELECT
            cnpk.*,
            pm.material_cd as parent_material_cd
        FROM distinct_materials cnpk 
        JOIN `edw-prd-e567f9.enterprise.dim_product_material_uom` pm ON cnpk.ean_upc_cd = pm.ean_upc_cd
        WHERE cnpk.material_type_cd = 'CNPK' AND pm.current_flg = true
    )
),
customer_parents AS (
        SELECT DISTINCT
            comp_codes.source_type_cd,
            cust.language_cd,
            cust.customer_cd,
            cust.customer_name_1_desc AS customer_name,
            cust.customer_hier_corporate_parent_desc AS parent_account,
            CASE
                WHEN STARTS_WITH(cust.customer_name_1_desc, 'ALBERTSONS') THEN 'ALBERTSONS'
                WHEN STARTS_WITH(cust.customer_name_1_desc, 'AMAZON') THEN 'AMAZON'
                WHEN STARTS_WITH(cust.customer_name_1_desc, 'ASDA') THEN 'ASDA'
                WHEN STARTS_WITH(cust.customer_name_1_desc, 'ASSOCIATED FOODS') THEN 'ASSOCIATED FOODS'
                WHEN STARTS_WITH(cust.customer_name_1_desc, 'CHEWY') THEN 'CHEWY'
                WHEN STARTS_WITH(cust.customer_name_1_desc, 'COLES') THEN 'COLES'
                WHEN STARTS_WITH(cust.customer_name_1_desc, 'CORNERSHOP') THEN 'CORNERSHOP'
                WHEN STARTS_WITH(cust.customer_name_1_desc, 'COSTCO') THEN 'COSTCO'
                WHEN STARTS_WITH(cust.customer_name_1_desc, 'HARRIS TEETER') THEN 'HARRIS TEETER'
                WHEN STARTS_WITH(cust.customer_name_1_desc, 'INSTACART') THEN 'INSTACART'
                WHEN STARTS_WITH(cust.customer_name_1_desc, 'KROGER') THEN 'KROGER'
                WHEN STARTS_WITH(cust.customer_name_1_desc, 'LOBLAWS') THEN 'LOBLAWS'
                WHEN STARTS_WITH(cust.customer_name_1_desc, 'MEIJER') THEN 'MEIJER'
                WHEN STARTS_WITH(cust.customer_name_1_desc, 'OCADO') THEN 'OCADO'
                WHEN STARTS_WITH(cust.customer_name_1_desc, 'PEAPOD') THEN 'PEAPOD'
                WHEN STARTS_WITH(cust.customer_name_1_desc, 'PETCO') THEN 'PETCO'
                WHEN STARTS_WITH(cust.customer_name_1_desc, 'PETSMART') THEN 'PETSMART'
                WHEN STARTS_WITH(cust.customer_name_1_desc, 'PUBLIX') THEN 'PUBLIX'
                WHEN STARTS_WITH(cust.customer_name_1_desc, 'SAINSBURY') THEN 'SAINSBURY'
                WHEN STARTS_WITH(cust.customer_name_1_desc, 'SAMS') THEN 'SAMS'
                WHEN STARTS_WITH(cust.customer_name_1_desc, 'SHIPT') THEN 'SHIPT'
                WHEN STARTS_WITH(cust.customer_name_1_desc, 'SHOPRITE') THEN 'SHOPRITE'
                WHEN STARTS_WITH(cust.customer_name_1_desc, 'SOBEYS') THEN 'SOBEYS'
                WHEN STARTS_WITH(cust.customer_name_1_desc, 'TARGET') THEN 'TARGET'
                WHEN STARTS_WITH(cust.customer_name_1_desc, 'TESCO') THEN 'TESCO'
                WHEN STARTS_WITH(cust.customer_name_1_desc, 'WAITROSE') THEN 'WAITROSE'
                WHEN STARTS_WITH(cust.customer_name_1_desc, 'WAL MART') THEN 'WALMART'
                WHEN STARTS_WITH(cust.customer_name_1_desc, 'WALMART') THEN 'WALMART'
                WHEN STARTS_WITH(cust.customer_name_1_desc, 'WAL-MART') THEN 'WALMART'
                WHEN STARTS_WITH(cust.customer_name_1_desc, 'WOOLWORTHS') THEN 'WOOLWORTHS'
                WHEN STARTS_WITH(cust.customer_name_1_desc, 'LIDL') THEN 'LIDL'
            ELSE
               NULL
            END AS customer_parent
        FROM `edw-prd-e567f9.enterprise.dim_customer` cust
        JOIN `edw-prd-e567f9.enterprise.dim_customer_company_code` cust_comp_codes ON (cust_comp_codes.language_cd = cust.language_cd AND cust_comp_codes.customer_cd = cust.customer_cd)
        JOIN `edw-prd-e567f9.enterprise.dim_company_code` comp_codes ON (comp_codes.source_type_cd = cust_comp_codes.source_type_cd AND comp_codes.company_cd = cust_comp_codes.company_cd)
    ),
customer_mat as (
    (
        SELECT DISTINCT 
            m.*,
            cust.* EXCEPT (source_type_cd, language_cd),
            cust_mat.sales_organization_cd,
            cust_mat.sales_organization_desc,
            cust_mat.distribution_channel_cd,
            cust_mat.distribution_channel_desc,
            shipped.customer_cd AS shippedto_customer,
            IF(shipped.customer_cd IS NOT NULL, TRUE, FALSE) AS ecomm_shipped_flg,   
            shipped.material_cd AS shipped_material,
            shipped.uom_cd AS shipped_uom_cd
        FROM material_with_parent m
        JOIN `edw-prd-e567f9.enterprise.dim_customer_material` cust_mat ON (cust_mat.material_cd = m.parent_material_cd AND cust_mat.language_cd = m.language_cd AND m.source_type_cd = cust_mat.source_type_cd)
        JOIN customer_parents cust ON  (cust_mat.language_cd = cust.language_cd AND cust_mat.customer_cd = cust.customer_cd)
        LEFT JOIN
            (
                SELECT 
                    x.customer_cd, 
                    x.material_cd, 
                    x.uom_cd,
                    CASE x.source_system_cd
                        WHEN 'IE' THEN 'INTL'
                        WHEN 'ER' THEN 'NA'
                    END AS source_type_cd
                FROM `shareddata-prd-cb5872.shared_data_finance.gf_volume_by_scenario` x 
                WHERE 
                    x.scenario = 'ACT'
                    AND x.fiscal_year_nbr IN (SELECT fiscal_year_nbr FROM fiscal_years)
            ) shipped ON (
                cust_mat.source_type_cd = shipped.source_type_cd 
                AND cust_mat.customer_cd = shipped.customer_cd 
                AND cust_mat.material_cd = shipped.material_cd
            )

    ) UNION DISTINCT (
        SELECT 
            m.*,
            --NULL AS source_type_cd,
            --NULL AS language_cd,
            'GMI' as customer_cd,
            'General Mills' as customer_name,
            'General Mills' as parent_account,
            'GMI' as customer_parent,
            NULL AS sales_organization_cd,
            NULL AS sales_organization_desc,
            NULL AS distribution_channel_cd,
            NULL AS distribution_channel_desc,
            NULL AS shippedto_customer,
            FALSE AS ecomm_shipped_flg,   
            NULL AS shipped_material,
            NULL AS shipped_uom_cd
        FROM material_with_parent m
    )
),
sap_orders as (
    SELECT 
        cp.customer_parent,
        h.vbeln AS sales_document,
        h.erdat AS sales_document_created_dt,
        h.audat AS sales_document_document_dt,
        h.vkorg AS sales_organization_cd,
        h.vtweg AS distribution_channel_cd,
        h.spart AS division_cd,
        h.vdatu AS requested_delivery_dt,
        h.bstnk AS customer_po_nbr,
        h.kunnr AS customer_cd,
        d.matnr AS material_cd, 
        d.matwa AS material_entered,
        d.matkl AS material_group,
        d.zieme AS target_quantity_uom,
        d.meins AS base_uom,
        d.kdmat AS customer_product_cd,
        d.ean11,
       -- d.abgru AS order_item_rejection_reason_cd,
       -- IF(LENGTH(TRIM(d.abgru)) > 0, TRUE, FALSE) order_item_rejected_flg
    FROM `edw-ods-prd-ba33c3.sap_ods.er_vbak` h 
    JOIN `edw-ods-prd-ba33c3.sap_ods.er_vbap` d on h.vbeln = d.vbeln
    JOIN customer_parents cp on h.kunnr = cp.customer_cd 
    WHERE CAST(h.erdat AS DATE) >= (SELECT start_date from date_range) -- ORDER_DATE
    GROUP BY 
        cp.customer_parent,
        h.vbeln,
        h.erdat,
        h.audat,
        h.vkorg,
        h.vtweg,
        h.spart,
        h.vdatu,
        h.bstnk,
        h.kunnr,
        d.vbeln,
        d.matnr,
        d.matwa,
        d.matkl,
        d.zieme,
        d.meins,
        d.kdmat,
        d.ean11
       -- d.abgru 
    ORDER BY CAST(h.erdat AS DATE) DESC
),
latest_sap_orders as (
    SELECT * 
    FROM (
        SELECT sap_orders.*,
        ROW_NUMBER() OVER (PARTITION BY customer_cd, material_cd ORDER BY sales_document_created_dt DESC) rank_order
        FROM sap_orders        
    ) WHERE rank_order = 1
),
latest_sap_rpcs as (
    SELECT 
        x.customer_parent,
        x.material_cd,
        x.customer_product_cd AS latest_customer_product_cd,
        x.sales_document_created_dt AS latest_customer_product_cd_dt
    FROM (
        SELECT sap_orders.*,
         ROW_NUMBER() OVER (PARTITION BY customer_parent, material_cd ORDER BY sales_document_created_dt DESC) rank_order
        FROM sap_orders 
        WHERE customer_product_cd IS NOT NULL       
    ) x WHERE x.rank_order = 1
)

, opc as ( SELECT
      IF(UPPER(customer_parent) = 'INSTACART', 'GMI', customer_parent) as customer_parent,
      x.customer_parent opc_customer_parent,
      x.ean_upc_derived_cd,
      x.derived_retailer_product_cd,
      x.fiscal_year_nbr,
      x.host,
      x.chain_nm,
      x.banner_nm
    FROM `{{params.ECOMM_DLF}}`.processed.ecomm_retailer_product_codes x )

,product_catalog as(
    SELECT 
        DISTINCT 
        ABS(FARM_FINGERPRINT(mat.customer_parent)) AS customer_parent_key,
        mat.*,
        orders.* EXCEPT(customer_parent, customer_cd, sales_organization_cd, distribution_channel_cd, material_cd, rank_order),
        rpcs.* EXCEPT(customer_parent, material_cd),
        opc.* EXCEPT (customer_parent, ean_upc_derived_cd)
    FROM customer_mat mat -- May need to revert joins to customer_cd instead of customer_parent
    LEFT JOIN latest_sap_orders orders ON mat.parent_material_cd = orders.material_cd and mat.customer_parent = orders.customer_parent
    LEFT JOIN latest_sap_rpcs rpcs ON mat.parent_material_cd = rpcs.material_cd and mat.customer_parent = rpcs.customer_parent
    LEFT JOIN  opc ON mat.customer_parent = opc.customer_parent AND mat.ean_upc_derived_cd = opc.ean_upc_derived_cd
    where mat.customer_parent is not null

)
SELECT * FROM product_catalog p

