

DECLARE ORDER_DATE DATE DEFAULT DATE_SUB(CURRENT_DATE(), INTERVAL 6 MONTH);

DROP TABLE IF EXISTS `{{params.ECOMM_DLF}}`.processed.ecomm_product_catalog;

CREATE TABLE `{{params.ECOMM_DLF}}`.processed.ecomm_product_catalog
PARTITION BY RANGE_BUCKET(customer_parent_key, GENERATE_ARRAY(0, 500, 10))
CLUSTER BY customer_parent, customer_cd, material_cd, material_type_cd
OPTIONS(
  friendly_name="eCommerce product catalog",  
  description="Common table for all things Material for eCommerce",
  labels =
    [
      ("category", "product_catalog"),
      ("data_classification", "confidential_internal_2b")
    ]
) AS

WITH 
fiscal_years AS (
    SELECT 
        d.fiscal_year_nbr,
        d.language_cd
    FROM `edw-prd-e567f9.enterprise.dim_date` d 
    WHERE 
        d.fiscal_year_nbr 
        BETWEEN EXTRACT(YEAR FROM DATE_SUB(CURRENT_DATE(), INTERVAL 1 YEAR)) AND EXTRACT(YEAR FROM CURRENT_DATE())
    AND d.language_cd = 'EN'
    GROUP BY d.fiscal_year_nbr, d.language_cd
),
customer_prents AS (
    SELECT
        comp_codes.source_type_cd,
        cust.customer_cd,
        cust.customer_name_1_desc AS customer_name,
        cust.customer_hier_corporate_parent_desc AS parent_account,
        CASE
            WHEN STARTS_WITH(cust.customer_name_1_desc, 'ALBERTSONS') THEN 'ALBERTSONS'
            WHEN STARTS_WITH(cust.customer_name_1_desc, 'AMAZON') THEN 'AMAZON'
            WHEN STARTS_WITH(cust.customer_name_1_desc, 'ASDA') THEN 'ASDA'
            WHEN STARTS_WITH(cust.customer_name_1_desc, 'ASSOCIATED FOODS') THEN 'ASSOCIATED FOODS'
            WHEN STARTS_WITH(cust.customer_name_1_desc, 'CHEWY') THEN 'CHEWY'
            WHEN STARTS_WITH(cust.customer_name_1_desc, 'COLES') THEN 'COLES'
            WHEN STARTS_WITH(cust.customer_name_1_desc, 'CORNERSHOP') THEN 'CORNERSHOP'
            WHEN STARTS_WITH(cust.customer_name_1_desc, 'COSTCO') THEN 'COSTCO'
            WHEN STARTS_WITH(cust.customer_name_1_desc, 'HARRIS TEETER') THEN 'HARRIS TEETER'
            WHEN STARTS_WITH(cust.customer_name_1_desc, 'INSTACART') THEN 'INSTACART'
            WHEN STARTS_WITH(cust.customer_name_1_desc, 'KROGER') THEN 'KROGER'
            WHEN STARTS_WITH(cust.customer_name_1_desc, 'LOBLAWS') THEN 'LOBLAWS'
            WHEN STARTS_WITH(cust.customer_name_1_desc, 'MEIJER') THEN 'MEIJER'
            WHEN STARTS_WITH(cust.customer_name_1_desc, 'OCADO') THEN 'OCADO'
            WHEN STARTS_WITH(cust.customer_name_1_desc, 'PEAPOD') THEN 'PEAPOD'
            WHEN STARTS_WITH(cust.customer_name_1_desc, 'PETCO') THEN 'PETCO'
            WHEN STARTS_WITH(cust.customer_name_1_desc, 'PETSMART') THEN 'PETSMART'
            WHEN STARTS_WITH(cust.customer_name_1_desc, 'PUBLIX') THEN 'PUBLIX'
            WHEN STARTS_WITH(cust.customer_name_1_desc, 'SAINSBURY') THEN 'SAINSBURY'
            WHEN STARTS_WITH(cust.customer_name_1_desc, 'SAMS') THEN 'SAMS'
            WHEN STARTS_WITH(cust.customer_name_1_desc, 'SHIPT') THEN 'SHIPT'
            WHEN STARTS_WITH(cust.customer_name_1_desc, 'SHOPRITE') THEN 'SHOPRITE'
            WHEN STARTS_WITH(cust.customer_name_1_desc, 'SOBEYS') THEN 'SOBEYS'
            WHEN STARTS_WITH(cust.customer_name_1_desc, 'TARGET') THEN 'TARGET'
            WHEN STARTS_WITH(cust.customer_name_1_desc, 'TESCO') THEN 'TESCO'
            WHEN STARTS_WITH(cust.customer_name_1_desc, 'WAITROSE') THEN 'WAITROSE'
            WHEN STARTS_WITH(cust.customer_name_1_desc, 'WAL MART') THEN 'WALMART'
            WHEN STARTS_WITH(cust.customer_name_1_desc, 'WALMART') THEN 'WALMART'
            WHEN STARTS_WITH(cust.customer_name_1_desc, 'WAL-MART') THEN 'WALMART'
            WHEN STARTS_WITH(cust.customer_name_1_desc, 'WOOLWORTHS') THEN 'WOOLWORTHS'
            WHEN STARTS_WITH(cust.customer_name_1_desc, 'LIDL') THEN 'LIDL'
        ELSE
            CONCAT(cust.customer_name_1_desc, ' ***')
        END AS customer_parent
    FROM
    `edw-prd-e567f9.enterprise.dim_company_code` comp_codes
    JOIN `edw-prd-e567f9.enterprise.dim_customer_company_code` cust_comp_codes ON
        (comp_codes.source_type_cd = cust_comp_codes.source_type_cd AND comp_codes.company_cd = cust_comp_codes.company_cd)
    JOIN `edw-prd-e567f9.enterprise.dim_customer` cust ON  (cust_comp_codes.language_cd = cust.language_cd AND cust_comp_codes.customer_cd = cust.customer_cd)
),
distinct_materials AS (
    SELECT
        m.material_cd,
        m.current_flg,
        m.source_type_cd,
        m.material_type_cd,   
        m.ean_category_cd,
        m.ci_launch_type_cd,
        m.ci_launch_type_desc,
        m.material_nbr,
        m.product_in_out_seasonal_flg,
        m.special_pack_sales_seasonal_flg,
        m.base_product_cd,
        m.base_product_nbr,
        m.base_product_desc,
        m.conversion_base_product_cd,
        m.base_product_cd AS material_base_product_cd,
        m.base_product_ean_upc_cd,
        m.base_uom_to_eqc_fctr,
        m.base_uom_to_ecv_fctr,
        m.ean_upc_cd,
        m.ean_upc_derived_cd,
        CASE WHEN REGEXP_CONTAINS(m.ean_upc_derived_cd, r'^(0\d{12})$') THEN m.ean_upc_derived_cd ELSE NULL END AS ean_13_digit_retail_upc,
        m.start_ship_dt as ipp_start_dt,
        IF(SAFE_CAST(m.start_ship_dt AS DATE) IS NOT NULL AND EXTRACT(YEAR FROM m.start_ship_dt) < 9999, DATE_ADD(m.start_ship_dt, INTERVAL 83 DAY), NULL) AS ipp_end_dt,
        m.size_dimension_txt,
        m.material_short_desc,
        m.sls_hier_sub_category_desc,
        m.sls_hier_category_desc,
        m.sls_hier_division_desc,
        m.sls_hier_accrual_group_cd,
        m.sls_hier_ppg_cd,
        m.sls_hier_accrual_group_desc,
        m.sls_hier_ppg_desc,
        m.sls_hier_sub_category_cd,
        m.sls_hier_category_cd,
        m.sls_hier_division_cd,
        m.bph1_hier_bph10_desc,
        m.bph1_hier_bph20_desc,
        m.bph1_hier_bph30_desc,
        m.bph1_hier_bph40_desc,
        m.bph1_hier_bph50_desc,
        m.bph1_hier_bph60_desc,
        m.bph1_hier_bph70_desc,
        m.gph_hier_top_cd,
        m.gph_hier_family_cd,
        m.gph_hier_category_cd,
        m.gph_hier_flavor_format_cd,
        m.gph_hier_package_size_cd,
        m.gph_hier_top_desc,
        m.gph_hier_family_desc,
        m.gph_hier_category_desc,
        m.gph_hier_flavor_format_desc,
        m.gph_hier_package_size_desc,
        m.gross_weight_uom_qty, 
        m.net_weight_uom_qty,
        m.weight_uom_cd,
        m.brand_cd,
        m.brand_desc,
        m.sub_brand_desc
    FROM `edw-prd-e567f9.enterprise.dim_material` m
    WHERE m.language_cd = 'EN'
    GROUP BY 
        m.material_cd,
        m.current_flg,
        m.source_type_cd,
        m.ean_upc_derived_cd, 
        m.start_ship_dt,       
        m.material_type_cd,   
        m.ean_category_cd,
        m.ci_launch_type_cd,
        m.ci_launch_type_desc,
        m.material_nbr,
        m.product_in_out_seasonal_flg,
        m.special_pack_sales_seasonal_flg,
        m.base_product_cd,
        m.base_product_nbr,
        m.base_product_desc,
        m.conversion_base_product_cd,
        m.base_product_cd,
        m.base_product_ean_upc_cd,
        m.base_uom_to_eqc_fctr,
        m.base_uom_to_ecv_fctr,
        m.ean_upc_cd,
        m.ean_upc_derived_cd,
        m.size_dimension_txt,
        m.material_short_desc,
        m.sls_hier_sub_category_desc,
        m.sls_hier_category_desc,
        m.sls_hier_division_desc,
        m.sls_hier_accrual_group_cd,
        m.sls_hier_ppg_cd,
        m.sls_hier_accrual_group_desc,
        m.sls_hier_ppg_desc,
        m.sls_hier_sub_category_cd,
        m.sls_hier_category_cd,
        m.sls_hier_division_cd,
        m.bph1_hier_bph10_desc,
        m.bph1_hier_bph20_desc,
        m.bph1_hier_bph30_desc,
        m.bph1_hier_bph40_desc,
        m.bph1_hier_bph50_desc,
        m.bph1_hier_bph60_desc,
        m.bph1_hier_bph70_desc,
        m.gph_hier_top_cd,
        m.gph_hier_family_cd,
        m.gph_hier_category_cd,
        m.gph_hier_flavor_format_cd,
        m.gph_hier_package_size_cd,
        m.gph_hier_top_desc,
        m.gph_hier_family_desc,
        m.gph_hier_category_desc,
        m.gph_hier_flavor_format_desc,
        m.gph_hier_package_size_desc,
        m.gross_weight_uom_qty, 
        m.net_weight_uom_qty,
        m.weight_uom_cd,
        m.brand_cd,
        m.brand_desc,
        m.sub_brand_desc
),

customer_orders as (
    SELECT 
        h.vbeln AS sales_document,
        h.erdat AS created_dt,
        h.audat AS document_dt,
        h.vkorg AS sales_organization_cd,
        h.vtweg AS distribution_channel_cd,
        h.spart AS division_cd,
        h.vdatu AS requested_delivery_dt,
        h.bstnk AS customer_po_nbr,
        h.kunnr AS customer_cd,
        d.vbeln AS sales_document,
        d.matnr AS material_cd, 
        d.matwa AS material_entered,
        d.matkl AS material_group,
        d.zieme AS target_quantity_uom,
        d.meins AS base_uom,
        d.kdmat AS customer_product_cd,
        d.ean11        
        FROM `edw-ods-prd-ba33c3.sap_ods.er_vbak` h JOIN `edw-ods-prd-ba33c3.sap_ods.er_vbap` d on h.vbeln = d.vbeln
        WHERE CAST(h.erdat AS DATE) > ORDER_DATE
        GROUP BY 
        h.vbeln,
        h.erdat,
        h.audat,
        h.vkorg,
        h.vtweg,
        h.spart,
        h.vdatu,
        h.bstnk,
        h.kunnr,
        d.vbeln,
        d.matnr,
        d.matwa,
        d.matkl,
        d.zieme,
        d.meins,
        d.kdmat,
        d.ean11 
    ORDER BY CAST(h.erdat AS DATE) DESC
),
sold_materials as (
    SELECT * FROM (
        (
            SELECT 
                m.source_type_cd,
                c.sales_organization_cd,
                c.distribution_channel_cd,
                c.division_cd,
                m.current_flg,
                c.material_cd AS parent_material_cd, 
                c.material_cd, 
                c.customer_cd,
                c.customer_product_cd,
                m.ean_upc_cd,
                m.material_type_cd,
                pm.ean_upc_cd AS child_item_upc
            FROM customer_orders c
            JOIN `edw-prd-e567f9.enterprise.dim_material` m ON c.material_cd = m.material_cd
            JOIN  `edw-prd-e567f9.enterprise.dim_product_material_uom` pm ON m.material_cd = pm.material_cd
            WHERE pm.ean_upc_cd IS NOT NULL AND m.material_type_cd in ('HAWA', 'FINI', 'CNPK', 'FERT', 'NPD')
        )
        UNION ALL 
        (
            SELECT  
                m.source_type_cd, 
                pm.sales_organization_cd,
                pm.distribution_channel_cd,
                pm.division_cd,
                m.current_flg,     
                pm.material_cd AS parent_material_cd,
                m.material_cd,
                pm.customer_cd,
                pm.customer_product_cd,
                pm.ean_upc_cd,
                m.material_type_cd,
                pm.ean_upc_cd AS child_item_upc

            FROM
            (
                SELECT 
                    p.material_cd,
                    p.ean_upc_cd,
                    c.customer_cd,
                    c.customer_product_cd,
                    c.sales_organization_cd,
                    c.distribution_channel_cd,
                    c.division_cd                    
                FROM `edw-prd-e567f9.enterprise.dim_product_material_uom` p 
                JOIN customer_orders c ON p.material_cd = c.material_cd 
                WHERE p.ean_upc_cd IS NOT NULL
            ) pm
        JOIN `edw-prd-e567f9.enterprise.dim_material` m ON pm.ean_upc_cd = m.ean_upc_cd
        WHERE m.language_cd = 'EN' AND m.material_type_cd = 'CNPK'
        )) cnpks
    GROUP BY 
        cnpks.source_type_cd,
        cnpks.sales_organization_cd,
        cnpks.distribution_channel_cd,
        cnpks.division_cd,
        cnpks.current_flg,
        cnpks.parent_material_cd,
        cnpks.material_cd,
        cnpks.material_type_cd,
        cnpks.customer_cd,
        cnpks.customer_product_cd,
        cnpks.ean_upc_cd,
        cnpks.child_item_upc
),
customer_detail AS (
    SELECT
    comp_codes.source_type_cd,
    cust.customer_cd,
    cust.customer_name_1_desc AS customer_name,
    cust.customer_hier_corporate_parent_desc AS parent_account,
    CASE
        WHEN STARTS_WITH(cust.customer_name_1_desc, 'ALBERTSONS') THEN 'ALBERTSONS'
        WHEN STARTS_WITH(cust.customer_name_1_desc, 'AMAZON') THEN 'AMAZON'
        WHEN STARTS_WITH(cust.customer_name_1_desc, 'ASDA') THEN 'ASDA'
        WHEN STARTS_WITH(cust.customer_name_1_desc, 'ASSOCIATED FOODS') THEN 'ASSOCIATED FOODS'
        WHEN STARTS_WITH(cust.customer_name_1_desc, 'CHEWY') THEN 'CHEWY'
        WHEN STARTS_WITH(cust.customer_name_1_desc, 'COLES') THEN 'COLES'
        WHEN STARTS_WITH(cust.customer_name_1_desc, 'CORNERSHOP') THEN 'CORNERSHOP'
        WHEN STARTS_WITH(cust.customer_name_1_desc, 'COSTCO') THEN 'COSTCO'
        WHEN STARTS_WITH(cust.customer_name_1_desc, 'HARRIS TEETER') THEN 'HARRIS TEETER'
        WHEN STARTS_WITH(cust.customer_name_1_desc, 'INSTACART') THEN 'INSTACART'
        WHEN STARTS_WITH(cust.customer_name_1_desc, 'KROGER') THEN 'KROGER'
        WHEN STARTS_WITH(cust.customer_name_1_desc, 'LOBLAWS') THEN 'LOBLAWS'
        WHEN STARTS_WITH(cust.customer_name_1_desc, 'MEIJER') THEN 'MEIJER'
        WHEN STARTS_WITH(cust.customer_name_1_desc, 'OCADO') THEN 'OCADO'
        WHEN STARTS_WITH(cust.customer_name_1_desc, 'PEAPOD') THEN 'PEAPOD'
        WHEN STARTS_WITH(cust.customer_name_1_desc, 'PETCO') THEN 'PETCO'
        WHEN STARTS_WITH(cust.customer_name_1_desc, 'PETSMART') THEN 'PETSMART'
        WHEN STARTS_WITH(cust.customer_name_1_desc, 'PUBLIX') THEN 'PUBLIX'
        WHEN STARTS_WITH(cust.customer_name_1_desc, 'SAINSBURY') THEN 'SAINSBURY'
        WHEN STARTS_WITH(cust.customer_name_1_desc, 'SAMS') THEN 'SAMS'
        WHEN STARTS_WITH(cust.customer_name_1_desc, 'SHIPT') THEN 'SHIPT'
        WHEN STARTS_WITH(cust.customer_name_1_desc, 'SHOPRITE') THEN 'SHOPRITE'
        WHEN STARTS_WITH(cust.customer_name_1_desc, 'SOBEYS') THEN 'SOBEYS'
        WHEN STARTS_WITH(cust.customer_name_1_desc, 'TARGET') THEN 'TARGET'
        WHEN STARTS_WITH(cust.customer_name_1_desc, 'TESCO') THEN 'TESCO'
        WHEN STARTS_WITH(cust.customer_name_1_desc, 'WAITROSE') THEN 'WAITROSE'
        WHEN STARTS_WITH(cust.customer_name_1_desc, 'WAL MART') THEN 'WALMART'
        WHEN STARTS_WITH(cust.customer_name_1_desc, 'WALMART') THEN 'WALMART'
        WHEN STARTS_WITH(cust.customer_name_1_desc, 'WAL-MART') THEN 'WALMART'
        WHEN STARTS_WITH(cust.customer_name_1_desc, 'WOOLWORTHS') THEN 'WOOLWORTHS'
        WHEN STARTS_WITH(cust.customer_name_1_desc, 'LIDL') THEN 'LIDL'
    ELSE
        CONCAT(cust.customer_name_1_desc, ' ***')
    END AS customer_parent,
    cust_mat.sales_organization_cd,
    cust_mat.sales_organization_desc,
    cust_mat.distribution_channel_cd,
    cust_mat.distribution_channel_desc,
    cust_mat.material_cd,
    shipped.customer_cd AS shippedto_customer,
    IF(shipped.customer_cd IS NOT NULL, TRUE, FALSE) AS ecomm_shipped_flg,   
    shipped.material_cd AS shipped_material,
    shipped.uom_cd AS shipped_uom_cd
    FROM
    `edw-prd-e567f9.enterprise.dim_company_code` comp_codes
    JOIN `edw-prd-e567f9.enterprise.dim_customer_company_code` cust_comp_codes ON
        (comp_codes.source_type_cd = cust_comp_codes.source_type_cd AND comp_codes.company_cd = cust_comp_codes.company_cd)
    JOIN `edw-prd-e567f9.enterprise.dim_customer` cust ON  (cust_comp_codes.language_cd = cust.language_cd AND cust_comp_codes.customer_cd = cust.customer_cd)
    JOIN `edw-prd-e567f9.enterprise.dim_customer_material` cust_mat ON (cust_mat.customer_cd = cust.customer_cd AND cust_mat.language_cd = cust.language_cd)
    LEFT JOIN
    (SELECT 
        x.customer_cd, 
        x.material_cd, 
        x.uom_cd,
        CASE x.source_system_cd
            WHEN 'IE' THEN 'INTL'
            WHEN 'ER' THEN 'NA'
        END AS source_type_cd
        FROM `edw-prd-e567f9.finance.gf_volume_by_scenario` x
        
        WHERE 
        x.scenario = 'ACT'
        AND x.fiscal_year_nbr IN (SELECT fiscal_year_nbr FROM fiscal_years)
    ) shipped ON 
    (cust_mat.source_type_cd = shipped.source_type_cd 
    AND cust_mat.customer_cd = shipped.customer_cd 
    AND cust_mat.material_cd = shipped.material_cd)
WHERE
cust_mat.language_cd = 'EN'
GROUP BY 
    comp_codes.source_type_cd,
    cust.customer_cd,
    cust.customer_name_1_desc,
    cust.customer_hier_corporate_parent_desc,
    cust_mat.sales_organization_cd,
    cust_mat.sales_organization_desc,
    cust_mat.distribution_channel_cd,
    cust_mat.distribution_channel_desc,
    cust_mat.material_cd,
    shipped.customer_cd,
    shipped.material_cd,
    shipped.uom_cd
),
updated_rpcs as (
    SELECT 
        o.customer_parent,
        o.material_cd,
        o.customer_product_cd AS latest_customer_product_cd,
        o.create_dt AS latest_customer_product_cd_dt,
    FROM (
        SELECT 
        x.customer_parent,
        x.material_cd,
        x.customer_product_cd,
        x.create_dt,
        ROW_NUMBER() OVER (PARTITION BY x.customer_parent, material_cd ORDER BY priority, create_dt DESC) row_number
        FROM
        (
            SELECT 
            cd.customer_parent,
            h.kunnr AS customer_cd,
            d.matnr AS material_cd, 
            d.kdmat AS customer_product_cd,
            CAST(d.erdat AS DATE) as create_dt,
            CASE WHEN d.kdmat IS NULL THEN 1 ELSE 0 END AS priority,      
            FROM `edw-ods-prd-ba33c3.sap_ods.er_vbak` h JOIN `edw-ods-prd-ba33c3.sap_ods.er_vbap` d on h.vbeln = d.vbeln
            JOIN customer_detail cd ON h.kunnr = cd.customer_cd AND d.matnr = cd.material_cd
            WHERE CAST(h.erdat AS DATE) > DATE_SUB(CURRENT_DATE(), INTERVAL 6 MONTH)        
            GROUP BY 
            cd.customer_parent,
            h.kunnr,
            d.matnr,
            d.kdmat,
            d.erdat
        ) x
    ) o 
    
    WHERE  row_number = 1
    GROUP BY 
        o.customer_parent,
        o.material_cd,
        o.customer_product_cd,
        o.create_dt
)

SELECT distinct result.*,
r.latest_customer_product_cd,
r.latest_customer_product_cd_dt
FROM (
SELECT  
    ABS(FARM_FINGERPRINT(cd.customer_parent)) AS customer_parent_key,
    m.*,    
    cd.* EXCEPT (source_type_cd, material_cd),
    sm.* EXCEPT (source_type_cd, sales_organization_cd, distribution_channel_cd, material_cd, customer_cd, material_type_cd, ean_upc_cd, current_flg),
    
FROM customer_detail cd
JOIN sold_materials sm ON
( 
    cd.source_type_cd = sm.source_type_cd
    AND cd.sales_organization_cd = sm.sales_organization_cd
    AND cd.distribution_channel_cd = sm.distribution_channel_cd
    AND sm.customer_cd = cd.customer_cd 
    AND sm.parent_material_cd = cd.material_cd
)
JOIN distinct_materials m ON 
(
    sm.material_cd = m.material_cd 
    AND sm.source_type_cd = m.source_type_cd 
    AND sm.current_flg = m.current_flg
)
) result
LEFT JOIN updated_rpcs r on  result.customer_parent = r.customer_parent and result.parent_material_cd = r.material_cd
  