DECLARE VALID_CUSTOMERS ARRAY<STRING>;
DECLARE AGG_COLUMNS , INNER_AGG_COLUMNS STRING;

CREATE OR REPLACE TABLE `{{params.ECOMM_DLF}}`.processed.temp_product_content_extract AS (



SELECT * from (



SELECT
  x.brand_cd, x.brand_desc,
  CASE WHEN pc.catalog_type = 'CORE' OR (pc.catalog_type is null and x.customer_parent = 'AMAZON') THEN 'AMAZON_COM' 
       WHEN pc.catalog_type = 'FRESH' THEN 'AMAZON_FRESH'
       ELSE x.customer_parent END as  customer_parent,
  CONCAT("'",x.material_cd, "'") material_cd,
  CONCAT("'",x.ean_13_digit_retail_upc, "'") ean_13_digit_retail_upc,
  CASE WHEN upper(x.customer_parent) = 'AMAZON' THEN NULL ELSE x.latest_customer_product_cd END as latest_customer_product_cd,
  '' as chain_nm,
  CASE WHEN upper(x.customer_parent) = 'KROGER' then x.gtin_cd
       WHEN upper(x.customer_parent) = 'AMAZON' THEN pc.retailer_online_cd 
       ELSE x.online_item_derived_item_cd END AS online_item_derived_item_cd,
  x.material_short_desc,
  x.pim_title AS retailer_text,
  CASE WHEN x.net_weight_uom_qty > 0 THEN CONCAT(x.net_weight_uom_qty, ' ', x.weight_uom_cd) ELSE NULL END AS size
FROM
  `edw-prd-e567f9.ecomm.ecomm_common_product_catalog` x
LEFT OUTER JOIN 
(

SELECT

  x.upc,
  x.catalog_type,
  x.retailer_online_cd,
  x.retailer

FROM

  `edw-prd-e567f9.ecomm.ecomm_retailer_online_product_codes` x

WHERE

  LOWER(x.retailer) = 'amazon'
  AND x.is_active = TRUE

GROUP BY
  x.upc,
  x.catalog_type,
  x.retailer_online_cd,
  x.retailer

) pc


on safe_cast(pc.upc as INT64) = safe_cast(x.ean_13_digit_retail_upc as INT64)
and upper(pc.retailer) = upper(x.customer_parent)

WHERE (x.customer_parent IN ('AMAZON', 'TARGET', 'WALMART', 'KROGER', 'ADUSA', 'MEIJER', 'SHIPT')) 
  AND x.material_type_cd = 'CNPK'
  AND x.current_flg = TRUE
GROUP BY
      x.brand_cd, x.brand_desc,
      CASE WHEN pc.catalog_type = 'CORE' OR (pc.catalog_type is null and x.customer_parent = 'AMAZON') THEN 'AMAZON_COM' 
       WHEN pc.catalog_type = 'FRESH' THEN 'AMAZON_FRESH'
       ELSE x.customer_parent END,
  x.material_cd,
  x.ean_13_digit_retail_upc,
  CASE WHEN upper(x.customer_parent) = 'AMAZON' THEN NULL ELSE x.latest_customer_product_cd END,
  CASE WHEN upper(x.customer_parent) = 'KROGER' then x.gtin_cd
       WHEN upper(x.customer_parent) = 'AMAZON' THEN pc.retailer_online_cd 
       ELSE x.online_item_derived_item_cd END ,
  
  x.material_short_desc,
  x.pim_title,
  x.net_weight_uom_qty,
  weight_uom_cd

UNION ALL

SELECT
  x.brand_cd, x.brand_desc,
  upper(pc.retailer) as  customer_parent,
  CONCAT("'",x.material_cd, "'") material_cd,
  CONCAT("'",x.ean_13_digit_retail_upc, "'") ean_13_digit_retail_upc,
  pc.retailer_online_cd as latest_customer_product_cd,
  '' as chain_nm,
  pc.retailer_online_cd  AS online_item_derived_item_cd,
  x.material_short_desc,
  pc.product_title AS retailer_text,
  CASE WHEN x.net_weight_uom_qty > 0 THEN CONCAT(x.net_weight_uom_qty, ' ', x.weight_uom_cd) ELSE NULL END AS size,
FROM
( SELECT DISTINCT brand_cd, brand_desc, material_cd, gtin_cd, material_short_desc, ean_13_digit_retail_upc, customer_parent, material_type_cd, current_flg, online_item_derived_item_cd, net_weight_uom_qty, weight_uom_cd FROM  `edw-prd-e567f9.ecomm.ecomm_common_product_catalog`  ) x
Inner JOIN 
(

SELECT

  x.upc,
  x.catalog_type,
  x.retailer_online_cd,
  x.retailer,
  x.product_title

FROM

  `edw-prd-e567f9.ecomm.ecomm_retailer_online_product_codes` x

WHERE

  LOWER(x.retailer) = 'instacart'

GROUP BY
  x.upc,
  x.catalog_type,
  x.retailer_online_cd,
  x.retailer,
  x.product_title

) pc
on safe_cast(pc.upc as INT64) = safe_cast(x.ean_13_digit_retail_upc as INT64)


WHERE x.material_type_cd = 'CNPK'
  AND x.current_flg = TRUE
GROUP BY
      x.brand_cd, x.brand_desc,
      pc.retailer,
  x.material_cd,
  x.ean_13_digit_retail_upc,
  pc.retailer_online_cd,  
  x.material_short_desc,
  pc.product_title ,
  x.net_weight_uom_qty,
  weight_uom_cd




) x


);


SET VALID_CUSTOMERS = (SELECT ARRAY_AGG(DISTINCT lower(customer_parent)) as customers from `{{params.ECOMM_DLF}}`.processed.temp_product_content_extract);

SET AGG_COLUMNS = "brand_cd, brand_desc,material_cd,upc, default_text, size, ";

SET INNER_AGG_COLUMNS = "COALESCE(brand_cd,'') as brand_cd, COALESCE(brand_desc,'') as brand_desc, COALESCE(material_cd,'') as material_cd,COALESCE(ean_13_digit_retail_upc,'') as upc,COALESCE(material_short_desc,'') as  default_text, size,";

FOR cust in (SELECT lower(cust) as cust FROM UNNEST(VALID_CUSTOMERS) as cust ORDER BY cust)
DO
SET AGG_COLUMNS = CONCAT(AGG_COLUMNS,"STRING_AGG( DISTINCT ",cust.cust,"_code) as ",cust.cust,"_code, ");
SET AGG_COLUMNS = CONCAT(AGG_COLUMNS,"STRING_AGG( DISTINCT ",cust.cust,"_onlinestorecode) as ",cust.cust,"_onlinestorecode, ");
SET AGG_COLUMNS = CONCAT(AGG_COLUMNS,"STRING_AGG( DISTINCT ",cust.cust,"_chain) as ",cust.cust,"_chain, ");
SET AGG_COLUMNS = CONCAT(AGG_COLUMNS,"STRING_AGG( DISTINCT ",cust.cust,"_text) as ",cust.cust,"_text, ");
SET INNER_AGG_COLUMNS = CONCAT(INNER_AGG_COLUMNS,'CASE WHEN lower(customer_parent) = "',cust.cust,'" THEN latest_customer_product_cd ELSE NULL END AS ', cust.cust, "_code, ");
SET INNER_AGG_COLUMNS = CONCAT(INNER_AGG_COLUMNS,'CASE WHEN lower(customer_parent) = "',cust.cust,'" THEN online_item_derived_item_cd ELSE NULL END AS ', cust.cust, "_onlinestorecode, ");
SET INNER_AGG_COLUMNS = CONCAT(INNER_AGG_COLUMNS,'CASE WHEN lower(customer_parent) = "',cust.cust,'" THEN chain_nm ELSE NULL END AS ', cust.cust, "_chain, ");
SET INNER_AGG_COLUMNS = CONCAT(INNER_AGG_COLUMNS,'CASE WHEN lower(customer_parent) = "',cust.cust,'" THEN retailer_text ELSE NULL END AS ', cust.cust, "_text, ");
END FOR;




EXECUTE IMMEDIATE FORMAT("""
CREATE OR REPLACE TABLE `{{params.ECOMM_DLF}}`.processed.profitero_product_catalog_export AS
SELECT %s,
FROM 
(
SELECT %s
from `{{params.ECOMM_DLF}}`.processed.temp_product_content_extract
group by 
      brand_cd, 
      brand_desc,
      material_cd, 
      ean_13_digit_retail_upc,
      customer_parent,
      material_short_desc,
      chain_nm,
        online_item_derived_item_cd,
      retailer_text,
      latest_customer_product_cd,      
      size
)
group by brand_cd, brand_desc, material_cd,upc, default_text, size """,substr(AGG_COLUMNS,1,length(AGG_COLUMNS)-2),substr(INNER_AGG_COLUMNS,1,length(INNER_AGG_COLUMNS)-2)) ;
