CREATE OR REPLACE PROCEDURE transient.ecomm_sproc_refresh_product_catalog_v4 (
    GET_YEAR_DIFF INT64
)
OPTIONS(
    description = """
        How to Call
            CALL transient.ecomm_sproc_refresh_product_catalog_v2 (
                1 -- GET_YEAR_DIFF
            )
    """
)
BEGIN

DECLARE FISCAL_DATES        STRUCT
                                  <
                                    START_FY_WEEK_NBR INT64,
                                    START_FISCAL_WEEK_BEGINT_DT DATE,
                                    END_FY_WEEK_NBR INT64,
                                    END_FISCAL_WEEK_BEGIN_DT DATE
                                  >;

DECLARE FISCAL_YEAR_NBR             ARRAY<INT64>;

DECLARE SOURCE_TYPE_CD              DEFAULT ['NA'];
DECLARE LANGUAGE_CD                 DEFAULT ['EN'];
DECLARE MATERIAL_STATUS_CD          DEFAULT ['A','I','D','N'];
DECLARE MATERIAL_TYPE_CD            DEFAULT ['HAWA','FINI','CNPK','FERT','NPD'];
DECLARE IS_CONVERSION_ITEMS         DEFAULT ['RSZCONV'];
DECLARE URL_CUSTOMERS               DEFAULT ['KROGER'];

DECLARE CUSTOMER_PARENT_TBL         DEFAULT "_SESSION.ecomm_pipeline_computed_customer_parent";
DECLARE SAP_ORDER_TBL               DEFAULT "_SESSION.ecomm_pipeline_sap_orders";
DECLARE PRODUCT_CATALOG_TEMP_TBL    DEFAULT "_SESSION.ecomm_pipeline_product_catalog_temp";
DECLARE PRODUCT_CATALOG_TBL         DEFAULT "processed.ecomm_product_catalog_v4";

SET FISCAL_DATES = (SELECT transient.calculate_fiscal_year_interval(GET_YEAR_DIFF));

EXECUTE IMMEDIATE CONCAT("""
    CREATE TEMP TABLE """,CUSTOMER_PARENT_TBL,""" AS (
        WITH CTE AS (
            SELECT
                DISTINCT comp_codes.source_type_cd,
                cust.language_cd,
                cust.customer_cd,
                cust.customer_name_1_desc AS customer_name,
                cust.customer_hier_corporate_parent_desc AS parent_account,
                CASE
                  WHEN STARTS_WITH(cust.customer_name_1_desc, 'ALBERTSONS') THEN 'ALBERTSONS'
                  WHEN STARTS_WITH(cust.customer_name_1_desc, 'AMAZON') THEN 'AMAZON'
                  WHEN STARTS_WITH(cust.customer_name_1_desc, 'ASDA') THEN 'ASDA'
                  WHEN STARTS_WITH(cust.customer_name_1_desc, 'ASSOCIATED FOODS') THEN 'ASSOCIATED FOODS'
                  WHEN STARTS_WITH(cust.customer_name_1_desc, 'CHEWY') THEN 'CHEWY'
                  WHEN STARTS_WITH(cust.customer_name_1_desc, 'COLES') THEN 'COLES'
                  WHEN STARTS_WITH(cust.customer_name_1_desc, 'CORNERSHOP') THEN 'CORNERSHOP'
                  WHEN STARTS_WITH(cust.customer_name_1_desc, 'COSTCO') THEN 'COSTCO'
                  WHEN STARTS_WITH(cust.customer_name_1_desc, 'HARRIS TEETER') THEN 'HARRIS TEETER'
                  WHEN STARTS_WITH(cust.customer_name_1_desc, 'INSTACART') THEN 'INSTACART'
                  WHEN STARTS_WITH(cust.customer_name_1_desc, 'KROGER') THEN 'KROGER'
                  WHEN STARTS_WITH(cust.customer_name_1_desc, 'LOBLAWS') THEN 'LOBLAWS'
                  WHEN STARTS_WITH(cust.customer_name_1_desc, 'MEIJER') THEN 'MEIJER'
                  WHEN STARTS_WITH(cust.customer_name_1_desc, 'OCADO') THEN 'OCADO'
                  WHEN STARTS_WITH(cust.customer_name_1_desc, 'PEAPOD') THEN 'PEAPOD'
                  WHEN STARTS_WITH(cust.customer_name_1_desc, 'PETCO') THEN 'PETCO'
                  WHEN STARTS_WITH(cust.customer_name_1_desc, 'PETSMART') THEN 'PETSMART'
                  WHEN STARTS_WITH(cust.customer_name_1_desc, 'PUBLIX') THEN 'PUBLIX'
                  WHEN STARTS_WITH(cust.customer_name_1_desc, 'SAINSBURY') THEN 'SAINSBURY'
                  WHEN STARTS_WITH(cust.customer_name_1_desc, 'SAMS') THEN 'SAMS'
                  WHEN STARTS_WITH(cust.customer_name_1_desc, 'SHIPT') THEN 'SHIPT'
                  WHEN STARTS_WITH(cust.customer_name_1_desc, 'SHOPRITE') THEN 'SHOPRITE'
                  WHEN STARTS_WITH(cust.customer_name_1_desc, 'SOBEYS') THEN 'SOBEYS'
                  WHEN STARTS_WITH(cust.customer_name_1_desc, 'TARGET') THEN 'TARGET'
                  WHEN STARTS_WITH(cust.customer_name_1_desc, 'TESCO') THEN 'TESCO'
                  WHEN STARTS_WITH(cust.customer_name_1_desc, 'WAITROSE') THEN 'WAITROSE'
                  WHEN STARTS_WITH(cust.customer_name_1_desc, 'WAL MART') THEN 'WALMART'
                  WHEN STARTS_WITH(cust.customer_name_1_desc, 'WALMART') THEN 'WALMART'
                  WHEN STARTS_WITH(cust.customer_name_1_desc, 'WAL-MART') THEN 'WALMART'
                  WHEN STARTS_WITH(cust.customer_name_1_desc, 'WOOLWORTHS') THEN 'WOOLWORTHS'
                  WHEN STARTS_WITH(cust.customer_name_1_desc, 'LIDL') THEN 'LIDL'
                ELSE
                CONCAT(cust.customer_name_1_desc, ' ***')
              END
                AS customer_parent
            FROM
              `edw-prd-e567f9.enterprise.dim_customer` cust
            JOIN
              `edw-prd-e567f9.enterprise.dim_customer_company_code` cust_comp_codes
            ON
              (cust_comp_codes.language_cd = cust.language_cd
                AND cust_comp_codes.customer_cd = cust.customer_cd)
            JOIN
              `edw-prd-e567f9.enterprise.dim_company_code` comp_codes
            ON
              (comp_codes.source_type_cd = cust_comp_codes.source_type_cd
                AND comp_codes.company_cd = cust_comp_codes.company_cd)
        )
        SELECT *,
            IF(TRIM(customer_parent) like '%***','ENTERPRISE',customer_parent) as data_parent,
            CASE
                WHEN UPPER(customer_parent) = 'WALMART' THEN 'https://www.walmart.com/ip/'
                WHEN UPPER(customer_parent) = 'TARGET' THEN 'https://www.target.com/p/-/A-'
                WHEN UPPER(customer_parent) = 'INSTACART' THEN 'https://www.instacart.com/store/products/'
                WHEN UPPER(customer_parent) = 'KROGER' THEN 'https://www.kroger.com/p/product/'
                WHEN UPPER(customer_parent) = 'AMAZON' THEN 'https://www.amazon.com/dp/'
            ELSE '' END AS url
        FROM CTE
    )
""");

EXECUTE IMMEDIATE CONCAT("""
    CREATE TEMP TABLE """,SAP_ORDER_TBL,""" AS (
        SELECT
            DISTINCT
            cp.customer_parent,
            h.vbeln AS sales_document,
            h.erdat AS sap_order_created_dt,
            h.audat AS sap_order_dt,
            h.vkorg AS sales_organization_cd,
            h.vtweg AS distribution_channel_cd,
            h.spart AS division_cd,
            h.vdatu AS requested_delivery_dt,
            h.bstnk AS customer_po_nbr,
            h.kunnr AS customer_cd,
            d.matnr AS material_cd,
            d.matwa AS material_entered,
            d.matkl AS material_group,
            d.zieme AS target_quantity_uom,
            d.meins AS base_uom,
            d.kdmat AS customer_product_cd,
            d.ean11,
           -- d.abgru AS order_item_rejection_reason_cd,
           -- IF(LENGTH(TRIM(d.abgru)) > 0, TRUE, FALSE) order_item_rejected_flg
        FROM `edw-ods-prd-ba33c3.sap_ods.er_vbak` h
        JOIN `edw-ods-prd-ba33c3.sap_ods.er_vbap` d on h.vbeln = d.vbeln
        JOIN """,CUSTOMER_PARENT_TBL,""" cp on h.kunnr = cp.customer_cd
        WHERE CAST(h.erdat AS DATE) >= CAST('""",FISCAL_DATES.START_FISCAL_WEEK_BEGINT_DT,"""' AS DATE) -- ORDER_DATE
        ORDER BY CAST(h.erdat AS DATE) DESC
    )
""");



EXECUTE IMMEDIATE CONCAT("""
    CREATE TEMP TABLE """,PRODUCT_CATALOG_TEMP_TBL,""" AS (
        WITH fiscal_years AS (
            SELECT
                CAST(FLOOR(""",FISCAL_DATES.START_FY_WEEK_NBR,"""/100) AS INT64) as fiscal_year_nbr
            UNION DISTINCT
            SELECT
                CAST(FLOOR(""",FISCAL_DATES.END_FY_WEEK_NBR,"""/100) AS INT64)
        ),
        available_upcs AS (
        SELECT m.* EXCEPT(ipp_start_dt,ipp_end_dt, is_fini_flg),
            IF(m.ipp_start_dt is null ,LAG(m.ipp_start_dt,1,null) OVER (PARTITION BY m.parent_material_cd ORDER by m.is_fini_flg desc), m.ipp_start_dt) as ipp_start_dt,
            IF(m.ipp_end_dt is null ,LAG(m.ipp_end_dt,1,null) OVER (PARTITION BY m.parent_material_cd ORDER by m.is_fini_flg desc), m.ipp_end_dt) as ipp_end_dt,
            pim.consumer_product_name_txt as pim_title,
            pim.product_version_id,
            pim.gtin_cd as pim_gtin_cd
          FROM
            (
                SELECT
                  DISTINCT
                      m.source_type_cd,
                      m.material_type_cd,
                      uom.material_cd AS parent_material_cd,
                      m.material_cd,
                      m.material_nbr,
                      m.current_flg,
                      m.material_status_cd,
                      m.material_status_desc,
                      m.ean_category_cd,
                      m.ci_launch_type_cd,
                      m.ci_launch_type_desc,
                      IF(m.ci_launch_type_cd IN ('""",ARRAY_TO_STRING(IS_CONVERSION_ITEMS,"','"),"""'),TRUE,FALSE) as is_conversion_flg,
                      m.product_in_out_seasonal_flg,
                      m.special_pack_sales_seasonal_flg,
                      m.base_product_cd,
                      m.base_product_nbr,
                      m.base_product_desc,
                      m.conversion_base_product_cd,
                      m.base_product_cd AS material_base_product_cd,
                      m.base_product_ean_upc_cd,
                      m.base_uom_to_eqc_fctr,
                      m.base_uom_to_ecv_fctr,
                      m.gmi_division_cd,
                      m.gmi_division_desc,
                      IF(UPPER(m.gmi_division_desc) like '%DIVESTED%' OR UPPER(m.gmi_division_desc) like '%DVST%',True,False) as is_divested_fg,
                      m.ean_upc_cd,
                      m.ean_upc_derived_cd,
                      m.upc_package_prefix_cd,
                      m.start_ship_dt AS ipp_start_dt,
                      m.size_dimension_txt,
                      m.material_short_desc,
                      m.sls_hier_sub_category_desc,
                      m.sls_hier_category_desc,
                      m.sls_hier_division_desc,
                      m.sls_hier_accrual_group_cd,
                      m.sls_hier_ppg_cd,
                      m.sls_hier_accrual_group_desc,
                      m.sls_hier_ppg_desc,
                      m.sls_hier_sub_category_cd,
                      m.sls_hier_category_cd,
                      m.sls_hier_division_cd,
                      m.bph1_hier_bph10_desc,
                      m.bph1_hier_bph20_desc,
                      m.bph1_hier_bph30_desc,
                      m.bph1_hier_bph40_desc,
                      m.bph1_hier_bph50_desc,
                      m.bph1_hier_bph60_desc,
                      m.bph1_hier_bph70_desc,
                      m.gph_hier_top_cd,
                      m.gph_hier_family_cd,
                      m.gph_hier_category_cd,
                      m.gph_hier_flavor_format_cd,
                      m.gph_hier_package_size_cd,
                      m.gph_hier_top_desc,
                      m.gph_hier_family_desc,
                      m.gph_hier_category_desc,
                      m.gph_hier_flavor_format_desc,
                      m.gph_hier_package_size_desc,
                      m.gross_weight_uom_qty,
                      m.net_weight_uom_qty,
                      m.weight_uom_cd,
                      m.brand_cd,
                      m.brand_desc,
                      m.sub_brand_desc,
                      m.language_cd,
                      IF(m.ean_category_cd IN ('UP'),m.ean_upc_derived_cd, NULL) AS ean_13_digit_retail_upc, -- ADD INTL when available
                      IF
                          (SAFE_CAST(m.start_ship_dt AS DATE) IS NOT NULL AND EXTRACT(YEAR FROM m.start_ship_dt) < 9999,
                              DATE_ADD(m.start_ship_dt, INTERVAL 83 DAY),
                              NULL
                          ) AS ipp_end_dt,
                      IF(m.material_type_cd = 'FINI', True, False) as is_fini_flg,
                      m.mdm_national_last_ship_dt,
                      m.base_product_ean_upc_derived_cd,
                      m.sls_hier_sub_accrual_desc,
                      m.consumer_brand_desc,
                      m.global_trade_item_nbr as gtin_cd
                FROM `edw-prd-e567f9`.enterprise.dim_material m
                JOIN `edw-prd-e567f9`.enterprise.dim_product_material_uom uom
                  ON
                          m.ean_upc_cd         = uom.ean_upc_cd
                      AND m.source_type_cd     = uom.source_type_cd
                      AND m.current_flg        = uom.current_flg
                WHERE
                      m.current_flg       = TRUE
                  AND uom.current_flg     = TRUE
                  AND uom.ean_upc_cd IS NOT NULL
                  AND m.source_type_cd            IN ('""",ARRAY_TO_STRING(SOURCE_TYPE_CD,"','"),"""')
                  AND m.language_cd               IN ('""",ARRAY_TO_STRING(LANGUAGE_CD,"','"),"""')
                  AND UPPER(m.material_status_cd) IN ('""",ARRAY_TO_STRING(MATERIAL_STATUS_CD,"','"),"""')
                  AND UPPER(m.material_type_cd)   IN ('""",ARRAY_TO_STRING(MATERIAL_TYPE_CD,"','"),"""')
                QUALIFY ROW_NUMBER() OVER
                                          (
                                             PARTITION BY
                                                        m.material_cd,
                                                        uom.material_cd,
                                                        m.current_flg,
                                                        m.ean_upc_derived_cd,
                                                        m.material_type_cd,
                                                        uom.alternative_uom_cd,
                                                        uom.conversion_numerator_qty,
                                                        uom.conversion_denominator_qty,
                                                        uom.ean_category_cd,uom.source_type_cd,
                                                        uom.ean_upc_cd,m.language_cd
                                          ) = 1
            )m
            LEFT JOIN `edw-prd-e567f9.pic.dim_pim_product_all_retailers` pim ON m.material_nbr=CAST(pim.material_nbr AS STRING)
                                                                                AND UPPER(pim.retailer) = 'ENTERPRISE'
        )
      SELECT
        DISTINCT
            m.* EXCEPT(pim_title,product_version_id,pim_gtin_cd),
            IF(pim.retailer is null,m.pim_title,pim.consumer_product_name_txt) as pim_title,
            cust.* EXCEPT (source_type_cd, language_cd),
            cust_mat.sales_organization_cd,
            cust_mat.sales_organization_desc,
            cust_mat.distribution_channel_cd,
            cust_mat.distribution_channel_desc,
            shipped.customer_cd AS shippedto_customer,
            IF (shipped.customer_cd IS NOT NULL, TRUE, FALSE) AS ecomm_shipped_flg,
            shipped.material_cd AS shipped_material,
            shipped.uom_cd AS shipped_uom_cd,
            CASE
	               WHEN current_date() BETWEEN DATE(ipp_start_dt) AND DATE(ipp_end_dt)
                        THEN TRUE
	               WHEN DATE(ipp_start_dt) BETWEEN DATE_TRUNC(current_date(), WEEK(MONDAY))
	                                           AND DATE_TRUNC(DATE_ADD(current_date() , INTERVAL 1 WEEK), WEEK(SUNDAY))
					    THEN TRUE
	                WHEN DATE(ipp_end_dt) BETWEEN DATE_TRUNC(current_date(), WEEK(MONDAY))
                                AND DATE_TRUNC(DATE_ADD(current_date() , INTERVAL 1 WEEK), WEEK(SUNDAY))
					    THEN TRUE
                    ELSE FALSE
            END AS is_new_prod_for_curr_week_flg,
            COALESCE(m.product_version_id,pim.product_version_id) as product_version_id,
            COALESCE(m.pim_gtin_cd,pim.gtin_cd) as pim_gtin_cd
      FROM
        available_upcs m
      JOIN
        `edw-prd-e567f9.enterprise.dim_customer_material` cust_mat
      ON
        (cust_mat.material_cd = m.parent_material_cd
          AND cust_mat.language_cd = m.language_cd
          AND m.source_type_cd = cust_mat.source_type_cd)
      JOIN
        """,CUSTOMER_PARENT_TBL,""" cust
      ON
        (cust_mat.language_cd = cust.language_cd AND cust_mat.customer_cd = cust.customer_cd)
      LEFT JOIN `edw-prd-e567f9.pic.dim_pim_product_all_retailers` pim
        ON  m.material_nbr             =   CAST(pim.material_nbr AS STRING)
        AND UPPER(pim.retailer)        =   UPPER(cust.customer_parent)
      LEFT JOIN
        (
            SELECT
              x.customer_cd,
              x.material_cd,
              x.uom_cd,
              CASE x.source_system_cd
                WHEN 'IE' THEN 'INTL'
                WHEN 'ER' THEN 'NA'
              END AS source_type_cd
            FROM
              `shareddata-prd-cb5872.shared_data_finance.gf_volume_by_scenario` x
            WHERE
              x.scenario = 'ACT'
              AND x.fiscal_year_nbr IN
                                      (
                                            SELECT
                                              fiscal_year_nbr
                                            FROM
                                              fiscal_years
                                       )
        ) shipped
            ON
                cust_mat.source_type_cd = shipped.source_type_cd
                AND cust_mat.customer_cd = shipped.customer_cd
                AND cust_mat.material_cd = shipped.material_cd
    )
""");

EXECUTE IMMEDIATE CONCAT("""
    CREATE OR REPLACE TABLE """,PRODUCT_CATALOG_TBL,""" AS (
        with latest_sap_orders as (
           SELECT
        		sap_orders.*
           FROM """,SAP_ORDER_TBL,""" sap_orders
           QUALIFY ROW_NUMBER() OVER (PARTITION BY customer_parent, material_cd ORDER BY sap_order_created_dt DESC) = 1
        ),
        latest_sap_rpcs as (
        	SELECT
        		sap_orders.customer_parent,
        		sap_orders.material_cd,
        		sap_orders.customer_product_cd AS latest_customer_product_cd,
        		sap_orders.sap_order_created_dt AS latest_customer_product_cd_dt
        	FROM """,SAP_ORDER_TBL,""" sap_orders
        	WHERE customer_product_cd IS NOT NULL
        	QUALIFY ROW_NUMBER() OVER (PARTITION BY customer_parent, material_cd ORDER BY sap_order_created_dt DESC) = 1
        ),
        product_catalog as (
            SELECT
                DISTINCT
                ABS(FARM_FINGERPRINT(mat.customer_parent)) AS customer_parent_key,
                mat.*,
                orders.* EXCEPT(customer_parent, customer_cd, sales_organization_cd, distribution_channel_cd, material_cd),
                rpcs.* EXCEPT(customer_parent, material_cd)
            FROM """,PRODUCT_CATALOG_TEMP_TBL,""" mat -- May need to revert joins to customer_cd instead of customer_parent
            LEFT JOIN latest_sap_orders orders ON mat.parent_material_cd = orders.material_cd and mat.customer_parent = orders.customer_parent
            LEFT JOIN latest_sap_rpcs rpcs ON mat.parent_material_cd = rpcs.material_cd and mat.customer_parent = rpcs.customer_parent
        ),
        get_online_rpc as (
            SELECT
                SAFE_CAST(upc AS STRING) as upc,
                asin as online_cd,
                catalog_type,
                "AMAZON" as customer_parent
            FROM processed.lkp_amazon_fresh_catalog
                UNION DISTINCT
            SELECT
                SAFE_CAST(upc AS STRING) as upc,
                asin as online_cd,
                catalog_type,
                "AMAZON" as customer_parent
            FROM processed.lkp_amazon_core_catalog
                UNION DISTINCT
            SELECT
                SAFE_CAST(swcd.UPC_with_check_digit_cd as STRING) as upc,
                SAFE_CAST(swcd.wm_item_id as STRING) as online_cd,
                "ONLINE" as catalog_type,
                "WALMART" as customer_parent
            FROM `edw-prd-e567f9.srm.wm_catalog_dim` swcd
            WHERE SAFE_CAST(swcd.UPC_with_check_digit_cd as BIGINT) is not NULL
                UNION DISTINCT
            SELECT
                SAFE_CAST(primary_3991_barcode AS STRING) as upc,
                SAFE_CAST(tcin as STRING) as online_cd,
                catalog_type,
                "TARGET" as customer_parent
            FROM processed.lkp_target_catalog
        ),
        joined_product_codes AS (
            SELECT
              DISTINCT pc.customer_parent,
              pc.material_cd,
              pc.ean_13_digit_retail_upc,
              pc.ean_upc_cd,
              cte.online_cd,
              cte.catalog_type as online_item_catalog_type,
              COALESCE(online_cd, latest_customer_product_cd) AS online_item_derived_item_cd,
              IF(online_cd is not null, TRUE, FALSE) AS is_online_code_fg
            FROM
              product_catalog pc
            LEFT JOIN
              get_online_rpc cte
            ON
              CAST(CAST(pc.ean_upc_cd AS bigint)AS string) = CAST(SAFE_CAST(cte.upc AS bigint)AS string)
              AND UPPER(pc.customer_parent) = UPPER(cte.customer_parent)
            WHERE
              cte.catalog_type IS NOT NULL
              AND pc.material_type_cd = 'CNPK'
        ),
        product_assets AS (
            SELECT
              x.product_version_id,
              ARRAY_AGG( STRUCT( x.product_version_id AS product_version_id,
                  x.language_cd AS language_cd,
                  x.assetdesc AS description,
                  x.imagefileformat AS fileformat,
                  x.imageurl AS url ) ) assets_info
            FROM
              `edw-prd-e567f9.pic.dim_pim_assets` x
            WHERE
              x.imageurl IS NOT NULL
            GROUP BY
              product_version_id
        )
        SELECT
          pc.* EXCEPT(url),
          CASE WHEN UPPER(data_parent) IN ('KROGER') THEN CONCAT(url,gtin_cd)
               WHEN is_online_code_fg = TRUE AND url <> '' THEN CONCAT(url,online_item_derived_item_cd)
               WHEN is_online_code_fg = FALSE AND url <> '' THEN
                    IF(ecomm_shipped_flg = TRUE OR DATE(COALESCE(latest_customer_product_cd_dt,'1800-01-01')) < DATE_SUB(DATE(current_date()), INTERVAL 60 DAY), CONCAT(url, latest_customer_product_cd), '')
               ELSE ''
          END AS retailer_url,
          jpc.is_online_code_fg,
          online_item_derived_item_cd,
          online_item_catalog_type,
          pa.assets_info
        FROM
          product_catalog pc
        LEFT JOIN
          joined_product_codes jpc
        ON
          CAST(CAST(pc.ean_upc_cd AS bigint)AS string) = CAST(CAST(jpc.ean_13_digit_retail_upc AS bigint)AS string)
          AND UPPER(pc.customer_parent) = UPPER(jpc.customer_parent)
        LEFT JOIN
            product_assets pa on pa.product_version_id = pc.product_version_id
    )
""");

EXECUTE IMMEDIATE CONCAT("""
    ALTER TABLE """,PRODUCT_CATALOG_TBL,"""
        SET
            OPTIONS(
                  friendly_name="Ecomm product catalog table.",
                  description="This table is used as a catalog for all the products.",
                  labels=[("data_classification", "confidential_internal_2b"), ("rls", "rls-skip")]
                )
""");

END;