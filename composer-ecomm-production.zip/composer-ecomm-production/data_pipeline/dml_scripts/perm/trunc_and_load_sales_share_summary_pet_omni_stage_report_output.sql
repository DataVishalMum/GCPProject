/* Truncate exsting data           */
TRUNCATE TABLE  `{{params.ECOMM_ANALYTICS}}`.output.gss_sales_share_summary_pet_omni_report_stage ;

/* Create TEMPORARY function to customer customer_share_flag based on customer          */
CREATE TEMPORARY FUNCTION 	get_customer_share_flag(customer_name string) AS ((
  select
  CASE upper(customer_name)
	WHEN 'CHEWY_OMNI' THEN 'N'
	WHEN 'INSTACART_MODALITY' THEN 'N'
	WHEN 'PETSMART' THEN 'Y'
	WHEN 'WALMART_LUMINATE' THEN 'Y'
	WHEN 'PETCO_MODALITY' THEN 'Y'
	END
	AS customer_share_flag
));

/* Create TEMPORARY function to make modality column as generic    */
CREATE TEMPORARY FUNCTION 	get_modality_harmonized_name(modality string) AS ((
  select
  CASE upper(modality)
	WHEN 'NO AUTOSHIP' THEN 'Non-Subscription'
	WHEN 'AUTOSHIP' THEN 'Subscription'
	WHEN 'PICKUP' THEN 'Pickup'
	WHEN 'IN_STORE' THEN 'In Store'
	WHEN 'DELIVERY' THEN 'Non-Subscription'
	WHEN 'ONLINE' THEN 'Non-Subscription'
	WHEN 'ECOM' THEN 'Non-Subscription'
	WHEN 'STORE (PCC)' THEN 'In Store'
	WHEN 'PICK UP (NON-RD)' THEN 'Pickup'
	WHEN 'REPEAT DELIVERY (RD)' THEN 'Subscription'
	WHEN 'ONE TIME DELIVERY (OTD)' THEN 'Non-Subscription'
	ELSE upper(modality)
	END
	AS modality_harmonized
));

/*Insert reporting data into table */
insert into  `{{params.ECOMM_ANALYTICS}}`.output.gss_sales_share_summary_pet_omni_report_stage (
with summary_omni_report as (
select *from `{{params.ECOMM_ANALYTICS}}`.output.gss_sales_share_petsmart_pet_omni_report_stage UNION ALL
select *from `{{params.ECOMM_ANALYTICS}}`.output.gss_sales_share_chewy_pet_omni_report_stage UNION ALL
select *from `{{params.ECOMM_ANALYTICS}}`.output.gss_sales_share_walmart_luminate_pet_omni_report_stage UNION ALL
select *from `{{params.ECOMM_ANALYTICS}}`.output.gss_sales_share_instacart_pet_omni_report_stage

)
select
agg_fact_sk
,customer_name
,customer_parent
,customer_account
,get_customer_share_flag(customer_name) as customer_share_flag
,upc
,manufacturer
,fiscal_year
,fiscal_year_nbr
,fiscal_year_month_nbr
,fiscal_year_week_nbr
,fiscal_month_in_year_short_desc
,fiscal_month_number_short_desc
,fiscal_quarter_in_year_nbr
,fiscal_quarter_nbr
,fiscal_quarter_number_short_desc
,fiscal_week_begin_dt
,fiscal_week_in_year_nbr
,latest_completed_fiscal_month_customer_fg
,source_item_code
,source_item_name
,ty_sales_value
,ly_sales_value
,ty_sales_units
,ly_sales_units
,ty_cogs_value
,ly_cogs_value
,change_in_sales_value
,change_in_sales_units
,resolved_brand
,resolved_category
,global_category
,gmi_sub_category_desc
,modality as modality_original
,get_modality_harmonized_name(modality) as modality_harmonized
,calendar_year_nbr
,fiscal_date_customer_max
,fiscal_ytd_fg
,latest_completed_fiscal_quarter_customer_fg
,rolling_13_by_customer_fg
,rolling_26_by_customer_fg
,rolling_52_by_customer_fg
,latest_completed_fiscal_year_customer_fg
,fiscal_month_verbose_tableau_mapping
,fiscal_week_begin_dt_tableau_mapping
,species
,foodform
,skuname
,subcategory
,brandhigh
,brandlow
,created_by
,created_datetime
,modified_by
,modified_datetime

from summary_omni_report
);