/* Specific where   gmi_category_desc IS NULL        */
CREATE TEMP FUNCTION get_resolved_brand  (source_item_name STRING)
AS (
  CASE
    WHEN CONTAINS_SUBSTR((source_item_name),'BABY BLUE')  THEN  'BABY BLUE'
    WHEN CONTAINS_SUBSTR((source_item_name),'BASICS')  THEN  'BLUE BASICS'
    WHEN CONTAINS_SUBSTR((source_item_name),'CARNIVOR')  THEN 'BLUE CARNIVORA'
    WHEN CONTAINS_SUBSTR((source_item_name),'FREEDOM')  THEN  'BLUE FREEDOM'
    WHEN CONTAINS_SUBSTR((source_item_name),'SOLUTION')  THEN  'BLUE TRUE SOLUTIONS'
    WHEN CONTAINS_SUBSTR((source_item_name),'WILDERNESS')  THEN  'BLUE WILDERNESS'
    WHEN CONTAINS_SUBSTR((source_item_name),'VETERINARY')  THEN  'BLUE RM BR'
    WHEN CONTAINS_SUBSTR((source_item_name),'LONGEVITY')  THEN  'BLUE RM BR'
    WHEN CONTAINS_SUBSTR((source_item_name),'ESSENTIAL')  THEN  'BLUE RM BR'
    WHEN CONTAINS_SUBSTR((source_item_name),'TRUE CHEW')  THEN  'TRUE CHEWS'
    WHEN CONTAINS_SUBSTR((source_item_name),'NUDGES')  THEN 'NUDGES'
  ELSE
    'BLUE LPF'
  END

);
/* Specific where   gmi_category_desc IS NULL        */
CREATE TEMP FUNCTION get_gmi_sub_category_desc(source_item_name STRING)
AS (
  CASE
    WHEN (CONTAINS_SUBSTR((source_item_name),'CAT') OR CONTAINS_SUBSTR((source_item_name),'KITTEN')) THEN
      CASE
        WHEN CONTAINS_SUBSTR((source_item_name),'TREATS') THEN 'CAT TREATS'
        WHEN (CONTAINS_SUBSTR((source_item_name),'WET') OR CONTAINS_SUBSTR((source_item_name),'GRAVY')  OR CONTAINS_SUBSTR((source_item_name),'CANNED') OR CONTAINS_SUBSTR((source_item_name),'TRAY')) THEN 'WET CAT FOOD'
        ELSE 'DRY CAT FOOD'
        END
    WHEN (CONTAINS_SUBSTR((source_item_name),'DOG') OR CONTAINS_SUBSTR((source_item_name),'PUPPY')) THEN
      CASE
        WHEN CONTAINS_SUBSTR((source_item_name),'TREATS') THEN 'DOG TREATS'
        WHEN (CONTAINS_SUBSTR((source_item_name),'WET') OR CONTAINS_SUBSTR((source_item_name),'GRAVY')  OR CONTAINS_SUBSTR((source_item_name),'CANNED') OR CONTAINS_SUBSTR((source_item_name),'TRAY')) THEN 'WET DOG FOOD'
        ELSE 'DRY DOG FOOD'
        END
  END
);
/* Truncate exsting data           */
TRUNCATE TABLE  `{{params.ECOMM_ANALYTICS}}`.output.gss_sales_share_chewy_pet_omni_report ;

/*Insert reporting data into table */
insert into  `{{params.ECOMM_ANALYTICS}}`.output.gss_sales_share_chewy_pet_omni_report (

with  lkp_stonehenge AS (
    select
      nielsenupc,
      species,
      foodform,
      skuname,
      subcategory,
      brandhigh,
      brandlow,
      platformname,
      row_number() over (partition by nielsenupc order by nielsenupc asc) as rn_wo_platformname
    from
      `{{params.ECOMM_DLF}}.processed.lkp_stonehenge_product_master`),
    gss AS (

     select
            fct.*,
            lkp.species,
            lkp.foodform,
            lkp.skuname,
            lkp.subcategory,
            lkp.brandhigh,
            lkp.brandlow,
            null as ty_cogs_value,
            null as ly_cogs_value
        from
            `{{params.ECOMM_DLF}}.processed.chewy_omni_weekly_agg_fact` fct
        INNER JOIN
            `{{params.ECOMM_DLF}}.processed.ecom_data_release_control` cntrl
        ON
            fct.fiscal_year_week_nbr=cntrl.fiscal_year_week_nbr
            AND fct.fiscal_year_month_nbr=cntrl.fiscal_year_month_nbr
        LEFT JOIN
            lkp_stonehenge lkp
        ON
            LEFT(COALESCE(fct.upc,fct.source_item_code),11) = lkp.nielsenupc
            AND rn_wo_platformname = 1
        WHERE cntrl.staging_flg='Y' AND cntrl.release_flg='Y'
                AND cntrl.feed_name='CHEWY_OMNI'

         ),
    max_values AS (
    select
      max(fiscal_week_begin_dt) as max_week,
      max(fiscal_quarter_nbr) as max_qtr,
      max(fiscal_year_nbr) as max_yr,
      max(fiscal_week_end_dt) as max_week_end,
      customer_name
    from
      gss
    group by
      customer_name )
  select
    agg_fact_sk,
    upper(gss.customer_name) as customer_name,
    upper(customer_parent) as customer_parent,
    upper(customer_account) as customer_account,
    upper(customer_share_flag) as customer_share_flag,
    upper(upc) as upc,
    'GMI' as manufacturer, /* specific to Chewy customer */
    upper(fiscal_year) as fiscal_year,
    fiscal_year_nbr,
    fiscal_year_month_nbr,
    fiscal_year_week_nbr,
    upper(fiscal_month_in_year_short_desc) as fiscal_month_in_year_short_desc,
    upper(fiscal_month_number_short_desc) as fiscal_month_number_short_desc,
    fiscal_quarter_in_year_nbr,
    fiscal_quarter_nbr,
    upper(fiscal_quarter_number_short_desc) as fiscal_quarter_number_short_desc,
    cast(fiscal_week_begin_dt as DATE)fiscal_week_begin_dt,
    fiscal_week_in_year_nbr,
    upper(latest_completed_fiscal_month_customer_fg) as latest_completed_fiscal_month_customer_fg,
    upper(source_item_code) as source_item_code,
    upper(source_item_name) as source_item_name,
    ty_sales_value,
    ly_sales_value,
    ty_sales_units,
    ly_sales_units,
    ty_cogs_value,
    ly_cogs_value,
    change_in_sales_value,
    change_in_sales_units,
    (case
              when gmi_category_desc IS NULL then  get_resolved_brand(UPPER(source_item_name))
            else
              UPPER(resolved_brand)
          end) as resolved_brand,
    resolved_category,
    upper(global_category) as global_category,
    (case
              when gmi_category_desc IS NULL then  get_gmi_sub_category_desc(UPPER(source_item_name))
            else
              (gmi_sub_category_desc)
     end) as gmi_sub_category_desc ,
    modality,
    calendar_year_nbr,
    upper(fiscal_date_customer_max) as fiscal_date_customer_max,
    case
      when fiscal_year_nbr = mv.max_yr then 'Y'
    else
    'N'
    end
    as fiscal_ytd_fg,
    latest_completed_fiscal_quarter_customer_fg,
    rolling_13_by_customer_fg,
    rolling_26_by_customer_fg,
    rolling_52_by_customer_fg,
    upper(latest_completed_fiscal_year_customer_fg) as latest_completed_fiscal_year_customer_fg,
    upper(fiscal_month_verbose_tableau_mapping) as fiscal_month_verbose_tableau_mapping,
    fiscal_week_begin_dt_tableau_mapping,
    upper(species) as species,
    upper(foodform) as foodform,
    upper(skuname) as skuname,
    upper(subcategory) as subcategory,
    upper(brandhigh) as brandhigh,
    upper(brandlow) as brandlow,
    created_by as created_by,
    created_datetime as created_datetime,
    modified_by as modified_by,
    modified_datetime as modified_datetime
  from
    gss
  inner join
    max_values mv
  on
    gss.customer_name=mv.customer_name
);


