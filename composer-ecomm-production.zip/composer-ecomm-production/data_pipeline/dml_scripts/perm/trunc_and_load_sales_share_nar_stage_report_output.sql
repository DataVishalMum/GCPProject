/* Truncate exsting data           */
TRUNCATE TABLE `{{params.ECOMM_ANALYTICS}}`.output.gss_sales_share_us_nar_report_stage;

/*Insert reporting data into table */
insert into  `{{params.ECOMM_ANALYTICS}}`.output.gss_sales_share_us_nar_report_stage  (

with walmart_src as (
	SELECT * FROM `{{params.ECOMM_DLF}}`.processed.walmart_luminate_weekly_agg_fact
),
 online_sales as (select distinct
sum(ty_sales_eqc_units)	ty_sales_eqc_units_new,
sum(ly_sales_eqc_units)	ly_sales_eqc_units_new,
sum(change_in_sales_eqc) change_in_sales_eqc_new,
sum(coalesce(safe_cast(ty_sales_units as INT64),0)) as ty_sales_units_new,
sum(ly_sales_units) ly_sales_units_new,
sum(change_in_sales_units) change_in_sales_units_new,
sum(coalesce(safe_cast(ty_sales_value as float64),0)) as ty_sales_value_new,
sum(ly_sales_value)	ly_sales_value_new,
sum(change_in_sales_value)change_in_sales_value_new,
sum(ty_sales_value_usd)	ty_sales_value_usd_new,
sum(ly_sales_value_usd) ly_sales_value_usd_new,
sum(change_in_sales_value_usd) change_in_sales_value_usd_new,
upc, fiscal_week_begin_dt, source_item_name
FROM walmart_src fct
where modality <> 'in_store'
group by  upc, fiscal_week_begin_dt, source_item_name
),
final as (select distinct --null as
agg_fact_sk ,
a.upc,
TIMESTAMP(a.fiscal_week_begin_dt) fiscal_week_begin_dt,
fiscal_week_end_dt,
source_item_name,
base_product_cd,
base_product_desc,
material_cd,
material_short_desc,
material_nbr,
ean_upc_cd,
xref_brand,
xref_sub_brand,
country,
segment,
channel,
customer_share_flag,
standard_currency_symbol,
standard_currency_code,
customer_desc,
retailer,
manufacturer,
fiscal_week_in_year_nbr,
fiscal_month_in_year_short_desc,
fiscal_quarter_nbr,
fiscal_month_in_year_nbr,
fiscal_quarter_in_year_nbr,
fiscal_year_nbr,
fiscal_year_week_nbr,
fiscal_month_number_short_desc,
fiscal_quarter_number_short_desc,
fiscal_year,
fiscal_year_short_desc,
fiscal_year_month_nbr,
global_category,
global_sub_category,
share_category_relevancy_flag,
sls_hier_division_desc,
sls_hier_category_desc,
sls_hier_sub_category_desc,
sls_hier_accrual_group_desc,
sls_hier_sub_accrual_desc,
sls_hier_ppg_desc,
gph_hier_category_desc,
gph_hier_flavor_format_desc,
gph_hier_package_size_desc,
gph_hier_family_desc,
gph_hier_top_desc,
gmi_category_desc,
gmi_sub_category_desc,
gmi_segment_desc,
gmi_brand_desc,
gmi_global_brand_desc,
gmi_manufacturer_desc,
gmi_global_manufacturer_desc,
brand_high_desc,
brand_low_desc,
gmi_megacategory_desc,
ean_upc_derived_cd,
resolved_brand,
resolved_category,
resolved_product_name,
divested_fg,
base_uom_to_eqc_fctr,
base_uom_to_ecv_fctr,
ty_sales_eqc_units
,ly_sales_eqc_units
,change_in_sales_eqc
,ty_sales_units
,ly_sales_units
,change_in_sales_units
,ty_sales_value
,ly_sales_value
,change_in_sales_value
,ty_sales_value_usd
,ly_sales_value_usd
,change_in_sales_value_usd
,grain,
report_fg,
notes,
bph20_desc,
bph30_desc,
bph40_desc,
bph50_desc,
bph60_desc,
bph70_desc,
customer_parent,
customer_account,
global_category_parent,
zone_hierarchy,
customer_sales_flag,
customer_name,
currency_code,
currency_symbol,
source_item_code,
calendar_year_nbr,
fiscal_date_customer_max,
rolling_13_by_customer_fg,
rolling_26_by_customer_fg,
rolling_52_by_customer_fg,
latest_completed_fiscal_month_customer_fg,
latest_completed_fiscal_quarter_customer_fg,
latest_completed_fiscal_year_customer_fg,
euau_business_operating_unit_desc,
euau_business_product_group_desc,
euau_business_product_sub_group_desc,
product_category_derived_desc,
product_sector_desc,
product_sub_segment_derived_desc,
fiscal_month_verbose_tableau_mapping,
fiscal_week_begin_dt_tableau_mapping,
item_name_with_code_tableau_mapping,
manufacturer_brand_tableau_mapping,
created_by as created_by,
created_datetime as created_datetime,
modified_by as modified_by,
modified_datetime as modified_datetime from (select fct.* except(modality,ty_sales_eqc_units
,ly_sales_eqc_units
,change_in_sales_eqc
,ty_sales_units
,ly_sales_units
,change_in_sales_units
,ty_sales_value
,ly_sales_value
,change_in_sales_value
,ty_sales_value_usd
,ly_sales_value_usd
,change_in_sales_value_usd),
ty_sales_eqc_units_new as	ty_sales_eqc_units
,ly_sales_eqc_units_new ly_sales_eqc_units
,change_in_sales_eqc_new change_in_sales_eqc
,ty_sales_units_new	ty_sales_units
,ly_sales_units_new	ly_sales_units
,change_in_sales_units_new	change_in_sales_units
,ty_sales_value_new	ty_sales_value
,ly_sales_value_new	ly_sales_value
,change_in_sales_value_new	change_in_sales_value
,ty_sales_value_usd_new	ty_sales_value_usd
,ly_sales_value_usd_new	ly_sales_value_usd
,change_in_sales_value_usd_new change_in_sales_value_usd,
row_number() over(PARTITION BY fct.upc, fct.fiscal_week_begin_dt, fct.source_item_name ORDER BY fct.fiscal_week_begin_dt DESC)
rnk_1
FROM walmart_src fct
inner join online_sales on fct.upc=online_sales.upc and fct.fiscal_week_begin_dt=online_sales.fiscal_week_begin_dt
and fct.source_item_name=online_sales.source_item_name
)a where rnk_1=1)

select gss.* from 
        (

        SELECT 
        agg_fact_sk,
        upc,
        DATE(fiscal_week_begin_dt) fiscal_week_begin_dt,
        fiscal_week_end_dt,
        source_item_name,
        base_product_cd,
        base_product_desc,
        material_cd,
        material_short_desc,
        material_nbr,
        ean_upc_cd,
        xref_brand,
        xref_sub_brand,
        country,
        segment,
        channel,
        customer_share_flag,
        standard_currency_symbol,
        standard_currency_code,
        customer_desc,
        retailer,
        manufacturer,
        fiscal_week_in_year_nbr,
        fiscal_month_in_year_short_desc,
        fiscal_quarter_nbr,
        fiscal_month_in_year_nbr,
        fiscal_quarter_in_year_nbr,
        fiscal_year_nbr,
        fiscal_year_week_nbr,
        fiscal_month_number_short_desc,
        fiscal_quarter_number_short_desc,
        fiscal_year,
        fiscal_year_short_desc,
        fiscal_year_month_nbr,
        global_category,
        global_sub_category,
        share_category_relevancy_flag,
        sls_hier_division_desc,
        sls_hier_category_desc,
        sls_hier_sub_category_desc,
        sls_hier_accrual_group_desc,
        sls_hier_sub_accrual_desc,
        sls_hier_ppg_desc,
        gph_hier_category_desc,
        gph_hier_flavor_format_desc,
        gph_hier_package_size_desc,
        gph_hier_family_desc,
        gph_hier_top_desc,
        gmi_category_desc,
        gmi_sub_category_desc,
        gmi_segment_desc,
        gmi_brand_desc,
        gmi_global_brand_desc,
        gmi_manufacturer_desc,
        gmi_global_manufacturer_desc,
        brand_high_desc,
        brand_low_desc,
        gmi_megacategory_desc,
        ean_upc_derived_cd,
        resolved_brand,
        resolved_category,
        resolved_product_name,
        divested_fg,
        base_uom_to_eqc_fctr,
        base_uom_to_ecv_fctr,
        ty_sales_eqc_units,
        ly_sales_eqc_units,
        change_in_sales_eqc,
        ty_sales_units,
        ly_sales_units,
        change_in_sales_units,
        ty_sales_value,
        ly_sales_value,
        change_in_sales_value,
        ty_sales_value_usd,
        ly_sales_value_usd,
        change_in_sales_value_usd,
        grain,
        report_fg,
        notes,
        bph20_desc,
        bph30_desc,
        bph40_desc,
        bph50_desc,
        bph60_desc,
        bph70_desc,
        customer_parent,
        customer_account,
        global_category_parent,
        zone_hierarchy,
        customer_sales_flag,
        customer_name,
        currency_code,
        currency_symbol,
        source_item_code,
        calendar_year_nbr,
        cast(fiscal_date_customer_max as STRING),
        rolling_13_by_customer_fg,
        rolling_26_by_customer_fg,
        rolling_52_by_customer_fg,
        latest_completed_fiscal_month_customer_fg,
        latest_completed_fiscal_quarter_customer_fg,
        latest_completed_fiscal_year_customer_fg,
        euau_business_operating_unit_desc,
        euau_business_product_group_desc,
        euau_business_product_sub_group_desc,
        product_category_derived_desc,
        product_sector_desc,
        product_sub_segment_derived_desc,
        fiscal_month_verbose_tableau_mapping,
        fiscal_week_begin_dt_tableau_mapping,
        item_name_with_code_tableau_mapping,
        manufacturer_brand_tableau_mapping,
        created_by as created_by,
        created_datetime as created_datetime,
        modified_by as modified_by,
        modified_datetime as modified_datetime
        from (
            select fct.* from  `{{params.ECOMM_DLF}}`.processed.albertsons_safeway_weekly_agg_fact fct  inner join `{{params.ECOMM_DLF}}`.processed.ecom_data_release_control cntrl on fct.fiscal_year_week_nbr=cntrl.fiscal_year_week_nbr and fct.fiscal_year_month_nbr=cntrl.fiscal_year_month_nbr  where cntrl.staging_flg='Y' and cntrl.feed_name='ALBERTSONS_SAFEWAY'                
            union all
            select fct.* from  `{{params.ECOMM_DLF}}`.processed.amazon_com_weekly_agg_fact fct  inner join `{{params.ECOMM_DLF}}`.processed.ecom_data_release_control cntrl on fct.fiscal_year_week_nbr=cntrl.fiscal_year_week_nbr and fct.fiscal_year_month_nbr=cntrl.fiscal_year_month_nbr  where cntrl.staging_flg='Y' and cntrl.feed_name='AMAZON_COM'  and fct.manufacturer !='3P GMI Sales'
            union all 
            select fct.* from  `{{params.ECOMM_DLF}}`.processed.amazon_fresh_weekly_agg_fact fct  inner join `{{params.ECOMM_DLF}}`.processed.ecom_data_release_control cntrl on fct.fiscal_year_week_nbr=cntrl.fiscal_year_week_nbr and fct.fiscal_year_month_nbr=cntrl.fiscal_year_month_nbr  where cntrl.staging_flg='Y' and cntrl.feed_name='AMAZON_FRESH'  and fct.manufacturer !='3P GMI Sales'
            union all
            select fct.* from  `{{params.ECOMM_DLF}}`.processed.amazon_pantry_weekly_agg_fact fct  inner join `{{params.ECOMM_DLF}}`.processed.ecom_data_release_control cntrl on fct.fiscal_year_week_nbr=cntrl.fiscal_year_week_nbr and fct.fiscal_year_month_nbr=cntrl.fiscal_year_month_nbr  where cntrl.staging_flg='Y' and cntrl.feed_name='AMAZON_PANTRY'  and fct.manufacturer !='3P GMI Sales'
            union all 
            select fct.* from  `{{params.ECOMM_DLF}}`.processed.amazon_prime_now_weekly_agg_fact fct  inner join `{{params.ECOMM_DLF}}`.processed.ecom_data_release_control cntrl on fct.fiscal_year_week_nbr=cntrl.fiscal_year_week_nbr and fct.fiscal_year_month_nbr=cntrl.fiscal_year_month_nbr  where cntrl.staging_flg='Y' and cntrl.feed_name='AMAZON_PRIME_NOW'   and fct.manufacturer !='3P GMI Sales'
            union all
            select fct.* from  `{{params.ECOMM_DLF}}`.processed.boxed_weekly_agg_fact fct  inner join `{{params.ECOMM_DLF}}`.processed.ecom_data_release_control cntrl on fct.fiscal_year_week_nbr=cntrl.fiscal_year_week_nbr and fct.fiscal_year_month_nbr=cntrl.fiscal_year_month_nbr  where cntrl.staging_flg='Y' and cntrl.feed_name='BOXED'
            union all
            select fct.* from  `{{params.ECOMM_DLF}}`.processed.giant_eagle_weekly_agg_fact fct  inner join `{{params.ECOMM_DLF}}`.processed.ecom_data_release_control cntrl on fct.fiscal_year_week_nbr=cntrl.fiscal_year_week_nbr and fct.fiscal_year_month_nbr=cntrl.fiscal_year_month_nbr  where cntrl.staging_flg='Y' and cntrl.feed_name='GIANT_EAGLE' 
            union all 
            select fct.* from  `{{params.ECOMM_DLF}}`.processed.harris_teeter_weekly_agg_fact fct  inner join `{{params.ECOMM_DLF}}`.processed.ecom_data_release_control cntrl on fct.fiscal_year_week_nbr=cntrl.fiscal_year_week_nbr and fct.fiscal_year_month_nbr=cntrl.fiscal_year_month_nbr  where cntrl.staging_flg='Y' and cntrl.feed_name='HARRIS_TEETER' 
            union all
            select fct.* from  `{{params.ECOMM_DLF}}`.processed.hyvee_weekly_agg_fact fct  inner join `{{params.ECOMM_DLF}}`.processed.ecom_data_release_control cntrl on fct.fiscal_year_week_nbr=cntrl.fiscal_year_week_nbr and fct.fiscal_year_month_nbr=cntrl.fiscal_year_month_nbr  where cntrl.staging_flg='Y' and cntrl.feed_name='HYVEE' 
			union all
            select fct.* from  `{{params.ECOMM_DLF}}`.processed.instacart_weekly_sales_agg_fact fct  inner join `{{params.ECOMM_DLF}}`.processed.ecom_data_release_control cntrl on fct.fiscal_year_week_nbr=cntrl.fiscal_year_week_nbr and fct.fiscal_year_month_nbr=cntrl.fiscal_year_month_nbr  where cntrl.staging_flg='Y' and cntrl.feed_name='INSTACART_WEEKLY'
            union all
            select fct.* from  `{{params.ECOMM_DLF}}`.processed.kroger_market6_sales_weekly_agg_fact fct  inner join `{{params.ECOMM_DLF}}`.processed.ecom_data_release_control cntrl on fct.fiscal_year_week_nbr=cntrl.fiscal_year_week_nbr and fct.fiscal_year_month_nbr=cntrl.fiscal_year_month_nbr  where cntrl.staging_flg='Y' and cntrl.feed_name='KROGER' 
            union all
            select fct.* from  `{{params.ECOMM_DLF}}`.processed.kroger_grocery_weekly_agg_fact fct  inner join `{{params.ECOMM_DLF}}`.processed.ecom_data_release_control cntrl on fct.fiscal_year_week_nbr=cntrl.fiscal_year_week_nbr and fct.fiscal_year_month_nbr=cntrl.fiscal_year_month_nbr  where cntrl.staging_flg='Y' and cntrl.feed_name='KROGER_GROCERY_SHARE' 
            union all
            --select fct.* from  `{{params.ECOMM_DLF}}`.processed.kroger_market6_share_weekly_agg_fact fct  inner join `{{params.ECOMM_DLF}}`.processed.ecom_data_release_control cntrl on fct.fiscal_year_week_nbr=cntrl.fiscal_year_week_nbr and fct.fiscal_year_month_nbr=cntrl.fiscal_year_month_nbr  where cntrl.staging_flg='Y' and cntrl.feed_name='KROGER_MARKET6_SHARE' 
            --union all
            select fct.* from  `{{params.ECOMM_DLF}}`.processed.kroger_ship_weekly_agg_fact fct  inner join `{{params.ECOMM_DLF}}`.processed.ecom_data_release_control cntrl on fct.fiscal_year_week_nbr=cntrl.fiscal_year_week_nbr and fct.fiscal_year_month_nbr=cntrl.fiscal_year_month_nbr  where cntrl.staging_flg='Y' and cntrl.feed_name='KROGER_SHIP' 
            union all
            select fct.* from  `{{params.ECOMM_DLF}}`.processed.kroger_delivery_weekly_agg_fact fct  inner join `{{params.ECOMM_DLF}}`.processed.ecom_data_release_control cntrl on fct.fiscal_year_week_nbr=cntrl.fiscal_year_week_nbr and fct.fiscal_year_month_nbr=cntrl.fiscal_year_month_nbr  where cntrl.staging_flg='Y' and cntrl.feed_name='KROGER_DELIVERY' 
            union all 
            select fct.* from  `{{params.ECOMM_DLF}}`.processed.meijer_weekly_agg_fact fct  inner join `{{params.ECOMM_DLF}}`.processed.ecom_data_release_control cntrl on fct.fiscal_year_week_nbr=cntrl.fiscal_year_week_nbr and fct.fiscal_year_month_nbr=cntrl.fiscal_year_month_nbr  where cntrl.staging_flg='Y' and cntrl.feed_name='MEIJER' 
            union all
            select fct.* from  `{{params.ECOMM_DLF}}`.processed.peapod_weekly_agg_fact fct  inner join `{{params.ECOMM_DLF}}`.processed.ecom_data_release_control cntrl on fct.fiscal_year_week_nbr=cntrl.fiscal_year_week_nbr and fct.fiscal_year_month_nbr=cntrl.fiscal_year_month_nbr  where cntrl.staging_flg='Y' and cntrl.feed_name='PEAPOD' 
            union all
            select fct.* from  `{{params.ECOMM_DLF}}`.processed.sams_club_weekly_agg_fact fct  inner join `{{params.ECOMM_DLF}}`.processed.ecom_data_release_control cntrl on fct.fiscal_year_week_nbr=cntrl.fiscal_year_week_nbr and fct.fiscal_year_month_nbr=cntrl.fiscal_year_month_nbr  where cntrl.staging_flg='Y' and cntrl.feed_name='SAMS_CLUB' 
            union all
            select fct.* from  `{{params.ECOMM_DLF}}`.processed.shipt_weekly_agg_fact fct  inner join `{{params.ECOMM_DLF}}`.processed.ecom_data_release_control cntrl on fct.fiscal_year_week_nbr=cntrl.fiscal_year_week_nbr and fct.fiscal_year_month_nbr=cntrl.fiscal_year_month_nbr  where cntrl.staging_flg='Y' and cntrl.feed_name='SHIPT' 
            union all  
            select fct.* from  `{{params.ECOMM_DLF}}`.processed.shoprite_weekly_agg_fact fct  inner join `{{params.ECOMM_DLF}}`.processed.ecom_data_release_control cntrl on fct.fiscal_year_week_nbr=cntrl.fiscal_year_week_nbr and fct.fiscal_year_month_nbr=cntrl.fiscal_year_month_nbr  where cntrl.staging_flg='Y' and cntrl.feed_name='SHOPRITE'
            union all
			select fct.* from  `{{params.ECOMM_DLF}}`.processed.target_weekly_agg_fact fct  inner join `{{params.ECOMM_DLF}}`.processed.ecom_data_release_control cntrl on fct.fiscal_year_week_nbr=cntrl.fiscal_year_week_nbr and fct.fiscal_year_month_nbr=cntrl.fiscal_year_month_nbr  where cntrl.staging_flg='Y' and cntrl.feed_name='TARGET'
			union all
            select fct.* from  `{{params.ECOMM_DLF}}`.processed.walmart_opd_weekly_agg_fact fct  inner join `{{params.ECOMM_DLF}}`.processed.ecom_data_release_control cntrl on fct.fiscal_year_week_nbr=cntrl.fiscal_year_week_nbr and fct.fiscal_year_month_nbr=cntrl.fiscal_year_month_nbr  where cntrl.staging_flg='Y' and cntrl.feed_name='WALMART_OPD' 
            union all  
            select fct.* from  `{{params.ECOMM_DLF}}`.processed.walmart_com_weekly_agg_fact fct  inner join `{{params.ECOMM_DLF}}`.processed.ecom_data_release_control cntrl on fct.fiscal_year_week_nbr=cntrl.fiscal_year_week_nbr and fct.fiscal_year_month_nbr=cntrl.fiscal_year_month_nbr  where cntrl.staging_flg='Y' and cntrl.feed_name='WALMART_COM'
            union all
            select fct.* from  final fct inner join `{{params.ECOMM_DLF}}`.processed.ecom_data_release_control cntrl on fct.fiscal_year_week_nbr=cntrl.fiscal_year_week_nbr and fct.fiscal_year_month_nbr=cntrl.fiscal_year_month_nbr  where cntrl.staging_flg='Y' and cntrl.feed_name='WALMART_LUMINATE'
            union all  
            select fct.* from  `{{params.ECOMM_DLF}}`.processed.wegmans_weekly_agg_fact fct  inner join `{{params.ECOMM_DLF}}`.processed.ecom_data_release_control cntrl on fct.fiscal_year_week_nbr=cntrl.fiscal_year_week_nbr and fct.fiscal_year_month_nbr=cntrl.fiscal_year_month_nbr  where cntrl.staging_flg='Y' and cntrl.feed_name='WEGMANS' 

            )
        ) gss

where DATE(gss.fiscal_week_begin_dt) >= DATE_SUB(CURRENT_DATE(), INTERVAL {{params.load_number_days_range}} DAY)

)

;



