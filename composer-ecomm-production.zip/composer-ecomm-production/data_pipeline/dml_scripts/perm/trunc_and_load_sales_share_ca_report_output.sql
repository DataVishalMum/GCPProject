/* Truncate exsting data           */
TRUNCATE TABLE  `{{params.ECOMM_ANALYTICS}}`.output.gss_sales_share_ca_nar_report;

/*Insert reporting data into table */
insert into  `{{params.ECOMM_ANALYTICS}}`.output.gss_sales_share_ca_nar_report


(

select gss.* from 
        (

SELECT 
agg_fact_sk,
upc,
DATE(fiscal_week_begin_dt) fiscal_week_begin_dt,
fiscal_week_end_dt,
source_item_name,
base_product_cd,
base_product_desc,
material_cd,
material_short_desc,
material_nbr,
ean_upc_cd,
xref_brand,
xref_sub_brand,
country,
segment,
channel,
customer_share_flag,
standard_currency_symbol,
standard_currency_code,
customer_desc,
retailer,
manufacturer,
fiscal_week_in_year_nbr,
fiscal_month_in_year_short_desc,
fiscal_quarter_nbr,
fiscal_month_in_year_nbr,
fiscal_quarter_in_year_nbr,
fiscal_year_nbr,
fiscal_year_week_nbr,
fiscal_month_number_short_desc,
fiscal_quarter_number_short_desc,
fiscal_year,
fiscal_year_short_desc,
fiscal_year_month_nbr,
global_category,
global_sub_category,
share_category_relevancy_flag,
sls_hier_division_desc,
sls_hier_category_desc,
sls_hier_sub_category_desc,
sls_hier_accrual_group_desc,
sls_hier_sub_accrual_desc,
sls_hier_ppg_desc,
gph_hier_category_desc,
gph_hier_flavor_format_desc,
gph_hier_package_size_desc,
gph_hier_family_desc,
gph_hier_top_desc,
gmi_category_desc,
gmi_sub_category_desc,
gmi_segment_desc,
gmi_brand_desc,
gmi_global_brand_desc,
gmi_manufacturer_desc,
gmi_global_manufacturer_desc,
brand_high_desc,
brand_low_desc,
gmi_megacategory_desc,
ean_upc_derived_cd,
resolved_brand,
resolved_category,
resolved_product_name,
divested_fg,
base_uom_to_eqc_fctr,
base_uom_to_ecv_fctr,
ty_sales_eqc_units,
ly_sales_eqc_units,
change_in_sales_eqc,
ty_sales_units,
ly_sales_units,
change_in_sales_units,
ty_sales_value,
ly_sales_value,
change_in_sales_value,
ty_sales_value_usd,
ly_sales_value_usd,
change_in_sales_value_usd,
grain,
report_fg,
notes,
bph20_desc,
bph30_desc,
bph40_desc,
bph50_desc,
bph60_desc,
bph70_desc,
customer_parent,
customer_account,
global_category_parent,
zone_hierarchy,
customer_sales_flag,
customer_name,
currency_code,
currency_symbol,
source_item_code,
calendar_year_nbr,
fiscal_date_customer_max,
rolling_13_by_customer_fg,
rolling_26_by_customer_fg,
rolling_52_by_customer_fg,
latest_completed_fiscal_month_customer_fg,
latest_completed_fiscal_quarter_customer_fg,
latest_completed_fiscal_year_customer_fg,
euau_business_operating_unit_desc,
euau_business_product_group_desc,
euau_business_product_sub_group_desc,
product_category_derived_desc,
product_sector_desc,
product_sub_segment_derived_desc,
fiscal_month_verbose_tableau_mapping,
fiscal_week_begin_dt_tableau_mapping,
item_name_with_code_tableau_mapping,
manufacturer_brand_tableau_mapping,
created_by as created_by,
created_datetime as created_datetime,
modified_by as modified_by,
modified_datetime as modified_datetime
from (
select fct.* from  `{{params.ECOMM_DLF}}`.processed.amazon_canada_weekly_agg_fact fct  inner join `{{params.ECOMM_DLF}}`.processed.ecom_data_release_control cntrl on fct.fiscal_year_week_nbr=cntrl.fiscal_year_week_nbr and fct.fiscal_year_month_nbr=cntrl.fiscal_year_month_nbr  where cntrl.staging_flg='Y' and cntrl.release_flg='Y' and cntrl.feed_name='AMAZON_CANADA' 
union all 
select fct.* from  `{{params.ECOMM_DLF}}`.processed.loblaws_weekly_agg_fact fct  inner join `{{params.ECOMM_DLF}}`.processed.ecom_data_release_control cntrl on fct.fiscal_year_week_nbr=cntrl.fiscal_year_week_nbr and fct.fiscal_year_month_nbr=cntrl.fiscal_year_month_nbr  where cntrl.staging_flg='Y' and cntrl.release_flg='Y' and cntrl.feed_name='LOBLAWS' 
union all
select fct.* from  `{{params.ECOMM_DLF}}`.processed.walmart_canada_weekly_agg_fact fct  inner join `{{params.ECOMM_DLF}}`.processed.ecom_data_release_control cntrl on fct.fiscal_year_week_nbr=cntrl.fiscal_year_week_nbr and fct.fiscal_year_month_nbr=cntrl.fiscal_year_month_nbr  where cntrl.staging_flg='Y' and cntrl.release_flg='Y' and cntrl.feed_name='WALMART_CANADA' 
union all
select fct.* from  `{{params.ECOMM_DLF}}`.processed.cornershop_canada_weekly_agg_fact fct  inner join `{{params.ECOMM_DLF}}`.processed.ecom_data_release_control cntrl on fct.fiscal_year_week_nbr=cntrl.fiscal_year_week_nbr and fct.fiscal_year_month_nbr=cntrl.fiscal_year_month_nbr  where cntrl.staging_flg='Y' and cntrl.release_flg='Y' and cntrl.feed_name='CORNERSHOP_CANADA' 
union all
select fct.* from  `{{params.ECOMM_DLF}}`.processed.sobeys_voila_weekly_agg_fact fct  inner join `{{params.ECOMM_DLF}}`.processed.ecom_data_release_control cntrl on fct.fiscal_year_week_nbr=cntrl.fiscal_year_week_nbr and fct.fiscal_year_month_nbr=cntrl.fiscal_year_month_nbr  where cntrl.staging_flg='Y' and cntrl.release_flg='Y' and cntrl.feed_name='SOBEYS_VOILA' 
union all 
select fct.* from  `{{params.ECOMM_DLF}}`.processed.costco_canada_weekly_agg_fact fct   inner join `{{params.ECOMM_DLF}}`.processed.ecom_data_release_control cntrl on fct.fiscal_year_week_nbr=cntrl.fiscal_year_week_nbr and fct.fiscal_year_month_nbr=cntrl.fiscal_year_month_nbr  where cntrl.staging_flg='Y' and cntrl.release_flg='Y' and cntrl.feed_name='COSTCO_CANADA' 
)
)  gss





    where gss.fiscal_week_begin_dt >= DATE_SUB(CURRENT_DATE(), INTERVAL {{params.load_number_days_range}} DAY)

)



;


