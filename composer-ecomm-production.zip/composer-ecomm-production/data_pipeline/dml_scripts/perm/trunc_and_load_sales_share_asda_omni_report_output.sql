/* Truncate exsting data           */
TRUNCATE TABLE  `{{params.ECOMM_ANALYTICS}}`.output.gss_sales_share_asda_omni_report;

/*Insert reporting data into table */
insert into  `{{params.ECOMM_ANALYTICS}}`.output.gss_sales_share_asda_omni_report

with
gss as (
select fct.*,cntrl.feed_name from  `{{params.ECOMM_DLF}}`.processed.asda_weekly_agg_fact fct

inner join `{{params.ECOMM_DLF}}`.processed.ecom_data_release_control cntrl on fct.fiscal_year_week_nbr=cntrl.fiscal_year_week_nbr and fct.fiscal_year_month_nbr=cntrl.fiscal_year_month_nbr  where cntrl.staging_flg='Y' and cntrl.release_flg='Y' and cntrl.feed_name='ASDA'
),
feed_release_week_rnk as
(select
row_number() over(partition by feed_name order by fiscal_year_week_nbr desc) as rnk
,*
from `{{params.ECOMM_DLF}}`.processed.ecom_data_release_control where release_flg = 'Y' and feed_name = 'ASDA'
),
max_feed_release_week as (
    select w_rnk.*, dt.fiscal_week_end_dt as max_fiscal_week_end_dt,
	DATE_SUB(fiscal_week_end_dt,INTERVAL 13 WEEK) as rolling13Start,
	DATE_SUB(fiscal_week_end_dt,INTERVAL 26 WEEK) as rolling26Start,
    DATE_SUB(fiscal_week_end_dt,INTERVAL 52 WEEK) as rolling52Start
    from feed_release_week_rnk w_rnk
    inner join
    (select fiscal_year_week_nbr, fiscal_week_end_dt from`edw-prd-e567f9.enterprise.dim_date` dt group by 1,2) dt
    on w_rnk.fiscal_year_week_nbr=dt.fiscal_year_week_nbr
    where rnk=1
)
SELECT
agg_fact_sk,
upc,
DATE(fiscal_week_begin_dt) fiscal_week_begin_dt,
fiscal_week_end_dt,
source_item_name,
base_product_cd,
base_product_desc,
material_cd,
material_short_desc,
material_nbr,
ean_upc_cd,
xref_brand,
xref_sub_brand,
country,
segment,
channel,
customer_share_flag,
standard_currency_symbol,
standard_currency_code,
customer_desc,
retailer,
manufacturer,
fiscal_week_in_year_nbr,
fiscal_month_in_year_short_desc,
fiscal_quarter_nbr,
fiscal_month_in_year_nbr,
fiscal_quarter_in_year_nbr,
fct.fiscal_year_nbr,
fct.fiscal_year_week_nbr,
fiscal_month_number_short_desc,
fiscal_quarter_number_short_desc,
fiscal_year,
fiscal_year_short_desc,
fct.fiscal_year_month_nbr,
global_category,
global_sub_category,
share_category_relevancy_flag,
sls_hier_division_desc,
sls_hier_category_desc,
sls_hier_sub_category_desc,
sls_hier_accrual_group_desc,
sls_hier_sub_accrual_desc,
sls_hier_ppg_desc,
gph_hier_category_desc,
gph_hier_flavor_format_desc,
gph_hier_package_size_desc,
gph_hier_family_desc,
gph_hier_top_desc,
gmi_category_desc,
gmi_sub_category_desc,
gmi_segment_desc,
gmi_brand_desc,
gmi_global_brand_desc,
gmi_manufacturer_desc,
gmi_global_manufacturer_desc,
brand_high_desc,
brand_low_desc,
gmi_megacategory_desc,
ean_upc_derived_cd,
resolved_brand,
resolved_category,
resolved_product_name,
divested_fg,
base_uom_to_eqc_fctr,
base_uom_to_ecv_fctr,
ty_sales_eqc_units,
ly_sales_eqc_units,
change_in_sales_eqc,
ty_sales_units,
ly_sales_units,
change_in_sales_units,
ty_sales_value,
ly_sales_value,
change_in_sales_value,
ty_sales_value_usd,
ly_sales_value_usd,
change_in_sales_value_usd,
grain,
report_fg,
notes,
bph20_desc,
bph30_desc,
bph40_desc,
bph50_desc,
bph60_desc,
bph70_desc,
customer_parent,
customer_account,
global_category_parent,
zone_hierarchy,
customer_sales_flag,
fct.customer_name,
currency_code,
currency_symbol,
source_item_code,
channel_type,
calendar_year_nbr,
cntrl_latest.max_fiscal_week_end_dt as fiscal_date_customer_max,
CASE WHEN (cast(fct.fiscal_week_begin_dt as date) >= cntrl_latest.rolling13Start) AND cast(fct.fiscal_week_begin_dt as date)<= cntrl_latest.max_fiscal_week_end_dt THEN 'Y'
        ELSE 'N' END AS rolling_13_by_customer_fg,
CASE WHEN (cast(fct.fiscal_week_begin_dt as date) >= cntrl_latest.rolling26Start) AND cast(fct.fiscal_week_begin_dt as date)<= cntrl_latest.max_fiscal_week_end_dt THEN 'Y'
        ELSE 'N' END AS rolling_26_by_customer_fg,
CASE WHEN (cast(fct.fiscal_week_begin_dt as date) >= cntrl_latest.rolling52Start) AND cast(fct.fiscal_week_begin_dt as date)<= cntrl_latest.max_fiscal_week_end_dt THEN 'Y'
        ELSE 'N' END AS rolling_52_by_customer_fg,
latest_completed_fiscal_month_customer_fg,
latest_completed_fiscal_quarter_customer_fg,
latest_completed_fiscal_year_customer_fg,
euau_business_operating_unit_desc,
euau_business_product_group_desc,
euau_business_product_sub_group_desc,
product_category_derived_desc,
product_sector_desc,
product_sub_segment_derived_desc,
fiscal_month_verbose_tableau_mapping,
fiscal_week_begin_dt_tableau_mapping,
item_name_with_code_tableau_mapping,
manufacturer_brand_tableau_mapping,
fct.created_by as created_by,
fct.created_datetime as created_datetime,
fct.modified_by as modified_by,
fct.modified_datetime as modified_datetime
from  gss fct
left outer join max_feed_release_week cntrl_latest
on fct.feed_name = cntrl_latest.feed_name

where  DATE(fiscal_week_begin_dt) >= DATE_SUB(CURRENT_DATE(), INTERVAL {{params.load_number_days_range}} DAY)
;