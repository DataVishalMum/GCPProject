CALL `{{params.ECOMM_ANALYTICS}}`.transient.sp_profitero_blue_product_coverage('{{params.ECOMM_ANALYTICS}}','{{params.ECOMM_ANALYTICS}}','output',blue_buffalo_product_coverage_report');

