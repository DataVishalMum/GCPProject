CALL `{{params.ECOMM_DLF}}`.transient.sp_profitero_blue_ratings_report('{{params.ECOMM_DLF}}','edw-prd-e567f9','{{params.ECOMM_ANALYTICS}}','processed','enterprise','output','blue_buffalo_ratings_stage_report,blue_buffalo_ratings_report');

CALL `{{params.ECOMM_DLF}}`.transient.sp_profitero_blue_reviews_report('{{params.ECOMM_DLF}}','edw-prd-e567f9','{{params.ECOMM_ANALYTICS}}','processed','enterprise','output','blue_buffalo_reviews_stage_report,blue_buffalo_reviews_report');


