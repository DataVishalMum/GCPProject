/* Truncate exsting data           */
TRUNCATE TABLE `{{params.ECOMM_ANALYTICS}}`.output.keyword_search_share_of_search_report;

/*Insert reporting data into table */
insert into  `{{params.ECOMM_ANALYTICS}}`.output.keyword_search_share_of_search_report


SELECT
fct.search_date,
fct.search_term,
fct.retailer,
fct.customer_parent,
fct.customer_account,
fct.upc,
fct.rpc,
fct.ean,
fct.product_title,
fct.product_title_clnsd,
fct.is_sponsored,
fct.brand,
fct.sub_brand,
fct.manufacturer,
fct.actual_rank,
fct.rnk_weightage,
fct.cust_weightage,
fct.keyword_type,
fct.ou,
fct.category,
fct.location,
fct.segment,
fct.fiscal_year_nbr,
fct.fiscal_month_in_year_nbr,
fct.fiscal_quarter_in_year_nbr,
fct.fiscal_month_in_year_short_desc,
fct.latest_completed_fiscal_month_fg,
fct.previous_completed_fiscal_month_fg
from `ecomm-dlf-prd-634888.processed.profitero_keyword_search_product_level` fct
inner join `ecomm-dlf-prd-634888.processed.ecom_data_release_control` cntrl ON fct.fiscal_year_week_nbr=cntrl.fiscal_year_week_nbr AND fct.fiscal_year_month_nbr=cntrl.fiscal_year_month_nbr
WHERE cntrl.staging_flg='Y' AND cntrl.release_flg='Y' AND cntrl.feed_name='PROFITERO_KEYWORD_SEARCH_RANKING'
AND COALESCE(TRIM(fct.category),'') <>''
AND fct.search_date >= DATE_SUB(CURRENT_DATE(), INTERVAL {{params.load_number_days_range}} DAY)

;


/* Truncate exsting data           */
TRUNCATE TABLE `{{params.ECOMM_ANALYTICS}}`.output.keyword_search_share_of_search_stage_report;

/*Insert reporting data into table */
insert into  `{{params.ECOMM_ANALYTICS}}`.output.keyword_search_share_of_search_stage_report


SELECT
fct.search_date,
fct.search_term,
fct.retailer,
fct.customer_parent,
fct.customer_account,
fct.upc,
fct.rpc,
fct.ean,
fct.product_title,
fct.product_title_clnsd,
fct.is_sponsored,
fct.brand,
fct.sub_brand,
fct.manufacturer,
fct.actual_rank,
fct.rnk_weightage,
fct.cust_weightage,
fct.keyword_type,
fct.ou,
fct.category,
fct.location,
fct.segment,
fct.fiscal_year_nbr,
fct.fiscal_month_in_year_nbr,
fct.fiscal_quarter_in_year_nbr,
fct.fiscal_month_in_year_short_desc,
fct.latest_completed_fiscal_month_fg,
fct.previous_completed_fiscal_month_fg
from `ecomm-dlf-prd-634888.processed.profitero_keyword_search_product_level` fct
inner join `ecomm-dlf-prd-634888.processed.ecom_data_release_control` cntrl ON fct.fiscal_year_week_nbr=cntrl.fiscal_year_week_nbr AND fct.fiscal_year_month_nbr=cntrl.fiscal_year_month_nbr
WHERE cntrl.staging_flg='Y' AND cntrl.release_flg='Y' AND cntrl.feed_name='PROFITERO_KEYWORD_SEARCH_RANKING'
AND COALESCE(TRIM(fct.category),'') <>''
AND fct.search_date >= DATE_SUB(CURRENT_DATE(), INTERVAL {{params.load_number_days_range}} DAY)
;
