TRUNCATE TABLE
 `{{params.ECOMM_DLF}}`.processed.casefill_na_weekly;
INSERT INTO
 `{{params.ECOMM_DLF}}`.processed.casefill_na_weekly
WITH
fiscal_years  AS(
SELECT
  d.fiscal_dt,
  d.fiscal_year_month_nbr,
  d.fiscal_week_begin_dt,
FROM
 `shareddata-prd-cb5872.shared_data_enterprise.fiscal_day` d
WHERE
  d.language_cd = 'EN'
GROUP BY 
  d.fiscal_dt,
  d.fiscal_year_month_nbr,
  d.fiscal_week_begin_dt
)
SELECT
  e.source_type_cd,
  e.customer_parent,
  e.parent_material_cd,
  e.material_cd,
  e.base_product_cd,
  e.material_short_desc,
  e.ean_upc_derived_cd,
  e.customer_product_cd AS customer_material_cd,
  SUM(c.cf_numerator) AS cf_numerator,
  SUM(c.cf_denominator) AS cf_denominator,
  DATE(fy.fiscal_week_begin_dt) AS fiscal_week_begin_dt,
  current_datetime() AS created_datetime,
FROM
  `{{params.ECOMM_DLF}}`.processed.ecomm_product_catalog e
JOIN
  `edw-prd-e567f9.supplychain.casefill_na_fact` c
ON
  e.sales_organization_cd = c.sales_organization_cd
  AND e.distribution_channel_cd = c.distribution_channel_cd
  AND e.customer_cd = c.customer_account_cd
  AND e.parent_material_cd = c.material_cd
JOIN
  fiscal_years fy
ON
  DATE(c.actual_goods_issue_dt) = DATE(fy.fiscal_dt)
GROUP BY 
  e.source_type_cd,
  e.customer_parent,
  e.parent_material_cd,
  e.material_cd,
  e.base_product_cd,
  e.material_short_desc,
  e.ean_upc_derived_cd,
  e.customer_product_cd,
  fy.fiscal_week_begin_dt,
  created_datetime