/* Truncate exsting data           */
TRUNCATE TABLE `{{params.ECOMM_ANALYTICS}}`.output.new_upc_conversion_report;