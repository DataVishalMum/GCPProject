/* Truncate exsting data           */
TRUNCATE TABLE `{{params.ECOMM_ANALYTICS}}`.output.ecomm_ana_euau_assortment_report;

/*Insert reporting data into table */
insert into  `{{params.ECOMM_ANALYTICS}}`.output.ecomm_ana_euau_assortment_report

SELECT * FROM  `{{params.ECOMM_DLF}}`.processed.ecomm_ana_euau_assortment_report;


CALL `{{params.ECOMM_DLF}}.processed.sp_apply_rls_policies_on_tables`(
  "{{params.ECOMM_ANALYTICS}}", 
  "output", 
  "{{params.ECOMM_ANALYTICS}}", 
  "processed", 
  "ecomm_common_customer_info", 
  "'ecomm_ana_euau_assortment_report'",
  TRUE
);
