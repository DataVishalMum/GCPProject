/* Truncate exsting data           */
truncate table `{{params.ECOMM_ANALYTICS}}`.output.assortment_availability_report;
/*Insert reporting data into table */
insert into  `{{params.ECOMM_ANALYTICS}}`.output.assortment_availability_report

with
 calendar as (
    select
        fiscal_year_week_nbr
        , fiscal_year_month_nbr
        , fiscal_month_in_year_nbr
        , fiscal_month_in_year_short_desc
        , fiscal_week_begin_dt
        , fiscal_year_nbr
        , fiscal_quarter_in_year_nbr
        , fiscal_week_in_year_nbr
        , fiscal_week_end_dt
        , fiscal_month_begin_dt
        , fiscal_month_end_dt
        , fiscal_quarter_begin_dt
        , fiscal_quarter_end_dt
        , fiscal_year_begin_dt
        , fiscal_year_end_dt
        , fiscal_year_short_desc
        , fiscal_quarter_nbr
        , min(calendar_year_nbr) as calendar_year_nbr
    from `edw-prd-e567f9.enterprise.dim_date` cal
    WHERE cal.language_cd = 'EN'
    AND cal.fiscal_year_variant_cd = '07'
    AND cal.calendar_dt >= DATE_SUB(CURRENT_DATE(), INTERVAL {{params.load_number_days_range}} DAY)
    GROUP BY
        fiscal_year_week_nbr
        , fiscal_year_month_nbr
        , fiscal_month_in_year_nbr
        , fiscal_month_in_year_short_desc
        , fiscal_week_begin_dt
        , fiscal_year_nbr
        , fiscal_quarter_in_year_nbr
        , fiscal_week_in_year_nbr
        , fiscal_week_end_dt
        , fiscal_month_begin_dt
        , fiscal_month_end_dt
        , fiscal_quarter_begin_dt
        , fiscal_quarter_end_dt
        , fiscal_year_begin_dt
        , fiscal_year_end_dt
        , fiscal_year_short_desc
        , fiscal_quarter_nbr
),

avg_online_assortment as (

select
  ana.customer_parent,
  ana.ean_upc_cd,
  ana.fiscal_week_begin_dt,
(sum(ana.is_online_distribution)) as DA
from

`{{params.ECOMM_DLF}}`.processed.walmart_opd_distribution_availability_with_upc_fact AS ana

group by
  ana.customer_parent,
  ana.ean_upc_cd,
  ana.fiscal_week_begin_dt

 ),

gss as (
    select
        ean_upc_cd
        , case when upper(customer_name) = 'WALMART_LUMINATE' then 'WALMART_OPD'
               when upper(customer_name) = 'WALMART_OPD' then null
               else customer_name
          end as customer_name
        , cast(fiscal_week_begin_dt as date) fiscal_week_begin_dt
        , sum(safe_cast(ty_sales_value as FLOAT64)) ty_sales_value
    from `{{params.ECOMM_ANALYTICS}}`.processed.gss_sales_share_us_nar_report
    where (ty_sales_value is not null and ty_sales_value != 0)
    group by
        ean_upc_cd
        , customer_name
        ,  fiscal_week_begin_dt
),
casefill as (
    select
        case
            when customer_parent = 'HEB SAN ANTONIO DRY ***'
                then 'HEB'
            when customer_parent in ('KROGER', 'MEIJER', 'TARGET', 'WALMART')
                then initcap(customer_parent)
            when customer_parent = 'ALBERTSONS' or customer_parent like '%SAFEWAY%'
                then 'Albertsons Safeway'
            when lower(customer_parent) like '%adusa distribution llc%'
                then 'ADUSA_HANNAFORD_FOODLION'
            when lower(customer_parent) like '%hyvee%'
                then 'HY VEE'
            when lower(customer_parent) like '%adusa giant food%'
                then 'ADUSA_GIANT_FOOD'
            when lower(customer_parent) like '%stop%'
                then 'ADUSA_STOP_AND_SHOP'
            when customer_parent like 'ADUSA GIANT COMPANY%'
                then 'ADUSA_GIANT_COMPANY'
            when lower(customer_parent) like '%publix%'
                then 'INSTACART_PUBLIX'
        end as customer_parent
        , case
            when length(ean_upc_derived_cd) = 14 and LEFT(ean_upc_derived_cd, 3) in ('100', '000')
                then substr(ean_upc_derived_cd, 4)
            when length(ean_upc_derived_cd) = 13 and LEFT(ean_upc_derived_cd, 1) = '0'
                then cast(cast(ean_upc_derived_cd as INT64) as STRING)
            else ean_upc_derived_cd
        end as ean_upc_derived_cd
        , fiscal_week_begin_dt
        , avg(cf_numerator) as casefill_numerator
        , avg(cf_denominator) as casefill_denominator
        , safe_divide(avg(cf_numerator), avg(cf_denominator)) as casefill_percentage
    from 
`{{params.ECOMM_DLF}}`.processed.casefill_na_weekly
    where (customer_parent in ('HEB SAN ANTONIO DRY ***', 'KROGER', 'MEIJER', 'TARGET', 'WALMART', 'ALBERTSONS')
    or customer_parent like '%SAFEWAY%'
    or lower(customer_parent) like '%hannaford%'
    or lower(customer_parent) like '%hyvee%'
    or lower(customer_parent) like '%giant food%'
    or lower(customer_parent) like '%stop%'
    or lower(customer_parent) like '%giant company%'
    or lower(customer_parent) like '%adusa%'
    or lower(customer_parent) like '%publix%')
    group by
        customer_parent
        , ean_upc_derived_cd
        , fiscal_week_begin_dt
),
brand as (
select
  av.store_zipcode,
  av.store_display_name,
  av.unique_store_composite_key,
  av.ean_upc_cd,
  av.sls_hier_division_desc,
  av.sls_hier_category_desc,
  av.sls_hier_sub_category_desc,
  av.material_short_desc,
  av.consecutive_missing_weeks,
  av.cm_tdp_reach,
  av.is_available,
  av.is_instore,
  av.is_online,
  av.is_instore_distribution_authorized,
  av.is_online_distribution,
  av.is_online_distribution_authorized,
  av.fiscal_month_period_desc,
  av.fiscal_week_begin_dt_desc,
  av.fiscal_month_in_year_nbr,
  av.fiscal_year_nbr,
  av.fiscal_quarter_in_year_nbr,
  av.fiscal_month_in_year_short_desc,
  av.fiscal_week_begin_dt,
  av.fiscal_year_short_desc,
  av.report_fg,
  av.retailer_type,
  av.customer_parent,
  av.customer_account,
  av.customer_name,
  av.available_count,
  av.ly_online_distribution_count,
  case when av.customer_account = 'INSTACART_PUBLIX' then safe_cast((gss.ty_sales_value * 0.21) as FLOAT64)
       WHEN av.customer_account = 'INSTACART_KROGER' THEN safe_cast((gss.ty_sales_value * 0.11) as FLOAT64)
       WHEN av.customer_account = 'ADUSA_FOOD_LION' THEN safe_cast((gss.ty_sales_value * 0.38) as FLOAT64)
       WHEN av.customer_account = 'ADUSA_STOP_AND_SHOP' THEN safe_cast((gss.ty_sales_value * 0.27) as FLOAT64)
       WHEN av.customer_account = 'ADUSA_HANNAFORD' THEN safe_cast((gss.ty_sales_value * 0.12) as FLOAT64)
       WHEN av.customer_account = 'ADUSA_GIANT_COMPANY' THEN safe_cast((gss.ty_sales_value * 0.14) as FLOAT64)
       WHEN av.customer_account = 'ADUSA_GIANT_FOOD' THEN safe_cast((gss.ty_sales_value * 0.09) as FLOAT64)
       ELSE safe_cast(gss.ty_sales_value as FLOAT64)
  END AS ty_sales_value,
  cs.casefill_percentage
 ,av.stores_selling_delivery_amt as stores_selling_delivery_amt
 ,av.stores_selling_in_store_amt as stores_selling_in_store_amt
 ,av.stores_selling_ecom_amt as stores_selling_ecom_amt
 ,av.stores_selling_pickup_amt as stores_selling_pickup_amt
 ,av.stores_selling_total_amt as stores_selling_total_amt
 ,case
when
  DA
   - av.stores_selling_in_store_amt < 0 then 'Yes'
when
  DA
   - av.stores_selling_in_store_amt > 0 then 'No'
when av.customer_account != 'WALMART_OPD' then 'N/A'
else 'No'
end as fp_flag
from
        (
select * from (
(select
'NULL' store_zipcode
,cast(fct.customer_account as string) as  store_display_name
,fct.customer_account unique_store_composite_key
,fct.ean_upc_cd
,fct.sls_hier_division_desc
,fct.sls_hier_category_desc
,fct.sls_hier_sub_category_desc
,fct.material_short_desc
,0 consecutive_missing_weeks
,null as cm_tdp_reach
,fct.is_available
,null is_instore
,fct.is_online
,null is_instore_distribution_authorized
,null is_online_distribution
,null is_online_distribution_authorized
,concat(cast(cal.fiscal_month_in_year_nbr as string), '-', cal.fiscal_month_in_year_short_desc) fiscal_month_period_desc
,cast(date(cal.fiscal_week_begin_dt) as string) fiscal_week_begin_dt_desc
,cal.fiscal_year_week_nbr
,cal.fiscal_month_in_year_nbr
,cal.fiscal_year_nbr
,cal.fiscal_quarter_in_year_nbr
,cal.fiscal_week_in_year_nbr
,cal.fiscal_month_in_year_short_desc
,cal.fiscal_week_begin_dt
,cal.fiscal_year_short_desc
,'Y' report_fg
,fct.retailer_type
,fct.customer_parent
,fct.customer_account
,fct.customer_name
,ifnull(fct.is_available,0) as available_count
,LEAD (ifnull(fct.is_online,0), 1,NULL)
  OVER (PARTITION BY fct.customer_account, fct.fiscal_week_in_year_nbr, fct.ean_upc_cd ORDER BY fct.fiscal_year_week_nbr DESC) ly_online_distribution_count
,null as stores_selling_delivery_amt
,null as stores_selling_in_store_amt
,null as stores_selling_ecom_amt
,null as stores_selling_pickup_amt
,null as stores_selling_total_amt
 FROM 
`{{params.ECOMM_DLF}}`.processed.amazon_prime_now_distribution_availability_with_upc_fact fct
 inner join `{{params.ECOMM_DLF}}`.processed.ecom_data_release_control cntrl
    on fct.fiscal_year_week_nbr=cntrl.fiscal_year_week_nbr
    and fct.fiscal_year_month_nbr=cntrl.fiscal_year_month_nbr
 inner join calendar cal
    on fct.fiscal_year_week_nbr = cal.fiscal_year_week_nbr
    and fct.fiscal_year_month_nbr = cal.fiscal_year_month_nbr
 where
   cntrl.staging_flg='Y' and cntrl.release_flg = 'Y'
   and
   cntrl.feed_name='AMAZON_PRIME_NOW_DISTRIBUTION_AVAILABILITY_SUBCATG_AGG_FACT')
UNION ALL
(select
'NULL' store_zipcode
,cast(fct.customer_account as string) as  store_display_name
,fct.customer_account unique_store_composite_key
,fct.ean_upc_cd
,fct.sls_hier_division_desc
,fct.sls_hier_category_desc
,fct.sls_hier_sub_category_desc
,fct.material_short_desc
,0 consecutive_missing_weeks
,null as cm_tdp_reach
,fct.is_available
,null is_instore
,fct.is_online
,null is_instore_distribution_authorized
,null is_online_distribution
,null is_online_distribution_authorized
,concat(cast(cal.fiscal_month_in_year_nbr as string), '-', cal.fiscal_month_in_year_short_desc) fiscal_month_period_desc
,cast(date(cal.fiscal_week_begin_dt) as string) fiscal_week_begin_dt_desc
,cal.fiscal_year_week_nbr
,cal.fiscal_month_in_year_nbr
,cal.fiscal_year_nbr
,cal.fiscal_quarter_in_year_nbr
,cal.fiscal_week_in_year_nbr
,cal.fiscal_month_in_year_short_desc
,cal.fiscal_week_begin_dt
,cal.fiscal_year_short_desc
,'Y' report_fg
,fct.retailer_type
,fct.customer_parent
,fct.customer_account
,fct.customer_name
,ifnull(fct.is_available,0) as available_count
,LEAD (ifnull(fct.is_online,0), 1,NULL)
  OVER (PARTITION BY fct.customer_account, fct.fiscal_week_in_year_nbr, fct.ean_upc_cd ORDER BY fct.fiscal_year_week_nbr DESC) ly_online_distribution_count
,null as stores_selling_delivery_amt
,null as stores_selling_in_store_amt
,null as stores_selling_ecom_amt
,null as stores_selling_pickup_amt
,null as stores_selling_total_amt
 FROM 
`{{params.ECOMM_DLF}}`.processed.amazon_com_distribution_availability_with_upc_fact fct
 inner join `{{params.ECOMM_DLF}}.processed.ecom_data_release_control` cntrl
    on fct.fiscal_year_week_nbr=cntrl.fiscal_year_week_nbr
    and fct.fiscal_year_month_nbr=cntrl.fiscal_year_month_nbr
 inner join calendar cal
    on fct.fiscal_year_week_nbr = cal.fiscal_year_week_nbr
    and fct.fiscal_year_month_nbr = cal.fiscal_year_month_nbr
 where
   cntrl.staging_flg='Y' and cntrl.release_flg = 'Y'
   and
   cntrl.feed_name='AMAZON_COM_DISTRIBUTION_AVAILABILITY_SUBCATG_AGG_FACT')
UNION ALL
(select
cast(fct.store_zipcode as string) as store_zipcode
,cast(fct.store_display_name as string) as store_display_name
,fct.unique_store_composite_key
,fct.ean_upc_cd
,fct.sls_hier_division_desc
,fct.sls_hier_category_desc
,fct.sls_hier_sub_category_desc
,fct.material_short_desc
,fct.consecutive_missing_weeks
,null as cm_tdp_reach
,fct.is_available
,fct.is_instore
,fct.is_online
,fct.is_instore_distribution_authorized
,fct.is_online_distribution
,fct.is_online_distribution_authorized
,concat(cast(cal.fiscal_month_in_year_nbr as string), '-', cal.fiscal_month_in_year_short_desc) fiscal_month_period_desc
,cast(date(cal.fiscal_week_begin_dt) as string) fiscal_week_begin_dt_desc
,cal.fiscal_year_week_nbr
,cal.fiscal_month_in_year_nbr
,cal.fiscal_year_nbr
,cal.fiscal_quarter_in_year_nbr
,cal.fiscal_week_in_year_nbr
,cal.fiscal_month_in_year_short_desc
,cal.fiscal_week_begin_dt
,cal.fiscal_year_short_desc
,'Y' report_fg
,fct.retailer_type
,fct.customer_parent
,fct.customer_account
,fct.customer_name
,ifnull(fct.is_available,0) as available_count
,LEAD (ifnull(fct.is_online,0), 1,NULL)
  OVER (PARTITION BY fct.customer_account, fct.fiscal_week_in_year_nbr, fct.ean_upc_cd ORDER BY fct.fiscal_year_week_nbr DESC) ly_online_distribution_count
,null as stores_selling_delivery_amt
,null as stores_selling_in_store_amt
,null as stores_selling_ecom_amt
,null as stores_selling_pickup_amt
,null as stores_selling_total_amt
FROM 
`{{params.ECOMM_DLF}}`.processed.target_distribution_availability_with_upc_fact fct
 inner join `{{params.ECOMM_DLF}}.processed.ecom_data_release_control` cntrl
    on fct.fiscal_year_week_nbr=cntrl.fiscal_year_week_nbr
    and fct.fiscal_year_month_nbr=cntrl.fiscal_year_month_nbr
 inner join calendar cal
    on fct.fiscal_year_week_nbr = cal.fiscal_year_week_nbr
    and fct.fiscal_year_month_nbr = cal.fiscal_year_month_nbr
 where
   cntrl.staging_flg='Y' and cntrl.release_flg = 'Y'
   and
   cntrl.feed_name='TARGET_DISTRIBUTION_AVAILABILITY_SUBCATG_AGG_FACT')
UNION ALL
(select
cast(fct.store_zipcode as string) as store_zipcode
,cast(fct.store_display_name as string) as store_display_name
,fct.unique_store_composite_key
,fct.ean_upc_cd
,fct.sls_hier_division_desc
,fct.sls_hier_category_desc
,fct.sls_hier_sub_category_desc
,fct.material_short_desc
,fct.consecutive_missing_weeks
,null as cm_tdp_reach
,fct.is_available
,fct.is_instore
,fct.is_online
,fct.is_instore_distribution_authorized
,fct.is_online_distribution
,fct.is_online_distribution_authorized
,concat(cast(cal.fiscal_month_in_year_nbr as string), '-', cal.fiscal_month_in_year_short_desc) fiscal_month_period_desc
,cast(date(cal.fiscal_week_begin_dt) as string) fiscal_week_begin_dt_desc
,cal.fiscal_year_week_nbr
,cal.fiscal_month_in_year_nbr
,cal.fiscal_year_nbr
,cal.fiscal_quarter_in_year_nbr
,cal.fiscal_week_in_year_nbr
,cal.fiscal_month_in_year_short_desc
,cal.fiscal_week_begin_dt
,cal.fiscal_year_short_desc
,'Y' report_fg
,fct.retailer_type
,fct.customer_parent
,fct.customer_account
,fct.customer_name
,ifnull(fct.is_available,0) as available_count
,LEAD (ifnull(fct.is_online,0), 1,NULL)
  OVER (PARTITION BY fct.customer_account, fct.fiscal_week_in_year_nbr, fct.ean_upc_cd ORDER BY fct.fiscal_year_week_nbr DESC) ly_online_distribution_count
,null as stores_selling_delivery_amt
,null as stores_selling_in_store_amt
,null as stores_selling_ecom_amt
,null as stores_selling_pickup_amt
,null as stores_selling_total_amt
 FROM 
`{{params.ECOMM_DLF}}`.processed.kroger_distribution_availability_with_upc_fact fct
 inner join `{{params.ECOMM_DLF}}.processed.ecom_data_release_control` cntrl
    on fct.fiscal_year_week_nbr=cntrl.fiscal_year_week_nbr
    and fct.fiscal_year_month_nbr=cntrl.fiscal_year_month_nbr
 inner join calendar cal
    on fct.fiscal_year_week_nbr = cal.fiscal_year_week_nbr
    and fct.fiscal_year_month_nbr = cal.fiscal_year_month_nbr
 where
   cntrl.staging_flg='Y' and cntrl.release_flg = 'Y'
   and
   cntrl.feed_name='KROGER_DISTRIBUTION_AVAILABILITY_SUBCATG_AGG_FACT')
UNION ALL
(
select
   cast(fct.store_zipcode as string) as store_zipcode
   ,cast(fct.store_display_name as string) as store_display_name
   ,fct.unique_store_composite_key
   ,fct.ean_upc_cd
   ,fct.sls_hier_division_desc
   ,fct.sls_hier_category_desc
   ,fct.sls_hier_sub_category_desc
   ,fct.material_short_desc
   ,fct.consecutive_missing_weeks
   ,null as cm_tdp_reach
   ,fct.is_available
   ,fct.is_instore
   ,fct.is_online
   ,fct.is_instore_distribution_authorized
   ,fct.is_online_distribution
   ,fct.is_online_distribution_authorized
   ,concat(cast(cal.fiscal_month_in_year_nbr as string), '-', cal.fiscal_month_in_year_short_desc) fiscal_month_period_desc
   ,cast(date(cal.fiscal_week_begin_dt) as string) fiscal_week_begin_dt_desc
   ,cal.fiscal_year_week_nbr
   ,cal.fiscal_month_in_year_nbr
   ,cal.fiscal_year_nbr
   ,cal.fiscal_quarter_in_year_nbr
   ,cal.fiscal_week_in_year_nbr
   ,cal.fiscal_month_in_year_short_desc
   ,cal.fiscal_week_begin_dt
   ,cal.fiscal_year_short_desc
   ,'Y' report_fg
   ,fct.retailer_type
   ,fct.customer_parent
   ,fct.customer_account
   ,fct.customer_name
   ,ifnull(fct.is_available,0) as available_count
   ,LEAD (ifnull(fct.is_online,0), 1,NULL)
   OVER (PARTITION BY fct.customer_account, cal.fiscal_week_in_year_nbr, fct.ean_upc_cd ORDER BY cal.fiscal_year_week_nbr DESC) ly_online_distribution_count
  ,coalesce(luminate.stores_selling_delivery_amt, delayed_luminate.stores_selling_delivery_amt)
  ,coalesce(luminate.stores_selling_in_store_amt, delayed_luminate.stores_selling_in_store_amt)
  ,coalesce(luminate.stores_selling_ecom_amt, delayed_luminate.stores_selling_ecom_amt)
  ,coalesce(luminate.stores_selling_pickup_amt, delayed_luminate.stores_selling_pickup_amt)
  ,coalesce(luminate.stores_selling_total_amt, delayed_luminate.stores_selling_total_amt)

FROM

`{{params.ECOMM_DLF}}`.processed.walmart_opd_distribution_availability_with_upc_fact fct
 inner join

`{{params.ECOMM_DLF}}`.processed.ecom_data_release_control cntrl
    on fct.fiscal_year_week_nbr=cntrl.fiscal_year_week_nbr
    and fct.fiscal_year_month_nbr=cntrl.fiscal_year_month_nbr
 inner join calendar cal
    on fct.fiscal_year_week_nbr = cal.fiscal_year_week_nbr
    and fct.fiscal_year_month_nbr = cal.fiscal_year_month_nbr
LEFT JOIN
(
select
customer_parent,
ean_upc_cd,
fiscal_week_begin_dt,
stores_selling_delivery_amt,
stores_selling_in_store_amt,
stores_selling_ecom_amt,
stores_selling_pickup_amt,
stores_selling_total_amt
from
`{{params.ECOMM_DLF}}`.processed.walmart_luminate_fact
group by
customer_parent,
ean_upc_cd,
fiscal_week_begin_dt,
stores_selling_delivery_amt,
stores_selling_in_store_amt,
stores_selling_ecom_amt,
stores_selling_pickup_amt,
stores_selling_total_amt)

luminate
ON
  fct.ean_upc_cd = luminate.ean_upc_cd
  AND fct.fiscal_week_begin_dt =
  CAST(luminate.fiscal_week_begin_dt AS DATE)

 LEFT JOIN
(
select
customer_parent,
ean_upc_cd,
fiscal_week_begin_dt,
stores_selling_delivery_amt,
stores_selling_in_store_amt,
stores_selling_ecom_amt,
stores_selling_pickup_amt,
stores_selling_total_amt
from
`{{params.ECOMM_DLF}}`.processed.walmart_luminate_fact
where fiscal_week_begin_dt in (select max(fiscal_week_begin_dt) from `ecomm-dlf-prd-634888`.processed.walmart_luminate_fact)

group by
customer_parent,
ean_upc_cd,
fiscal_week_begin_dt,
stores_selling_delivery_amt,
stores_selling_in_store_amt,
stores_selling_ecom_amt,
stores_selling_pickup_amt,
stores_selling_total_amt
)

delayed_luminate
ON
  fct.ean_upc_cd = delayed_luminate.ean_upc_cd
WHERE
   cntrl.staging_flg='Y' and cntrl.release_flg = 'Y'
   and
   cntrl.feed_name='WALMART_OPD_DISTRIBUTION_AVAILABILITY_SUBCATG_AGG_FACT'
)

UNION ALL
(select
'NULL' store_zipcode
,cast(fct.customer_account as string) as  store_display_name
,fct.customer_account unique_store_composite_key
,fct.ean_upc_cd
,fct.sls_hier_division_desc
,fct.sls_hier_category_desc
,fct.sls_hier_sub_category_desc
,fct.material_short_desc
,0 consecutive_missing_weeks
,null as cm_tdp_reach
,fct.is_available
,null is_instore
,fct.is_online
,null is_instore_distribution_authorized
,null is_online_distribution
,null is_online_distribution_authorized
,concat(cast(cal.fiscal_month_in_year_nbr as string), '-', cal.fiscal_month_in_year_short_desc) fiscal_month_period_desc
,cast(date(cal.fiscal_week_begin_dt) as string) fiscal_week_begin_dt_desc
,cal.fiscal_year_week_nbr
,cal.fiscal_month_in_year_nbr
,cal.fiscal_year_nbr
,cal.fiscal_quarter_in_year_nbr
,cal.fiscal_week_in_year_nbr
,cal.fiscal_month_in_year_short_desc
,cal.fiscal_week_begin_dt
,cal.fiscal_year_short_desc
,'Y' report_fg
,fct.retailer_type
,fct.customer_parent
,fct.customer_account
,fct.customer_name
,ifnull(fct.is_available,0) as available_count
,LEAD (ifnull(fct.is_online,0), 1,NULL)
  OVER (PARTITION BY fct.customer_account, fct.fiscal_week_in_year_nbr, fct.ean_upc_cd ORDER BY fct.fiscal_year_week_nbr DESC) ly_online_distribution_count
,null as stores_selling_delivery_amt
,null as stores_selling_in_store_amt
,null as stores_selling_ecom_amt
,null as stores_selling_pickup_amt
,null as stores_selling_total_amt
 FROM 
`{{params.ECOMM_DLF}}`.processed.amazon_fresh_distribution_availability_with_upc_fact fct
 inner join `{{params.ECOMM_DLF}}.processed.ecom_data_release_control` cntrl
    on fct.fiscal_year_week_nbr=cntrl.fiscal_year_week_nbr
    and fct.fiscal_year_month_nbr=cntrl.fiscal_year_month_nbr
 inner join calendar cal
    on fct.fiscal_year_week_nbr = cal.fiscal_year_week_nbr
    and fct.fiscal_year_month_nbr = cal.fiscal_year_month_nbr
 where
   cntrl.staging_flg='Y' and cntrl.release_flg = 'Y'
   and
   cntrl.feed_name='AMAZON_FRESH_DISTRIBUTION_AVAILABILITY_SUBCATG_AGG_FACT')
UNION ALL
(select
cast(fct.store_zipcode as string) as store_zipcode
,cast(fct.store_display_name as string) as store_display_name
,fct.unique_store_composite_key
,fct.ean_upc_cd
,fct.sls_hier_division_desc
,fct.sls_hier_category_desc
,fct.sls_hier_sub_category_desc
,fct.material_short_desc
,fct.consecutive_missing_weeks
,null as cm_tdp_reach
,fct.is_available
,fct.is_instore
,fct.is_online
,fct.is_instore_distribution_authorized
,fct.is_online_distribution
,fct.is_online_distribution_authorized
,concat(cast(cal.fiscal_month_in_year_nbr as string), '-', cal.fiscal_month_in_year_short_desc) fiscal_month_period_desc
,cast(date(cal.fiscal_week_begin_dt) as string) fiscal_week_begin_dt_desc
,cal.fiscal_year_week_nbr
,cal.fiscal_month_in_year_nbr
,cal.fiscal_year_nbr
,cal.fiscal_quarter_in_year_nbr
,cal.fiscal_week_in_year_nbr
,cal.fiscal_month_in_year_short_desc
,cal.fiscal_week_begin_dt
,cal.fiscal_year_short_desc
,'Y' report_fg
,fct.retailer_type
,fct.customer_parent
,fct.customer_account
,fct.customer_name
,ifnull(fct.is_available,0) as available_count
,LEAD (ifnull(fct.is_online,0), 1,NULL)
 OVER (PARTITION BY fct.customer_account, fct.fiscal_week_in_year_nbr, fct.ean_upc_cd ORDER BY fct.fiscal_year_week_nbr DESC) ly_online_distribution_count
,null as stores_selling_delivery_amt
,null as stores_selling_in_store_amt
,null as stores_selling_ecom_amt
,null as stores_selling_pickup_amt
,null as stores_selling_total_amt
 FROM 
`{{params.ECOMM_DLF}}`.processed.kroger_instacart_distribution_availability_with_upc_fact fct
 inner join `{{params.ECOMM_DLF}}.processed.ecom_data_release_control` cntrl
    on fct.fiscal_year_week_nbr=cntrl.fiscal_year_week_nbr
    and fct.fiscal_year_month_nbr=cntrl.fiscal_year_month_nbr
 inner join calendar cal
    on fct.fiscal_year_week_nbr = cal.fiscal_year_week_nbr
    and fct.fiscal_year_month_nbr = cal.fiscal_year_month_nbr
 where
   cntrl.staging_flg='Y' and cntrl.release_flg = 'Y'
   and
   cntrl.feed_name='KROGER_INSTACART_DISTRIBUTION_AVAILABILITY_SUBCATG_AGG_FACT')

UNION ALL
(select
cast(fct.store_zipcode as string) as store_zipcode
,cast(fct.store_display_name as string) as store_display_name
,fct.unique_store_composite_key
,fct.ean_upc_cd
,fct.sls_hier_division_desc
,fct.sls_hier_category_desc
,fct.sls_hier_sub_category_desc
,fct.material_short_desc
,fct.consecutive_missing_weeks
,null as cm_tdp_reach
,fct.is_available
,fct.is_instore
,fct.is_online
,fct.is_instore_distribution_authorized
,fct.is_online_distribution
,fct.is_online_distribution_authorized
,concat(cast(cal.fiscal_month_in_year_nbr as string), '-', cal.fiscal_month_in_year_short_desc) fiscal_month_period_desc
,cast(date(cal.fiscal_week_begin_dt) as string) fiscal_week_begin_dt_desc
,cal.fiscal_year_week_nbr
,cal.fiscal_month_in_year_nbr
,cal.fiscal_year_nbr
,cal.fiscal_quarter_in_year_nbr
,cal.fiscal_week_in_year_nbr
,cal.fiscal_month_in_year_short_desc
,cal.fiscal_week_begin_dt
,cal.fiscal_year_short_desc
,'Y' report_fg
,fct.retailer_type
,fct.customer_parent
,fct.customer_account
,fct.customer_name
,ifnull(fct.is_available,0) as available_count
,LEAD (ifnull(fct.is_online,0), 1,NULL)
  OVER (PARTITION BY fct.customer_account, fct.fiscal_week_in_year_nbr, fct.ean_upc_cd ORDER BY fct.fiscal_year_week_nbr DESC) ly_online_distribution_count
,null as stores_selling_delivery_amt
,null as stores_selling_in_store_amt
,null as stores_selling_ecom_amt
,null as stores_selling_pickup_amt
,null as stores_selling_total_amt
 FROM 
`{{params.ECOMM_DLF}}`.processed.walmart_opd_instacart_distribution_availability_with_upc_fact fct
 inner join `{{params.ECOMM_DLF}}.processed.ecom_data_release_control` cntrl
    on fct.fiscal_year_week_nbr=cntrl.fiscal_year_week_nbr
    and fct.fiscal_year_month_nbr=cntrl.fiscal_year_month_nbr
 inner join calendar cal
    on fct.fiscal_year_week_nbr = cal.fiscal_year_week_nbr
    and fct.fiscal_year_month_nbr = cal.fiscal_year_month_nbr
 where
   cntrl.staging_flg='Y' and cntrl.release_flg = 'Y'
   and
   cntrl.feed_name='WALMART_OPD_INSTACART_DISTRIBUTION_AVAILABILITY_SUBCATG_AGG_FACT')
UNION ALL
(select
cast(fct.store_zipcode as string) as store_zipcode
,cast(fct.store_display_name as string) as store_display_name
,fct.unique_store_composite_key
,fct.ean_upc_cd
,fct.sls_hier_division_desc
,fct.sls_hier_category_desc
,fct.sls_hier_sub_category_desc
,fct.material_short_desc
,fct.consecutive_missing_weeks
,null as cm_tdp_reach
,fct.is_available
,fct.is_instore
,fct.is_online
,fct.is_instore_distribution_authorized
,fct.is_online_distribution
,fct.is_online_distribution_authorized
,concat(cast(cal.fiscal_month_in_year_nbr as string), '-', cal.fiscal_month_in_year_short_desc) fiscal_month_period_desc
,cast(date(cal.fiscal_week_begin_dt) as string) fiscal_week_begin_dt_desc
,cal.fiscal_year_week_nbr
,cal.fiscal_month_in_year_nbr
,cal.fiscal_year_nbr
,cal.fiscal_quarter_in_year_nbr
,cal.fiscal_week_in_year_nbr
,cal.fiscal_month_in_year_short_desc
,cal.fiscal_week_begin_dt
,cal.fiscal_year_short_desc
,'Y' report_fg
,fct.retailer_type
,fct.customer_parent
,fct.customer_account
,fct.customer_name
,ifnull(fct.is_available,0) as available_count
,LEAD (ifnull(fct.is_online,0), 1,NULL)
  OVER (PARTITION BY fct.customer_account, fct.fiscal_week_in_year_nbr, fct.ean_upc_cd ORDER BY fct.fiscal_year_week_nbr DESC) ly_online_distribution_count
,null as stores_selling_delivery_amt
,null as stores_selling_in_store_amt
,null as stores_selling_ecom_amt
,null as stores_selling_pickup_amt
,null as stores_selling_total_amt
 FROM 
`{{params.ECOMM_DLF}}`.processed.albertsons_safeway_distribution_availability_with_upc_fact fct
 inner join `{{params.ECOMM_DLF}}.processed.ecom_data_release_control` cntrl
    on fct.fiscal_year_week_nbr=cntrl.fiscal_year_week_nbr
    and fct.fiscal_year_month_nbr=cntrl.fiscal_year_month_nbr
 inner join calendar cal
    on fct.fiscal_year_week_nbr = cal.fiscal_year_week_nbr
    and fct.fiscal_year_month_nbr = cal.fiscal_year_month_nbr
 where
   cntrl.staging_flg='Y' and cntrl.release_flg = 'Y'
   and
   cntrl.feed_name='ALBERTSONS_SAFEWAY_DISTRIBUTION_AVAILABILITY_SUBCATG_AGG_FACT')

UNION ALL
(SELECT
cast(fct.store_zipcode as string) as store_zipcode
,cast(fct.store_display_name as string) as store_display_name
,fct.unique_store_composite_key
,fct.ean_upc_cd
,fct.sls_hier_division_desc
,fct.sls_hier_category_desc
,fct.sls_hier_sub_category_desc
,fct.material_short_desc
,fct.consecutive_missing_weeks
,NULL as cm_tdp_reach
,fct.is_available
,fct.is_instore
,fct.is_online
,fct.is_instore_distribution_authorized
,fct.is_online_distribution
,fct.is_online_distribution_authorized
,concat(cast(cal.fiscal_month_in_year_nbr as string), '-', cal.fiscal_month_in_year_short_desc) fiscal_month_period_desc
,cast(date(cal.fiscal_week_begin_dt) as string) fiscal_week_begin_dt_desc
,cal.fiscal_year_week_nbr
,cal.fiscal_month_in_year_nbr
,cal.fiscal_year_nbr
,cal.fiscal_quarter_in_year_nbr
,cal.fiscal_week_in_year_nbr
,cal.fiscal_month_in_year_short_desc
,cal.fiscal_week_begin_dt
,cal.fiscal_year_short_desc
,'Y' report_fg
,fct.retailer_type
,fct.customer_parent
,fct.customer_account
,fct.customer_name
,ifnull(fct.is_available,0) as available_count
,LEAD (ifnull(fct.is_online,0), 1,NULL)
  OVER (PARTITION BY fct.customer_account, fct.fiscal_week_in_year_nbr, fct.ean_upc_cd ORDER BY fct.fiscal_year_week_nbr DESC) ly_online_distribution_count
,null as stores_selling_delivery_amt
,null as stores_selling_in_store_amt
,null as stores_selling_ecom_amt
,null as stores_selling_pickup_amt
,null as stores_selling_total_amt
 FROM `{{params.ECOMM_DLF}}`.processed.meijer_distribution_availability_with_upc_fact fct
 inner join `{{params.ECOMM_DLF}}.processed.ecom_data_release_control` cntrl
    on fct.fiscal_year_week_nbr=cntrl.fiscal_year_week_nbr
    and fct.fiscal_year_month_nbr=cntrl.fiscal_year_month_nbr
 inner join calendar cal
    on fct.fiscal_year_week_nbr = cal.fiscal_year_week_nbr
    and fct.fiscal_year_month_nbr = cal.fiscal_year_month_nbr
 where
   cntrl.staging_flg='Y' and cntrl.release_flg = 'Y'
   and
   cntrl.feed_name='MEIJER_DISTRIBUTION_AVAILABILITY_SUBCATG_AGG_FACT')

UNION ALL
(select
cast(fct.store_zipcode as string) as store_zipcode
,cast(fct.store_display_name as string) as store_display_name
,fct.unique_store_composite_key
,fct.ean_upc_cd
,fct.sls_hier_division_desc
,fct.sls_hier_category_desc
,fct.sls_hier_sub_category_desc
,fct.material_short_desc
,fct.consecutive_missing_weeks
,null as cm_tdp_reach
,fct.is_available
,fct.is_instore
,fct.is_online
,fct.is_instore_distribution_authorized
,fct.is_online_distribution
,fct.is_online_distribution_authorized
,concat(cast(cal.fiscal_month_in_year_nbr as string), '-', cal.fiscal_month_in_year_short_desc) fiscal_month_period_desc
,cast(date(cal.fiscal_week_begin_dt) as string) fiscal_week_begin_dt_desc
,cal.fiscal_year_week_nbr
,cal.fiscal_month_in_year_nbr
,cal.fiscal_year_nbr
,cal.fiscal_quarter_in_year_nbr
,cal.fiscal_week_in_year_nbr
,cal.fiscal_month_in_year_short_desc
,cal.fiscal_week_begin_dt
,cal.fiscal_year_short_desc
,'Y' report_fg
,fct.retailer_type
,fct.customer_parent
,fct.customer_account
,fct.customer_name
,ifnull(fct.is_available,0) as available_count
,LEAD (ifnull(fct.is_online,0), 1,NULL)
  OVER (PARTITION BY fct.customer_account, fct.fiscal_week_in_year_nbr, fct.ean_upc_cd ORDER BY fct.fiscal_year_week_nbr DESC) ly_online_distribution_count
,null as stores_selling_delivery_amt
,null as stores_selling_in_store_amt
,null as stores_selling_ecom_amt
,null as stores_selling_pickup_amt
,null as stores_selling_total_amt
 FROM 
`{{params.ECOMM_DLF}}`.processed.heb_distribution_availability_with_upc_fact fct
 inner join `{{params.ECOMM_DLF}}.processed.ecom_data_release_control` cntrl
    on fct.fiscal_year_week_nbr=cntrl.fiscal_year_week_nbr
    and fct.fiscal_year_month_nbr=cntrl.fiscal_year_month_nbr
 inner join calendar cal
    on fct.fiscal_year_week_nbr = cal.fiscal_year_week_nbr
    and fct.fiscal_year_month_nbr = cal.fiscal_year_month_nbr
 where
   cntrl.staging_flg='Y' and cntrl.release_flg = 'Y'
   and
   cntrl.feed_name='HEB_DISTRIBUTION_AVAILABILITY_SUBCATG_AGG_FACT')
UNION ALL
(select
cast(fct.store_zipcode as string) as store_zipcode
,cast(fct.store_display_name as string) as store_display_name
,fct.unique_store_composite_key
,fct.ean_upc_cd
,fct.sls_hier_division_desc
,fct.sls_hier_category_desc
,fct.sls_hier_sub_category_desc
,fct.material_short_desc
,fct.consecutive_missing_weeks
,null as cm_tdp_reach
,fct.is_available
,fct.is_instore
,fct.is_online
,fct.is_instore_distribution_authorized
,fct.is_online_distribution
,fct.is_online_distribution_authorized
,concat(cast(cal.fiscal_month_in_year_nbr as string), '-', cal.fiscal_month_in_year_short_desc) fiscal_month_period_desc
,cast(date(cal.fiscal_week_begin_dt) as string) fiscal_week_begin_dt_desc
,cal.fiscal_year_week_nbr
,cal.fiscal_month_in_year_nbr
,cal.fiscal_year_nbr
,cal.fiscal_quarter_in_year_nbr
,cal.fiscal_week_in_year_nbr
,cal.fiscal_month_in_year_short_desc
,cal.fiscal_week_begin_dt
,cal.fiscal_year_short_desc
,'Y' report_fg
,fct.retailer_type
,fct.customer_parent
,fct.customer_account
,fct.customer_name
,ifnull(fct.is_available,0) as available_count
,LEAD (ifnull(fct.is_online,0), 1,NULL)
  OVER (PARTITION BY fct.customer_account, fct.fiscal_week_in_year_nbr, fct.ean_upc_cd ORDER BY fct.fiscal_year_week_nbr DESC) ly_online_distribution_count
,null as stores_selling_delivery_amt
,null as stores_selling_in_store_amt
,null as stores_selling_ecom_amt
,null as stores_selling_pickup_amt
,null as stores_selling_total_amt
 FROM 
`{{params.ECOMM_DLF}}`.processed.sams_club_distribution_availability_with_upc_fact fct
 inner join `{{params.ECOMM_DLF}}.processed.ecom_data_release_control` cntrl
    on fct.fiscal_year_week_nbr=cntrl.fiscal_year_week_nbr
    and fct.fiscal_year_month_nbr=cntrl.fiscal_year_month_nbr
 inner join calendar cal
    on fct.fiscal_year_week_nbr = cal.fiscal_year_week_nbr
    and fct.fiscal_year_month_nbr = cal.fiscal_year_month_nbr
 where
   cntrl.staging_flg='Y' and cntrl.release_flg = 'Y'
   and
   cntrl.feed_name='SAMS_CLUB_DISTRIBUTION_AVAILABILITY_SUBCATG_AGG_FACT')
UNION ALL
(select
cast(fct.store_zipcode as string) as store_zipcode
,cast(fct.store_display_name as string) as store_display_name
,fct.unique_store_composite_key
,fct.ean_upc_cd
,fct.sls_hier_division_desc
,fct.sls_hier_category_desc
,fct.sls_hier_sub_category_desc
,fct.material_short_desc
,fct.consecutive_missing_weeks
,null as cm_tdp_reach
,fct.is_available
,fct.is_instore
,fct.is_online
,fct.is_instore_distribution_authorized
,fct.is_online_distribution
,fct.is_online_distribution_authorized
,concat(cast(cal.fiscal_month_in_year_nbr as string), '-', cal.fiscal_month_in_year_short_desc) fiscal_month_period_desc
,cast(date(cal.fiscal_week_begin_dt) as string) fiscal_week_begin_dt_desc
,cal.fiscal_year_week_nbr
,cal.fiscal_month_in_year_nbr
,cal.fiscal_year_nbr
,cal.fiscal_quarter_in_year_nbr
,cal.fiscal_week_in_year_nbr
,cal.fiscal_month_in_year_short_desc
,cal.fiscal_week_begin_dt
,cal.fiscal_year_short_desc
,'Y' report_fg
,fct.retailer_type
,fct.customer_parent
,fct.customer_account
,fct.customer_name
,ifnull(fct.is_available,0) as available_count
,LEAD (ifnull(fct.is_online,0), 1,NULL)
  OVER (PARTITION BY fct.customer_account, fct.fiscal_week_in_year_nbr, fct.ean_upc_cd ORDER BY fct.fiscal_year_week_nbr DESC) ly_online_distribution_count
,null as stores_selling_delivery_amt
,null as stores_selling_in_store_amt
,null as stores_selling_ecom_amt
,null as stores_selling_pickup_amt
,null as stores_selling_total_amt
 FROM 
`{{params.ECOMM_DLF}}`.processed.hannaford_distribution_availability_with_upc_fact fct
 inner join `{{params.ECOMM_DLF}}.processed.ecom_data_release_control` cntrl
    on fct.fiscal_year_week_nbr=cntrl.fiscal_year_week_nbr
    and fct.fiscal_year_month_nbr=cntrl.fiscal_year_month_nbr
 inner join calendar cal
    on fct.fiscal_year_week_nbr = cal.fiscal_year_week_nbr
    and fct.fiscal_year_month_nbr = cal.fiscal_year_month_nbr
 where
   cntrl.staging_flg='Y' and cntrl.release_flg = 'Y'
   and
   cntrl.feed_name='HANNAFORD_DISTRIBUTION_AVAILABILITY_SUBCATG_AGG_FACT')
UNION ALL
(select
cast(fct.store_zipcode as string) as store_zipcode
,cast(fct.store_display_name as string) as store_display_name
,fct.unique_store_composite_key
,fct.ean_upc_cd
,fct.sls_hier_division_desc
,fct.sls_hier_category_desc
,fct.sls_hier_sub_category_desc
,fct.material_short_desc
,fct.consecutive_missing_weeks
,null as cm_tdp_reach
,fct.is_available
,fct.is_instore
,fct.is_online
,fct.is_instore_distribution_authorized
,fct.is_online_distribution
,fct.is_online_distribution_authorized
,concat(cast(cal.fiscal_month_in_year_nbr as string), '-', cal.fiscal_month_in_year_short_desc) fiscal_month_period_desc
,cast(date(cal.fiscal_week_begin_dt) as string) fiscal_week_begin_dt_desc
,cal.fiscal_year_week_nbr
,cal.fiscal_month_in_year_nbr
,cal.fiscal_year_nbr
,cal.fiscal_quarter_in_year_nbr
,cal.fiscal_week_in_year_nbr
,cal.fiscal_month_in_year_short_desc
,cal.fiscal_week_begin_dt
,cal.fiscal_year_short_desc
,'Y' report_fg
,fct.retailer_type
,fct.customer_parent
,fct.customer_account
,fct.customer_name
,ifnull(fct.is_available,0) as available_count
,LEAD (ifnull(fct.is_online,0), 1,NULL)
  OVER (PARTITION BY fct.customer_account, fct.fiscal_week_in_year_nbr, fct.ean_upc_cd ORDER BY fct.fiscal_year_week_nbr DESC) ly_online_distribution_count
,null as stores_selling_delivery_amt
,null as stores_selling_in_store_amt
,null as stores_selling_ecom_amt
,null as stores_selling_pickup_amt
,null as stores_selling_total_amt
 FROM 
`{{params.ECOMM_DLF}}`.processed.food_lion_distribution_availability_with_upc_fact fct
 inner join `{{params.ECOMM_DLF}}.processed.ecom_data_release_control` cntrl
    on fct.fiscal_year_week_nbr=cntrl.fiscal_year_week_nbr
    and fct.fiscal_year_month_nbr=cntrl.fiscal_year_month_nbr
 inner join calendar cal
    on fct.fiscal_year_week_nbr = cal.fiscal_year_week_nbr
    and fct.fiscal_year_month_nbr = cal.fiscal_year_month_nbr
 where
   cntrl.staging_flg='Y' and cntrl.release_flg = 'Y'
   and
   cntrl.feed_name='FOOD_LION_DISTRIBUTION_AVAILABILITY_SUBCATG_AGG_FACT')
UNION ALL
(select
cast(fct.store_zipcode as string) as store_zipcode
,cast(fct.store_display_name as string) as store_display_name
,fct.unique_store_composite_key
,fct.ean_upc_cd
,fct.sls_hier_division_desc
,fct.sls_hier_category_desc
,fct.sls_hier_sub_category_desc
,fct.material_short_desc
,fct.consecutive_missing_weeks
,null as cm_tdp_reach
,fct.is_available
,fct.is_instore
,fct.is_online
,fct.is_instore_distribution_authorized
,fct.is_online_distribution
,fct.is_online_distribution_authorized
,concat(cast(cal.fiscal_month_in_year_nbr as string), '-', cal.fiscal_month_in_year_short_desc) fiscal_month_period_desc
,cast(date(cal.fiscal_week_begin_dt) as string) fiscal_week_begin_dt_desc
,cal.fiscal_year_week_nbr
,cal.fiscal_month_in_year_nbr
,cal.fiscal_year_nbr
,cal.fiscal_quarter_in_year_nbr
,cal.fiscal_week_in_year_nbr
,cal.fiscal_month_in_year_short_desc
,cal.fiscal_week_begin_dt
,cal.fiscal_year_short_desc
,'Y' report_fg
,fct.retailer_type
,fct.customer_parent
,fct.customer_account
,fct.customer_name
,ifnull(fct.is_available,0) as available_count
,LEAD (ifnull(fct.is_online,0), 1,NULL)
  OVER (PARTITION BY fct.customer_account, fct.fiscal_week_in_year_nbr, fct.ean_upc_cd ORDER BY fct.fiscal_year_week_nbr DESC) ly_online_distribution_count
,null as stores_selling_delivery_amt
,null as stores_selling_in_store_amt
,null as stores_selling_ecom_amt
,null as stores_selling_pickup_amt
,null as stores_selling_total_amt
 FROM 
`{{params.ECOMM_DLF}}`.processed.hyvee_distribution_availability_with_upc_fact fct
 inner join `{{params.ECOMM_DLF}}.processed.ecom_data_release_control` cntrl
    on fct.fiscal_year_week_nbr=cntrl.fiscal_year_week_nbr
    and fct.fiscal_year_month_nbr=cntrl.fiscal_year_month_nbr
 inner join calendar cal
    on fct.fiscal_year_week_nbr = cal.fiscal_year_week_nbr
    and fct.fiscal_year_month_nbr = cal.fiscal_year_month_nbr
 where
   cntrl.staging_flg='Y' and cntrl.release_flg = 'Y'
   and
   cntrl.feed_name='HYVEE_DISTRIBUTION_AVAILABILITY_SUBCATG_AGG_FACT')
UNION ALL
(select
cast(fct.store_zipcode as string) as store_zipcode
,cast(fct.store_display_name as string) as store_display_name
,fct.unique_store_composite_key
,fct.ean_upc_cd
,fct.sls_hier_division_desc
,fct.sls_hier_category_desc
,fct.sls_hier_sub_category_desc
,fct.material_short_desc
,fct.consecutive_missing_weeks
,null as cm_tdp_reach
,fct.is_available
,fct.is_instore
,fct.is_online
,fct.is_instore_distribution_authorized
,fct.is_online_distribution
,fct.is_online_distribution_authorized
,concat(cast(cal.fiscal_month_in_year_nbr as string), '-', cal.fiscal_month_in_year_short_desc) fiscal_month_period_desc
,cast(date(cal.fiscal_week_begin_dt) as string) fiscal_week_begin_dt_desc
,cal.fiscal_year_week_nbr
,cal.fiscal_month_in_year_nbr
,cal.fiscal_year_nbr
,cal.fiscal_quarter_in_year_nbr
,cal.fiscal_week_in_year_nbr
,cal.fiscal_month_in_year_short_desc
,cal.fiscal_week_begin_dt
,cal.fiscal_year_short_desc
,'Y' report_fg
,fct.retailer_type
,fct.customer_parent
,fct.customer_account
,fct.customer_name
,ifnull(fct.is_available,0) as available_count
,LEAD (ifnull(fct.is_online,0), 1,NULL)
  OVER (PARTITION BY fct.customer_account, fct.fiscal_week_in_year_nbr, fct.ean_upc_cd ORDER BY fct.fiscal_year_week_nbr DESC) ly_online_distribution_count
,null as stores_selling_delivery_amt
,null as stores_selling_in_store_amt
,null as stores_selling_ecom_amt
,null as stores_selling_pickup_amt
,null as stores_selling_total_amt
 FROM 
`{{params.ECOMM_DLF}}`.processed.giant_food_distribution_availability_with_upc_fact fct
 inner join `{{params.ECOMM_DLF}}.processed.ecom_data_release_control` cntrl
    on fct.fiscal_year_week_nbr=cntrl.fiscal_year_week_nbr
    and fct.fiscal_year_month_nbr=cntrl.fiscal_year_month_nbr
 inner join calendar cal
    on fct.fiscal_year_week_nbr = cal.fiscal_year_week_nbr
    and fct.fiscal_year_month_nbr = cal.fiscal_year_month_nbr
 where
   cntrl.staging_flg='Y' and cntrl.release_flg = 'Y'
   and
   cntrl.feed_name='GIANT_FOOD_DISTRIBUTION_AVAILABILITY_SUBCATG_AGG_FACT')
UNION ALL
(select
cast(fct.store_zipcode as string) as store_zipcode
,cast(fct.store_display_name as string) as store_display_name
,fct.unique_store_composite_key
,fct.ean_upc_cd
,fct.sls_hier_division_desc
,fct.sls_hier_category_desc
,fct.sls_hier_sub_category_desc
,fct.material_short_desc
,fct.consecutive_missing_weeks
,null as cm_tdp_reach
,fct.is_available
,fct.is_instore
,fct.is_online
,fct.is_instore_distribution_authorized
,fct.is_online_distribution
,fct.is_online_distribution_authorized
,concat(cast(cal.fiscal_month_in_year_nbr as string), '-', cal.fiscal_month_in_year_short_desc) fiscal_month_period_desc
,cast(date(cal.fiscal_week_begin_dt) as string) fiscal_week_begin_dt_desc
,cal.fiscal_year_week_nbr
,cal.fiscal_month_in_year_nbr
,cal.fiscal_year_nbr
,cal.fiscal_quarter_in_year_nbr
,cal.fiscal_week_in_year_nbr
,cal.fiscal_month_in_year_short_desc
,cal.fiscal_week_begin_dt
,cal.fiscal_year_short_desc
,'Y' report_fg
,fct.retailer_type
,fct.customer_parent
,fct.customer_account
,fct.customer_name
,ifnull(fct.is_available,0) as available_count
,LEAD (ifnull(fct.is_online,0), 1,NULL)
  OVER (PARTITION BY fct.customer_account, fct.fiscal_week_in_year_nbr, fct.ean_upc_cd ORDER BY fct.fiscal_year_week_nbr DESC) ly_online_distribution_count
,null as stores_selling_delivery_amt
,null as stores_selling_in_store_amt
,null as stores_selling_ecom_amt
,null as stores_selling_pickup_amt
,null as stores_selling_total_amt
 FROM 
`{{params.ECOMM_DLF}}`.processed.shoprite_distribution_availability_with_upc_fact fct
 inner join `{{params.ECOMM_DLF}}.processed.ecom_data_release_control` cntrl
    on fct.fiscal_year_week_nbr=cntrl.fiscal_year_week_nbr
    and fct.fiscal_year_month_nbr=cntrl.fiscal_year_month_nbr
 inner join calendar cal
    on fct.fiscal_year_week_nbr = cal.fiscal_year_week_nbr
    and fct.fiscal_year_month_nbr = cal.fiscal_year_month_nbr
 where
   cntrl.staging_flg='Y' and cntrl.release_flg = 'Y'
   and
   cntrl.feed_name='SHOPRITE_DISTRIBUTION_AVAILABILITY_SUBCATG_AGG_FACT')
UNION ALL
(select
cast(fct.store_zipcode as string) as store_zipcode
,cast(fct.store_display_name as string) as store_display_name
,fct.unique_store_composite_key
,fct.ean_upc_cd
,fct.sls_hier_division_desc
,fct.sls_hier_category_desc
,fct.sls_hier_sub_category_desc
,fct.material_short_desc
,fct.consecutive_missing_weeks
,fct.cm_tdp_reach
,fct.is_available
,fct.is_instore
,fct.is_online
,fct.is_instore_distribution_authorized
,fct.is_online_distribution
,fct.is_online_distribution_authorized
,concat(cast(cal.fiscal_month_in_year_nbr as string), '-', cal.fiscal_month_in_year_short_desc) fiscal_month_period_desc
,cast(date(cal.fiscal_week_begin_dt) as string) fiscal_week_begin_dt_desc
,cal.fiscal_year_week_nbr
,cal.fiscal_month_in_year_nbr
,cal.fiscal_year_nbr
,cal.fiscal_quarter_in_year_nbr
,cal.fiscal_week_in_year_nbr
,cal.fiscal_month_in_year_short_desc
,cal.fiscal_week_begin_dt
,cal.fiscal_year_short_desc
,'Y' report_fg
,fct.retailer_type
,"Instacart" as customer_parent
,"INSTACART_PUBLIX" as customer_account
,fct.customer_name
,ifnull(fct.is_available,0) as available_count
,LEAD (ifnull(fct.is_online,0), 1,NULL)
  OVER (PARTITION BY fct.customer_account, fct.fiscal_week_in_year_nbr, fct.ean_upc_cd ORDER BY fct.fiscal_year_week_nbr DESC) ly_online_distribution_count
,null as stores_selling_delivery_amt
,null as stores_selling_in_store_amt
,null as stores_selling_ecom_amt
,null as stores_selling_pickup_amt
,null as stores_selling_total_amt
 FROM 
`{{params.ECOMM_DLF}}`.processed.publix_instacart_distribution_availability_with_upc_fact fct
 inner join `{{params.ECOMM_DLF}}.processed.ecom_data_release_control` cntrl
    on fct.fiscal_year_week_nbr=cntrl.fiscal_year_week_nbr
    and fct.fiscal_year_month_nbr=cntrl.fiscal_year_month_nbr
 inner join calendar cal
    on fct.fiscal_year_week_nbr = cal.fiscal_year_week_nbr
    and fct.fiscal_year_month_nbr = cal.fiscal_year_month_nbr
 where
   cntrl.staging_flg='Y' and cntrl.release_flg = 'Y'
   and
   cntrl.feed_name='PUBLIX_INSTACART_DISTRIBUTION_AVAILABILITY_SUBCATG_AGG_FACT')
UNION ALL
(select
cast(fct.store_zipcode as string) as store_zipcode
,cast(fct.store_display_name as string) as store_display_name
,fct.unique_store_composite_key
,fct.ean_upc_cd
,fct.sls_hier_division_desc
,fct.sls_hier_category_desc
,fct.sls_hier_sub_category_desc
,fct.material_short_desc
,fct.consecutive_missing_weeks
,null as cm_tdp_reach
,fct.is_available
,fct.is_instore
,fct.is_online
,fct.is_instore_distribution_authorized
,fct.is_online_distribution
,fct.is_online_distribution_authorized
,concat(cast(cal.fiscal_month_in_year_nbr as string), '-', cal.fiscal_month_in_year_short_desc) fiscal_month_period_desc
,cast(date(cal.fiscal_week_begin_dt) as string) fiscal_week_begin_dt_desc
,cal.fiscal_year_week_nbr
,cal.fiscal_month_in_year_nbr
,cal.fiscal_year_nbr
,cal.fiscal_quarter_in_year_nbr
,cal.fiscal_week_in_year_nbr
,cal.fiscal_month_in_year_short_desc
,cal.fiscal_week_begin_dt
,cal.fiscal_year_short_desc
,'Y' report_fg
,fct.retailer_type
,fct.customer_parent
,fct.customer_account
,fct.customer_name
,ifnull(fct.is_available,0) as available_count
,LEAD (ifnull(fct.is_online,0), 1,NULL)
  OVER (PARTITION BY fct.customer_account, fct.fiscal_week_in_year_nbr, fct.ean_upc_cd ORDER BY fct.fiscal_year_week_nbr DESC) ly_online_distribution_count
,null as stores_selling_delivery_amt
,null as stores_selling_in_store_amt
,null as stores_selling_ecom_amt
,null as stores_selling_pickup_amt
,null as stores_selling_total_amt
 FROM 
`{{params.ECOMM_DLF}}`.processed.giant_co_distribution_availability_with_upc_fact fct
 inner join `{{params.ECOMM_DLF}}.processed.ecom_data_release_control` cntrl
    on fct.fiscal_year_week_nbr=cntrl.fiscal_year_week_nbr
    and fct.fiscal_year_month_nbr=cntrl.fiscal_year_month_nbr
 inner join calendar cal
    on fct.fiscal_year_week_nbr = cal.fiscal_year_week_nbr
    and fct.fiscal_year_month_nbr = cal.fiscal_year_month_nbr
 where
   cntrl.staging_flg='Y' and cntrl.release_flg = 'Y'
   and
   cntrl.feed_name='GIANT_CO_DISTRIBUTION_AVAILABILITY_SUBCATG_AGG_FACT')
UNION ALL
(select
cast(fct.store_zipcode as string) as store_zipcode
,cast(fct.store_display_name as string) as store_display_name
,fct.unique_store_composite_key
,fct.ean_upc_cd
,fct.sls_hier_division_desc
,fct.sls_hier_category_desc
,fct.sls_hier_sub_category_desc
,fct.material_short_desc
,fct.consecutive_missing_weeks
,null as cm_tdp_reach
,fct.is_available
,fct.is_instore
,fct.is_online
,fct.is_instore_distribution_authorized
,fct.is_online_distribution
,fct.is_online_distribution_authorized
,concat(cast(cal.fiscal_month_in_year_nbr as string), '-', cal.fiscal_month_in_year_short_desc) fiscal_month_period_desc
,cast(date(cal.fiscal_week_begin_dt) as string) fiscal_week_begin_dt_desc
,cal.fiscal_year_week_nbr
,cal.fiscal_month_in_year_nbr
,cal.fiscal_year_nbr
,cal.fiscal_quarter_in_year_nbr
,cal.fiscal_week_in_year_nbr
,cal.fiscal_month_in_year_short_desc
,cal.fiscal_week_begin_dt
,cal.fiscal_year_short_desc
,'Y' report_fg
,fct.retailer_type
,fct.customer_parent
,fct.customer_account
,fct.customer_name
,ifnull(fct.is_available,0) as available_count
,LEAD (ifnull(fct.is_online,0), 1,NULL)
 OVER (PARTITION BY fct.customer_account, fct.fiscal_week_in_year_nbr, fct.ean_upc_cd ORDER BY fct.fiscal_year_week_nbr DESC) ly_online_distribution_count
,null as stores_selling_delivery_amt
,null as stores_selling_in_store_amt
,null as stores_selling_ecom_amt
,null as stores_selling_pickup_amt
,null as stores_selling_total_amt
 FROM 
`{{params.ECOMM_DLF}}`.processed.stop_and_shop_distribution_availability_with_upc_fact fct
 inner join `{{params.ECOMM_DLF}}.processed.ecom_data_release_control` cntrl
    on fct.fiscal_year_week_nbr=cntrl.fiscal_year_week_nbr
    and fct.fiscal_year_month_nbr=cntrl.fiscal_year_month_nbr
 inner join calendar cal
    on fct.fiscal_year_week_nbr = cal.fiscal_year_week_nbr
    and fct.fiscal_year_month_nbr = cal.fiscal_year_month_nbr
 where
   cntrl.staging_flg='Y' and cntrl.release_flg = 'Y'
   and
   cntrl.feed_name='STOP_AND_SHOP_DISTRIBUTION_AVAILABILITY_SUBCATG_AGG_FACT')
)) av
left join gss
    on av.ean_upc_cd = gss.ean_upc_cd
    and (upper(av.customer_name) = upper(gss.customer_name)
     or upper(av.customer_parent) = upper(gss.customer_name))
    and av.fiscal_week_begin_dt = gss.fiscal_week_begin_dt
left join casefill cs
     on (upper(av.customer_parent) = upper(cs.customer_parent)
     or upper(cs.customer_parent) like REGEXP_EXTRACT(upper(av.customer_account),'KROGER')
     or upper(cs.customer_parent) like REGEXP_EXTRACT(upper(av.customer_account), 'WALMART')
     or upper(cs.customer_parent) like REGEXP_EXTRACT(upper(av.customer_account), 'INSTACART_PUBLIX')
     or upper(cs.customer_parent) like REGEXP_EXTRACT(upper(av.customer_account), 'ADUSA_GIANT_FOOD')
     or upper(cs.customer_parent) like REGEXP_EXTRACT(upper(av.customer_account), 'ADUSA_GIANT_COMPANY')
     or upper(cs.customer_parent) like REGEXP_EXTRACT(upper(av.customer_account), 'ADUSA_STOP_AND_SHOP')
     or REGEXP_EXTRACT(upper(cs.customer_parent), 'HANNAFORD') like REGEXP_EXTRACT(upper(av.customer_account), 'HANNAFORD')
     or REGEXP_EXTRACT(upper(cs.customer_parent), 'FOODLION') like REGEXP_EXTRACT(upper(av.customer_account), 'FOODLION'))
    and av.ean_upc_cd = cs.ean_upc_derived_cd
    and av.fiscal_week_begin_dt = cs.fiscal_week_begin_dt

left join avg_online_assortment
on av.ean_upc_cd = avg_online_assortment.ean_upc_cd
AND av.fiscal_week_begin_dt = avg_online_assortment.fiscal_week_begin_dt


WHERE upper(av.sls_hier_division_desc) in ('MEALS-BAKING','MORNING FOODS','SNACKS'))
select
brand.store_zipcode,
brand.store_display_name,
brand.unique_store_composite_key,
brand.ean_upc_cd,
brand.sls_hier_division_desc,
brand.sls_hier_category_desc,
brand.sls_hier_sub_category_desc,
brand.material_short_desc,
dpa.consumer_brand_desc as brand_desc,
brand.consecutive_missing_weeks,
brand.cm_tdp_reach,
brand.is_available,
brand.is_instore,
brand.is_online,
brand.is_instore_distribution_authorized,
brand.is_online_distribution,
brand.is_online_distribution_authorized,
brand.fiscal_month_period_desc,
brand.fiscal_week_begin_dt_desc,
brand.fiscal_month_in_year_nbr,
brand.fiscal_year_nbr,
brand.fiscal_quarter_in_year_nbr,
brand.fiscal_month_in_year_short_desc,
brand.fiscal_week_begin_dt,
brand.fiscal_year_short_desc,
brand.report_fg,
brand.retailer_type,
brand.customer_parent,
brand.customer_account,
brand.customer_name,
brand.available_count,
brand.ly_online_distribution_count,
brand.ty_sales_value,
brand.casefill_percentage,
brand.stores_selling_delivery_amt,
brand.stores_selling_in_store_amt,
brand.stores_selling_ecom_amt,
brand.stores_selling_pickup_amt,
brand.stores_selling_total_amt,
brand.fp_flag

from brand LEFT JOIN
`edw-prd-e567f9.enterprise.dim_product_active` dpa
on brand.ean_upc_cd=dpa.ean_upc_cd and brand.material_short_desc=dpa.material_short_desc
WHERE dpa.language_cd = 'EN';

CALL `{{params.ECOMM_DLF}}.processed.sp_apply_rls_policies_on_tables`(
  "{{params.ECOMM_ANALYTICS}}",
  "output",
  "{{params.ECOMM_ANALYTICS}}",
  "processed",
  "ecomm_common_customer_info",
  "'assortment_availability_report'",
  TRUE
);
