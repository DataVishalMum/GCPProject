/* Truncate exsting data           */
TRUNCATE TABLE output.upc_conversions_report;

/*Insert reporting data into table */
insert into  output.upc_conversions_report


(

select uc.* from
        (
Select * from (
(SELECT
	COALESCE(dna.fiscal_week_begin_dt,gss.fiscal_week_begin_dt) fiscal_week_begin_dt,
	COALESCE(dna.customer_account,gss.customer_account) customer_account,
	COALESCE(dna.customer_parent,gss.customer_parent) customer_parent,
	COALESCE(dna.customer_name,gss.customer_name) customer_name,
	COALESCE(dna.old_ean_upc_cd,gss.old_ean_upc_cd) old_ean_upc_cd,
    COALESCE(dna.new_ean_upc_cd,gss.new_ean_upc_cd) new_ean_upc_cd,
	COALESCE(dna.conversion_date,gss.conversion_date) conversion_date,
	COALESCE(dna.old_sls_hier_division_desc,gss.old_sls_hier_division_desc) as old_sls_hier_division_desc,
	COALESCE(dna.old_sls_hier_category_desc,gss.old_sls_hier_category_desc) as old_sls_hier_category_desc,
	COALESCE(dna.old_sls_hier_sub_category_desc,gss.old_sls_hier_sub_category_desc) as old_sls_hier_sub_category_desc,
	COALESCE(dna.old_sls_hier_ppg_desc,gss.old_sls_hier_ppg_desc) as old_sls_hier_ppg_desc,
	COALESCE(dna.old_material_short_desc,gss.old_material_short_desc) as old_material_short_desc,
	COALESCE(dna.new_sls_hier_division_desc,gss.new_sls_hier_division_desc) as new_sls_hier_division_desc,
	COALESCE(dna.new_sls_hier_category_desc,gss.new_sls_hier_category_desc) as new_sls_hier_category_desc,
	COALESCE(dna.new_sls_hier_sub_category_desc,gss.new_sls_hier_sub_category_desc) as new_sls_hier_sub_category_desc,
	COALESCE(dna.new_sls_hier_ppg_desc,gss.new_sls_hier_ppg_desc) as new_sls_hier_ppg_desc,
	COALESCE(dna.new_material_short_desc,gss.new_material_short_desc) as new_material_short_desc,
    dna.old_ean_instore_distribution_count,
    dna.old_ean_online_distribution_count,
    dna.new_ean_instore_distribution_count,
    dna.new_ean_online_distribution_count,
	COALESCE(dna.new_ean_display_name,gss.new_ean_display_name) new_ean_display_name,
	COALESCE(dna.old_ean_display_name,gss.old_ean_display_name) old_ean_display_name,
    gss.new_ty_sales_value_usd,
	gss.old_ty_sales_value_usd,
    gss.old_ty_sales_eqc_units,
    gss.new_ty_sales_eqc_units,
	gss.old_ean_avg_ty_sales_eqc,
    dna.old_ean_avg_instore_distribution,
    dna.old_ean_avg_online_distribution,
	gss.old_ean_avg_ty_sales_value_usd,
	case when dna.modified_datetime > gss.modified_datetime then dna.modified_datetime
		 else COALESCE(gss.modified_datetime,dna.modified_datetime) end as modified_datetime
from `ecomm-dlf-prd-634888`.processed.meijer_distribution_availability_upc_conversions dna
full outer join
`ecomm-dlf-prd-634888`.processed.meijer_sales_share_upc_conversions gss
on
dna.old_ean_upc_cd = gss.old_ean_upc_cd
and dna.new_ean_upc_cd = gss.new_ean_upc_cd
and dna.conversion_date = gss.conversion_date
and dna.fiscal_week_begin_dt = gss.fiscal_week_begin_dt)

UNION ALL

(SELECT
	COALESCE(dna.fiscal_week_begin_dt,gss.fiscal_week_begin_dt) fiscal_week_begin_dt,
	COALESCE(dna.customer_account,gss.customer_account) customer_account,
	COALESCE(dna.customer_parent,gss.customer_parent) customer_parent,
	COALESCE(dna.customer_name,gss.customer_name) customer_name,
	COALESCE(dna.old_ean_upc_cd,gss.old_ean_upc_cd) old_ean_upc_cd,
    COALESCE(dna.new_ean_upc_cd,gss.new_ean_upc_cd) new_ean_upc_cd,
	COALESCE(dna.conversion_date,gss.conversion_date) conversion_date,
	COALESCE(dna.old_sls_hier_division_desc,gss.old_sls_hier_division_desc) as old_sls_hier_division_desc,
	COALESCE(dna.old_sls_hier_category_desc,gss.old_sls_hier_category_desc) as old_sls_hier_category_desc,
	COALESCE(dna.old_sls_hier_sub_category_desc,gss.old_sls_hier_sub_category_desc) as old_sls_hier_sub_category_desc,
	COALESCE(dna.old_sls_hier_ppg_desc,gss.old_sls_hier_ppg_desc) as old_sls_hier_ppg_desc,
	COALESCE(dna.old_material_short_desc,gss.old_material_short_desc) as old_material_short_desc,
	COALESCE(dna.new_sls_hier_division_desc,gss.new_sls_hier_division_desc) as new_sls_hier_division_desc,
	COALESCE(dna.new_sls_hier_category_desc,gss.new_sls_hier_category_desc) as new_sls_hier_category_desc,
	COALESCE(dna.new_sls_hier_sub_category_desc,gss.new_sls_hier_sub_category_desc) as new_sls_hier_sub_category_desc,
	COALESCE(dna.new_sls_hier_ppg_desc,gss.new_sls_hier_ppg_desc) as new_sls_hier_ppg_desc,
	COALESCE(dna.new_material_short_desc,gss.new_material_short_desc) as new_material_short_desc,
    dna.old_ean_instore_distribution_count,
    dna.old_ean_online_distribution_count,
    dna.new_ean_instore_distribution_count,
    dna.new_ean_online_distribution_count,
	COALESCE(dna.new_ean_display_name,gss.new_ean_display_name) new_ean_display_name,
	COALESCE(dna.old_ean_display_name,gss.old_ean_display_name) old_ean_display_name,
    gss.new_ty_sales_value_usd,
	gss.old_ty_sales_value_usd,
    gss.old_ty_sales_eqc_units,
    gss.new_ty_sales_eqc_units,
	gss.old_ean_avg_ty_sales_eqc,
    dna.old_ean_avg_instore_distribution,
    dna.old_ean_avg_online_distribution,
	gss.old_ean_avg_ty_sales_value_usd,
	case when dna.modified_datetime > gss.modified_datetime then dna.modified_datetime
		 else COALESCE(gss.modified_datetime,dna.modified_datetime) end as modified_datetime
from `ecomm-dlf-prd-634888`.processed.kroger_distribution_availability_upc_conversions dna
full outer join
`ecomm-dlf-prd-634888`.processed.kroger_sales_share_upc_conversions gss
on
dna.old_ean_upc_cd = gss.old_ean_upc_cd
and dna.new_ean_upc_cd = gss.new_ean_upc_cd
and dna.conversion_date = gss.conversion_date
and dna.fiscal_week_begin_dt = gss.fiscal_week_begin_dt)

UNION ALL

(SELECT
	COALESCE(dna.fiscal_week_begin_dt,gss.fiscal_week_begin_dt) fiscal_week_begin_dt,
	COALESCE(dna.customer_account,gss.customer_account) customer_account,
	COALESCE(dna.customer_parent,gss.customer_parent) customer_parent,
	COALESCE(dna.customer_name,gss.customer_name) customer_name,
	COALESCE(dna.old_ean_upc_cd,gss.old_ean_upc_cd) old_ean_upc_cd,
    COALESCE(dna.new_ean_upc_cd,gss.new_ean_upc_cd) new_ean_upc_cd,
	COALESCE(dna.conversion_date,gss.conversion_date) conversion_date,
	COALESCE(dna.old_sls_hier_division_desc,gss.old_sls_hier_division_desc) as old_sls_hier_division_desc,
	COALESCE(dna.old_sls_hier_category_desc,gss.old_sls_hier_category_desc) as old_sls_hier_category_desc,
	COALESCE(dna.old_sls_hier_sub_category_desc,gss.old_sls_hier_sub_category_desc) as old_sls_hier_sub_category_desc,
	COALESCE(dna.old_sls_hier_ppg_desc,gss.old_sls_hier_ppg_desc) as old_sls_hier_ppg_desc,
	COALESCE(dna.old_material_short_desc,gss.old_material_short_desc) as old_material_short_desc,
	COALESCE(dna.new_sls_hier_division_desc,gss.new_sls_hier_division_desc) as new_sls_hier_division_desc,
	COALESCE(dna.new_sls_hier_category_desc,gss.new_sls_hier_category_desc) as new_sls_hier_category_desc,
	COALESCE(dna.new_sls_hier_sub_category_desc,gss.new_sls_hier_sub_category_desc) as new_sls_hier_sub_category_desc,
	COALESCE(dna.new_sls_hier_ppg_desc,gss.new_sls_hier_ppg_desc) as new_sls_hier_ppg_desc,
	COALESCE(dna.new_material_short_desc,gss.new_material_short_desc) as new_material_short_desc,
    dna.old_ean_instore_distribution_count,
    dna.old_ean_online_distribution_count,
    dna.new_ean_instore_distribution_count,
    dna.new_ean_online_distribution_count,
	COALESCE(dna.new_ean_display_name,gss.new_ean_display_name) new_ean_display_name,
	COALESCE(dna.old_ean_display_name,gss.old_ean_display_name) old_ean_display_name,
    gss.new_ty_sales_value_usd,
	gss.old_ty_sales_value_usd,
    gss.old_ty_sales_eqc_units,
    gss.new_ty_sales_eqc_units,
	gss.old_ean_avg_ty_sales_eqc,
    dna.old_ean_avg_instore_distribution,
    dna.old_ean_avg_online_distribution,
	gss.old_ean_avg_ty_sales_value_usd,
	case when dna.modified_datetime > gss.modified_datetime then dna.modified_datetime
		 else COALESCE(gss.modified_datetime,dna.modified_datetime) end as modified_datetime
from `ecomm-dlf-prd-634888`.processed.walmart_opd_distribution_availability_upc_conversions dna
full outer join
`ecomm-dlf-prd-634888`.processed.walmart_opd_sales_share_upc_conversions gss
on
dna.old_ean_upc_cd = gss.old_ean_upc_cd
and dna.new_ean_upc_cd = gss.new_ean_upc_cd
and dna.conversion_date = gss.conversion_date
and dna.fiscal_week_begin_dt = gss.fiscal_week_begin_dt)

UNION ALL

(SELECT
	COALESCE(dna.fiscal_week_begin_dt,gss.fiscal_week_begin_dt) fiscal_week_begin_dt,
	COALESCE(dna.customer_account,gss.customer_account) customer_account,
	COALESCE(dna.customer_parent,gss.customer_parent) customer_parent,
	COALESCE(dna.customer_name,gss.customer_name) customer_name,
	COALESCE(dna.old_ean_upc_cd,gss.old_ean_upc_cd) old_ean_upc_cd,
    COALESCE(dna.new_ean_upc_cd,gss.new_ean_upc_cd) new_ean_upc_cd,
	COALESCE(dna.conversion_date,gss.conversion_date) conversion_date,
	COALESCE(dna.old_sls_hier_division_desc,gss.old_sls_hier_division_desc) as old_sls_hier_division_desc,
	COALESCE(dna.old_sls_hier_category_desc,gss.old_sls_hier_category_desc) as old_sls_hier_category_desc,
	COALESCE(dna.old_sls_hier_sub_category_desc,gss.old_sls_hier_sub_category_desc) as old_sls_hier_sub_category_desc,
	COALESCE(dna.old_sls_hier_ppg_desc,gss.old_sls_hier_ppg_desc) as old_sls_hier_ppg_desc,
	COALESCE(dna.old_material_short_desc,gss.old_material_short_desc) as old_material_short_desc,
	COALESCE(dna.new_sls_hier_division_desc,gss.new_sls_hier_division_desc) as new_sls_hier_division_desc,
	COALESCE(dna.new_sls_hier_category_desc,gss.new_sls_hier_category_desc) as new_sls_hier_category_desc,
	COALESCE(dna.new_sls_hier_sub_category_desc,gss.new_sls_hier_sub_category_desc) as new_sls_hier_sub_category_desc,
	COALESCE(dna.new_sls_hier_ppg_desc,gss.new_sls_hier_ppg_desc) as new_sls_hier_ppg_desc,
	COALESCE(dna.new_material_short_desc,gss.new_material_short_desc) as new_material_short_desc,
    dna.old_ean_instore_distribution_count,
    dna.old_ean_online_distribution_count,
    dna.new_ean_instore_distribution_count,
    dna.new_ean_online_distribution_count,
	COALESCE(dna.new_ean_display_name,gss.new_ean_display_name) new_ean_display_name,
	COALESCE(dna.old_ean_display_name,gss.old_ean_display_name) old_ean_display_name,
    gss.new_ty_sales_value_usd,
	gss.old_ty_sales_value_usd,
    gss.old_ty_sales_eqc_units,
    gss.new_ty_sales_eqc_units,
	gss.old_ean_avg_ty_sales_eqc,
    dna.old_ean_avg_instore_distribution,
    dna.old_ean_avg_online_distribution,
	gss.old_ean_avg_ty_sales_value_usd,
	case when dna.modified_datetime > gss.modified_datetime then dna.modified_datetime
		 else COALESCE(gss.modified_datetime,dna.modified_datetime) end as modified_datetime
from `ecomm-dlf-prd-634888`.processed.amazon_com_distribution_availability_upc_conversions dna
full outer join
`ecomm-dlf-prd-634888`.processed.amazon_com_sales_share_upc_conversions gss
on
dna.old_ean_upc_cd = gss.old_ean_upc_cd
and dna.new_ean_upc_cd = gss.new_ean_upc_cd
and dna.conversion_date = gss.conversion_date
and dna.fiscal_week_begin_dt = gss.fiscal_week_begin_dt)

UNION ALL

(SELECT
	COALESCE(dna.fiscal_week_begin_dt,gss.fiscal_week_begin_dt) fiscal_week_begin_dt,
	COALESCE(dna.customer_account,gss.customer_account) customer_account,
	COALESCE(dna.customer_parent,gss.customer_parent) customer_parent,
	COALESCE(dna.customer_name,gss.customer_name) customer_name,
	COALESCE(dna.old_ean_upc_cd,gss.old_ean_upc_cd) old_ean_upc_cd,
    COALESCE(dna.new_ean_upc_cd,gss.new_ean_upc_cd) new_ean_upc_cd,
	COALESCE(dna.conversion_date,gss.conversion_date) conversion_date,
	COALESCE(dna.old_sls_hier_division_desc,gss.old_sls_hier_division_desc) as old_sls_hier_division_desc,
	COALESCE(dna.old_sls_hier_category_desc,gss.old_sls_hier_category_desc) as old_sls_hier_category_desc,
	COALESCE(dna.old_sls_hier_sub_category_desc,gss.old_sls_hier_sub_category_desc) as old_sls_hier_sub_category_desc,
	COALESCE(dna.old_sls_hier_ppg_desc,gss.old_sls_hier_ppg_desc) as old_sls_hier_ppg_desc,
	COALESCE(dna.old_material_short_desc,gss.old_material_short_desc) as old_material_short_desc,
	COALESCE(dna.new_sls_hier_division_desc,gss.new_sls_hier_division_desc) as new_sls_hier_division_desc,
	COALESCE(dna.new_sls_hier_category_desc,gss.new_sls_hier_category_desc) as new_sls_hier_category_desc,
	COALESCE(dna.new_sls_hier_sub_category_desc,gss.new_sls_hier_sub_category_desc) as new_sls_hier_sub_category_desc,
	COALESCE(dna.new_sls_hier_ppg_desc,gss.new_sls_hier_ppg_desc) as new_sls_hier_ppg_desc,
	COALESCE(dna.new_material_short_desc,gss.new_material_short_desc) as new_material_short_desc,
    dna.old_ean_instore_distribution_count,
    dna.old_ean_online_distribution_count,
    dna.new_ean_instore_distribution_count,
    dna.new_ean_online_distribution_count,
	COALESCE(dna.new_ean_display_name,gss.new_ean_display_name) new_ean_display_name,
	COALESCE(dna.old_ean_display_name,gss.old_ean_display_name) old_ean_display_name,
    gss.new_ty_sales_value_usd,
	gss.old_ty_sales_value_usd,
    gss.old_ty_sales_eqc_units,
    gss.new_ty_sales_eqc_units,
	gss.old_ean_avg_ty_sales_eqc,
    dna.old_ean_avg_instore_distribution,
    dna.old_ean_avg_online_distribution,
	gss.old_ean_avg_ty_sales_value_usd,
	case when dna.modified_datetime > gss.modified_datetime then dna.modified_datetime
		 else COALESCE(gss.modified_datetime,dna.modified_datetime) end as modified_datetime
from `ecomm-dlf-prd-634888`.processed.amazon_prime_now_distribution_availability_upc_conversions dna
full outer join
`ecomm-dlf-prd-634888`.processed.amazon_prime_now_sales_share_upc_conversions gss
on
dna.old_ean_upc_cd = gss.old_ean_upc_cd
and dna.new_ean_upc_cd = gss.new_ean_upc_cd
and dna.conversion_date = gss.conversion_date
and dna.fiscal_week_begin_dt = gss.fiscal_week_begin_dt)

UNION ALL

(SELECT
	COALESCE(dna.fiscal_week_begin_dt,gss.fiscal_week_begin_dt) fiscal_week_begin_dt,
	COALESCE(dna.customer_account,gss.customer_account) customer_account,
	COALESCE(dna.customer_parent,gss.customer_parent) customer_parent,
	COALESCE(dna.customer_name,gss.customer_name) customer_name,
	COALESCE(dna.old_ean_upc_cd,gss.old_ean_upc_cd) old_ean_upc_cd,
    COALESCE(dna.new_ean_upc_cd,gss.new_ean_upc_cd) new_ean_upc_cd,
	COALESCE(dna.conversion_date,gss.conversion_date) conversion_date,
	COALESCE(dna.old_sls_hier_division_desc,gss.old_sls_hier_division_desc) as old_sls_hier_division_desc,
	COALESCE(dna.old_sls_hier_category_desc,gss.old_sls_hier_category_desc) as old_sls_hier_category_desc,
	COALESCE(dna.old_sls_hier_sub_category_desc,gss.old_sls_hier_sub_category_desc) as old_sls_hier_sub_category_desc,
	COALESCE(dna.old_sls_hier_ppg_desc,gss.old_sls_hier_ppg_desc) as old_sls_hier_ppg_desc,
	COALESCE(dna.old_material_short_desc,gss.old_material_short_desc) as old_material_short_desc,
	COALESCE(dna.new_sls_hier_division_desc,gss.new_sls_hier_division_desc) as new_sls_hier_division_desc,
	COALESCE(dna.new_sls_hier_category_desc,gss.new_sls_hier_category_desc) as new_sls_hier_category_desc,
	COALESCE(dna.new_sls_hier_sub_category_desc,gss.new_sls_hier_sub_category_desc) as new_sls_hier_sub_category_desc,
	COALESCE(dna.new_sls_hier_ppg_desc,gss.new_sls_hier_ppg_desc) as new_sls_hier_ppg_desc,
	COALESCE(dna.new_material_short_desc,gss.new_material_short_desc) as new_material_short_desc,
    dna.old_ean_instore_distribution_count,
    dna.old_ean_online_distribution_count,
    dna.new_ean_instore_distribution_count,
    dna.new_ean_online_distribution_count,
	COALESCE(dna.new_ean_display_name,gss.new_ean_display_name) new_ean_display_name,
	COALESCE(dna.old_ean_display_name,gss.old_ean_display_name) old_ean_display_name,
    gss.new_ty_sales_value_usd,
	gss.old_ty_sales_value_usd,
    gss.old_ty_sales_eqc_units,
    gss.new_ty_sales_eqc_units,
	gss.old_ean_avg_ty_sales_eqc,
    dna.old_ean_avg_instore_distribution,
    dna.old_ean_avg_online_distribution,
	gss.old_ean_avg_ty_sales_value_usd,
	case when dna.modified_datetime > gss.modified_datetime then dna.modified_datetime
		 else COALESCE(gss.modified_datetime,dna.modified_datetime) end as modified_datetime
from `ecomm-dlf-prd-634888`.processed.amazon_fresh_distribution_availability_upc_conversions dna
full outer join
`ecomm-dlf-prd-634888`.processed.amazon_fresh_sales_share_upc_conversions gss
on
dna.old_ean_upc_cd = gss.old_ean_upc_cd
and dna.new_ean_upc_cd = gss.new_ean_upc_cd
and dna.conversion_date = gss.conversion_date
and dna.fiscal_week_begin_dt = gss.fiscal_week_begin_dt)

UNION ALL

(SELECT
	dna.fiscal_week_begin_dt fiscal_week_begin_dt,
	dna.customer_account customer_account,
	dna.customer_parent customer_parent,
	dna.customer_name customer_name,
	dna.old_ean_upc_cd old_ean_upc_cd,
    dna.new_ean_upc_cd new_ean_upc_cd,
	dna.conversion_date conversion_date,
	dna.old_sls_hier_division_desc as old_sls_hier_division_desc,
	dna.old_sls_hier_category_desc as old_sls_hier_category_desc,
	dna.old_sls_hier_sub_category_desc as old_sls_hier_sub_category_desc,
	dna.old_sls_hier_ppg_desc as old_sls_hier_ppg_desc,
	dna.old_material_short_desc as old_material_short_desc,
	dna.new_sls_hier_division_desc as new_sls_hier_division_desc,
	dna.new_sls_hier_category_desc as new_sls_hier_category_desc,
	dna.new_sls_hier_sub_category_desc as new_sls_hier_sub_category_desc,
	dna.new_sls_hier_ppg_desc as new_sls_hier_ppg_desc,
	dna.new_material_short_desc as new_material_short_desc,
    dna.old_ean_instore_distribution_count,
    dna.old_ean_online_distribution_count,
    dna.new_ean_instore_distribution_count,
    dna.new_ean_online_distribution_count,
	dna.new_ean_display_name new_ean_display_name,
	dna.old_ean_display_name old_ean_display_name,
    NULL as new_ty_sales_value_usd,
	NULL as old_ty_sales_value_usd,
    NULL as old_ty_sales_eqc_units,
    NULL as new_ty_sales_eqc_units,
	NULL as old_ean_avg_ty_sales_eqc,
    dna.old_ean_avg_instore_distribution,
    dna.old_ean_avg_online_distribution,
	NULL as old_ean_avg_ty_sales_value_usd,
	modified_datetime
from `ecomm-dlf-prd-634888`.processed.target_distribution_availability_upc_conversions dna
)

UNION ALL

(SELECT
	gss.fiscal_week_begin_dt fiscal_week_begin_dt,
	gss.customer_account customer_account,
	gss.customer_parent customer_parent,
	gss.customer_name customer_name,
	gss.old_ean_upc_cd old_ean_upc_cd,
    gss.new_ean_upc_cd new_ean_upc_cd,
	gss.conversion_date conversion_date,
	gss.old_sls_hier_division_desc as old_sls_hier_division_desc,
	gss.old_sls_hier_category_desc as old_sls_hier_category_desc,
	gss.old_sls_hier_sub_category_desc as old_sls_hier_sub_category_desc,
	gss.old_sls_hier_ppg_desc as old_sls_hier_ppg_desc,
	gss.old_material_short_desc as old_material_short_desc,
	gss.new_sls_hier_division_desc as new_sls_hier_division_desc,
	gss.new_sls_hier_category_desc as new_sls_hier_category_desc,
	gss.new_sls_hier_sub_category_desc as new_sls_hier_sub_category_desc,
	gss.new_sls_hier_ppg_desc as new_sls_hier_ppg_desc,
	gss.new_material_short_desc as new_material_short_desc,
    NULL as old_ean_instore_distribution_count,
    NULL as old_ean_online_distribution_count,
    NULL as new_ean_instore_distribution_count,
    NULL as new_ean_online_distribution_count,
	gss.new_ean_display_name new_ean_display_name,
	gss.old_ean_display_name old_ean_display_name,
    gss.new_ty_sales_value_usd,
	gss.old_ty_sales_value_usd,
    gss.old_ty_sales_eqc_units,
    gss.new_ty_sales_eqc_units,
	gss.old_ean_avg_ty_sales_eqc,
    NULL as old_ean_avg_instore_distribution,
    NULL as old_ean_avg_online_distribution,
	gss.old_ean_avg_ty_sales_value_usd,
	modified_datetime
from `ecomm-dlf-prd-634888`.processed.instacart_sales_share_upc_conversions gss
)

UNION ALL

(SELECT
	gss.fiscal_week_begin_dt fiscal_week_begin_dt,
	gss.customer_account customer_account,
	gss.customer_parent customer_parent,
	gss.customer_name customer_name,
	gss.old_ean_upc_cd old_ean_upc_cd,
    gss.new_ean_upc_cd new_ean_upc_cd,
	gss.conversion_date conversion_date,
	gss.old_sls_hier_division_desc as old_sls_hier_division_desc,
	gss.old_sls_hier_category_desc as old_sls_hier_category_desc,
	gss.old_sls_hier_sub_category_desc as old_sls_hier_sub_category_desc,
	gss.old_sls_hier_ppg_desc as old_sls_hier_ppg_desc,
	gss.old_material_short_desc as old_material_short_desc,
	gss.new_sls_hier_division_desc as new_sls_hier_division_desc,
	gss.new_sls_hier_category_desc as new_sls_hier_category_desc,
	gss.new_sls_hier_sub_category_desc as new_sls_hier_sub_category_desc,
	gss.new_sls_hier_ppg_desc as new_sls_hier_ppg_desc,
	gss.new_material_short_desc as new_material_short_desc,
    NULL as old_ean_instore_distribution_count,
    NULL as old_ean_online_distribution_count,
    NULL as new_ean_instore_distribution_count,
    NULL as new_ean_online_distribution_count,
	gss.new_ean_display_name new_ean_display_name,
	gss.old_ean_display_name old_ean_display_name,
    gss.new_ty_sales_value_usd,
	gss.old_ty_sales_value_usd,
    gss.old_ty_sales_eqc_units,
    gss.new_ty_sales_eqc_units,
	gss.old_ean_avg_ty_sales_eqc,
    NULL as old_ean_avg_instore_distribution,
    NULL as old_ean_avg_online_distribution,
	gss.old_ean_avg_ty_sales_value_usd,
	modified_datetime
from `ecomm-dlf-prd-634888`.processed.harris_teeter_sales_share_upc_conversions gss
)

UNION ALL

(SELECT
	gss.fiscal_week_begin_dt fiscal_week_begin_dt,
	gss.customer_account customer_account,
	gss.customer_parent customer_parent,
	gss.customer_name customer_name,
	gss.old_ean_upc_cd old_ean_upc_cd,
    gss.new_ean_upc_cd new_ean_upc_cd,
	gss.conversion_date conversion_date,
	gss.old_sls_hier_division_desc as old_sls_hier_division_desc,
	gss.old_sls_hier_category_desc as old_sls_hier_category_desc,
	gss.old_sls_hier_sub_category_desc as old_sls_hier_sub_category_desc,
	gss.old_sls_hier_ppg_desc as old_sls_hier_ppg_desc,
	gss.old_material_short_desc as old_material_short_desc,
	gss.new_sls_hier_division_desc as new_sls_hier_division_desc,
	gss.new_sls_hier_category_desc as new_sls_hier_category_desc,
	gss.new_sls_hier_sub_category_desc as new_sls_hier_sub_category_desc,
	gss.new_sls_hier_ppg_desc as new_sls_hier_ppg_desc,
	gss.new_material_short_desc as new_material_short_desc,
    NULL as old_ean_instore_distribution_count,
    NULL as old_ean_online_distribution_count,
    NULL as new_ean_instore_distribution_count,
    NULL as new_ean_online_distribution_count,
	gss.new_ean_display_name new_ean_display_name,
	gss.old_ean_display_name old_ean_display_name,
    gss.new_ty_sales_value_usd,
	gss.old_ty_sales_value_usd,
    gss.old_ty_sales_eqc_units,
    gss.new_ty_sales_eqc_units,
	gss.old_ean_avg_ty_sales_eqc,
    NULL as old_ean_avg_instore_distribution,
    NULL as old_ean_avg_online_distribution,
	gss.old_ean_avg_ty_sales_value_usd,
	modified_datetime
from `ecomm-dlf-prd-634888`.processed.kroger_delivery_sales_share_upc_conversions gss
)

UNION ALL

(SELECT
	gss.fiscal_week_begin_dt fiscal_week_begin_dt,
	gss.customer_account customer_account,
	gss.customer_parent customer_parent,
	gss.customer_name customer_name,
	gss.old_ean_upc_cd old_ean_upc_cd,
    gss.new_ean_upc_cd new_ean_upc_cd,
	gss.conversion_date conversion_date,
	gss.old_sls_hier_division_desc as old_sls_hier_division_desc,
	gss.old_sls_hier_category_desc as old_sls_hier_category_desc,
	gss.old_sls_hier_sub_category_desc as old_sls_hier_sub_category_desc,
	gss.old_sls_hier_ppg_desc as old_sls_hier_ppg_desc,
	gss.old_material_short_desc as old_material_short_desc,
	gss.new_sls_hier_division_desc as new_sls_hier_division_desc,
	gss.new_sls_hier_category_desc as new_sls_hier_category_desc,
	gss.new_sls_hier_sub_category_desc as new_sls_hier_sub_category_desc,
	gss.new_sls_hier_ppg_desc as new_sls_hier_ppg_desc,
	gss.new_material_short_desc as new_material_short_desc,
    NULL as old_ean_instore_distribution_count,
    NULL as old_ean_online_distribution_count,
    NULL as new_ean_instore_distribution_count,
    NULL as new_ean_online_distribution_count,
	gss.new_ean_display_name new_ean_display_name,
	gss.old_ean_display_name old_ean_display_name,
    gss.new_ty_sales_value_usd,
	gss.old_ty_sales_value_usd,
    gss.old_ty_sales_eqc_units,
    gss.new_ty_sales_eqc_units,
	gss.old_ean_avg_ty_sales_eqc,
    NULL as old_ean_avg_instore_distribution,
    NULL as old_ean_avg_online_distribution,
	gss.old_ean_avg_ty_sales_value_usd,
	modified_datetime
from `ecomm-dlf-prd-634888`.processed.kroger_ship_sales_share_upc_conversions gss
)

UNION ALL

(SELECT
	gss.fiscal_week_begin_dt fiscal_week_begin_dt,
	gss.customer_account customer_account,
	gss.customer_parent customer_parent,
	gss.customer_name customer_name,
	gss.old_ean_upc_cd old_ean_upc_cd,
    gss.new_ean_upc_cd new_ean_upc_cd,
	gss.conversion_date conversion_date,
	gss.old_sls_hier_division_desc as old_sls_hier_division_desc,
	gss.old_sls_hier_category_desc as old_sls_hier_category_desc,
	gss.old_sls_hier_sub_category_desc as old_sls_hier_sub_category_desc,
	gss.old_sls_hier_ppg_desc as old_sls_hier_ppg_desc,
	gss.old_material_short_desc as old_material_short_desc,
	gss.new_sls_hier_division_desc as new_sls_hier_division_desc,
	gss.new_sls_hier_category_desc as new_sls_hier_category_desc,
	gss.new_sls_hier_sub_category_desc as new_sls_hier_sub_category_desc,
	gss.new_sls_hier_ppg_desc as new_sls_hier_ppg_desc,
	gss.new_material_short_desc as new_material_short_desc,
    NULL as old_ean_instore_distribution_count,
    NULL as old_ean_online_distribution_count,
    NULL as new_ean_instore_distribution_count,
    NULL as new_ean_online_distribution_count,
	gss.new_ean_display_name new_ean_display_name,
	gss.old_ean_display_name old_ean_display_name,
    gss.new_ty_sales_value_usd,
	gss.old_ty_sales_value_usd,
    gss.old_ty_sales_eqc_units,
    gss.new_ty_sales_eqc_units,
	gss.old_ean_avg_ty_sales_eqc,
    NULL as old_ean_avg_instore_distribution,
    NULL as old_ean_avg_online_distribution,
	gss.old_ean_avg_ty_sales_value_usd,
	modified_datetime
from `ecomm-dlf-prd-634888`.processed.sams_club_sales_share_upc_conversions gss
)

UNION ALL

(SELECT
	gss.fiscal_week_begin_dt fiscal_week_begin_dt,
	gss.customer_account customer_account,
	gss.customer_parent customer_parent,
	gss.customer_name customer_name,
	gss.old_ean_upc_cd old_ean_upc_cd,
    gss.new_ean_upc_cd new_ean_upc_cd,
	gss.conversion_date conversion_date,
	gss.old_sls_hier_division_desc as old_sls_hier_division_desc,
	gss.old_sls_hier_category_desc as old_sls_hier_category_desc,
	gss.old_sls_hier_sub_category_desc as old_sls_hier_sub_category_desc,
	gss.old_sls_hier_ppg_desc as old_sls_hier_ppg_desc,
	gss.old_material_short_desc as old_material_short_desc,
	gss.new_sls_hier_division_desc as new_sls_hier_division_desc,
	gss.new_sls_hier_category_desc as new_sls_hier_category_desc,
	gss.new_sls_hier_sub_category_desc as new_sls_hier_sub_category_desc,
	gss.new_sls_hier_ppg_desc as new_sls_hier_ppg_desc,
	gss.new_material_short_desc as new_material_short_desc,
    NULL as old_ean_instore_distribution_count,
    NULL as old_ean_online_distribution_count,
    NULL as new_ean_instore_distribution_count,
    NULL as new_ean_online_distribution_count,
	gss.new_ean_display_name new_ean_display_name,
	gss.old_ean_display_name old_ean_display_name,
    gss.new_ty_sales_value_usd,
	gss.old_ty_sales_value_usd,
    gss.old_ty_sales_eqc_units,
    gss.new_ty_sales_eqc_units,
	gss.old_ean_avg_ty_sales_eqc,
    NULL as old_ean_avg_instore_distribution,
    NULL as old_ean_avg_online_distribution,
	gss.old_ean_avg_ty_sales_value_usd,
	modified_datetime
from `ecomm-dlf-prd-634888`.processed.shipt_sales_share_upc_conversions gss
)

UNION ALL

(SELECT
	dna.fiscal_week_begin_dt fiscal_week_begin_dt,
	dna.customer_account customer_account,
	dna.customer_parent customer_parent,
	dna.customer_name customer_name,
	dna.old_ean_upc_cd old_ean_upc_cd,
    dna.new_ean_upc_cd new_ean_upc_cd,
	dna.conversion_date conversion_date,
	dna.old_sls_hier_division_desc as old_sls_hier_division_desc,
	dna.old_sls_hier_category_desc as old_sls_hier_category_desc,
	dna.old_sls_hier_sub_category_desc as old_sls_hier_sub_category_desc,
	dna.old_sls_hier_ppg_desc as old_sls_hier_ppg_desc,
	dna.old_material_short_desc as old_material_short_desc,
	dna.new_sls_hier_division_desc as new_sls_hier_division_desc,
	dna.new_sls_hier_category_desc as new_sls_hier_category_desc,
	dna.new_sls_hier_sub_category_desc as new_sls_hier_sub_category_desc,
	dna.new_sls_hier_ppg_desc as new_sls_hier_ppg_desc,
	dna.new_material_short_desc as new_material_short_desc,
    dna.old_ean_instore_distribution_count,
    dna.old_ean_online_distribution_count,
    dna.new_ean_instore_distribution_count,
    dna.new_ean_online_distribution_count,
	dna.new_ean_display_name new_ean_display_name,
	dna.old_ean_display_name old_ean_display_name,
    NULL as new_ty_sales_value_usd,
	NULL as old_ty_sales_value_usd,
    NULL as old_ty_sales_eqc_units,
    NULL as new_ty_sales_eqc_units,
	NULL as old_ean_avg_ty_sales_eqc,
    dna.old_ean_avg_instore_distribution,
    dna.old_ean_avg_online_distribution,
	NULL as old_ean_avg_ty_sales_value_usd,
	modified_datetime
from `ecomm-dlf-prd-634888`.processed.albertsons_safeway_distribution_availability_upc_conversions dna
)

UNION ALL

(SELECT
	dna.fiscal_week_begin_dt fiscal_week_begin_dt,
	dna.customer_account customer_account,
	dna.customer_parent customer_parent,
	dna.customer_name customer_name,
	dna.old_ean_upc_cd old_ean_upc_cd,
    dna.new_ean_upc_cd new_ean_upc_cd,
	dna.conversion_date conversion_date,
	dna.old_sls_hier_division_desc as old_sls_hier_division_desc,
	dna.old_sls_hier_category_desc as old_sls_hier_category_desc,
	dna.old_sls_hier_sub_category_desc as old_sls_hier_sub_category_desc,
	dna.old_sls_hier_ppg_desc as old_sls_hier_ppg_desc,
	dna.old_material_short_desc as old_material_short_desc,
	dna.new_sls_hier_division_desc as new_sls_hier_division_desc,
	dna.new_sls_hier_category_desc as new_sls_hier_category_desc,
	dna.new_sls_hier_sub_category_desc as new_sls_hier_sub_category_desc,
	dna.new_sls_hier_ppg_desc as new_sls_hier_ppg_desc,
	dna.new_material_short_desc as new_material_short_desc,
    dna.old_ean_instore_distribution_count,
    dna.old_ean_online_distribution_count,
    dna.new_ean_instore_distribution_count,
    dna.new_ean_online_distribution_count,
	dna.new_ean_display_name new_ean_display_name,
	dna.old_ean_display_name old_ean_display_name,
    NULL as new_ty_sales_value_usd,
	NULL as old_ty_sales_value_usd,
    NULL as old_ty_sales_eqc_units,
    NULL as new_ty_sales_eqc_units,
	NULL as old_ean_avg_ty_sales_eqc,
    dna.old_ean_avg_instore_distribution,
    dna.old_ean_avg_online_distribution,
	NULL as old_ean_avg_ty_sales_value_usd,
	modified_datetime
from `ecomm-dlf-prd-634888`.processed.heb_distribution_availability_upc_conversions dna
)

UNION ALL

(SELECT
	dna.fiscal_week_begin_dt fiscal_week_begin_dt,
	dna.customer_account customer_account,
	dna.customer_parent customer_parent,
	dna.customer_name customer_name,
	dna.old_ean_upc_cd old_ean_upc_cd,
    dna.new_ean_upc_cd new_ean_upc_cd,
	dna.conversion_date conversion_date,
	dna.old_sls_hier_division_desc as old_sls_hier_division_desc,
	dna.old_sls_hier_category_desc as old_sls_hier_category_desc,
	dna.old_sls_hier_sub_category_desc as old_sls_hier_sub_category_desc,
	dna.old_sls_hier_ppg_desc as old_sls_hier_ppg_desc,
	dna.old_material_short_desc as old_material_short_desc,
	dna.new_sls_hier_division_desc as new_sls_hier_division_desc,
	dna.new_sls_hier_category_desc as new_sls_hier_category_desc,
	dna.new_sls_hier_sub_category_desc as new_sls_hier_sub_category_desc,
	dna.new_sls_hier_ppg_desc as new_sls_hier_ppg_desc,
	dna.new_material_short_desc as new_material_short_desc,
    dna.old_ean_instore_distribution_count,
    dna.old_ean_online_distribution_count,
    dna.new_ean_instore_distribution_count,
    dna.new_ean_online_distribution_count,
	dna.new_ean_display_name new_ean_display_name,
	dna.old_ean_display_name old_ean_display_name,
    NULL as new_ty_sales_value_usd,
	NULL as old_ty_sales_value_usd,
    NULL as old_ty_sales_eqc_units,
    NULL as new_ty_sales_eqc_units,
	NULL as old_ean_avg_ty_sales_eqc,
    dna.old_ean_avg_instore_distribution,
    dna.old_ean_avg_online_distribution,
	NULL as old_ean_avg_ty_sales_value_usd,
	modified_datetime
from `ecomm-dlf-prd-634888`.processed.publix_instacart_distribution_availability_upc_conversions dna
)

)
) uc
 
);


CALL `{{params.ECOMM_DLF}}.processed.sp_apply_rls_policies_on_tables`(
  "{{params.ECOMM_ANALYTICS}}", 
  "output", 
  "{{params.ECOMM_ANALYTICS}}", 
  "processed", 
  "ecomm_common_customer_info", 
  "'upc_conversions_report'",
  TRUE
);
