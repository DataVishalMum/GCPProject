/* Truncate exsting data           */
TRUNCATE TABLE `{{params.ECOMM_ANALYTICS}}`.output.ana_blue_report;

/*Insert reporting data into table */
insert into  `{{params.ECOMM_ANALYTICS}}`.output.ana_blue_report

WITH
  cte AS(
SELECT
fact_sk,
UPPER(customer_name) as customer_name,
date,
country,
CASE
  WHEN UPPER(retailer) LIKE 'WALMART 1P%' THEN 'WALMART 1P'
  WHEN UPPER(retailer) LIKE 'WALMART 3P%' THEN 'WALMART 3P'
  WHEN UPPER(retailer) LIKE 'TARGET%' THEN 'TARGET'
  ELSE UPPER(retailer)
END AS retailer,
upc,
ean,
rpc,
product_model_number,
UPPER(product_title) as product_title,
match_type,
availability,
add_on_item,
prime_exclusive,
url,
UPPER(manufacturer) as manufacturer,
UPPER(brand) as brand,
UPPER(sub_brand) as sub_brand,
profitero_id,
account_category,
account_category_2,
account_category_3,
account_category_4,
account_category_5,
account_category_6,
account_category_7,
account_category_8,
rctl_uuid,
source_product_hash,
created_by,
created_datetime,
modified_by,
modified_datetime,
UPPER(customer_parent) as customer_parent,
fiscal_dt,
fiscal_day_in_week_nbr,
fiscal_year_week_nbr,
cast(fiscal_week_begin_dt as DATE) as fiscal_week_begin_dt,
fiscal_week_end_dt,
fiscal_year_month_nbr,
fiscal_month_in_year_short_desc,
fiscal_month_in_year_nbr,
fiscal_quarter_nbr,
fiscal_year_nbr,
availbility_fg,
is_online_fg,
UPPER(species) as species,
UPPER(foodform) as foodform,
UPPER(skuname) as skuname,
UPPER(subcategory) as subcategory,
UPPER(brandhigh) as brandhigh,
UPPER(brandlow) as brandlow,
rolling_52_fg,
latest_completed_fiscal_month_fg,
latest_completed_fiscal_quarter_fg,
ly_availbility_fg,
ly_availbility,
ly_is_online_fg
from `{{params.ECOMM_DLF}}`.processed.profitero_blue_availability_view),

cte_rn as (
select *,
row_number() over (partition by upc, fiscal_week_begin_dt, product_title, availability,skuname, manufacturer, retailer order by upc desc) rn
 from cte
)

SELECT
* except(rn)
  FROM
  cte_rn
WHERE 
  retailer IN (
'AMAZON 1P',
'PETCO',
'WALMART 1P',
'AMAZON 3P',
'PETSMART',
'TARGET',
'CHEWY'
  )
AND rn=1;     