/* Truncate exsting data           */
TRUNCATE TABLE `{{params.ECOMM_ANALYTICS}}`.output.ecom_new_product_tracker_report;

/*Insert reporting data into table */
insert into  `{{params.ECOMM_ANALYTICS}}`.output.ecom_new_product_tracker_report




(



select av.* from 
        (        

SELECT * FROM (
(SELECT 
ean_upc_cd,
		source_item_name,
		ipp_start_date,
		ipp_end_date,
		sls_lnch_ty_cd,
		sls_hier_division_desc,
		sls_hier_category_desc,
		sls_hier_sub_category_desc,
		sls_hier_ppg_desc,
		material_short_desc,
		customer_parent,
		customer_account,
		fct.customer_name,
		fiscal_week_begin_dt,
		ty_sales_eqc_units,
		ty_sales_value_usd,
		instore_distribution_count,
		online_distribution_count,
        category_sales_benchmark,
		sub_category_sales_benchmark,
		sub_category_eqc_benchmark,
        fct.modified_datetime
 FROM `ecomm-dlf-qa-ee8fb9`.processed.ecom_amazon_prime_now_new_product_tracker fct 
 inner join `ecomm-dlf-qa-ee8fb9.processed.ecom_data_release_control` cntrl
 on fct.fiscal_year_week_nbr=cntrl.fiscal_year_week_nbr and fct.fiscal_year_month_nbr=cntrl.fiscal_year_month_nbr  
 where 
   cntrl.staging_flg='Y' and cntrl.release_flg = 'Y'  
   and 
   cntrl.feed_name='AMAZON_PRIME_NOW_DISTRIBUTION_AVAILABILITY_SUBCATG_AGG_FACT')

UNION ALL
(SELECT 
ean_upc_cd,
		source_item_name,
		ipp_start_date,
		ipp_end_date,
		sls_lnch_ty_cd,
		sls_hier_division_desc,
		sls_hier_category_desc,
		sls_hier_sub_category_desc,
		sls_hier_ppg_desc,
		material_short_desc,
		customer_parent,
		customer_account,
		fct.customer_name,
		fiscal_week_begin_dt,
		ty_sales_eqc_units,
		ty_sales_value_usd,
		instore_distribution_count,
		online_distribution_count,
        category_sales_benchmark,
		sub_category_sales_benchmark,
		sub_category_eqc_benchmark,
        fct.modified_datetime
 FROM `ecomm-dlf-qa-ee8fb9`.processed.ecom_kroger_new_product_tracker fct 
 inner join `ecomm-dlf-qa-ee8fb9.processed.ecom_data_release_control` cntrl
 on fct.fiscal_year_week_nbr=cntrl.fiscal_year_week_nbr and fct.fiscal_year_month_nbr=cntrl.fiscal_year_month_nbr  
 where 
   cntrl.staging_flg='Y' and cntrl.release_flg = 'Y'
   and 
   cntrl.feed_name='KROGER_DISTRIBUTION_AVAILABILITY_SUBCATG_AGG_FACT')

UNION ALL
(SELECT 
ean_upc_cd,
		source_item_name,
		ipp_start_date,
		ipp_end_date,
		sls_lnch_ty_cd,
		sls_hier_division_desc,
		sls_hier_category_desc,
		sls_hier_sub_category_desc,
		sls_hier_ppg_desc,
		material_short_desc,
		customer_parent,
		customer_account,
		fct.customer_name,
		fiscal_week_begin_dt,
		ty_sales_eqc_units,
		ty_sales_value_usd,
		instore_distribution_count,
		online_distribution_count,
        category_sales_benchmark,
		sub_category_sales_benchmark,
		sub_category_eqc_benchmark,
        fct.modified_datetime
 FROM `ecomm-dlf-qa-ee8fb9`.processed.ecom_meijer_new_product_tracker fct 
 inner join `ecomm-dlf-qa-ee8fb9.processed.ecom_data_release_control` cntrl
 on fct.fiscal_year_week_nbr=cntrl.fiscal_year_week_nbr and fct.fiscal_year_month_nbr=cntrl.fiscal_year_month_nbr  
 where 
   cntrl.staging_flg='Y' and cntrl.release_flg = 'Y'
   and 
   cntrl.feed_name='MEIJER_DISTRIBUTION_AVAILABILITY_SUBCATG_AGG_FACT')
UNION ALL
(SELECT 
ean_upc_cd,
		source_item_name,
		ipp_start_date,
		ipp_end_date,
		sls_lnch_ty_cd,
		sls_hier_division_desc,
		sls_hier_category_desc,
		sls_hier_sub_category_desc,
		sls_hier_ppg_desc,
		material_short_desc,
		customer_parent,
		customer_account,
		fct.customer_name,
		fiscal_week_begin_dt,
		ty_sales_eqc_units,
		ty_sales_value_usd,
		instore_distribution_count,
		online_distribution_count,
        category_sales_benchmark,
		sub_category_sales_benchmark,
		sub_category_eqc_benchmark,
        fct.modified_datetime
 FROM `ecomm-dlf-qa-ee8fb9`.processed.ecom_walmart_opd_new_product_tracker fct 
inner join `ecomm-dlf-qa-ee8fb9.processed.ecom_data_release_control` cntrl
 on fct.fiscal_year_week_nbr=cntrl.fiscal_year_week_nbr and fct.fiscal_year_month_nbr=cntrl.fiscal_year_month_nbr  
 where 
   cntrl.staging_flg='Y' and cntrl.release_flg = 'Y'
   and 
   cntrl.feed_name='WALMART_OPD_DISTRIBUTION_AVAILABILITY_SUBCATG_AGG_FACT')

UNION ALL
(SELECT 
ean_upc_cd,
		source_item_name,
		ipp_start_date,
		ipp_end_date,
		sls_lnch_ty_cd,
		sls_hier_division_desc,
		sls_hier_category_desc,
		sls_hier_sub_category_desc,
		sls_hier_ppg_desc,
		material_short_desc,
		customer_parent,
		customer_account,
		fct.customer_name,
		fiscal_week_begin_dt,
		ty_sales_eqc_units,
		ty_sales_value_usd,
		instore_distribution_count,
		online_distribution_count,
        category_sales_benchmark,
		sub_category_sales_benchmark,
		sub_category_eqc_benchmark,
        fct.modified_datetime
 FROM `ecomm-dlf-qa-ee8fb9`.processed.ecom_amazon_com_new_product_tracker fct 
inner join `ecomm-dlf-qa-ee8fb9.processed.ecom_data_release_control` cntrl
 on fct.fiscal_year_week_nbr=cntrl.fiscal_year_week_nbr and fct.fiscal_year_month_nbr=cntrl.fiscal_year_month_nbr  
 where 
   cntrl.staging_flg='Y' and cntrl.release_flg = 'Y'
   and 
   cntrl.feed_name='AMAZON_COM_DISTRIBUTION_AVAILABILITY_SUBCATG_AGG_FACT')

UNION ALL
(SELECT 
ean_upc_cd,
		source_item_name,
		ipp_start_date,
		ipp_end_date,
		sls_lnch_ty_cd,
		sls_hier_division_desc,
		sls_hier_category_desc,
		sls_hier_sub_category_desc,
		sls_hier_ppg_desc,
		material_short_desc,
		customer_parent,
		customer_account,
		fct.customer_name,
		fiscal_week_begin_dt,
		ty_sales_eqc_units,
		ty_sales_value_usd,
		instore_distribution_count,
		online_distribution_count,
        category_sales_benchmark,
		sub_category_sales_benchmark,
		sub_category_eqc_benchmark,
        fct.modified_datetime
 FROM `ecomm-dlf-qa-ee8fb9`.processed.ecom_amazon_fresh_new_product_tracker fct
 inner join `ecomm-dlf-qa-ee8fb9.processed.ecom_data_release_control` cntrl
 on fct.fiscal_year_week_nbr=cntrl.fiscal_year_week_nbr and fct.fiscal_year_month_nbr=cntrl.fiscal_year_month_nbr  
 where 
   cntrl.staging_flg='Y'  and cntrl.release_flg = 'Y'
   and 
   cntrl.feed_name='AMAZON_FRESH_DISTRIBUTION_AVAILABILITY_SUBCATG_AGG_FACT')

UNION ALL
(SELECT
ean_upc_cd,
		source_item_name,
		ipp_start_date,
		ipp_end_date,
		sls_lnch_ty_cd,
		sls_hier_division_desc,
		sls_hier_category_desc,
		sls_hier_sub_category_desc,
		sls_hier_ppg_desc,
		material_short_desc,
		customer_parent,
		customer_account,
		fct.customer_name,
		fiscal_week_begin_dt,
		ty_sales_eqc_units,
		ty_sales_value_usd,
		instore_distribution_count,
		online_distribution_count,
        category_sales_benchmark,
		sub_category_sales_benchmark,
		sub_category_eqc_benchmark,
        fct.modified_datetime
 FROM `ecomm-dlf-qa-ee8fb9`.processed.ecom_kroger_instacart_new_product_tracker fct
 inner join `ecomm-dlf-qa-ee8fb9.processed.ecom_data_release_control` cntrl
 on fct.fiscal_year_week_nbr=cntrl.fiscal_year_week_nbr and fct.fiscal_year_month_nbr=cntrl.fiscal_year_month_nbr
 where
   cntrl.staging_flg='Y'  and cntrl.release_flg = 'Y'
   and
   cntrl.feed_name='KROGER_INSTACART_DISTRIBUTION_AVAILABILITY_SUBCATG_AGG_FACT')

UNION ALL
(SELECT
ean_upc_cd,
		source_item_name,
		ipp_start_date,
		ipp_end_date,
		sls_lnch_ty_cd,
		sls_hier_division_desc,
		sls_hier_category_desc,
		sls_hier_sub_category_desc,
		sls_hier_ppg_desc,
		material_short_desc,
		customer_parent,
		customer_account,
		fct.customer_name,
		fiscal_week_begin_dt,
		ty_sales_eqc_units,
		ty_sales_value_usd,
		instore_distribution_count,
		online_distribution_count,
        category_sales_benchmark,
		sub_category_sales_benchmark,
		sub_category_eqc_benchmark,
        fct.modified_datetime
 FROM `ecomm-dlf-qa-ee8fb9`.processed.ecom_walmart_opd_instacart_new_product_tracker fct
 inner join `ecomm-dlf-qa-ee8fb9.processed.ecom_data_release_control` cntrl
 on fct.fiscal_year_week_nbr=cntrl.fiscal_year_week_nbr and fct.fiscal_year_month_nbr=cntrl.fiscal_year_month_nbr
 where
   cntrl.staging_flg='Y'  and cntrl.release_flg = 'Y'
   and
   cntrl.feed_name='WALMART_OPD_INSTACART_DISTRIBUTION_AVAILABILITY_SUBCATG_AGG_FACT')

UNION ALL
(SELECT
ean_upc_cd,
		source_item_name,
		ipp_start_date,
		ipp_end_date,
		sls_lnch_ty_cd,
		sls_hier_division_desc,
		sls_hier_category_desc,
		sls_hier_sub_category_desc,
		sls_hier_ppg_desc,
		material_short_desc,
		customer_parent,
		customer_account,
		fct.customer_name,
		fiscal_week_begin_dt,
		ty_sales_eqc_units,
		ty_sales_value_usd,
		instore_distribution_count,
		online_distribution_count,
        category_sales_benchmark,
		sub_category_sales_benchmark,
		sub_category_eqc_benchmark,
        fct.modified_datetime
 FROM `ecomm-dlf-qa-ee8fb9`.processed.ecom_shipt_new_product_tracker fct
 inner join `ecomm-dlf-qa-ee8fb9.processed.ecom_data_release_control` cntrl
 on fct.fiscal_year_week_nbr=cntrl.fiscal_year_week_nbr and fct.fiscal_year_month_nbr=cntrl.fiscal_year_month_nbr
 where
   cntrl.staging_flg='Y'  and cntrl.release_flg = 'Y'
   and
   cntrl.feed_name='SHIPT')

UNION ALL
(SELECT
ean_upc_cd,
		source_item_name,
		ipp_start_date,
		ipp_end_date,
		sls_lnch_ty_cd,
		sls_hier_division_desc,
		sls_hier_category_desc,
		sls_hier_sub_category_desc,
		sls_hier_ppg_desc,
		material_short_desc,
		customer_parent,
		customer_account,
		fct.customer_name,
		fiscal_week_begin_dt,
		ty_sales_eqc_units,
		ty_sales_value_usd,
		instore_distribution_count,
		online_distribution_count,
        category_sales_benchmark,
		sub_category_sales_benchmark,
		sub_category_eqc_benchmark,
        fct.modified_datetime
 FROM `ecomm-dlf-qa-ee8fb9`.processed.ecom_kroger_delivery_new_product_tracker fct
 inner join `ecomm-dlf-qa-ee8fb9.processed.ecom_data_release_control` cntrl
 on fct.fiscal_year_week_nbr=cntrl.fiscal_year_week_nbr and fct.fiscal_year_month_nbr=cntrl.fiscal_year_month_nbr
 where
   cntrl.staging_flg='Y'  and cntrl.release_flg = 'Y'
   and
   cntrl.feed_name='KROGER_DELIVERY')

UNION ALL
(SELECT
ean_upc_cd,
		source_item_name,
		ipp_start_date,
		ipp_end_date,
		sls_lnch_ty_cd,
		sls_hier_division_desc,
		sls_hier_category_desc,
		sls_hier_sub_category_desc,
		sls_hier_ppg_desc,
		material_short_desc,
		customer_parent,
		customer_account,
		fct.customer_name,
		fiscal_week_begin_dt,
		ty_sales_eqc_units,
		ty_sales_value_usd,
		instore_distribution_count,
		online_distribution_count,
        category_sales_benchmark,
		sub_category_sales_benchmark,
		sub_category_eqc_benchmark,
        fct.modified_datetime
 FROM `ecomm-dlf-qa-ee8fb9`.processed.ecom_kroger_ship_new_product_tracker fct
 inner join `ecomm-dlf-qa-ee8fb9.processed.ecom_data_release_control` cntrl
 on fct.fiscal_year_week_nbr=cntrl.fiscal_year_week_nbr and fct.fiscal_year_month_nbr=cntrl.fiscal_year_month_nbr
 where
   cntrl.staging_flg='Y'  and cntrl.release_flg = 'Y'
   and
   cntrl.feed_name='KROGER_SHIP')

UNION ALL
(SELECT
ean_upc_cd,
		source_item_name,
		ipp_start_date,
		ipp_end_date,
		sls_lnch_ty_cd,
		sls_hier_division_desc,
		sls_hier_category_desc,
		sls_hier_sub_category_desc,
		sls_hier_ppg_desc,
		material_short_desc,
		customer_parent,
		customer_account,
		fct.customer_name,
		fiscal_week_begin_dt,
		ty_sales_eqc_units,
		ty_sales_value_usd,
		instore_distribution_count,
		online_distribution_count,
        category_sales_benchmark,
		sub_category_sales_benchmark,
		sub_category_eqc_benchmark,
        fct.modified_datetime
 FROM `ecomm-dlf-qa-ee8fb9`.processed.ecom_shoprite_new_product_tracker fct
 inner join `ecomm-dlf-qa-ee8fb9.processed.ecom_data_release_control` cntrl
 on fct.fiscal_year_week_nbr=cntrl.fiscal_year_week_nbr and fct.fiscal_year_month_nbr=cntrl.fiscal_year_month_nbr
 where
   cntrl.staging_flg='Y'  and cntrl.release_flg = 'Y'
   and
   cntrl.feed_name='SHOPRITE')

UNION ALL
(SELECT
ean_upc_cd,
		source_item_name,
		ipp_start_date,
		ipp_end_date,
		sls_lnch_ty_cd,
		sls_hier_division_desc,
		sls_hier_category_desc,
		sls_hier_sub_category_desc,
		sls_hier_ppg_desc,
		material_short_desc,
		customer_parent,
		customer_account,
		fct.customer_name,
		fiscal_week_begin_dt,
		ty_sales_eqc_units,
		ty_sales_value_usd,
		instore_distribution_count,
		online_distribution_count,
        category_sales_benchmark,
		sub_category_sales_benchmark,
		sub_category_eqc_benchmark,
        fct.modified_datetime
 FROM `ecomm-dlf-qa-ee8fb9`.processed.ecom_sams_club_new_product_tracker fct
 inner join `ecomm-dlf-qa-ee8fb9.processed.ecom_data_release_control` cntrl
 on fct.fiscal_year_week_nbr=cntrl.fiscal_year_week_nbr and fct.fiscal_year_month_nbr=cntrl.fiscal_year_month_nbr
 where
   cntrl.staging_flg='Y'  and cntrl.release_flg = 'Y'
   and
   cntrl.feed_name='SAMS_CLUB')

UNION ALL
(SELECT
ean_upc_cd,
		source_item_name,
		ipp_start_date,
		ipp_end_date,
		sls_lnch_ty_cd,
		sls_hier_division_desc,
		sls_hier_category_desc,
		sls_hier_sub_category_desc,
		sls_hier_ppg_desc,
		material_short_desc,
		customer_parent,
		customer_account,
		fct.customer_name,
		fiscal_week_begin_dt,
		ty_sales_eqc_units,
		ty_sales_value_usd,
		instore_distribution_count,
		online_distribution_count,
        category_sales_benchmark,
		sub_category_sales_benchmark,
		sub_category_eqc_benchmark,
        fct.modified_datetime
 FROM `ecomm-dlf-qa-ee8fb9`.processed.ecom_harris_teeter_new_product_tracker fct
 inner join `ecomm-dlf-qa-ee8fb9.processed.ecom_data_release_control` cntrl
 on fct.fiscal_year_week_nbr=cntrl.fiscal_year_week_nbr and fct.fiscal_year_month_nbr=cntrl.fiscal_year_month_nbr
 where
   cntrl.staging_flg='Y'  and cntrl.release_flg = 'Y'
   and
   cntrl.feed_name='HARRIS_TEETER')

UNION ALL
(SELECT
ean_upc_cd,
		source_item_name,
		ipp_start_date,
		ipp_end_date,
		sls_lnch_ty_cd,
		sls_hier_division_desc,
		sls_hier_category_desc,
		sls_hier_sub_category_desc,
		sls_hier_ppg_desc,
		material_short_desc,
		customer_parent,
		customer_account,
		fct.customer_name,
		fiscal_week_begin_dt,
		ty_sales_eqc_units,
		ty_sales_value_usd,
		instore_distribution_count,
		online_distribution_count,
        category_sales_benchmark,
		sub_category_sales_benchmark,
		sub_category_eqc_benchmark,
        fct.modified_datetime
 FROM `ecomm-dlf-qa-ee8fb9`.processed.ecom_instacart_new_product_tracker fct
 inner join `ecomm-dlf-qa-ee8fb9.processed.ecom_data_release_control` cntrl
 on fct.fiscal_year_week_nbr=cntrl.fiscal_year_week_nbr and fct.fiscal_year_month_nbr=cntrl.fiscal_year_month_nbr
 where
   cntrl.staging_flg='Y'  and cntrl.release_flg = 'Y'
   and
   cntrl.feed_name='INSTACART')

UNION ALL
(SELECT
ean_upc_cd,
		source_item_name,
		ipp_start_date,
		ipp_end_date,
		sls_lnch_ty_cd,
		sls_hier_division_desc,
		sls_hier_category_desc,
		sls_hier_sub_category_desc,
		sls_hier_ppg_desc,
		material_short_desc,
		customer_parent,
		customer_account,
		fct.customer_name,
		fiscal_week_begin_dt,
		ty_sales_eqc_units,
		ty_sales_value_usd,
		instore_distribution_count,
		online_distribution_count,
        category_sales_benchmark,
		sub_category_sales_benchmark,
		sub_category_eqc_benchmark,
        fct.modified_datetime
 FROM `ecomm-dlf-qa-ee8fb9`.processed.ecom_target_new_product_tracker fct
 inner join `ecomm-dlf-qa-ee8fb9.processed.ecom_data_release_control` cntrl
 on fct.fiscal_year_week_nbr=cntrl.fiscal_year_week_nbr and fct.fiscal_year_month_nbr=cntrl.fiscal_year_month_nbr
 where
   cntrl.staging_flg='Y'  and cntrl.release_flg = 'Y'
   and
   cntrl.feed_name='TARGET_DISTRIBUTION_AVAILABILITY_SUBCATG_AGG_FACT')

UNION ALL
(SELECT
ean_upc_cd,
		source_item_name,
		ipp_start_date,
		ipp_end_date,
		sls_lnch_ty_cd,
		sls_hier_division_desc,
		sls_hier_category_desc,
		sls_hier_sub_category_desc,
		sls_hier_ppg_desc,
		material_short_desc,
		customer_parent,
		customer_account,
		fct.customer_name,
		fiscal_week_begin_dt,
		ty_sales_eqc_units,
		ty_sales_value_usd,
		instore_distribution_count,
		online_distribution_count,
        category_sales_benchmark,
		sub_category_sales_benchmark,
		sub_category_eqc_benchmark,
        fct.modified_datetime
 FROM `ecomm-dlf-qa-ee8fb9`.processed.ecom_albertsons_safeway_new_product_tracker fct
 inner join `ecomm-dlf-qa-ee8fb9.processed.ecom_data_release_control` cntrl
 on fct.fiscal_year_week_nbr=cntrl.fiscal_year_week_nbr and fct.fiscal_year_month_nbr=cntrl.fiscal_year_month_nbr
 where
   cntrl.staging_flg='Y'  and cntrl.release_flg = 'Y'
   and
   cntrl.feed_name='ALBERTSONS_SAFEWAY_DISTRIBUTION_AVAILABILITY_SUBCATG_AGG_FACT')

UNION ALL
(SELECT
ean_upc_cd,
		source_item_name,
		ipp_start_date,
		ipp_end_date,
		sls_lnch_ty_cd,
		sls_hier_division_desc,
		sls_hier_category_desc,
		sls_hier_sub_category_desc,
		sls_hier_ppg_desc,
		material_short_desc,
		customer_parent,
		customer_account,
		fct.customer_name,
		fiscal_week_begin_dt,
		ty_sales_eqc_units,
		ty_sales_value_usd,
		instore_distribution_count,
		online_distribution_count,
        category_sales_benchmark,
		sub_category_sales_benchmark,
		sub_category_eqc_benchmark,
        fct.modified_datetime
 FROM `ecomm-dlf-qa-ee8fb9`.processed.ecom_heb_new_product_tracker fct
 inner join `ecomm-dlf-qa-ee8fb9.processed.ecom_data_release_control` cntrl
 on fct.fiscal_year_week_nbr=cntrl.fiscal_year_week_nbr and fct.fiscal_year_month_nbr=cntrl.fiscal_year_month_nbr
 where
   cntrl.staging_flg='Y'  and cntrl.release_flg = 'Y'
   and
   cntrl.feed_name='HEB_DISTRIBUTION_AVAILABILITY_SUBCATG_AGG_FACT')

UNION ALL
(SELECT
ean_upc_cd,
		source_item_name,
		ipp_start_date,
		ipp_end_date,
		sls_lnch_ty_cd,
		sls_hier_division_desc,
		sls_hier_category_desc,
		sls_hier_sub_category_desc,
		sls_hier_ppg_desc,
		material_short_desc,
		customer_parent,
		customer_account,
		fct.customer_name,
		fiscal_week_begin_dt,
		ty_sales_eqc_units,
		ty_sales_value_usd,
		instore_distribution_count,
		online_distribution_count,
        category_sales_benchmark,
		sub_category_sales_benchmark,
		sub_category_eqc_benchmark,
        fct.modified_datetime
 FROM `ecomm-dlf-qa-ee8fb9`.processed.ecom_publix_instacart_new_product_tracker fct
 inner join `ecomm-dlf-qa-ee8fb9.processed.ecom_data_release_control` cntrl
 on fct.fiscal_year_week_nbr=cntrl.fiscal_year_week_nbr and fct.fiscal_year_month_nbr=cntrl.fiscal_year_month_nbr
 where
   cntrl.staging_flg='Y'  and cntrl.release_flg = 'Y'
   and
   cntrl.feed_name='PUBLIX_INSTACART_DISTRIBUTION_AVAILABILITY_SUBCATG_AGG_FACT')

)) av
   
) ;


CALL `{{params.ECOMM_DLF}}.processed.sp_apply_rls_policies_on_tables`(
  "{{params.ECOMM_ANALYTICS}}", 
  "output", 
  "{{params.ECOMM_ANALYTICS}}", 
  "processed", 
  "ecomm_common_customer_info", 
  "'ecom_new_product_tracker_report'",
  TRUE
);