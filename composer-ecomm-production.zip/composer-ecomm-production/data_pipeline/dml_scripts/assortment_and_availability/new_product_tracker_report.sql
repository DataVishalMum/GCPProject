/* Truncate exsting data           */
TRUNCATE TABLE `{{params.ECOMM_ANALYTICS}}`.output.new_product_tracker_report;
/*Insert reporting data into table */
INSERT INTO  `{{params.ECOMM_ANALYTICS}}`.output.new_product_tracker_report



WITH gss AS (
    SELECT
        ean_upc_cd
        , CASE WHEN UPPER(customer_name) = 'WALMART_LUMINATE' THEN 'WALMART_OPD'
               WHEN UPPER(customer_name) = 'WALMART_OPD' THEN NULL
               ELSE customer_name
          END AS customer_name
        , CAST(fiscal_week_begin_dt AS DATE) fiscal_week_begin_dt
        , SUM(safe_cast(ty_sales_value AS FLOAT64)) ty_sales_value
        ,SUM(SAFE_CAST(ty_sales_units AS FLOAT64)) ty_sales_units
    FROM `{{params.ECOMM_ANALYTICS}}`.output.gss_sales_share_us_nar_report
    WHERE (ty_sales_value IS NOT NULL AND ty_sales_value != 0)
    GROUP BY
        ean_upc_cd
        , customer_name
        , fiscal_week_begin_dt
),



aa_retailer_agg AS (
    SELECT
        customer_parent
        ,customer_account
        ,customer_name
        ,ean_upc_cd
        ,material_short_desc
        ,sls_hier_division_desc
        ,sls_hier_category_desc
        ,sls_hier_sub_category_desc
        ,fiscal_month_period_desc
        ,fiscal_week_begin_dt_desc
        ,fiscal_month_in_year_nbr
        ,fiscal_year_nbr
        ,fiscal_quarter_in_year_nbr
        ,fiscal_month_in_year_short_desc
        ,fiscal_week_begin_dt
        ,fiscal_year_short_desc
        ,SUM(is_available) AS is_available
        ,SUM(is_instore) AS is_instore
        ,SUM(is_online) AS is_online
        ,SUM(is_instore_distribution_authorized) AS is_instore_distribution_authorized
        ,SUM(is_online_distribution) AS is_online_distribution
        ,SUM(is_online_distribution_authorized) AS is_online_distribution_authorized
    FROM `{{params.ECOMM_ANALYTICS}}.processed.assortment_availability_report_stage`
    GROUP BY
        customer_parent
        ,customer_account
        ,customer_name
        ,ean_upc_cd
        ,material_short_desc
        ,sls_hier_division_desc
        ,sls_hier_category_desc
        ,sls_hier_sub_category_desc
        ,fiscal_month_period_desc
        ,fiscal_week_begin_dt_desc
        ,fiscal_month_in_year_nbr
        ,fiscal_year_nbr
        ,fiscal_quarter_in_year_nbr
        ,fiscal_month_in_year_short_desc
        ,fiscal_week_begin_dt
        ,fiscal_year_short_desc
)

,enriched_data as (
SELECT
    av.customer_parent
    ,av.customer_account
    ,CASE
        WHEN av.customer_name IN ('KROGER','HYVEE') THEN av.customer_account
        ELSE av.customer_name
    END AS customer_name
    ,av.ean_upc_cd
    ,av.material_short_desc
    ,ecpc.brand_desc
    ,av.sls_hier_division_desc
    ,av.sls_hier_category_desc
    ,av.sls_hier_sub_category_desc
    ,ecpc.ipp_start_dt
    ,ecpc.ipp_end_dt
    ,CASE
        WHEN ipp_start_dt >= DATE_SUB( current_date(), INTERVAL 3 MONTH)
            THEN TRUE ELSE FALSE END AS new_product_3m
    ,CASE
        WHEN ipp_start_dt >= DATE_SUB( current_date(), INTERVAL 6 MONTH)
            THEN TRUE ELSE FALSE END AS new_product_6m
    ,CASE
        WHEN ipp_start_dt >= DATE_SUB( current_date(), INTERVAL 12 MONTH)
            THEN TRUE ELSE FALSE END AS new_product_12m
    ,av.fiscal_month_period_desc
    ,av.fiscal_week_begin_dt_desc
    ,av.fiscal_month_in_year_nbr
    ,av.fiscal_year_nbr
    ,av.fiscal_quarter_in_year_nbr
    ,av.fiscal_month_in_year_short_desc
    ,av.fiscal_week_begin_dt
    ,av.fiscal_year_short_desc
    ,av.is_instore
    ,av.is_online
    ,av.is_instore_distribution_authorized
    ,av.is_online_distribution
    ,av.is_online_distribution_authorized
    ,CASE
        WHEN av.customer_account = 'INSTACART_KROGER' THEN (gss.ty_sales_value * 0.11)
        WHEN av.customer_account = 'ADUSA_FOOD_LION' THEN (gss.ty_sales_value * 0.38)
        WHEN av.customer_account = 'ADUSA_STOP_AND_SHOP' THEN (gss.ty_sales_value * 0.27)
        WHEN av.customer_account = 'ADUSA_HANNAFORD' THEN (gss.ty_sales_value * 0.12)
        WHEN av.customer_account = 'ADUSA_GIANT_COMPANY' THEN (gss.ty_sales_value * 0.14)
        WHEN av.customer_account = 'ADUSA_GIANT_FOOD' THEN (gss.ty_sales_value * 0.09)
        ELSE gss.ty_sales_value
    END AS ty_sales_value
    ,ty_sales_units

FROM aa_retailer_agg av
    INNER JOIN (
        SELECT DISTINCT
            ean_upc_cd
            ,material_short_desc
            ,brand_desc
            ,ipp_start_dt
            ,ipp_end_dt
        FROM `{{params.ECOMM_DLF}}`.processed.ecomm_common_product_catalog ec1
        INNER JOIN (
            SELECT DISTINCT ean_upc_cd AS upc,material_short_desc as msd, MAX(ipp_start_dt) AS max_start
            FROM `{{params.ECOMM_DLF}}`.processed.ecomm_common_product_catalog
            WHERE ipp_start_dt <> '9999-12-31'
            GROUP BY ean_upc_cd, material_short_desc
            ) ec2
            ON ec1.ean_upc_cd = ec2.upc
            AND ec1.material_short_desc = ec2.msd
            AND ec1.ipp_start_dt = ec2.max_start
        WHERE current_flg = TRUE
        AND material_type_cd IN ('CNPK', 'FINI')
        AND source_type_cd = 'NA'
        AND language_cd = 'EN'
    ) ecpc
        ON av.ean_upc_cd = ecpc.ean_upc_cd
        AND av.material_short_desc = ecpc.material_short_desc

    LEFT JOIN gss
        ON av.fiscal_week_begin_dt = gss.fiscal_week_begin_dt
        AND av.ean_upc_cd = gss.ean_upc_cd
        AND (UPPER(av.customer_name) = UPPER(gss.customer_name)
        OR UPPER(av.customer_parent) = UPPER(gss.customer_name))

)

SELECT
    *
    ,ROUND(AVG(ty_sales_value)
      OVER (PARTITION BY customer_name,ean_upc_cd ORDER BY fiscal_week_begin_dt ROWS BETWEEN 12 PRECEDING AND CURRENT ROW), 2) AS rolling_13_weeks_avg_sales
    ,ROUND(AVG(ty_sales_units) 
      OVER (PARTITION BY customer_name,ean_upc_cd ORDER BY fiscal_week_begin_dt ROWS BETWEEN 12 PRECEDING AND CURRENT ROW), 2) AS rolling_13_weeks_avg_units   
    ,ROUND(AVG(ty_sales_value) 
      OVER (PARTITION BY customer_name,ean_upc_cd ORDER BY fiscal_week_begin_dt ROWS BETWEEN 25 PRECEDING AND CURRENT ROW), 2) AS rolling_26_weeks_avg_sales   
    ,ROUND(AVG(ty_sales_units) 
      OVER (PARTITION BY customer_name,ean_upc_cd ORDER BY fiscal_week_begin_dt ROWS BETWEEN 25 PRECEDING AND CURRENT ROW), 2) AS rolling_26_weeks_avg_units

FROM enriched_data
WHERE (new_product_3m = TRUE OR new_product_6m = TRUE OR new_product_12m = TRUE)

