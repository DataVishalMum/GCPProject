/* Truncate exsting data           */
TRUNCATE TABLE `{{params.ECOMM_ANALYTICS}}`.{{params.dataset}}.assortment_availability_report;
/*Insert reporting data into table */
INSERT INTO `{{params.ECOMM_ANALYTICS}}`.{{params.dataset}}.assortment_availability_report

with gss as (
    select
        ean_upc_cd
        , case when upper(customer_name) = 'WALMART_LUMINATE' then 'WALMART_OPD'
               when upper(customer_name) = 'WALMART_OPD' then null
               else customer_name
          end as customer_name
        , cast(fiscal_week_begin_dt as date) fiscal_week_begin_dt
        , sum(safe_cast(ty_sales_value as FLOAT64)) ty_sales_value
    from `ecomm-analytics-prd-6238a8`.output.gss_sales_share_us_nar_report
    where (ty_sales_value is not null and ty_sales_value != 0)
    group by
        ean_upc_cd
        ,customer_name
        ,fiscal_week_begin_dt
),

gss_delayed as (
    select
        ean_upc_cd
        , case when upper(customer_name) = 'WALMART_LUMINATE' then 'WALMART_OPD'
               when upper(customer_name) = 'WALMART_OPD' then null
               else customer_name
          end as customer_name
        , cast(fiscal_week_begin_dt as date) fiscal_week_begin_dt
        , sum(safe_cast(ty_sales_value as FLOAT64)) ty_sales_value
    from `ecomm-analytics-prd-6238a8`.output.gss_sales_share_us_nar_report
    where (ty_sales_value is not null and ty_sales_value != 0)
    AND
    fiscal_week_begin_dt = (
    SELECT
      MAX(fiscal_week_begin_dt)
    FROM
      `ecomm-analytics-prd-6238a8`.output.gss_sales_share_us_nar_report
    WHERE fiscal_week_begin_dt < current_date() - 35)
    group by
        ean_upc_cd
        ,customer_name
        ,fiscal_week_begin_dt
),

casefill as (
    select
        case
            when customer_parent = 'HEB SAN ANTONIO DRY ***'
                then 'HEB'
            when customer_parent in ('KROGER', 'MEIJER', 'TARGET', 'WALMART')
                then initcap(customer_parent)
            when customer_parent = 'ALBERTSONS' or customer_parent like '%SAFEWAY%'
                then 'Albertsons Safeway'
            when lower(customer_parent) like '%adusa distribution llc%'
                then 'ADUSA_HANNAFORD_FOODLION'
            when lower(customer_parent) like '%hyvee%'
                then 'HY VEE'
            when lower(customer_parent) like '%adusa giant food%'
                then 'ADUSA_GIANT_FOOD'
            when lower(customer_parent) like '%stop%'
                then 'ADUSA_STOP_AND_SHOP'
            when customer_parent like 'ADUSA GIANT COMPANY%'
                then 'ADUSA_GIANT_COMPANY'
            when lower(customer_parent) like '%publix%'
                then 'INSTACART_PUBLIX'
        end as customer_parent
        , case
            when length(ean_upc_derived_cd) = 14 and LEFT(ean_upc_derived_cd, 3) in ('100', '000')
                then substr(ean_upc_derived_cd, 4)
            when length(ean_upc_derived_cd) = 13 and LEFT(ean_upc_derived_cd, 1) = '0'
                then cast(cast(ean_upc_derived_cd as INT64) as STRING)
            else ean_upc_derived_cd
        end as ean_upc_derived_cd
        , fiscal_week_begin_dt
        , avg(cf_numerator) as casefill_numerator
        , avg(cf_denominator) as casefill_denominator
        , safe_divide(avg(cf_numerator), avg(cf_denominator)) as casefill_percentage
    from
`{{params.ECOMM_DLF}}`.processed.casefill_na_weekly
    where (customer_parent in ('HEB SAN ANTONIO DRY ***', 'KROGER', 'MEIJER', 'TARGET', 'WALMART', 'ALBERTSONS')
    or customer_parent like '%SAFEWAY%'
    or lower(customer_parent) like '%hannaford%'
    or lower(customer_parent) like '%hyvee%'
    or lower(customer_parent) like '%giant food%'
    or lower(customer_parent) like '%stop%'
    or lower(customer_parent) like '%giant company%'
    or lower(customer_parent) like '%adusa%'
    or lower(customer_parent) like '%publix%')
    group by
        customer_parent
        , ean_upc_derived_cd
        , fiscal_week_begin_dt
),

update_customer_parent as (

select
store_zipcode,
store_display_name,
unique_store_composite_key,
ean_upc_cd,
sls_hier_division_desc,
sls_hier_category_desc,
sls_hier_sub_category_desc,
material_short_desc,
consecutive_missing_weeks,
cm_tdp_reach,
is_available,
is_instore,
is_online,
is_instore_distribution_authorized,
is_online_distribution,
is_online_distribution_authorized,
fiscal_month_period_desc,
fiscal_week_begin_dt_desc,
fiscal_month_in_year_nbr,
fiscal_year_nbr,
fiscal_quarter_in_year_nbr,
fiscal_month_in_year_short_desc,
fiscal_week_begin_dt,
fiscal_year_short_desc,
report_fg,
retailer_type,
CASE
        WHEN customer_parent = 'Publix' THEN 'Instacart'
        else customer_parent end as
customer_parent,
customer_account,
customer_name,
available_count,
ly_online_distribution_count
FROM `{{params.ECOMM_ANALYTICS}}.processed.assortment_availability_report_stage`
),

enriched_data as (
SELECT
    av.store_zipcode
    ,av.store_display_name
    ,av.unique_store_composite_key
    ,av.ean_upc_cd
    ,av.sls_hier_division_desc
    ,av.sls_hier_category_desc
    ,av.sls_hier_sub_category_desc
    ,av.material_short_desc
    ,ecpc.current_flg
    ,ecpc.is_conversion_flg
    ,ecpc.ci_launch_type_cd
    ,ecpc.product_in_out_seasonal_flg
    ,ecpc.special_pack_sales_seasonal_flg
    ,ecpc.is_new_prod_for_curr_week_flg
    ,ecpc.material_status_cd
    ,ecpc.base_product_desc
    ,ecpc.base_uom_to_eqc_fctr
    ,ecpc.gmi_division_desc
    ,ecpc.is_divested_fg
    ,ecpc.size_dimension_txt
    ,ecpc.brand_desc
    ,ecpc.consumer_brand_desc
    ,ecpc.base_product_material_valid_from_dt
    ,ecpc.ipp_start_dt
    ,ecpc.ipp_end_dt
    ,ecpc.srm_effective_date
    ,ecpc.current_upc
    ,ecpc.conversion_status
    ,av.consecutive_missing_weeks
    ,av.cm_tdp_reach
    ,av.is_available
    ,av.is_instore
    ,av.is_online
    ,CASE
        WHEN UPPER(av.customer_name) IN ('SHOPRITE','INSTACART_PUBLIX','HYVEE','HEB','ALBERTSONS_SAFEWAY','ADUSA_HANNAFORD','ADUSA_FOODLION') and is_instore_distribution_authorized=0
        THEN NULL
        ELSE av.is_instore_distribution_authorized
    END AS is_instore_distribution_authorized
    ,av.is_online_distribution
    ,av.is_online_distribution_authorized
    ,av.fiscal_month_period_desc
    ,av.fiscal_week_begin_dt_desc
    ,av.fiscal_month_in_year_nbr
    ,av.fiscal_year_nbr
    ,av.fiscal_quarter_in_year_nbr
    ,av.fiscal_month_in_year_short_desc
    ,av.fiscal_week_begin_dt
    ,av.fiscal_year_short_desc
    ,av.report_fg
    ,av.retailer_type
    ,av.customer_parent
    ,av.customer_account
       ,CASE
        WHEN av.customer_name IN ('KROGER','HYVEE') THEN av.customer_account
        ELSE av.customer_name
        END AS customer_name
    ,av.available_count
    ,av.ly_online_distribution_count
    ,CASE
        WHEN av.customer_account = 'INSTACART_KROGER' THEN safe_cast((gss.ty_sales_value * 0.11) AS FLOAT64)
        WHEN av.customer_account = 'INSTACART_PUBLIX' THEN safe_cast((gss.ty_sales_value * 0.21) AS FLOAT64)
        WHEN av.customer_account = 'INSTACART_WALMART_OPD' THEN safe_cast((gss.ty_sales_value * 0.02) AS FLOAT64)
        WHEN av.customer_account = 'ADUSA_FOOD_LION' THEN safe_cast((gss.ty_sales_value * 0.38) AS FLOAT64)
        WHEN av.customer_account = 'ADUSA_STOP_AND_SHOP' THEN safe_cast((gss.ty_sales_value * 0.27) AS FLOAT64)
        WHEN av.customer_account = 'ADUSA_HANNAFORD' THEN safe_cast((gss.ty_sales_value * 0.12) AS FLOAT64)
        WHEN av.customer_account = 'ADUSA_GIANT_COMPANY' THEN safe_cast((gss.ty_sales_value * 0.14) AS FLOAT64)
        WHEN av.customer_account = 'ADUSA_GIANT_FOOD' THEN safe_cast((gss.ty_sales_value * 0.09) AS FLOAT64)
        ELSE safe_cast(COALESCE(gss.ty_sales_value,gss_delayed.ty_sales_value) AS FLOAT64)
    END AS ty_sales_value
    ,cs.casefill_percentage
    ,COALESCE(luminate.stores_selling_delivery_amt, delayed_luminate.stores_selling_delivery_amt) AS stores_selling_delivery_amt
    ,COALESCE(luminate.stores_selling_in_store_amt, delayed_luminate.stores_selling_in_store_amt) AS stores_selling_in_store_amt
    ,COALESCE(luminate.stores_selling_ecom_amt, delayed_luminate.stores_selling_ecom_amt) AS stores_selling_ecom_amt
    ,COALESCE(luminate.stores_selling_pickup_amt, delayed_luminate.stores_selling_pickup_amt) AS stores_selling_pickup_amt
    ,COALESCE(luminate.stores_selling_total_amt, delayed_luminate.stores_selling_total_amt) AS stores_selling_total_amt
    ,CASE
--        WHEN
--            SUM(av.is_online_distribution)
--            OVER (PARTITION BY av.customer_parent, av.ean_upc_cd, av.fiscal_week_begin_dt) -
--            COALESCE(luminate.stores_selling_in_store_amt, delayed_luminate.stores_selling_in_store_amt) < 0
--        THEN 'Yes'
        WHEN
            av.customer_account IN ('TARGET','KROGER GROCERY','MEIJER','WALMART OPD') AND
            SUM(COALESCE(gss.ty_sales_value,gss_delayed.ty_sales_value))
            OVER (PARTITION BY av.ean_upc_cd, av.customer_parent, av.unique_store_composite_key, av.fiscal_week_begin_dt) > 100
            AND
            COALESCE(av.is_online_distribution_authorized,0) = 0
        THEN 'Yes'
        WHEN
            av.customer_account NOT IN ('AMAZON.COM','AMAZON FRESH','KROGER GROCERY','MEIJER','TARGET','WALMART OPD') AND
            SUM(COALESCE(gss.ty_sales_value,gss_delayed.ty_sales_value))
            OVER (PARTITION BY av.ean_upc_cd, av.customer_parent, av.unique_store_composite_key, av.fiscal_week_begin_dt) > 100
            AND
            COALESCE(av.is_online, 0) = 0
        THEN 'Yes'

        WHEN
            IFNULL(SUM(COALESCE(gss.ty_sales_value,gss_delayed.ty_sales_value))
            OVER (PARTITION BY av.ean_upc_cd, av.customer_parent, av.unique_store_composite_key, av.fiscal_week_begin_dt),0) = 0
            AND
            COALESCE(av.is_online, 0) > 100

        THEN 'No'
--        WHEN
--            SUM(av.is_online_distribution)
--            OVER (PARTITION BY av.customer_parent, av.ean_upc_cd, av.fiscal_week_begin_dt) -
--            COALESCE(luminate.stores_selling_in_store_amt, delayed_luminate.stores_selling_in_store_amt) > 0
--        THEN 'No'
        WHEN  av.customer_account in ('AMAZON.COM','AMAZON FRESH') THEN 'N/A'
        ELSE 'No'
    END AS fp_flag

FROM update_customer_parent av
    LEFT JOIN (
        SELECT DISTINCT
             ean_upc_cd
            ,max(material_short_desc) as material_short_desc
            ,max(current_flg) as current_flg
            ,max(is_conversion_flg) as is_conversion_flg
            ,max(ci_launch_type_cd) as ci_launch_type_cd
            ,max(product_in_out_seasonal_flg) as product_in_out_seasonal_flg
            ,max(special_pack_sales_seasonal_flg) as special_pack_sales_seasonal_flg
            ,max(is_new_prod_for_curr_week_flg) as is_new_prod_for_curr_week_flg
            ,max(material_status_cd) as material_status_cd
            ,max(base_product_desc) as base_product_desc
            ,max(base_uom_to_eqc_fctr) as base_uom_to_eqc_fctr
            ,max(gmi_division_desc) as gmi_division_desc
            ,max(is_divested_fg) as is_divested_fg
            ,max(size_dimension_txt) as size_dimension_txt
            ,max(brand_desc) as brand_desc
            ,max(consumer_brand_desc) as consumer_brand_desc
            ,max(base_product_material_valid_from_dt) as base_product_material_valid_from_dt
            ,max(ipp_start_dt) as ipp_start_dt
            ,max(srm_effective_date) as srm_effective_date
            ,max(ipp_end_dt) as ipp_end_dt
            ,max(current_upc) as current_upc
            ,max(conversion_status) as conversion_status

        FROM `{{params.ECOMM_DLF}}`.processed.ecomm_common_product_catalog ec1
        WHERE
        current_flg = TRUE
        AND material_type_cd IN ('CNPK', 'FINI')
        AND source_type_cd = 'NA'
        AND language_cd = 'EN'

        group by ean_upc_cd
    ) ecpc
        ON av.ean_upc_cd = ecpc.ean_upc_cd

    LEFT JOIN gss
        ON av.fiscal_week_begin_dt = gss.fiscal_week_begin_dt
        AND av.ean_upc_cd = gss.ean_upc_cd
        AND (UPPER(av.customer_name) = UPPER(gss.customer_name)
        OR UPPER(av.customer_parent) = UPPER(gss.customer_name))

    LEFT JOIN gss_delayed
            ON av.ean_upc_cd = gss_delayed.ean_upc_cd
            AND (UPPER(av.customer_name) = UPPER(gss_delayed.customer_name)
            OR UPPER(av.customer_parent) = UPPER(gss_delayed.customer_name))

    LEFT JOIN casefill cs
        ON av.fiscal_week_begin_dt = cs.fiscal_week_begin_dt
        AND av.ean_upc_cd = cs.ean_upc_derived_cd
        AND (UPPER(av.customer_parent) = UPPER(cs.customer_parent)
        OR UPPER(cs.customer_parent) like REGEXP_EXTRACT(UPPER(av.customer_account),'KROGER') -- can we switch to customer_name for performance?
        OR UPPER(cs.customer_parent) like REGEXP_EXTRACT(UPPER(av.customer_account), 'WALMART')
        OR UPPER(cs.customer_parent) like REGEXP_EXTRACT(UPPER(av.customer_account), 'INSTACART_PUBLIX')
        OR UPPER(cs.customer_parent) like REGEXP_EXTRACT(UPPER(av.customer_account), 'ADUSA_GIANT_FOOD')
        OR UPPER(cs.customer_parent) like REGEXP_EXTRACT(UPPER(av.customer_account), 'ADUSA_GIANT_COMPANY')
        OR UPPER(cs.customer_parent) like REGEXP_EXTRACT(UPPER(av.customer_account), 'ADUSA_STOP_AND_SHOP')
        OR REGEXP_EXTRACT(UPPER(cs.customer_parent), 'HANNAFORD') like REGEXP_EXTRACT(UPPER(av.customer_account), 'HANNAFORD')
        OR REGEXP_EXTRACT(UPPER(cs.customer_parent), 'FOODLION') like REGEXP_EXTRACT(UPPER(av.customer_account), 'FOODLION'))

    LEFT JOIN (
        SELECT
            customer_parent,
            ean_upc_cd,
            fiscal_week_begin_dt,
            MAX(stores_selling_delivery_amt) AS stores_selling_delivery_amt,
            MAX(stores_selling_in_store_amt) AS stores_selling_in_store_amt,
            MAX(stores_selling_ecom_amt) AS stores_selling_ecom_amt,
            MAX(stores_selling_pickup_amt) AS stores_selling_pickup_amt,
            MAX(stores_selling_total_amt) AS stores_selling_total_amt
        FROM `{{params.ECOMM_DLF}}`.processed.walmart_luminate_fact
        GROUP BY
            customer_parent,
            ean_upc_cd,
            fiscal_week_begin_dt
        ) luminate
        ON av.fiscal_week_begin_dt = CAST(luminate.fiscal_week_begin_dt AS DATE)
        AND av.ean_upc_cd = luminate.ean_upc_cd
        AND av.customer_name = 'WALMART_OPD'

    LEFT JOIN (
        SELECT
            customer_parent,
            ean_upc_cd,
            fiscal_week_begin_dt,
            MAX(stores_selling_delivery_amt) AS stores_selling_delivery_amt,
            MAX(stores_selling_in_store_amt) AS stores_selling_in_store_amt,
            MAX(stores_selling_ecom_amt) AS stores_selling_ecom_amt,
            MAX(stores_selling_pickup_amt) AS stores_selling_pickup_amt,
            MAX(stores_selling_total_amt) AS stores_selling_total_amt
        FROM `{{params.ECOMM_DLF}}`.processed.walmart_luminate_fact
        WHERE fiscal_week_begin_dt IN (SELECT MAX(fiscal_week_begin_dt) FROM `{{params.ECOMM_DLF}}`.processed.walmart_luminate_fact)
        GROUP BY
            customer_parent,
            ean_upc_cd,
            fiscal_week_begin_dt
        ) delayed_luminate
        ON av.ean_upc_cd = delayed_luminate.ean_upc_cd
        AND av.customer_name = 'WALMART_OPD'
)

SELECT
    *
FROM enriched_data
WHERE
    (is_instore_distribution_authorized <> 0  OR is_instore_distribution_authorized IS NULL) AND
    (material_status_cd = 'A' OR material_status_cd IS NULL)AND
    customer_name NOT IN ('ADUSA_GIANT_COMPANY', 'ADUSA_GIANT_FOOD', 'ADUSA_STOP_AND_SHOP')