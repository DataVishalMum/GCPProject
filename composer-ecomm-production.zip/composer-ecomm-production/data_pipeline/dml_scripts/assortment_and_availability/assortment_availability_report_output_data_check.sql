select
count(*) - (select count(*) from `{{params.ECOMM_ANALYTICS}}`.processed.assortment_availability_report_stage)
from `{{params.ECOMM_ANALYTICS}}`.output.assortment_availability_report