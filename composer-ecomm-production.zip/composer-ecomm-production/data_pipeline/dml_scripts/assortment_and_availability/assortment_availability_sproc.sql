CREATE OR REPLACE PROCEDURE `{{params.ECOMM_DLF}}`.transient.ecomm_sproc_assortment_availability_report_stage_{{params.retailer}}
(
)
BEGIN
DECLARE store_zipcode STRING DEFAULT NULL;
DECLARE store_display_name DEFAULT 'customer_account';
DECLARE unique_store_composite_key DEFAULT 'customer_account';
DECLARE consecutive_missing_weeks DEFAULT 0;
DECLARE cm_tdp_reach DEFAULT NULL;
DECLARE is_instore DEFAULT NULL;
DECLARE is_instore_distribution_authorized DEFAULT NULL;
DECLARE is_online_distribution DEFAULT NULL;
DECLARE is_online_distribution_authorized DEFAULT NULL;

INSERT INTO `{{params.ECOMM_ANALYTICS}}`.processed.assortment_availability_report_stage

   WITH calendar AS (
    SELECT
      fiscal_year_month_nbr
        , fiscal_month_in_year_nbr
        , fiscal_month_in_year_short_desc
        , fiscal_week_begin_dt
        , fiscal_year_nbr
        , fiscal_year_week_nbr
        , fiscal_quarter_in_year_nbr
        , fiscal_year_short_desc
        , MIN(calendar_year_nbr) AS calendar_year_nbr
    FROM `edw-prd-e567f9.enterprise.dim_date` cal
    WHERE cal.language_cd = 'EN'
    AND cal.fiscal_year_variant_cd = '07'
    AND cal.calendar_dt >= DATE_SUB(CURRENT_DATE(), INTERVAL 735 DAY)
    GROUP BY
        fiscal_year_month_nbr
        , fiscal_month_in_year_nbr
        , fiscal_month_in_year_short_desc
        , fiscal_week_begin_dt
        , fiscal_year_nbr
        , fiscal_year_week_nbr
        , fiscal_quarter_in_year_nbr
        , fiscal_year_short_desc
)

    SELECT
    CAST(store_zipcode AS string) AS store_zipcode
    ,CAST(store_display_name AS string) AS store_display_name
    ,unique_store_composite_key
    ,ean_upc_cd
    ,sls_hier_division_desc
    ,sls_hier_category_desc
    ,sls_hier_sub_category_desc
    ,material_short_desc
    ,consecutive_missing_weeks AS consecutive_missing_weeks
    ,cm_tdp_reach AS cm_tdp_reach
    ,is_available
    ,is_instore AS is_instore
    ,is_online
    ,is_instore_distribution_authorized AS is_instore_distribution_authorized
    ,is_online_distribution AS is_online_distribution
    ,is_online_distribution_authorized AS is_online_distribution_authorized
    ,concat(CAST(cal.fiscal_month_in_year_nbr AS string), '-', cal.fiscal_month_in_year_short_desc) fiscal_month_period_desc
    ,CAST(DATE(cal.fiscal_week_begin_dt) AS string) fiscal_week_begin_dt_desc
    ,cal.fiscal_month_in_year_nbr
    ,cal.fiscal_year_nbr
    ,cal.fiscal_quarter_in_year_nbr
    ,cal.fiscal_month_in_year_short_desc
    ,cal.fiscal_week_begin_dt
    ,cal.fiscal_year_short_desc
    ,'Y' report_fg
    ,retailer_type
    ,customer_parent
    ,customer_account
    ,fct.customer_name
    ,ifnull(fct.is_available,0) AS available_count
    ,LEAD (ifnull(fct.is_online,0), 1,NULL)
      OVER (PARTITION BY fct.customer_account, fct.fiscal_week_in_year_nbr, fct.ean_upc_cd ORDER BY fct.fiscal_year_week_nbr DESC) ly_online_distribution_count
    FROM
    `{{params.ECOMM_DLF}}`.processed.{{params.retailer}}_distribution_availability_with_upc_fact fct
      INNER JOIN `{{params.ECOMM_DLF}}`.processed.ecom_data_release_control  cntrl
         ON fct.fiscal_year_week_nbr=cntrl.fiscal_year_week_nbr
         AND fct.fiscal_year_month_nbr=cntrl.fiscal_year_month_nbr
      INNER JOIN calendar cal
         ON fct.fiscal_year_week_nbr = cal.fiscal_year_week_nbr
         AND fct.fiscal_year_month_nbr = cal.fiscal_year_month_nbr
      WHERE
       cntrl.staging_flg='Y' AND cntrl.release_flg = 'Y'
       AND cntrl.feed_name= UPPER('{{params.retailer}}_DISTRIBUTION_AVAILABILITY_SUBCATG_AGG_FACT')
       AND UPPER(sls_hier_division_desc) IN ('MEALS-BAKING','MORNING FOODS','SNACKS')

;END;

call `{{params.ECOMM_DLF}}`.transient.ecomm_sproc_assortment_availability_report_stage_{{params.retailer}}
();
