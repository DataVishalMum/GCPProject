/*
Purpose of the stored proc:

We need to monitor the converted items to check if they are performing well post conversion and if the
customer websites have reflected the new converted upcs.

Author :
	Danny Godwin
*/

CREATE OR REPLACE PROCEDURE `{{params.ECOMM_DLF}}`.transient.ecomm_sproc_ecom_new_conversion_tracker_AnA_only_retailers()

BEGIN
DECLARE is_instore DEFAULT NULL;
DECLARE is_available DEFAULT NULL;
DECLARE is_instore_distribution_authorized DEFAULT NULL;
DECLARE is_online_distribution DEFAULT NULL;
DECLARE is_online_distribution_authorized DEFAULT NULL;
DECLARE unique_store_composite_key DEFAULT 'customer_account';

INSERT INTO `{{params.ECOMM_ANALYTICS}}`.output.new_upc_conversion_report

WITH
  gss AS (
      SELECT
        ean_upc_cd
        , CASE WHEN UPPER(customer_name) = 'WALMART_LUMINATE' THEN 'WALMART_OPD'
               WHEN UPPER(customer_name) = 'WALMART_OPD' THEN NULL
               ELSE customer_name
          END AS customer_name
        , CAST(fiscal_week_begin_dt AS DATE) fiscal_week_begin_dt
        , SUM(safe_cast(ty_sales_value AS FLOAT64)) ty_sales_value
        , SUM(SAFE_CAST(ty_sales_units AS FLOAT64)) ty_sales_units
        , SUM(safe_cast(ly_sales_value AS FLOAT64)) ly_sales_value
        , SUM(safe_cast(ly_sales_units AS FLOAT64)) ly_sales_units
    FROM `ecomm-analytics-prd-6238a8`.output.gss_sales_share_us_nar_report
    WHERE (ty_sales_value IS NOT NULL AND ty_sales_value != 0)
    GROUP BY
        ean_upc_cd
        , customer_name
        , fiscal_week_begin_dt),

  calendar AS (
  SELECT
    fiscal_year_month_nbr,
    fiscal_month_in_year_nbr,
    fiscal_month_in_year_short_desc,
    fiscal_week_begin_dt,
    fiscal_year_nbr,
    fiscal_year_week_nbr,
    fiscal_quarter_in_year_nbr,
    fiscal_year_short_desc,
    MIN(calendar_year_nbr) AS calendar_year_nbr,
    fiscal_dt
  FROM
    `edw-prd-e567f9.enterprise.dim_date` cal
  WHERE
    cal.language_cd = 'EN'
    AND cal.fiscal_year_variant_cd = '07'
    AND cal.calendar_dt >= DATE_SUB(CURRENT_DATE(), INTERVAL 600 DAY)
  GROUP BY
    fiscal_dt,
    fiscal_year_month_nbr,
    fiscal_month_in_year_nbr,
    fiscal_month_in_year_short_desc,
    fiscal_week_begin_dt,
    fiscal_year_nbr,
    fiscal_year_week_nbr,
    fiscal_quarter_in_year_nbr,
    fiscal_year_short_desc ),

  data_enriched AS (
  SELECT
    av.ean_upc_cd,
    cal.fiscal_year_month_nbr AS fiscal_year_month_nbr,
    cal.fiscal_month_in_year_nbr AS fiscal_month_in_year_nbr,
    cal.fiscal_month_in_year_short_desc AS fiscal_month_in_year_short_desc,
    cal.fiscal_week_begin_dt AS fiscal_week_begin_dt,
    cal.fiscal_year_week_nbr AS fiscal_year_week_nbr,
    cal.fiscal_quarter_in_year_nbr AS fiscal_quarter_in_year_nbr,
    cal.fiscal_year_short_desc AS fiscal_year_short_desc,
    av.customer_account,
    av.customer_parent,
    COALESCE(pc.srm_old_gmi_cnpk_upc_cd, pc_post.srm_old_gmi_cnpk_upc_cd) AS srm_old_gmi_cnpk_upc_cd,
    COALESCE(pc.conv_srm_new_upc_cd, pc_post.conv_srm_new_upc_cd) AS conv_srm_new_upc_cd,
    COALESCE(pc.brand_desc, pc_post.brand_desc) AS brand_desc,
    COALESCE(pc.consumer_brand_desc, pc_post.consumer_brand_desc) AS consumer_brand_desc,
    COALESCE(CAST(pc.srm_effective_date AS DATE), CAST(pc_post.srm_effective_date AS DATE)) AS srm_effective_date,
--    av.old_sls_hier_division_desc,
--    av.old_sls_hier_category_desc,
--    av.old_sls_hier_sub_category_desc,
--    av.old_sls_hier_ppg_desc,
--    av.old_material_short_desc,
    av.sls_hier_division_desc,
    av.sls_hier_category_desc,
    av.sls_hier_sub_category_desc,
--    av.sls_hier_ppg_desc,
    av.is_online,
    av.is_instore,
    av.is_available,
    LAG(av.is_online,364) OVER(Partition by av.ean_upc_cd, av.customer_account order by cal.fiscal_dt asc) AS ly_is_online,
    LAG(av.is_instore,364) OVER(Partition by av.ean_upc_cd, av.customer_account order by cal.fiscal_dt asc) AS ly_is_instore,
    LAG(av.is_available,364) OVER(Partition by av.ean_upc_cd, av.customer_account order by cal.fiscal_dt asc) AS ly_is_available,
    av.unique_store_composite_key,
    av.is_instore_distribution_authorized,
    av.is_online_distribution,
    av.is_online_distribution_authorized,
    CASE
      WHEN av.customer_account = 'INSTACART_KROGER' THEN (gss.ty_sales_value * 0.11)
      WHEN av.customer_account = 'ADUSA_FOOD_LION' THEN (gss.ty_sales_value * 0.38)
      WHEN av.customer_account = 'ADUSA_STOP_AND_SHOP' THEN (gss.ty_sales_value * 0.27)
      WHEN av.customer_account = 'ADUSA_HANNAFORD' THEN (gss.ty_sales_value * 0.12)
      WHEN av.customer_account = 'ADUSA_GIANT_COMPANY' THEN (gss.ty_sales_value * 0.14)
      WHEN av.customer_account = 'ADUSA_GIANT_FOOD' THEN (gss.ty_sales_value * 0.09)
    ELSE
    gss.ty_sales_value
  END
    AS ty_sales_value,
    gss.ty_sales_units AS ty_sales_units,
    CASE
      WHEN av.customer_account = 'INSTACART_KROGER' THEN (gss.ly_sales_value * 0.11)
      WHEN av.customer_account = 'ADUSA_FOOD_LION' THEN (gss.ly_sales_value * 0.38)
      WHEN av.customer_account = 'ADUSA_STOP_AND_SHOP' THEN (gss.ly_sales_value * 0.27)
      WHEN av.customer_account = 'ADUSA_HANNAFORD' THEN (gss.ly_sales_value * 0.12)
      WHEN av.customer_account = 'ADUSA_GIANT_COMPANY' THEN (gss.ly_sales_value * 0.14)
      WHEN av.customer_account = 'ADUSA_GIANT_FOOD' THEN (gss.ly_sales_value * 0.09)
    ELSE
    gss.ly_sales_value
  END
    AS ly_sales_value,
    gss.ly_sales_units AS ly_sales_units

FROM `{{params.ECOMM_ANALYTICS}}`.processed.assortment_availability_report_stage av
    LEFT JOIN (
      SELECT DISTINCT ean_upc_cd,
      srm_old_gmi_cnpk_upc_cd,
      conv_srm_new_upc_cd,
      brand_desc,
      consumer_brand_desc,
      srm_effective_date,
      material_short_desc,
      ipp_start_dt,
      ipp_end_dt
        FROM `{{params.ECOMM_DLF}}`.processed.ecomm_common_product_catalog ec1
        INNER JOIN (
            SELECT DISTINCT ean_upc_cd AS upc,material_short_desc as msd, MAX(ipp_start_dt) AS max_start
            FROM `{{params.ECOMM_DLF}}`.processed.ecomm_common_product_catalog
            WHERE ipp_start_dt <> '9999-12-31'
            GROUP BY ean_upc_cd, material_short_desc
            ) ec2
            ON ec1.ean_upc_cd = ec2.upc
            AND ec1.material_short_desc = ec2.msd
            AND ec1.ipp_start_dt = ec2.max_start
        WHERE current_flg = TRUE
        AND material_type_cd IN ('CNPK', 'FINI')
        AND source_type_cd = 'NA'
        AND language_cd = 'EN'
    ) pc
        ON av.ean_upc_cd = pc.ean_upc_cd

LEFT JOIN (
      SELECT DISTINCT
      ean_upc_cd,
      srm_old_gmi_cnpk_upc_cd,
      conv_srm_new_upc_cd,
      brand_desc,
      consumer_brand_desc,
      srm_effective_date,
      material_short_desc,
      ipp_start_dt,
      ipp_end_dt
        FROM `{{params.ECOMM_DLF}}`.processed.ecomm_common_product_catalog ec1
       INNER JOIN (
           SELECT DISTINCT ean_upc_cd AS upc,material_short_desc as msd, MAX(ipp_start_dt) AS max_start
           FROM `{{params.ECOMM_DLF}}`.processed.ecomm_common_product_catalog
           WHERE ipp_start_dt <> '9999-12-31'
           GROUP BY ean_upc_cd, material_short_desc
           ) ec2
           ON ec1.ean_upc_cd = ec2.upc
           AND ec1.material_short_desc = ec2.msd
           AND ec1.ipp_start_dt = ec2.max_start
        WHERE current_flg = TRUE
        AND material_type_cd IN ('CNPK', 'FINI')
        AND source_type_cd = 'NA'
        AND language_cd = 'EN'
    ) pc_post
        ON av.ean_upc_cd = SUBSTRING(pc_post.conv_srm_new_upc_cd,3,11)

      INNER JOIN
    calendar cal
  ON
    av.fiscal_week_begin_dt = cal.fiscal_week_begin_dt
    AND av.fiscal_year_nbr = cal.fiscal_year_nbr

    LEFT JOIN gss

        ON av.fiscal_week_begin_dt = gss.fiscal_week_begin_dt
        AND av.ean_upc_cd = gss.ean_upc_cd
        AND (UPPER(av.customer_name) = UPPER(gss.customer_name)
        OR UPPER(av.customer_parent) = UPPER(gss.customer_name))
    ),

data_enriched_with_new_material_desc as (

SELECT

data_enriched.*,
md.material_short_desc

FROM
data_enriched

LEFT JOIN (
      SELECT DISTINCT
      ean_upc_cd,
      conv_srm_new_upc_cd,
      brand_desc,
      consumer_brand_desc,
      material_short_desc,

        FROM `{{params.ECOMM_DLF}}`.processed.ecomm_common_product_catalog ec1
       INNER JOIN (
           SELECT DISTINCT ean_upc_cd AS upc,material_short_desc as msd, MAX(ipp_start_dt) AS max_start
           FROM `{{params.ECOMM_DLF}}`.processed.ecomm_common_product_catalog
           WHERE ipp_start_dt <> '9999-12-31'
           GROUP BY ean_upc_cd, material_short_desc
           ) ec2
           ON ec1.ean_upc_cd = ec2.upc
           AND ec1.material_short_desc = ec2.msd
           AND ec1.ipp_start_dt = ec2.max_start
        WHERE current_flg = TRUE
        AND material_type_cd IN ('CNPK', 'FINI')
        AND source_type_cd = 'NA'
        AND language_cd = 'EN'
    ) md
        ON
        SUBSTRING(data_enriched.conv_srm_new_upc_cd,3,11) = md.ean_upc_cd
)

SELECT
  *,
  TRUNC(AVG(ty_sales_value) OVER (PARTITION BY customer_parent, ean_upc_cd ORDER BY fiscal_week_begin_dt ASC ROWS BETWEEN 12 PRECEDING AND CURRENT ROW), 2) AS rolling_13_weeks_avg_sales,
  TRUNC(AVG(ty_sales_units) OVER (PARTITION BY customer_parent, ean_upc_cd ORDER BY fiscal_week_begin_dt ASC ROWS BETWEEN 12 PRECEDING AND CURRENT ROW), 2) AS rolling_13_weeks_avg_units,
  TRUNC(AVG(ty_sales_value) OVER (PARTITION BY customer_parent, ean_upc_cd ORDER BY fiscal_week_begin_dt ASC ROWS BETWEEN 25 PRECEDING AND CURRENT ROW), 2) AS rolling_26_weeks_avg_sales,
  TRUNC(AVG(ty_sales_units) OVER (PARTITION BY customer_parent, ean_upc_cd ORDER BY fiscal_week_begin_dt ASC ROWS BETWEEN 25 PRECEDING AND CURRENT ROW), 2) AS rolling_26_weeks_avg_units
FROM
  data_enriched_with_new_material_desc
  ;
END;

call `{{params.ECOMM_DLF}}`.transient.ecomm_sproc_ecom_new_conversion_tracker_AnA_only_retailers();