DECLARE bq_target_project_name STRING DEFAULT NULL;
DECLARE bq_target_dataset_name STRING DEFAULT NULL;
DECLARE bq_customer_info_project_name STRING DEFAULT NULL;
DECLARE bq_customer_info_dataset_name STRING DEFAULT NULL;
DECLARE bq_customer_info_table_name STRING DEFAULT NULL;
DECLARE target_table_list STRING DEFAULT NULL;
DECLARE apply_all_rls BOOL DEFAULT NULL;
CALL `{{params.ECOMM_DLF}}.processed.sp_apply_rls_policies_on_tables`(
  
  "{{params.TARGET_PROJECT}}", 
  "output", 
  "{{params.TARGET_PROJECT}}", 
  "processed", 
  "ecomm_common_customer_info", 
   "'assortment_availability_report','ecom_new_product_tracker_report','ecomm_ana_euau_assortment_report','ecomm_ana_euau_availability_report','upc_conversions_report','gss_sales_share_blue_report','gss_sales_share_ca_nar_report','gss_sales_share_euau_report','gss_sales_share_france_report','gss_sales_share_tesco_omni_report','gss_sales_share_us_nar_report','gss_sales_share_walmart_luminate_pet_omni_report','gss_sales_share_blue_report_stage','gss_sales_share_ca_nar_report_stage','gss_sales_share_euau_report_stage','gss_sales_share_france_report_stage','gss_sales_share_tesco_omni_report_stage','gss_sales_share_us_nar_report_stage','gss_sales_share_walmart_luminate_pet_omni_report_stage'", 
  FALSE);