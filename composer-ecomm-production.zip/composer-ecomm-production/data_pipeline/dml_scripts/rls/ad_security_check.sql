
--        UPDATE `{{params.DESTINATION_PROJECT}}`.{{params.source_dataset}}.{{params.source_table}} x
--        SET
--            x.is_active_flg = false,
--            x.modified_by = "RLS - AD Group Check",
--            x.modified_dt =  CURRENT_TIMESTAMP()
--        WHERE
--            x.is_active_flg = true
--        AND x.security_type = 'GROUP'
        
--        AND x.security_name NOT IN (
--            SELECT
--               s.security_name
--            FROM `{{params.DESTINATION_PROJECT}}`.{{params.source_dataset}}.{{params.source_table}} s
--            JOIN `edw-prd-e567f9.enterprise.dim_azure_ad_membership_flat` ad ON s.security_name = ad.group_display_nm
--            JOIN `{{params.DESTINATION_PROJECT}}`.{{params.source_dataset}}.ecomm_common_customer_security d on d.security_id = s.security_id
--            )
--;



   -- DROP ALL ROW ACCESS POLICIES ON  `ecomm-analytics-prd-6238a8.output.gss_sales_share_blue_report`;
   --DROP ALL ROW ACCESS POLICIES ON  `ecomm-analytics-prd-6238a8.output.gss_sales_share_ca_nar_report`;
   --DROP ALL ROW ACCESS POLICIES ON  `ecomm-analytics-prd-6238a8.output.gss_sales_share_euau_report`;
   --DROP ALL ROW ACCESS POLICIES ON  `ecomm-analytics-prd-6238a8.output.gss_sales_share_france_report`;
   --DROP ALL ROW ACCESS POLICIES ON  `ecomm-analytics-prd-6238a8.output.gss_sales_share_tesco_omni_report`;
   --DROP ALL ROW ACCESS POLICIES ON  `ecomm-analytics-prd-6238a8.output.gss_sales_share_us_nar_report`;
   -- DROP ALL ROW ACCESS POLICIES ON  `ecomm-analytics-prd-6238a8.output.gss_sales_share_walmart_luminate_pet_omni_report`;

   -- DROP ALL ROW ACCESS POLICIES ON  `ecomm-analytics-prd-6238a8.output.gss_sales_share_blue_report_stage`;
   --DROP ALL ROW ACCESS POLICIES ON  `ecomm-analytics-prd-6238a8.output.gss_sales_share_ca_nar_report_stage`;
   --DROP ALL ROW ACCESS POLICIES ON  `ecomm-analytics-prd-6238a8.output.gss_sales_share_euau_report_stage`;
   --DROP ALL ROW ACCESS POLICIES ON  `ecomm-analytics-prd-6238a8.output.gss_sales_share_france_report_stage`;
   --DROP ALL ROW ACCESS POLICIES ON  `ecomm-analytics-prd-6238a8.output.gss_sales_share_us_nar_report_stage`;
   --DROP ALL ROW ACCESS POLICIES ON  `ecomm-analytics-prd-6238a8.output.gss_sales_share_tesco_omni_report_stage`;
   -- DROP ALL ROW ACCESS POLICIES ON  `ecomm-analytics-prd-6238a8.output.gss_sales_share_walmart_luminate_pet_omni_report_stage`;

   --     DROP ALL ROW ACCESS POLICIES ON  `ecomm-analytics-prd-6238a8.output.assortment_availability_report`;
   --DROP ALL ROW ACCESS POLICIES ON  `ecomm-analytics-prd-6238a8.output.ecom_new_product_tracker_report`;
   --DROP ALL ROW ACCESS POLICIES ON  `ecomm-analytics-prd-6238a8.output.ecomm_ana_euau_assortment_report`;
   --DROP ALL ROW ACCESS POLICIES ON  `ecomm-analytics-prd-6238a8.output.ecomm_ana_euau_availability_report`;
   --DROP ALL ROW ACCESS POLICIES ON  `ecomm-analytics-prd-6238a8.output.upc_conversions_report`;

   
    

 

update `ecomm-analytics-prd-6238a8.processed.ecomm_common_customer_info` set is_processed_flg = false where 1=1;

-- select 1;
