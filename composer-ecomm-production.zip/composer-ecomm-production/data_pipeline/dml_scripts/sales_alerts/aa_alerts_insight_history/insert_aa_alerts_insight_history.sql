--Documentation located at https://dev.azure.com/generalmills/eCommerce/_wiki/wikis/eCommerce.wiki/1836/AA-Alerts-Insight-History-Table

DELETE FROM `{{params.ECOMM_ANALYTICS}}.processed.aa_alerts_insight_history` WHERE EXTRACT(YEAR FROM date(created_datetime)) = EXTRACT(YEAR FROM CURRENT_DATE())
and EXTRACT(WEEK FROM date(created_datetime)) = EXTRACT(WEEK FROM CURRENT_DATE());

INSERT INTO `{{params.ECOMM_ANALYTICS}}.processed.aa_alerts_insight_history`

SELECT * FROM `{{params.ECOMM_ANALYTICS}}.processed.aa_alerts_insight_delta`
;