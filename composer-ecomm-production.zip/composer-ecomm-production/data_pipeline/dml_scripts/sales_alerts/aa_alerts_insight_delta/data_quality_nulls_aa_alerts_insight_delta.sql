/*
Check aa_alerts_insight_delta_view for nulls in fields that need to be populated.
These fields included the unique keys checks for required values, the ranks, and the key assortment metrics.
Result should be 0, for 0 rows with nulls in these fields.
*/

SELECT COUNT(*) null_count
FROM `{{params.ECOMM_ANALYTICS}}.processed.aa_alerts_insight_delta`
WHERE customer_nm IS NULL
  OR fiscal_week_begin_dt IS NULL
  OR ean_upc_cd IS NULL
  OR priority IS NULL
  OR created_datetime IS NULL
  OR present_online_store_ct IS NULL
  OR present_instore_store_ct IS NULL
  OR opportunity_rank IS NULL
  OR online_assortment_rank IS NULL
  OR in_store_ct_rank IS NULL
  OR ty_instore_sales_rank is NULL
  OR weekly_opportunity_gap IS NULL
  OR annual_opportunity_gap IS NULL;

