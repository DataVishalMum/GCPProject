/*
Check aa_alerts_insight_delta_view for keys that do not return a single unique row.
Result should be 1, for 1 row per unique key.
*/

WITH key_check AS (
  SELECT 
    customer_nm
    ,fiscal_week_begin_dt
    ,ean_upc_cd
    ,COUNT(*) AS rows_per_unique_key
  FROM `{{params.ECOMM_ANALYTICS}}.processed.aa_alerts_insight_delta`
  GROUP BY 
    customer_nm
    ,fiscal_week_begin_dt
    ,ean_upc_cd
)
SELECT max(rows_per_unique_key)
FROM key_check;