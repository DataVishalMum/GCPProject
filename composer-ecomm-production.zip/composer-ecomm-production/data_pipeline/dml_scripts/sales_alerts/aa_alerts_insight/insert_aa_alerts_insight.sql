--Documentation is located at https://dev.azure.com/generalmills/eCommerce/_wiki/wikis/eCommerce.wiki/1833/AA-Alerts-Insights-Table

TRUNCATE TABLE `{{params.ECOMM_ANALYTICS}}.processed.aa_alerts_insight`;
INSERT INTO `{{params.ECOMM_ANALYTICS}}.processed.aa_alerts_insight`

WITH instore_count AS (
    SELECT
        COUNT(DISTINCT aa.unique_store_composite_key) instore_store_ct,
        CASE WHEN aa.customer_name = 'KROGER GROCERY' THEN 'KROGER' ELSE aa.customer_name END AS customer_name,
        aa.fiscal_week_begin_dt
    FROM `{{params.ECOMM_ANALYTICS}}.processed.assortment_availability_report` aa
    WHERE aa.report_fg = 'Y'
--    AND aa.customer_name IN ('MEIJER','KROGER','TARGET','WALMART_OPD','ALBERTSONS_SAFEWAY','HEB')
    GROUP BY
        aa.customer_name
        ,aa.fiscal_week_begin_dt
),

acv_agg AS (
SELECT
     LTRIM(ean_upc_derived_cd,'0') ean_upc_cd
    ,ROUND(SUM(sales_value_amt),0) AS ty_instore_sales_amt
    ,ROUND(AVG(acv_stores_selling_13_Weeks_reach_pct), 0) AS acv_13wk
    ,ROUND(AVG(acv_stores_selling_fiscal_month_reach_pct),0) AS acv_monthly
    ,CASE WHEN gmi_corp_customer_desc = 'WALMART' THEN 'WALMART_OPD'
    WHEN gmi_corp_customer_desc = 'ALBERTSONS-SAFEWAY' THEN 'ALBERTSONS_SAFEWAY'
    ELSE gmi_corp_customer_desc END customer_nm
    ,DATE(fiscal_week_begin_dt) AS fiscal_week_begin_dt
FROM
    (SELECT
        product.gmi_manufacturer_desc
        ,market.gmi_corp_customer_desc
        ,product.ean_upc_derived_cd
        ,fact.sales_value_amt
        ,fact.acv_stores_selling_13_Weeks_reach_pct
        ,fact.acv_stores_selling_fiscal_month_reach_pct
        ,period.fiscal_week_begin_dt
    FROM `{{params.ECOMM_EDW}}.syndicated_nielsen.nielsen_connect_pos_us_fact` fact
    JOIN `{{params.ECOMM_EDW}}.syndicated_nielsen.dim_nielsen_connect_pos_us_period` period
      ON fact.period_week_join_key = period.period_week_join_key --could use unshifted_
    JOIN `{{params.ECOMM_EDW}}.syndicated_nielsen.dim_nielsen_connect_pos_us_market` market
      ON fact.market_join_key = market.market_join_key

    JOIN `{{params.ECOMM_EDW}}.syndicated_nielsen.dim_nielsen_connect_pos_us_product` product
      ON fact.product_join_key = product.product_join_key
      )
WHERE
  gmi_manufacturer_desc = 'GMI' AND
  gmi_corp_customer_desc IN ('WALMART', 'TARGET', 'MEIJER', 'ALBERTSONS-SAFEWAY')
GROUP BY
  gmi_corp_customer_desc
  ,fiscal_week_begin_dt
  ,ean_upc_derived_cd
HAVING acv_13wk > 0
AND acv_monthly > 0
),

casefill_agg as (
SELECT
    CASE
        WHEN customer_parent = 'HEB SAN ANTONIO DRY ***'
            THEN 'HEB'
        WHEN customer_parent in ('KROGER', 'MEIJER', 'TARGET', 'WALMART')
            THEN initcap(customer_parent)
        WHEN customer_parent = 'ALBERTSONS' or customer_parent like '%SAFEWAY%'
            THEN 'Albertsons Safeway'
    END AS customer_parent,
    CASE
        WHEN LENGTH(ean_upc_derived_cd) = 14 AND LEFT(ean_upc_derived_cd, 3) IN ('100', '000')
            THEN substr(ean_upc_derived_cd, 4)
        WHEN LENGTH(ean_upc_derived_cd) = 13 AND LEFT(ean_upc_derived_cd, 1) = '0'
            THEN CAST(CAST(ean_upc_derived_cd AS INT64) AS STRING)
        ELSE ean_upc_derived_cd
    END AS ean_upc_derived_cd,
    fiscal_week_begin_dt,
    ROUND((SUM(cf_numerator)/NULLIF(SUM(cf_denominator),0)),2) AS casefill_pct
FROM `{{params.ECOMM_DLF}}.processed.casefill_na_weekly`
GROUP BY
    customer_parent,
    ean_upc_derived_cd,
    fiscal_week_begin_dt
),

assortment AS (
SELECT
    CASE WHEN aa.customer_name = 'KROGER GROCERY' THEN 'KROGER' ELSE aa.customer_name END AS customer_name
    ,aa.customer_parent
    ,aa.ean_upc_cd
    ,aa.fiscal_week_begin_dt
    ,aa.sls_hier_division_desc
    ,aa.sls_hier_sub_category_desc
    ,aa.material_short_desc
    ,ROUND(SAFE_DIVIDE(SUM(CASE
                                WHEN aa.consecutive_missing_weeks >= 4 AND aa.is_online IS NULL AND aa.is_instore = 1
                                    THEN aa.consecutive_missing_weeks
                                ELSE 0
                            END),
                        SUM(CASE
                                WHEN aa.consecutive_missing_weeks >= 4 AND aa.is_online IS NULL AND aa.is_instore = 1
                                    THEN 1
                                ELSE 0
                            END)
                )
            , 2) avg_missing_weeks_per_store_4wk
    ,SUM(aa.is_online) present_online_store_ct
    ,SUM(aa.is_instore) present_instore_store_ct
    ,ic.instore_store_ct total_instore_store_ct
    ,aa.is_conversion_flg
    ,aa.ci_launch_type_cd
    ,aa.ipp_start_dt
    ,aa.srm_effective_date
    ,aa.product_in_out_seasonal_flg
    ,aa.special_pack_sales_seasonal_flg
    ,SUM(CASE
            WHEN aa.is_online IS NULL AND aa.is_instore = 1
                THEN 1 ELSE 0
        END) missing_store_ct

FROM `{{params.ECOMM_ANALYTICS}}.processed.assortment_availability_report` aa
LEFT JOIN instore_count ic
    ON CASE WHEN aa.customer_name = 'KROGER GROCERY' THEN 'KROGER' ELSE aa.customer_name END = ic.customer_name
    AND aa.fiscal_week_begin_dt = ic.fiscal_week_begin_dt

WHERE
    aa.report_fg = 'Y'
    AND aa.retailer_type = 'Brick and Mortar'
--    aa.customer_name IN ('MEIJER','KROGER','TARGET','WALMART_OPD','ALBERTSONS_SAFEWAY','HEB') AND
    AND fp_flag = 'No'
GROUP BY
    aa.ean_upc_cd
    ,aa.customer_parent
    ,aa.customer_name
    ,aa.fiscal_week_begin_dt
    ,aa.sls_hier_division_desc
    ,aa.sls_hier_sub_category_desc
    ,aa.material_short_desc
    ,ic.instore_store_ct
    ,aa.is_conversion_flg
    ,aa.ci_launch_type_cd
    ,aa.ipp_start_dt
    ,aa.srm_effective_date
    ,aa.product_in_out_seasonal_flg
    ,aa.special_pack_sales_seasonal_flg

),

gss_sales_agg AS (
    SELECT
        CASE
            WHEN gss.customer_name = 'WALMART_LUMINATE'
                THEN 'WALMART_OPD'
            ELSE gss.customer_name
        END AS customer_name
        ,gss.fiscal_week_begin_dt
        ,gss.ean_upc_cd
        ,(SELECT
                ROUND(AVG(gss2.ty_sales_value),2)
            FROM `{{params.ECOMM_ANALYTICS}}.output.gss_sales_share_us_nar_report` gss2
            WHERE CAST(gss2.fiscal_week_begin_dt AS DATE) >= DATE_SUB(gss.fiscal_week_begin_dt, INTERVAL 13 week)
                AND CAST(gss2.fiscal_week_begin_dt AS DATE) < gss.fiscal_week_begin_dt
                AND UPPER(gss2.customer_name) = UPPER(gss.customer_name)
                AND gss2.ean_upc_cd = gss.ean_upc_cd) ty_sales_amt_r13
        ,SUM(gss.ty_sales_value) as ty_sales_value

    FROM `{{params.ECOMM_ANALYTICS}}.output.gss_sales_share_us_nar_report` gss

    WHERE
    --    gss.customer_name IN ('MEIJER','KROGER','TARGET','WALMART_OPD','ALBERTSONS_SAFEWAY','HEB') AND
        gss.ean_upc_cd IS NOT NULL
    GROUP BY
        gss.customer_name
        ,gss.fiscal_week_begin_dt
        ,gss.ean_upc_cd
),

most_recent_week AS (
    SELECT
        CASE WHEN customer_name = 'KROGER GROCERY' THEN 'KROGER' ELSE customer_name END AS customer_name
        ,MAX(fiscal_week_begin_dt) max_date
    FROM `{{params.ECOMM_ANALYTICS}}.processed.assortment_availability_report`
    GROUP BY
        CASE WHEN customer_name = 'KROGER GROCERY' THEN 'KROGER' ELSE customer_name END
    ),

-- Grabbing UPCs that have scanned more than 90 days ago to remove brand new items
appeared_in_store_all_time AS (
    SELECT
        CASE WHEN aa.customer_name = 'KROGER GROCERY' THEN 'KROGER' ELSE aa.customer_name END AS customer_name
        ,aa.ean_upc_cd
        ,MIN(aa.fiscal_week_begin_dt) AS first_scan_week
    FROM `ecomm-analytics-prd-6238a8.processed.assortment_availability_report` aa
    LEFT JOIN most_recent_week mrw
        ON mrw.customer_name = CASE WHEN aa.customer_name = 'KROGER GROCERY' THEN 'KROGER' ELSE aa.customer_name END

    WHERE
        aa.report_fg = 'Y' AND
        aa.fiscal_week_begin_dt < DATE_SUB(mrw.max_date, INTERVAL 90 DAY)

    --    AND aa.customer_name IN ('MEIJER','KROGER','TARGET','WALMART_OPD','ALBERTSONS_SAFEWAY','HEB')
    GROUP BY
        aa.ean_upc_cd
        ,CASE WHEN aa.customer_name = 'KROGER GROCERY' THEN 'KROGER' ELSE aa.customer_name END),

-- Grabbing UPCs that have scanned within 90 days. Should confirm this is not just a seasonal item when paired with greater than 90 day scan.
appeared_in_store_three_months AS (
    SELECT
        CASE WHEN aa.customer_name = 'KROGER GROCERY' THEN 'KROGER' ELSE aa.customer_name END AS customer_name
        ,aa.ean_upc_cd
        ,MIN(aa.fiscal_week_begin_dt) AS first_scan_week
    FROM `{{params.ECOMM_ANALYTICS}}.processed.assortment_availability_report` aa
    LEFT JOIN most_recent_week mrw
        ON mrw.customer_name = CASE WHEN aa.customer_name = 'KROGER GROCERY' THEN 'KROGER' ELSE aa.customer_name END
    WHERE
        aa.report_fg = 'Y' AND
        aa.fiscal_week_begin_dt >= DATE_SUB(mrw.max_date, INTERVAL 90 DAY)
    --    AND aa.customer_name IN ('MEIJER','KROGER','TARGET','WALMART_OPD','ALBERTSONS_SAFEWAY','HEB')
    GROUP BY
        aa.ean_upc_cd
        ,CASE WHEN aa.customer_name = 'KROGER GROCERY' THEN 'KROGER' ELSE aa.customer_name END),

assortment_metrics as (
    SELECT
        a.customer_name customer_nm
        ,a.fiscal_week_begin_dt
        ,a.ean_upc_cd
        ,a.material_short_desc
        ,a.sls_hier_division_desc
        ,a.sls_hier_sub_category_desc

        --sales metrics
        ,COALESCE(gss.ty_sales_value
                ,CASE
                    WHEN
                        LAST_VALUE(gss.fiscal_week_begin_dt IGNORE NULLS)
                        OVER (PARTITION BY a.customer_name, a.ean_upc_cd ORDER BY a.fiscal_week_begin_dt ASC)
                        > DATE_SUB(a.fiscal_week_begin_dt, INTERVAL 28 DAY)
                    THEN
                        LAST_VALUE(gss.ty_sales_value IGNORE NULLS)
                        OVER (PARTITION BY a.customer_name, a.ean_upc_cd ORDER BY a.fiscal_week_begin_dt ASC)
                    ELSE NULL
                END
                ,0) as ty_online_sales_amt
        ,COALESCE(gss.ty_sales_amt_r13
                ,CASE
                    WHEN
                        LAST_VALUE(gss.fiscal_week_begin_dt IGNORE NULLS)
                        OVER (PARTITION BY a.customer_name, a.ean_upc_cd ORDER BY a.fiscal_week_begin_dt ASC)
                        > DATE_SUB(a.fiscal_week_begin_dt, INTERVAL 28 DAY)
                    THEN
                        LAST_VALUE(gss.ty_sales_amt_r13 IGNORE NULLS)
                        OVER (PARTITION BY a.customer_name, a.ean_upc_cd ORDER BY a.fiscal_week_begin_dt ASC)
                    ELSE NULL
                END
                ,0) as ty_online_sales_amt_r13
        ,COALESCE(gss.fiscal_week_begin_dt,
                CASE
                    WHEN LAST_VALUE(gss.fiscal_week_begin_dt IGNORE NULLS)
                        OVER (PARTITION BY a.customer_name, a.ean_upc_cd
                        ORDER BY a.fiscal_week_begin_dt ASC)
                    > DATE_SUB(a.fiscal_week_begin_dt, INTERVAL 28 DAY)
                    THEN LAST_VALUE(gss.fiscal_week_begin_dt IGNORE NULLS)
                        OVER (PARTITION BY a.customer_name, a.ean_upc_cd ORDER BY a.fiscal_week_begin_dt ASC)
                    ELSE NULL
                END) as sales_lag_dt

        -- acv metrics
        ,COALESCE(acv.ty_instore_sales_amt
                ,CASE
                    WHEN
                        LAST_VALUE(acv.fiscal_week_begin_dt IGNORE NULLS)
                        OVER (PARTITION BY a.customer_name, a.ean_upc_cd ORDER BY a.fiscal_week_begin_dt ASC)
                        > DATE_SUB(a.fiscal_week_begin_dt, INTERVAL 56 DAY)
                    THEN
                        LAST_VALUE(acv.ty_instore_sales_amt IGNORE NULLS)
                        OVER (PARTITION BY a.customer_name, a.ean_upc_cd ORDER BY a.fiscal_week_begin_dt ASC)
                    ELSE NULL
                END) AS ty_instore_sales_amt
        ,COALESCE(acv.acv_13wk
                ,CASE
                    WHEN
                        LAST_VALUE(acv.fiscal_week_begin_dt IGNORE NULLS)
                        OVER (PARTITION BY a.customer_name, a.ean_upc_cd ORDER BY a.fiscal_week_begin_dt ASC)
                        > DATE_SUB(a.fiscal_week_begin_dt, INTERVAL 56 DAY)
                    THEN
                        LAST_VALUE(acv.acv_13wk IGNORE NULLS)
                        OVER (PARTITION BY a.customer_name, a.ean_upc_cd ORDER BY a.fiscal_week_begin_dt ASC)
                    ELSE NULL
                END) AS acv_13wk

        ,COALESCE(acv.acv_monthly
                ,CASE
                    WHEN
                        LAST_VALUE(acv.fiscal_week_begin_dt IGNORE NULLS)
                        OVER (PARTITION BY a.customer_name, a.ean_upc_cd ORDER BY a.fiscal_week_begin_dt ASC)
                        > DATE_SUB(a.fiscal_week_begin_dt, INTERVAL 56 DAY)
                    THEN
                        LAST_VALUE(acv.acv_monthly IGNORE NULLS)
                        OVER (PARTITION BY a.customer_name, a.ean_upc_cd ORDER BY a.fiscal_week_begin_dt ASC)
                    ELSE NULL
                END) AS acv_monthly

        ,COALESCE(acv.fiscal_week_begin_dt,
                CASE
                    WHEN LAST_VALUE(acv.fiscal_week_begin_dt IGNORE NULLS)
                        OVER (PARTITION BY a.customer_name, a.ean_upc_cd
                        ORDER BY a.fiscal_week_begin_dt ASC)
                        > DATE_SUB(a.fiscal_week_begin_dt, INTERVAL 56 DAY)
                    THEN LAST_VALUE(acv.fiscal_week_begin_dt IGNORE NULLS)
                        OVER (PARTITION BY a.customer_name, a.ean_upc_cd
                        ORDER BY a.fiscal_week_begin_dt ASC)
                    ELSE NULL
                END) as acv_lag_dt


        --assortment metrics
        ,a.avg_missing_weeks_per_store_4wk
        ,IFNULL(a.present_online_store_ct,0) present_online_store_ct
        ,IFNULL((SELECT
                    ROUND(AVG(a2.present_online_store_ct),2)
                FROM assortment a2
                WHERE
                    CAST(a2.fiscal_week_begin_dt AS DATE) >= DATE_SUB(a.fiscal_week_begin_dt, INTERVAL 13 week)
                    AND CAST(a2.fiscal_week_begin_dt AS DATE) < a.fiscal_week_begin_dt
                    AND UPPER(a2.customer_name) = UPPER(a.customer_name)
                    AND a2.ean_upc_cd = a.ean_upc_cd)
                ,0) present_online_store_ct_r13
        ,a.present_instore_store_ct
        ,(SELECT
            ROUND(AVG(a2.present_instore_store_ct),2)
            FROM assortment a2
            WHERE
                CAST(a2.fiscal_week_begin_dt AS DATE) >= DATE_SUB(a.fiscal_week_begin_dt, INTERVAL 13 week)
                AND CAST(a2.fiscal_week_begin_dt AS DATE) < a.fiscal_week_begin_dt
                AND UPPER(a2.customer_name) = UPPER(a.customer_name)
                AND a2.ean_upc_cd = a.ean_upc_cd) present_instore_store_ct_r13
        ,a.total_instore_store_ct
        ,a.missing_store_ct
        ,IFNULL(ROUND(a.present_online_store_ct/a.present_instore_store_ct,2),0) pct_online_assortment
        ,IFNULL(ROUND(a.present_instore_store_ct/a.total_instore_store_ct,2),0) pct_instore_assortment

        -- casefill looks for the most recent field up to 4 weeks back
        ,COALESCE(cf.casefill_pct,
            CASE
                WHEN LAST_VALUE(cf.fiscal_week_begin_dt IGNORE NULLS)
                    OVER (PARTITION BY a.customer_name, a.ean_upc_cd
                    ORDER BY a.fiscal_week_begin_dt ASC)
                    >= DATE_SUB(a.fiscal_week_begin_dt, INTERVAL 28 DAY)
                THEN LAST_VALUE(cf.casefill_pct IGNORE NULLS)
                    OVER (PARTITION BY a.customer_name, a.ean_upc_cd
                    ORDER BY a.fiscal_week_begin_dt ASC)
                ELSE NULL
            END) AS casefill_pct
        ,COALESCE(cf.fiscal_week_begin_dt,
            CASE
                WHEN LAST_VALUE(cf.fiscal_week_begin_dt IGNORE NULLS)
                        OVER (PARTITION BY a.customer_name, a.ean_upc_cd
                        ORDER BY a.fiscal_week_begin_dt ASC)
                        >= DATE_SUB(a.fiscal_week_begin_dt, INTERVAL 28 DAY)
                    THEN LAST_VALUE(cf.fiscal_week_begin_dt IGNORE NULLS)
                        OVER (PARTITION BY a.customer_name, a.ean_upc_cd
                        ORDER BY a.fiscal_week_begin_dt ASC)
                ELSE NULL
            END) as casefill_lag_dt

        --opportunity gaps
        ,IFNULL(a.missing_store_ct *
                SAFE_DIVIDE(COALESCE(gss.ty_sales_value
                            ,LAST_VALUE(gss.ty_sales_value IGNORE NULLS)
                            OVER (PARTITION BY a.customer_name, a.ean_upc_cd ORDER BY a.fiscal_week_begin_dt ASC))
                    ,a.present_online_store_ct)
            ,0) weekly_opportunity_gap
        ,IFNULL(a.missing_store_ct *
                SAFE_DIVIDE(COALESCE(gss.ty_sales_value
                            ,LAST_VALUE(gss.ty_sales_value IGNORE NULLS)
                            OVER (PARTITION BY a.customer_name, a.ean_upc_cd ORDER BY a.fiscal_week_begin_dt ASC))
                    ,a.present_online_store_ct)
            ,0) * 52 annual_opportunity_gap

        --missing weeks
        ,CASE
            WHEN a.avg_missing_weeks_per_store_4wk BETWEEN 50 and 70
                THEN TRUE
            ELSE FALSE
        END missing_50_70_weeks
        ,CASE
            WHEN a.avg_missing_weeks_per_store_4wk > 70
                THEN TRUE
            ELSE FALSE
        END missing_gt_70_weeks
        ,a.is_conversion_flg
        ,CASE
            WHEN (a.product_in_out_seasonal_flg = 'Y' OR a.special_pack_sales_seasonal_flg = 'Y' OR a.ci_launch_type_cd = 'INOUT')
                THEN TRUE
                ELSE FALSE
        END is_seasonal_product
        ,CASE
            WHEN a.ipp_start_dt >= DATE_SUB(a.fiscal_week_begin_dt, INTERVAL 3 MONTH) AND a.ipp_start_dt <> '9999-12-31T00:00:00'
                THEN TRUE ELSE FALSE
        END is_new_product
        ,a.ipp_start_dt as new_product_dt
        ,a.srm_effective_date as conversion_dt

    FROM assortment a
    JOIN appeared_in_store_all_time ais
        ON ais.ean_upc_cd = a.ean_upc_cd
        AND ais.customer_name = a.customer_name
    JOIN appeared_in_store_three_months ais2
        ON ais2.ean_upc_cd = a.ean_upc_cd
        AND ais2.customer_name = a.customer_name

    LEFT JOIN gss_sales_agg gss on gss.fiscal_week_begin_dt = a.fiscal_week_begin_dt
        AND gss.ean_upc_cd = a.ean_upc_cd
        AND UPPER(a.customer_name) = UPPER(gss.customer_name)
    LEFT JOIN casefill_agg cf
        ON UPPER(a.customer_parent) = UPPER(cf.customer_parent)
        AND a.ean_upc_cd = cf.ean_upc_derived_cd
        AND a.fiscal_week_begin_dt = cf.fiscal_week_begin_dt
    LEFT JOIN acv_agg acv
        ON UPPER(a.customer_name) = UPPER(acv.customer_nm)
        AND a.ean_upc_cd = acv.ean_upc_cd
        AND a.fiscal_week_begin_dt = acv.fiscal_week_begin_dt
)

select
customer_nm
,fiscal_week_begin_dt
,ean_upc_cd
,material_short_desc
,sls_hier_division_desc
,sls_hier_sub_category_desc
,ty_online_sales_amt
,ty_online_sales_amt_r13
,sales_lag_dt
,ty_instore_sales_amt
,acv_13wk
,acv_monthly
,acv_lag_dt
,avg_missing_weeks_per_store_4wk
,present_online_store_ct
,present_online_store_ct_r13
,present_instore_store_ct
,present_instore_store_ct_r13
,total_instore_store_ct
,missing_store_ct
,pct_online_assortment
,pct_instore_assortment
,casefill_pct
,casefill_lag_dt
-- ,weekly_opportunity_gap
-- ,annual_opportunity_gap
-- SWAPPING OPP GAP WITH A ROLLING 13WK AVG
,IFNULL(t.missing_store_ct *
    SAFE_DIVIDE(t.ty_online_sales_amt_r13,t.present_online_store_ct_r13)
,0) weekly_opportunity_gap
,IFNULL(t.missing_store_ct *
        SAFE_DIVIDE(t.ty_online_sales_amt_r13,t.present_online_store_ct_r13)
    ,0) * 52 annual_opportunity_gap
,missing_50_70_weeks
,missing_gt_70_weeks
,is_conversion_flg
,is_seasonal_product
,is_new_product
,new_product_dt
,conversion_dt


    --threshold flags
    ,(CASE
        WHEN IFNULL(ROUND(t.present_online_store_ct/t.present_instore_store_ct,2),0) <= .25
            THEN TRUE
        ELSE FALSE
    END) online_assortment_threshold_flg
    ,(CASE
        WHEN COALESCE(t.acv_monthly/100, t.present_instore_store_ct/t.total_instore_store_ct) >= .2
            THEN TRUE
        ELSE FALSE
    END) instore_assortment_threshold_flg

    --for upc's or retailers where casefill data is missing, nulls will be assigned a 1 for casefill_threshold_flg
    ,(CASE
        WHEN t.casefill_pct < .7
            THEN FALSE
        ELSE TRUE
    END) casefill_threshold_flg
    ,(CASE
        -- If instore count falls less than 30% or ACV falls less than 20% flag TRUE
        WHEN (t.acv_13wk IS NULL AND ((t.present_instore_store_ct-t.present_instore_store_ct_r13)/t.present_instore_store_ct_r13) > -.3)
                OR ((t.acv_monthly-acv_13wk)/acv_13wk > -.2)
            THEN TRUE
        ELSE FALSE
    END) instore_decrease_threshold_flg
    ,(CASE
        WHEN IFNULL(t.missing_store_ct * SAFE_DIVIDE(t.ty_online_sales_amt_r13,t.present_online_store_ct_r13),0) > t.ty_instore_sales_amt
            THEN FALSE
        ELSE TRUE
    END) opportunity_threshold_flg

    ,current_datetime() created_datetime
FROM assortment_metrics t
JOIN most_recent_week mrw
    ON mrw.customer_name = t.customer_nm
    AND mrw.max_date = t.fiscal_week_begin_dt