/*
Purpose of the stored proc: 
	Delta Data extraction for 'albertsons_safeway' customer
History of Changes:
	6/10 – first version
Author : 
	Vishal Jadiya
How to Call:
		call transient.sp_albertsons_safeway_delta_temp
		(
		 99,
		'ecomm-dlf-dev-01cd47',
		'transient' ,
		'albertsons_safeway_delta_temp',
		'edw-dev-c119a7',
		'syndicated_nielsen',
		'TARGET'
		);

One time : insert into `ecomm-dlf-dev-01cd47.transient.gmi_customer_metadata_reference`  values  ('TARGET','TARGET','market_key,product_key,upc,report_date','customer_name,upc,source_item_name','upc,fiscal_year_week_nbr,source_item_name,manufacturer,source_item_code,customer_account,resolved_category,global_category_parent,resolved_brand,zone_hierarchy','customer_name,source_item_name,upc,source_product_hash','report_date','','TARGET',null,null,null);
insert into `ecomm-dlf-dev-01cd47.transient.data_extract_config`  values ( 'albertsons_safeway_weekly_agg_fact', cast ('1800-01-01 00:00:00' as timestamp), cast ('1800-01-01 00:00:00' as timestamp), 'Y','complete','GMI',current_timestamp,'GMI',current_timestamp ) ;
INSERT INTO `ecomm-dlf-qa-ee8fb9.processed.albertsons_safeway_weekly_agg_fact` (fiscal_week_begin_dt)
select cast('1800-01-01' as timestamp);

*/

CREATE PROCEDURE IF NOT EXISTS
  transient.ecomm_sproc_albertsons_safeway_delta_temp (
    SRC_PROJECT STRING,
    DEST_DATASET STRING,
    DEST_TABLE STRING,
    INTERMEDIATE_PROJECT STRING,
    INTERMEDIATE_DATASET STRING,
    CUSTOMER_NAME STRING,
    FEED_NAME STRING)
OPTIONS(
description = """

         CALL transient.sp_albertsons_safeway_delta_temp
		(
		    'ecomm-dlf-dev-01cd47', -- SRC_PROJECT
		    'transient', -- DEST_DATASET
		    'albertsons_safeway_delta_temp', -- DEST_TABLE
		    'edw-dev-c119a7', -- INTERMEDIATE_PROJECT
		    'syndicated_nielsen', -- INTERMEDIATE_DATASET
		    'TARGET', -- CUSTOMER_NAME
		    'TARGET' -- FEED_NAME
		);
"""
)
BEGIN

DECLARE JOB_RUN_ID DEFAULT 999999;
DECLARE BQ_PROJECT_NAME DEFAULT SRC_PROJECT;
DECLARE BQ_TRANSIENT_DATASET_NAME DEFAULT DEST_DATASET;
DECLARE BQ_DELTA_TEMP_TABLENAME DEFAULT DEST_TABLE;
DECLARE BQ_EDW_PROJECT_NAME DEFAULT INTERMEDIATE_PROJECT;
DECLARE BQ_EDW_DATASET_NAME DEFAULT INTERMEDIATE_DATASET;
DECLARE FISCAL_YEAR_NBR_VAL INT64;

/* Delta Temp Table is Truncate & Load */

EXECUTE IMMEDIATE
CONCAT("""TRUNCATE TABLE  `""" ,BQ_PROJECT_NAME,"""`.""",bq_transient_dataset_name,""".""",BQ_DELTA_TEMP_TABLENAME);

EXECUTE IMMEDIATE CONCAT(""" SELECT SAFE_CAST(MAX(fiscal_year_nbr) AS INT64) FROM `""",bq_edw_project_name,""".""",bq_edw_dataset_name,""".dim_nielsen_connect_pos_us_period` """) INTO fiscal_year_nbr_val;


/*Insert Details for passed customer into 'albertsons_safeway_delta_temp' table having fiscal_week_begin_dt in current fiscal year */

EXECUTE IMMEDIATE
CONCAT("""insert into  `""" ,BQ_PROJECT_NAME,"""`.""",bq_transient_dataset_name,""".""","""albertsons_safeway_delta_temp
(
   WITH
     dr AS (
     SELECT
       'WEEK' AS grain,
       'TARGET' AS retailer,
       '""",CUSTOMER_NAME,"""' AS customer_name,
       prod.upc_cd as bigint) as string) as source_item_code,
       prod.ean_upc_derived_cd as upc,
       p.fiscal_week_begin_dt AS report_date,
       prod.product_desc as source_item_name,
       m.market_join_key as market_join_key,
       SAFE_CAST(m.market_key as INT64) as market_key,
       m.market_desc as market_desc,
       prod.product_join_key as product_join_key,
       SAFE_CAST(prod.product_key as INT64) as product_key,
       prod.upc_cd as upc_cd,
	   -- prod.ean_upc_derived_cd as ean_upc_derived_cd,
	   -- prod.gmi_brand_desc as gmi_brand_desc,
	   -- prod.gmi_category_desc as gmi_category_desc,
	   -- prod.gmi_manufacturer_desc as gmi_manufacturer_desc,
	   -- prod.gmi_segment_desc as gmi_segment_desc,
	   -- prod.gmi_sub_brand_desc as gmi_sub_brand_desc,
	   -- prod.gmi_sub_category_desc as gmi_sub_category_desc,
       prod.gmi_pet_type_desc as gmi_pet_type_desc,
       p.unshifted_period_week_join_key as period_week_join_key,
       coalesce(SAFE_CAST(f.sales_value_amt AS FLOAT64),0) AS ty_sales_value,
       coalesce(SAFE_CAST(f.sales_unit_qty AS INT64),0) AS ty_sales_units,
       current_timestamp() ingest_date,
       '""",JOB_RUN_ID,"""' created_by,
       current_datetime created_datetime,
       '""",JOB_RUN_ID,"""' modified_by,
       current_datetime modified_datetime,

	   -- the following ranking is done to avoid duplicates if the ****same file
	   -- is loaded multiple times****. The data is partitioned on the natural key
	   -- of the file and the file_dt which is the timestamp on the file
	   -- The data is then ordered descending on ingest_date which is the current timestamp
	   -- coming from the ingestion framework.  Picking rank = 1 will result
	   -- in the record with latest ingest_date being picked in case duplicate records
	   -- exist in the raw table.  THIS SCENARIO WILL TYPICALLY NOT OCCUR.
	   -- Please note the use of ROW_NUMBER function to pick one record.
	   -- This function will be needed when the entire RAW table is read to reprocess history.

       ROW_NUMBER() OVER (PARTITION BY m.market_key,prod.product_key,prod.upc_cd,p.fiscal_week_begin_dt ORDER BY coalesce(SAFE_CAST(f.sales_value_amt AS FLOAT64),0) DESC) rnk_1
       FROM
         `""",BQ_EDW_PROJECT_NAME,""".""",BQ_EDW_DATASET_NAME,""".dim_nielsen_connect_pos_us_period` p
       INNER JOIN
         `""",BQ_EDW_PROJECT_NAME,""".""",BQ_EDW_DATASET_NAME,""".nielsen_connect_pos_us_fact` f
       ON f.period_week_join_key = p.unshifted_period_week_join_key and p.country_cd = f.country_cd
       INNER JOIN
         `""",BQ_EDW_PROJECT_NAME,""".""",BQ_EDW_DATASET_NAME,""".dim_nielsen_connect_pos_us_market` m
       ON m.market_join_key = f.market_join_key and m.country_cd = f.country_cd
       INNER JOIN
         `""",BQ_EDW_PROJECT_NAME,""".""",BQ_EDW_DATASET_NAME,""".dim_nielsen_connect_pos_us_product` prod
       ON prod.product_join_key = f.product_join_key and prod.country_cd = f.country_cd
       WHERE p.fiscal_year_nbr = """,fiscal_year_nbr_val,""" AND UPPER(m.market_desc) = 'ALBSCO TOTAL EXCLUDING UNITED ECOM TA' AND (f.sales_value_amt IS NOT NULL OR f.sales_unit_qty IS NOT NULL)
     )
     SELECT grain,
     retailer,
     customer_name,
     source_item_code,
     upc,
     report_date,
     source_item_name,
     market_join_key,
     market_key,
     market_desc,
     product_join_key,
     product_key,
     upc_cd,
     gmi_pet_type_desc,
     period_week_join_key,
     ty_sales_value,
     ty_sales_units,
     ingest_date,
     GENERATE_UUID() as rctl_uuid,
     created_by,
     created_datetime,
     modified_by,
     modified_datetime
   FROM
     dr
   WHERE
     rnk_1 = 1
)
""") ;

EXCEPTION WHEN ERROR THEN
        EXECUTE IMMEDIATE CONCAT(
            """INSERT INTO processed.sproc_error_details (
		        SELECT
			        '""",FEED_NAME,"""' AS FEED_NAME,
                    split(split(@@error.formatted_stack_trace,'transient.')[OFFSET (1)],'[')[OFFSET(0)],
			        @@error.statement_text,
			        @@error.message,
			        current_timestamp()
	        );
	    """);

	    SELECT
	        ERROR (
	            CONCAT(
	            		@@error.message ,' ' ,
	            		@@error.statement_text, ' ' ,
	            		@@error.formatted_stack_trace ,' '
	            	)
	        );

END;