/*
CREATE TABLE IF NOT EXISTS transient.amazon_pantry_mismatched_data 
(
    upc string
,fiscal_year_week_nbr INT64
,source_item_name string
,manufacturer string
,source_item_code string
,customer_account string
,resolved_category string
,global_category_parent string
,resolved_brand string
,zone_hierarchy STRING
,column_tested STRING
,BQ_value STRING
,Hadoop_value STRING
)

CALL transient.sp_compare_hadoop_gcp_data(
    'ecomm-dlf-dev-01cd47',
    'transient',
    'processed',
    'shareddata-prd-cb5872',
    'sales_ecomm_global_sales_and_share',
    'amazon_pantry_weekly_agg_fact',
    'amazon_pantry_mismatched_data',
    'AMAZON_PANTRY'
)
*/
CREATE PROCEDURE IF NOT EXISTS transient.sp_compare_hadoop_gcp_data
(
    bq_project_name STRING,
    bq_transient_dataset_name STRING,
    bq_processed_dataset_name STRING,
    bq_edw_project_name STRING,
    bq_gss_dataset_name STRING,
    bq_table_name STRING,
    target_test_table STRING,
    customer_name STRING)

    BEGIN

    DECLARE query_to_match_data STRING;

    DECLARE min_fiscal_year_week_nbr,max_fiscal_year_week_nbr INT64;

    EXECUTE IMMEDIATE 
    CONCAT(
        """TRUNCATE TABLE `""",bq_project_name,""".""",bq_transient_dataset_name,""".""",target_test_table,"""`"""
    );

    EXECUTE IMMEDIATE
    CONCAT
        ("""
    SELECT
      MIN(fiscal_year_week_nbr)
    FROM
      `""",bq_project_name,""".""",bq_processed_dataset_name,""".""",bq_table_name,"""`""")
      INTO min_fiscal_year_week_nbr;

    EXECUTE IMMEDIATE
     CONCAT
        ("""
    SELECT
      MAX(fiscal_year_week_nbr)
    FROM
      `""",bq_project_name,""".""",bq_processed_dataset_name,""".""",bq_table_name,"""`""")
      INTO max_fiscal_year_week_nbr;
    
    SET query_to_match_data = CONCAT(
        """
        with temp as (SELECT
  week.upc,
  week.fiscal_year_week_nbr,
  week.source_item_name,
  week.manufacturer,
  week.source_item_code,
  week.customer_account,
  week.resolved_category,
  week.global_category_parent,
  week.resolved_brand,
  week.zone_hierarchy,
  week.customer_name Proc2_customer_name,
  shared.customer_name Hadoop_customer_name,
  CASE
    WHEN ((IFNULL(week.customer_name, 'TestNull') = IFNULL( shared.customer_name, 'TestNull')) ) THEN ' Matched '
  ELSE
  CONCAT('UNMATCHED: Proc 2 Value:   ', COALESCE(week.customer_name,
      '-Null'), '   -- Hadoop Value:   ', COALESCE(shared.customer_name,
      '-Null'))
END
  customer_name_Differences,
  week.fiscal_year_week_nbr Proc2_fiscal_year_week_nbr,
  shared.fiscal_year_week_nbr Hadoop_fiscal_year_week_nbr,
  CASE
    WHEN ((IFNULL(week.fiscal_year_week_nbr, -99999) = IFNULL( shared.fiscal_year_week_nbr, -99999)) ) THEN ' Matched '
  ELSE
  CONCAT('UNMATCHED: Proc 2 Value:   ', COALESCE(week.fiscal_year_week_nbr,
      -99999), '   -- Hadoop Value:   ', COALESCE(shared.fiscal_year_week_nbr,
      -99999))
END
  fiscal_year_week_nbr_Differences,
  week.source_item_code Proc2_source_item_code,
  shared.source_item_code Hadoop_source_item_code,
  CASE
    WHEN ((IFNULL(week.source_item_code, 'TestNull') = IFNULL( shared.source_item_code, 'TestNull')) ) THEN ' Matched '
  ELSE
  CONCAT('UNMATCHED: Proc 2 Value:   ', COALESCE(week.source_item_code,
      '-Null'), '   -- Hadoop Value:   ', COALESCE(shared.source_item_code,
      '-Null'))
END
  source_item_code_Differences,
  week.source_item_name proc2_source_item_name,
  shared.source_item_name Hadoop_source_item_name,
  CASE
    WHEN ((IFNULL(week.source_item_name, 'TestNull') = IFNULL( shared.source_item_name, 'TestNull')) ) THEN 'Matched '
  ELSE
  CONCAT('UNMATCHED: Proc 2 col Value ', COALESCE(week.source_item_name,
      '-Null'), '   -- Hadoop Value:   ', COALESCE(shared.source_item_name,
      '-Null'))
END
  source_item_name_Differences,
  week.upc Proc2_upc,
  shared.upc Hadoop_upc,
  CASE
    WHEN ((IFNULL(week.upc, 'TestNull') = IFNULL( shared.upc, 'TestNull')) ) THEN ' Matched '
  ELSE
  CONCAT('UNMATCHED: Proc 2 Value:   ', COALESCE(week.upc,
      '-Null'), '   -- Hadoop Value:   ', COALESCE(shared.upc,
      '-Null'))
END
  upc_Differences,
  week.grain proc2_grain,
  shared.grain Hadoop_grain,
  CASE
    WHEN ((IFNULL(week.grain, 'TestNull') = IFNULL( shared.grain, 'TestNull')) ) THEN ' Matched '
  ELSE
  CONCAT('UNMATCHED: Proc 2 Value:   ', COALESCE(week.grain,
      '-Null'), '   -- Hadoop Value:   ', COALESCE(shared.grain,
      '-Null'))
END
  grain_Differences,
  week.base_product_cd Proc2_base_product_cd,
  shared.base_product_cd Hadoop_base_product_cd,
  CASE
    WHEN ((IFNULL(week.base_product_cd, 'TestNull') = IFNULL( shared.base_product_cd, 'TestNull')) ) THEN ' Matched '
  ELSE
  CONCAT('UNMATCHED: Proc 2 Value:   ', COALESCE(week.base_product_cd,
      '-Null'), '   -- Hadoop Value:   ', COALESCE(shared.base_product_cd,
      '-Null'))
END
  base_product_cd_Differences,
  week.base_product_desc Proc2_base_product_desc,
  shared.base_product_desc Hadoop_base_product_desc,
  CASE
    WHEN ((IFNULL(week.base_product_desc, 'TestNull') = IFNULL( shared.base_product_desc, 'TestNull')) ) THEN ' Matched '
  ELSE
  CONCAT('UNMATCHED: Proc 2 Value:   ', COALESCE(week.base_product_desc,
      '-Null'), '   -- Hadoop Value:   ', COALESCE(shared.base_product_desc,
      '-Null'))
END
  base_product_desc_Differences,
  week.base_uom_to_ecv_fctr Proc2_base_uom_to_ecv_fctr,
  shared.base_uom_to_ecv_fctr Hadoop_base_uom_to_ecv_fctr,
  CASE
    WHEN ((IFNULL(week.base_uom_to_ecv_fctr, -99999) = IFNULL( shared.base_uom_to_ecv_fctr, -99999)) ) THEN ' Matched '
  ELSE
  CONCAT('UNMATCHED: Proc 2 Value:   ', COALESCE(week.base_uom_to_ecv_fctr,
      -99999), '   -- Hadoop Value:   ', COALESCE(shared.base_uom_to_ecv_fctr,
      -99999))
END
  base_uom_to_ecv_fctr_Differences,
  week.base_uom_to_eqc_fctr Proc2_base_uom_to_eqc_fctr,
  shared.base_uom_to_eqc_fctr Hadoop_base_uom_to_eqc_fctr,
  CASE
    WHEN ((IFNULL(week.base_uom_to_eqc_fctr, -99999) = IFNULL( shared.base_uom_to_eqc_fctr, -99999)) ) THEN ' Matched '
  ELSE
  CONCAT('UNMATCHED: Proc 2 Value:   ', COALESCE(week.base_uom_to_eqc_fctr,
      -99999), '   -- Hadoop Value:   ', COALESCE(shared.base_uom_to_eqc_fctr,
      -99999))
END
  base_uom_to_eqc_fctr_Differences,
  week.bph20_desc Proc2_bph20_desc,
  shared.bph20_desc Hadoop_bph20_desc,
  CASE
    WHEN ((IFNULL(week.bph20_desc, 'TestNull') = IFNULL( shared.bph20_desc, 'TestNull')) ) THEN ' Matched '
  ELSE
  CONCAT('UNMATCHED: Proc 2 Value:   ', COALESCE(week.bph20_desc,
      '-Null'), '   -- Hadoop Value:   ', COALESCE(shared.bph20_desc,
      '-Null'))
END
  bph20_desc_Differences,
  week.bph30_desc Proc2_bph30_desc,
  shared.bph30_desc Hadoop_bph30_desc,
  CASE
    WHEN ((IFNULL(week.bph30_desc, 'TestNull') = IFNULL( shared.bph30_desc, 'TestNull')) ) THEN ' Matched '
  ELSE
  CONCAT('UNMATCHED: Proc 2 Value:   ', COALESCE(week.bph30_desc,
      '-Null'), '   -- Hadoop Value:   ', COALESCE(shared.bph30_desc,
      '-Null'))
END
  bph30_desc_Differences,
  week.bph40_desc Proc2_bph40_desc,
  shared.bph40_desc Hadoop_bph40_desc,
  CASE
    WHEN ((IFNULL(week.bph40_desc, 'TestNull') = IFNULL( shared.bph40_desc, 'TestNull')) ) THEN ' Matched '
  ELSE
  CONCAT('UNMATCHED: Proc 2 Value:   ', COALESCE(week.bph40_desc,
      '-Null'), '   -- Hadoop Value:   ', COALESCE(shared.bph40_desc,
      '-Null'))
END
  bph40_desc_Differences,
  week.bph50_desc Proc2_bph50_desc,
  shared.bph50_desc Hadoop_bph50_desc,
  CASE
    WHEN ((IFNULL(week.bph50_desc, 'TestNull') = IFNULL( shared.bph50_desc, 'TestNull')) ) THEN ' Matched '
  ELSE
  CONCAT('UNMATCHED: Proc 2 Value:   ', COALESCE(week.bph50_desc,
      '-Null'), '   -- Hadoop Value:   ', COALESCE(shared.bph50_desc,
      '-Null'))
END
  bph50_desc_Differences,
  week.bph60_desc proc2_bph60_desc,
  shared.bph60_desc Hadoop_bph60_desc,
  CASE
    WHEN ((IFNULL(week.bph60_desc, 'TestNull') = IFNULL( shared.bph60_desc, 'TestNull')) ) THEN ' Matched '
  ELSE
  CONCAT('UNMATCHED: Proc 2 Value:   ', COALESCE(week.bph60_desc,
      '-Null'), '   -- Hadoop Value:   ', COALESCE(shared.bph60_desc,
      '-Null'))
END
  bph60_desc_Differences,
  week.bph70_desc proc2_bph70_desc,
  shared.bph70_desc Hadoop_bph70_desc,
  CASE
    WHEN ((IFNULL(week.bph70_desc, 'TestNull') = IFNULL( shared.bph70_desc, 'TestNull')) ) THEN ' Matched '
  ELSE
  CONCAT('UNMATCHED: Proc 2 Value:   ', COALESCE(week.bph70_desc,
      '-Null'), '   -- Hadoop Value:   ', COALESCE(shared.bph70_desc,
      '-Null'))
END
  bph70_desc_Differences,
  week.brand_high_desc proc2_brand_high_desc,
  shared.brand_high_desc Hadoop_brand_high_desc,
  CASE
    WHEN ((IFNULL(week.brand_high_desc, 'TestNull') = IFNULL( shared.brand_high_desc, 'TestNull')) ) THEN ' Matched '
  ELSE
  CONCAT('UNMATCHED: Proc 2 Value:   ', COALESCE(week.brand_high_desc,
      '-Null'), '   -- Hadoop Value:   ', COALESCE(shared.brand_high_desc,
      '-Null'))
END
  brand_high_desc_Differences,
  week.brand_low_desc proc2_brand_low_desc,
  shared.brand_low_desc Hadoop_brand_low_desc,
  CASE
    WHEN ((IFNULL(week.brand_low_desc, 'TestNull') = IFNULL( shared.brand_low_desc, 'TestNull')) ) THEN ' Matched '
  ELSE
  CONCAT('UNMATCHED: Proc 2 Value:   ', COALESCE(week.brand_low_desc,
      '-Null'), '   -- Hadoop Value:   ', COALESCE(shared.brand_low_desc,
      '-Null'))
END
  brand_low_desc_Differences,
  week.calendar_year_nbr proc2_calendar_year_nbr,
  shared.calendar_year_nbr Hadoop_calendar_year_nbr,
  CASE
    WHEN ((IFNULL(week.calendar_year_nbr, -99999) = IFNULL( shared.calendar_year_nbr, -99999)) ) THEN ' Matched '
  ELSE
  CONCAT('UNMATCHED: Proc 2 Value:   ', COALESCE(week.calendar_year_nbr,
      -99999), '   -- Hadoop Value:   ', COALESCE(shared.calendar_year_nbr,
      -99999))
END
  calendar_year_nbr_Differences,
  week.change_in_sales_eqc proc2_change_in_sales_eqc,
  shared.change_in_sales_eqc Hadoop_change_in_sales_eqc,
  CASE
    WHEN ((IFNULL(week.change_in_sales_eqc, -99999) = IFNULL( shared.change_in_sales_eqc, -99999)) ) THEN ' Matched '
  ELSE
  CONCAT('UNMATCHED: Proc 2 Value:   ', COALESCE(week.change_in_sales_eqc,
      -99999), '   -- Hadoop Value:   ', COALESCE(shared.change_in_sales_eqc,
      -99999))
END
  change_in_sales_eqc_Differences,
  week.change_in_sales_units proc2_change_in_sales_units,
  shared.change_in_sales_units Hadoop_change_in_sales_units,
  CASE
    WHEN ((IFNULL(week.change_in_sales_units, -99999) = IFNULL( shared.change_in_sales_units, -99999)) ) THEN ' Matched '
  ELSE
  CONCAT('UNMATCHED: Proc 2 Value:   ', COALESCE(week.change_in_sales_units,
      -99999), '   -- Hadoop Value:   ', COALESCE(shared.change_in_sales_units,
      -99999))
END
  change_in_sales_units_Differences,
  week.change_in_sales_value_usd proc2_change_in_sales_value_usd,
  shared.change_in_sales_value_usd Hadoop_change_in_sales_value_usd,
  CASE
    WHEN ((IFNULL(week.change_in_sales_value_usd, -99999.99) = IFNULL( shared.change_in_sales_value_usd, -99999.99)) ) THEN 'Matched '
  ELSE
  CONCAT('UNMATCHED: Proc 2 col Value ', COALESCE(week.change_in_sales_value_usd,
      -99999.99), ' Hadoop Value ', COALESCE(shared.change_in_sales_value_usd,
      -99999.99))
END
  change_in_sales_value_usd_Differences,
  week.change_in_sales_value proc2_change_in_sales_value,
  shared.change_in_sales_value Hadoop_change_in_sales_value,
  CASE
    WHEN ((IFNULL(week.change_in_sales_value, -99999.99) = IFNULL( shared.change_in_sales_value, -99999.99)) ) THEN 'Matched '
  ELSE
  CONCAT('UNMATCHED: Proc 2 col Value ', COALESCE(week.change_in_sales_value,
      -99999.99), ' Hadoop Value ', COALESCE(shared.change_in_sales_value,
      -99999.99))
END
  change_in_sales_value_Differences,
  week.channel proc2_channel,
  shared.channel Hadoop_channel,
  CASE
    WHEN ((IFNULL(week.channel, 'TestNull') = IFNULL( shared.channel, 'TestNull')) ) THEN ' Matched '
  ELSE
  CONCAT('UNMATCHED: Proc 2 Value:   ', COALESCE(week.channel,
      '-Null'), '   -- Hadoop Value:   ', COALESCE(shared.channel,
      '-Null'))
END
  channel_Differences,
  week.country proc2_country,
  shared.country Hadoop_country,
  CASE
    WHEN ((IFNULL(week.country, 'TestNull') = IFNULL( shared.country, 'TestNull')) ) THEN ' Matched '
  ELSE
  CONCAT('UNMATCHED: Proc 2 Value:   ', COALESCE(week.country,
      '-Null'), '   -- Hadoop Value:   ', COALESCE(shared.country,
      '-Null'))
END
  country_Differences,
  week.currency_code proc2_currency_code,
  shared.currency_code Hadoop_currency_code,
  CASE
    WHEN ((IFNULL(week.currency_code, 'TestNull') = IFNULL( shared.currency_code, 'TestNull')) ) THEN ' Matched '
  ELSE
  CONCAT('UNMATCHED: Proc 2 Value:   ', COALESCE(week.currency_code,
      '-Null'), '   -- Hadoop Value:   ', COALESCE(shared.currency_code,
      '-Null'))
END
  currency_code_Differences,
  week.currency_symbol proc2_currency_symbol,
  shared.currency_symbol Hadoop_currency_symbol,
  CASE
    WHEN ((IFNULL(week.currency_symbol, 'TestNull') = IFNULL( shared.currency_symbol, 'TestNull')) ) THEN ' Matched '
  ELSE
  CONCAT('UNMATCHED: Proc 2 Value:   ', COALESCE(week.currency_symbol,
      '-Null'), '   -- Hadoop Value:   ', COALESCE(shared.currency_symbol,
      '-Null'))
END
  currency_symbol_Differences,
  week.customer_account proc2_customer_account,
  shared.customer_account Hadoop_customer_account,
  CASE
    WHEN ((IFNULL(week.customer_account, 'TestNull') = IFNULL( shared.customer_account, 'TestNull')) ) THEN ' Matched '
  ELSE
  CONCAT('UNMATCHED: Proc 2 Value:   ', COALESCE(week.customer_account,
      '-Null'), '   -- Hadoop Value:   ', COALESCE(shared.customer_account,
      '-Null'))
END
  customer_account_Differences,
  week.customer_desc proc2_customer_desc,
  shared.customer_desc Hadoop_customer_desc,
  CASE
    WHEN ((IFNULL(week.customer_desc, 'TestNull') = IFNULL( shared.customer_desc, 'TestNull')) ) THEN ' Matched '
  ELSE
  CONCAT('UNMATCHED: Proc 2 Value:   ', COALESCE(week.customer_desc,
      '-Null'), '   -- Hadoop Value:   ', COALESCE(shared.customer_desc,
      '-Null'))
END
  customer_desc_Differences,
  week.customer_parent proc2_customer_parent,
  shared.customer_parent Hadoop_customer_parent,
  CASE
    WHEN ((IFNULL(week.customer_parent, 'TestNull') = IFNULL( shared.customer_parent, 'TestNull')) ) THEN ' Matched '
  ELSE
  CONCAT('UNMATCHED: Proc 2 Value:   ', COALESCE(week.customer_parent,
      '-Null'), '   -- Hadoop Value:   ', COALESCE(shared.customer_parent,
      '-Null'))
END
  customer_parent_Differences,
  week.customer_sales_flag proc2_customer_sales_flag,
  shared.customer_sales_flag Hadoop_customer_sales_flag,
  CASE
    WHEN ((IFNULL(week.customer_sales_flag, 'TestNull') = IFNULL( shared.customer_sales_flag, 'TestNull')) ) THEN ' Matched '
  ELSE
  CONCAT('UNMATCHED: Proc 2 Value:   ', COALESCE(week.customer_sales_flag,
      '-Null'), '   -- Hadoop Value:   ', COALESCE(shared.customer_sales_flag,
      '-Null'))
END
  customer_sales_flag_Differences,
  week.customer_share_flag proc2_customer_share_flag,
  shared.customer_share_flag Hadoop_customer_share_flag,
  CASE
    WHEN ((IFNULL(week.customer_share_flag, 'TestNull') = IFNULL( shared.customer_share_flag, 'TestNull')) ) THEN ' Matched '
  ELSE
  CONCAT('UNMATCHED: Proc 2 Value:   ', COALESCE(week.customer_share_flag,
      '-Null'), '   -- Hadoop Value:   ', COALESCE(shared.customer_share_flag,
      '-Null'))
END
  customer_share_flag_Differences,
  week.divested_fg proc2_divested_fg,
  shared.divested_fg Hadoop_divested_fg,
  CASE
    WHEN ((IFNULL(week.divested_fg, 'TestNull') = IFNULL( shared.divested_fg, 'TestNull')) ) THEN ' Matched '
  ELSE
  CONCAT('UNMATCHED: Proc 2 Value:   ', COALESCE(week.divested_fg,
      '-Null'), '   -- Hadoop Value:   ', COALESCE(shared.divested_fg,
      '-Null'))
END
  divested_fg_Differences,
  week.ean_upc_cd proc2_ean_upc_cd,
  shared.ean_upc_cd Hadoop_ean_upc_cd,
  CASE
    WHEN ((IFNULL(week.ean_upc_cd, 'TestNull') = IFNULL( shared.ean_upc_cd, 'TestNull')) ) THEN ' Matched '
  ELSE
  CONCAT('UNMATCHED: Proc 2 Value:   ', COALESCE(week.ean_upc_cd,
      '-Null'), '   -- Hadoop Value:   ', COALESCE(shared.ean_upc_cd,
      '-Null'))
END
  ean_upc_cd_Differences,
  week.ean_upc_derived_cd proc2_ean_upc_derived_cd,
  shared.ean_upc_derived_cd Hadoop_ean_upc_derived_cd,
  CASE
    WHEN ((IFNULL(week.ean_upc_derived_cd, 'TestNull') = IFNULL( shared.ean_upc_derived_cd, 'TestNull')) ) THEN ' Matched '
  ELSE
  CONCAT('UNMATCHED: Proc 2 Value:   ', COALESCE(week.ean_upc_derived_cd,
      '-Null'), '   -- Hadoop Value:   ', COALESCE(shared.ean_upc_derived_cd,
      '-Null'))
END
  ean_upc_derived_cd_Differences,
  week.euau_business_operating_unit_desc proc2_euau_business_operating_unit_desc,
  shared.euau_business_operating_unit_desc Hadoop_euau_business_operating_unit_desc,
  CASE
    WHEN ((IFNULL(week.euau_business_operating_unit_desc, 'TestNull') = IFNULL( shared.euau_business_operating_unit_desc, 'TestNull')) ) THEN ' Matched '
  ELSE
  CONCAT('UNMATCHED: Proc 2 Value:   ', COALESCE(week.euau_business_operating_unit_desc,
      '-Null'), '   -- Hadoop Value:   ', COALESCE(shared.euau_business_operating_unit_desc,
      '-Null'))
END
  euau_business_operating_unit_desc_Differences,
  week.euau_business_product_group_desc proc2_euau_business_product_group_desc,
  shared.euau_business_product_group_desc Hadoop_euau_business_product_group_desc,
  CASE
    WHEN ((IFNULL(week.euau_business_product_group_desc, 'TestNull') = IFNULL( shared.euau_business_product_group_desc, 'TestNull')) ) THEN ' Matched '
  ELSE
  CONCAT('UNMATCHED: Proc 2 Value:   ', COALESCE(week.euau_business_product_group_desc,
      '-Null'), '   -- Hadoop Value:   ', COALESCE(shared.euau_business_product_group_desc,
      '-Null'))
END
  euau_business_product_group_desc_Differences,
  week.euau_business_product_sub_group_desc proc2_euau_business_product_sub_group_desc,
  shared.euau_business_product_sub_group_desc Hadoop_euau_business_product_sub_group_desc,
  CASE
    WHEN ((IFNULL(week.euau_business_product_sub_group_desc, 'TestNull') = IFNULL( shared.euau_business_product_sub_group_desc, 'TestNull')) ) THEN ' Matched '
  ELSE
  CONCAT('UNMATCHED: Proc 2 Value:   ', COALESCE(week.euau_business_product_sub_group_desc,
      '-Null'), '   -- Hadoop Value:   ', COALESCE(shared.euau_business_product_sub_group_desc,
      '-Null'))
END
  euau_business_product_sub_group_desc_Differences,
  week.fiscal_date_customer_max proc2_fiscal_date_customer_max,
  shared.fiscal_date_customer_max Hadoop_fiscal_date_customer_max,
  CASE
    WHEN ((IFNULL(week.fiscal_date_customer_max, '1900-01-01 00:00:00 UTC') = IFNULL( CAST(shared.fiscal_date_customer_max AS String), '1900-01-01 00:00:00 UTC')) ) THEN ' Matched '
  ELSE
  CONCAT('UNMATCHED: Proc 2 Value:   ', COALESCE(week.fiscal_date_customer_max,
      '1900-01-01 00:00:00 UTC'), '   -- Hadoop Value:   ', COALESCE(CAST(shared.fiscal_date_customer_max AS STRING),
      '1900-01-01 00:00:00 UTC'))
END
  fiscal_date_customer_max_Differences,
  week.fiscal_month_in_year_nbr proc2_fiscal_month_in_year_nbr,
  shared.fiscal_month_in_year_nbr Hadoop_fiscal_month_in_year_nbr,
  CASE
    WHEN ((IFNULL(week.fiscal_month_in_year_nbr, -99999) = IFNULL( shared.fiscal_month_in_year_nbr, -99999)) ) THEN ' Matched '
  ELSE
  CONCAT('UNMATCHED: Proc 2 Value:   ', COALESCE(week.fiscal_month_in_year_nbr,
      -99999), '   -- Hadoop Value:   ', COALESCE(shared.fiscal_month_in_year_nbr,
      -99999))
END
  fiscal_month_in_year_nbr_Differences,
  week.fiscal_month_in_year_short_desc proc2_fiscal_month_in_year_short_desc,
  shared.fiscal_month_in_year_short_desc Hadoop_fiscal_month_in_year_short_desc,
  CASE
    WHEN ((IFNULL(week.fiscal_month_in_year_short_desc, 'TestNull') = IFNULL( shared.fiscal_month_in_year_short_desc, 'TestNull')) ) THEN ' Matched '
  ELSE
  CONCAT('UNMATCHED: Proc 2 Value:   ', COALESCE(week.fiscal_month_in_year_short_desc,
      '-Null'), '   -- Hadoop Value:   ', COALESCE(shared.fiscal_month_in_year_short_desc,
      '-Null'))
END
  fiscal_month_in_year_short_desc_Differences,
  week.fiscal_month_number_short_desc proc2_fiscal_month_number_short_desc,
  shared.fiscal_month_number_short_desc Hadoop_fiscal_month_number_short_desc,
  CASE
    WHEN ((IFNULL(week.fiscal_month_number_short_desc, 'TestNull') = IFNULL( shared.fiscal_month_number_short_desc, 'TestNull')) ) THEN ' Matched '
  ELSE
  CONCAT('UNMATCHED: Proc 2 Value:   ', COALESCE(week.fiscal_month_number_short_desc,
      '-Null'), '   -- Hadoop Value:   ', COALESCE(shared.fiscal_month_number_short_desc,
      '-Null'))
END
  fiscal_month_number_short_desc_Differences,
  week.fiscal_month_verbose_tableau_mapping proc2_fiscal_month_verbose_tableau_mapping,
  shared.fiscal_month_verbose_tableau_mapping Hadoop_fiscal_month_verbose_tableau_mapping,
  CASE
    WHEN ((IFNULL(week.fiscal_month_verbose_tableau_mapping, 'TestNull') = IFNULL( shared.fiscal_month_verbose_tableau_mapping, 'TestNull')) ) THEN ' Matched '
  ELSE
  CONCAT('UNMATCHED: Proc 2 Value:   ', COALESCE(week.fiscal_month_verbose_tableau_mapping,
      '-Null'), '   -- Hadoop Value:   ', COALESCE(shared.fiscal_month_verbose_tableau_mapping,
      '-Null'))
END
  fiscal_month_verbose_tableau_mapping_Differences,
  week.fiscal_quarter_in_year_nbr proc2_fiscal_quarter_in_year_nbr,
  shared.fiscal_quarter_in_year_nbr Hadoop_fiscal_quarter_in_year_nbr,
  CASE
    WHEN ((IFNULL(week.fiscal_quarter_in_year_nbr, -99999) = IFNULL( shared.fiscal_quarter_in_year_nbr, -99999)) ) THEN ' Matched '
  ELSE
  CONCAT('UNMATCHED: Proc 2 Value:   ', COALESCE(week.fiscal_quarter_in_year_nbr,
      -99999), '   -- Hadoop Value:   ', COALESCE(shared.fiscal_quarter_in_year_nbr,
      -99999))
END
  fiscal_quarter_in_year_nbr_Differences,
  week.fiscal_quarter_nbr proc2_fiscal_quarter_nbr,
  shared.fiscal_quarter_nbr Hadoop_fiscal_quarter_nbr,
  CASE
    WHEN ((IFNULL(week.fiscal_quarter_nbr, -99999) = IFNULL( shared.fiscal_quarter_nbr, -99999)) ) THEN ' Matched '
  ELSE
  CONCAT('UNMATCHED: Proc 2 Value:   ', COALESCE(week.fiscal_quarter_nbr,
      -99999), '   -- Hadoop Value:   ', COALESCE(shared.fiscal_quarter_nbr,
      -99999))
END
  fiscal_quarter_nbr_Differences,
  week.fiscal_quarter_number_short_desc proc2_fiscal_quarter_number_short_desc,
  shared.fiscal_quarter_number_short_desc Hadoop_fiscal_quarter_number_short_desc,
  CASE
    WHEN ((IFNULL(week.fiscal_quarter_number_short_desc, 'TestNull') = IFNULL( shared.fiscal_quarter_number_short_desc, 'TestNull')) ) THEN ' Matched '
  ELSE
  CONCAT('UNMATCHED: Proc 2 Value:   ', COALESCE(week.fiscal_quarter_number_short_desc,
      '-Null'), '   -- Hadoop Value:   ', COALESCE(shared.fiscal_quarter_number_short_desc,
      '-Null'))
END
  fiscal_quarter_number_short_desc_Differences,
  week.fiscal_week_begin_dt proc2_fiscal_week_begin_dt,
  shared.fiscal_week_begin_dt Hadoop_fiscal_week_begin_dt,
  CASE
    WHEN ((IFNULL(week.fiscal_week_begin_dt, CURRENT_TIMESTAMP()) = IFNULL( shared.fiscal_week_begin_dt, CURRENT_TIMESTAMP()) )) THEN 'Matched in both'
  ELSE
  CONCAT('UNMATCHED: Proc 2 Value:   ', COALESCE(week.fiscal_week_begin_dt,
      '1900-01-01 00:00:00 UTC'), '   -- Hadoop Value:   ', COALESCE(CAST(shared.fiscal_week_begin_dt AS STRING),
      '1900-01-01 00:00:00 UTC'))
END
  fiscal_week_begin_dt_Differences,
  week.fiscal_week_end_dt proc2_fiscal_week_end_dt,
  shared.fiscal_week_end_dt Hadoop_fiscal_week_end_dt,
  CASE
    WHEN ((IFNULL(week.fiscal_week_end_dt, CURRENT_TIMESTAMP()) = IFNULL( shared.fiscal_week_end_dt, CURRENT_TIMESTAMP()) )) THEN 'Matched in both'
  ELSE
  CONCAT('UNMATCHED: Proc 2 Value:   ', COALESCE(week.fiscal_week_end_dt,
      '1900-01-01 00:00:00 UTC'), '   -- Hadoop Value:   ', COALESCE(CAST(shared.fiscal_week_end_dt AS STRING),
      '1900-01-01 00:00:00 UTC'))
END
  fiscal_week_end_dt_Differences,
  week.fiscal_week_begin_dt_tableau_mapping proc2_fiscal_week_begin_dt_tableau_mapping,
  shared.fiscal_week_begin_dt_tableau_mapping Hadoop_fiscal_week_begin_dt_tableau_mapping,
  CASE
    WHEN (( COALESCE(CAST(week.fiscal_week_begin_dt_tableau_mapping AS STRING), '') = COALESCE(shared.fiscal_week_begin_dt_tableau_mapping, '' ))) THEN 'Matched in both'
  ELSE
  CONCAT('UNMATCHED: Proc 2 Value:   ', COALESCE(CAST(week.fiscal_week_begin_dt_tableau_mapping AS STRING),
      '1900-01-01'), '   -- Hadoop Value:   ', COALESCE(CAST(shared.fiscal_week_begin_dt_tableau_mapping AS STRING),
      '1900-01-01'))
END
  fiscal_week_begin_dt_tableau_mapping_Differences,
  week.fiscal_week_in_year_nbr proc2_fiscal_week_in_year_nbr,
  shared.fiscal_week_in_year_nbr Hadoop_fiscal_week_in_year_nbr,
  CASE
    WHEN ((IFNULL(week.fiscal_week_in_year_nbr, -99999) = IFNULL( shared.fiscal_week_in_year_nbr, -99999)) ) THEN ' Matched '
  ELSE
  CONCAT('UNMATCHED: Proc 2 Value:   ', COALESCE(week.fiscal_week_in_year_nbr,
      -99999), '   -- Hadoop Value:   ', COALESCE(shared.fiscal_week_in_year_nbr,
      -99999))
END
  fiscal_week_in_year_nbr_Differences,
  week.fiscal_year proc2_fiscal_year,
  shared.fiscal_year Hadoop_fiscal_year,
  CASE
    WHEN ((IFNULL(week.fiscal_year, 'TestNull') = IFNULL( shared.fiscal_year, 'TestNull')) ) THEN ' Matched '
  ELSE
  CONCAT('UNMATCHED: Proc 2 Value:   ', COALESCE(week.fiscal_year,
      '-Null'), '   -- Hadoop Value:   ', COALESCE(shared.fiscal_year,
      '-Null'))
END
  fiscal_year_Differences,
  week.fiscal_year_month_nbr proc2_fiscal_year_month_nbr,
  shared.fiscal_year_month_nbr Hadoop_fiscal_year_month_nbr,
  CASE
    WHEN ((IFNULL(week.fiscal_year_month_nbr, -99999) = IFNULL( CAST(shared.fiscal_year_month_nbr AS INT64), -99999)) ) THEN ' Matched '
  ELSE
  CONCAT('UNMATCHED: Proc 2 Value:   ', COALESCE(week.fiscal_year_month_nbr,
      -99999), '   -- Hadoop Value:   ', COALESCE(CAST(shared.fiscal_year_month_nbr AS INT64),
      -99999))
END
  fiscal_year_month_nbr_Differences,
  week.fiscal_year_nbr proc2_fiscal_year_nbr,
  shared.fiscal_year_nbr Hadoop_fiscal_year_nbr,
  CASE
    WHEN ((IFNULL(week.fiscal_year_nbr, -99999) = IFNULL( shared.fiscal_year_nbr, -99999)) ) THEN ' Matched '
  ELSE
  CONCAT('UNMATCHED: Proc 2 Value:   ', COALESCE(week.fiscal_year_nbr,
      -99999), '   -- Hadoop Value:   ', COALESCE(shared.fiscal_year_nbr,
      -99999))
END
  fiscal_year_nbr_Differences,
  week.fiscal_year_short_desc proc2_fiscal_year_short_desc,
  shared.fiscal_year_short_desc Hadoop_fiscal_year_short_desc,
  CASE
    WHEN ((IFNULL(week.fiscal_year_short_desc, 'TestNull') = IFNULL( shared.fiscal_year_short_desc, 'TestNull')) ) THEN ' Matched '
  ELSE
  CONCAT('UNMATCHED: Proc 2 Value:   ', COALESCE(week.fiscal_year_short_desc,
      '-Null'), '   -- Hadoop Value:   ', COALESCE(shared.fiscal_year_short_desc,
      '-Null'))
END
  fiscal_year_short_desc_Differences,
  week.global_category proc2_global_category,
  shared.global_category Hadoop_global_category,
  CASE
    WHEN ((IFNULL(week.global_category, 'TestNull') = IFNULL( shared.global_category, 'TestNull')) ) THEN ' Matched '
  ELSE
  CONCAT('UNMATCHED: Proc 2 Value:   ', COALESCE(week.global_category,
      '-Null'), '   -- Hadoop Value:   ', COALESCE(shared.global_category,
      '-Null'))
END
  global_category_Differences,
  week.global_category_parent proc2_global_category_parent,
  shared.global_category_parent Hadoop_global_category_parent,
  CASE
    WHEN ((IFNULL(week.global_category_parent, 'TestNull') = IFNULL( shared.global_category_parent, 'TestNull')) ) THEN ' Matched '
  ELSE
  CONCAT('UNMATCHED: Proc 2 Value:   ', COALESCE(week.global_category_parent,
      '-Null'), '   -- Hadoop Value:   ', COALESCE(shared.global_category_parent,
      '-Null'))
END
  global_category_parent_Differences,
  week.global_sub_category proc2_global_sub_category,
  shared.global_sub_category Hadoop_global_sub_category,
  CASE
    WHEN ((IFNULL(week.global_sub_category, 'TestNull') = IFNULL( shared.global_sub_category, 'TestNull')) ) THEN ' Matched '
  ELSE
  CONCAT('UNMATCHED: Proc 2 Value:   ', COALESCE(week.global_sub_category,
      '-Null'), '   -- Hadoop Value:   ', COALESCE(shared.global_sub_category,
      '-Null'))
END
  global_sub_category_Differences,
  week.gmi_brand_desc proc2_gmi_brand_desc,
  shared.gmi_brand_desc Hadoop_gmi_brand_desc,
  CASE
    WHEN ((IFNULL(week.gmi_brand_desc, 'TestNull') = IFNULL( shared.gmi_brand_desc, 'TestNull')) ) THEN ' Matched '
  ELSE
  CONCAT('UNMATCHED: Proc 2 Value:   ', COALESCE(week.gmi_brand_desc,
      '-Null'), '   -- Hadoop Value:   ', COALESCE(shared.gmi_brand_desc,
      '-Null'))
END
  gmi_brand_desc_Differences,
  week.gmi_category_desc proc2_gmi_category_desc,
  shared.gmi_category_desc Hadoop_gmi_category_desc,
  CASE
    WHEN ((IFNULL(week.gmi_category_desc, 'TestNull') = IFNULL( shared.gmi_category_desc, 'TestNull')) ) THEN ' Matched '
  ELSE
  CONCAT('UNMATCHED: Proc 2 Value:   ', COALESCE(week.gmi_category_desc,
      '-Null'), '   -- Hadoop Value:   ', COALESCE(shared.gmi_category_desc,
      '-Null'))
END
  gmi_category_desc_Differences,
  week.gmi_global_brand_desc proc2_gmi_global_brand_desc,
  shared.gmi_global_brand_desc Hadoop_gmi_global_brand_desc,
  CASE
    WHEN ((IFNULL(week.gmi_global_brand_desc, 'TestNull') = IFNULL( shared.gmi_global_brand_desc, 'TestNull')) ) THEN ' Matched '
  ELSE
  CONCAT('UNMATCHED: Proc 2 Value:   ', COALESCE(week.gmi_global_brand_desc,
      '-Null'), '   -- Hadoop Value:   ', COALESCE(shared.gmi_global_brand_desc,
      '-Null'))
END
  gmi_global_brand_desc_Differences,
  week.gmi_global_manufacturer_desc proc2_gmi_global_manufacturer_desc,
  shared.gmi_global_manufacturer_desc Hadoop_gmi_global_manufacturer_desc,
  CASE
    WHEN ((IFNULL(week.gmi_global_manufacturer_desc, 'TestNull') = IFNULL( shared.gmi_global_manufacturer_desc, 'TestNull')) ) THEN ' Matched '
  ELSE
  CONCAT('UNMATCHED: Proc 2 Value:   ', COALESCE(week.gmi_global_manufacturer_desc,
      '-Null'), '   -- Hadoop Value:   ', COALESCE(shared.gmi_global_manufacturer_desc,
      '-Null'))
END
  gmi_global_manufacturer_desc_Differences,
  week.gmi_manufacturer_desc proc2_gmi_manufacturer_desc,
  shared.gmi_manufacturer_desc Hadoop_gmi_manufacturer_desc,
  CASE
    WHEN ((IFNULL(week.gmi_manufacturer_desc, 'TestNull') = IFNULL( shared.gmi_manufacturer_desc, 'TestNull')) ) THEN ' Matched '
  ELSE
  CONCAT('UNMATCHED: Proc 2 Value:   ', COALESCE(week.gmi_manufacturer_desc,
      '-Null'), '   -- Hadoop Value:   ', COALESCE(shared.gmi_manufacturer_desc,
      '-Null'))
END
  gmi_manufacturer_desc_Differences,
  week.gmi_megacategory_desc proc2_gmi_megacategory_desc,
  shared.gmi_megacategory_desc Hadoop_gmi_megacategory_desc,
  CASE
    WHEN ((IFNULL(week.gmi_megacategory_desc, 'TestNull') = IFNULL( shared.gmi_megacategory_desc, 'TestNull')) ) THEN ' Matched '
  ELSE
  CONCAT('UNMATCHED: Proc 2 Value:   ', COALESCE(week.gmi_megacategory_desc,
      '-Null'), '   -- Hadoop Value:   ', COALESCE(shared.gmi_megacategory_desc,
      '-Null'))
END
  gmi_megacategory_desc_Differences,
  week.gmi_segment_desc proc2_gmi_segment_desc,
  shared.gmi_segment_desc Hadoop_gmi_segment_desc,
  CASE
    WHEN ((IFNULL(week.gmi_segment_desc, 'TestNull') = IFNULL( shared.gmi_segment_desc, 'TestNull')) ) THEN ' Matched '
  ELSE
  CONCAT('UNMATCHED: Proc 2 Value:   ', COALESCE(week.gmi_segment_desc,
      '-Null'), '   -- Hadoop Value:   ', COALESCE(shared.gmi_segment_desc,
      '-Null'))
END
  gmi_segment_desc_Differences,
  week.gmi_sub_category_desc proc2_gmi_sub_category_desc,
  shared.gmi_sub_category_desc Hadoop_gmi_sub_category_desc,
  CASE
    WHEN ((IFNULL(week.gmi_sub_category_desc, 'TestNull') = IFNULL( shared.gmi_sub_category_desc, 'TestNull')) ) THEN ' Matched '
  ELSE
  CONCAT('UNMATCHED: Proc 2 Value:   ', COALESCE(week.gmi_sub_category_desc,
      '-Null'), '   -- Hadoop Value:   ', COALESCE(shared.gmi_sub_category_desc,
      '-Null'))
END
  gmi_sub_category_desc_Differences,
  week.gph_hier_category_desc proc2_gph_hier_category_desc,
  shared.gph_hier_category_desc Hadoop_gph_hier_category_desc,
  CASE
    WHEN ((IFNULL(week.gph_hier_category_desc, 'TestNull') = IFNULL( shared.gph_hier_category_desc, 'TestNull')) ) THEN ' Matched '
  ELSE
  CONCAT('UNMATCHED: Proc 2 Value:   ', COALESCE(week.gph_hier_category_desc,
      '-Null'), '   -- Hadoop Value:   ', COALESCE(shared.gph_hier_category_desc,
      '-Null'))
END
  gph_hier_category_desc_Differences,
  week.gph_hier_family_desc proc2_gph_hier_family_desc,
  shared.gph_hier_family_desc Hadoop_gph_hier_family_desc,
  CASE
    WHEN ((IFNULL(week.gph_hier_family_desc, 'TestNull') = IFNULL( shared.gph_hier_family_desc, 'TestNull')) ) THEN ' Matched '
  ELSE
  CONCAT('UNMATCHED: Proc 2 Value:   ', COALESCE(week.gph_hier_family_desc,
      '-Null'), '   -- Hadoop Value:   ', COALESCE(shared.gph_hier_family_desc,
      '-Null'))
END
  gph_hier_family_desc_Differences,
  week.gph_hier_flavor_format_desc proc2_gph_hier_flavor_format_desc,
  shared.gph_hier_flavor_format_desc Hadoop_gph_hier_flavor_format_desc,
  CASE
    WHEN ((IFNULL(week.gph_hier_flavor_format_desc, 'TestNull') = IFNULL( shared.gph_hier_flavor_format_desc, 'TestNull')) ) THEN ' Matched '
  ELSE
  CONCAT('UNMATCHED: Proc 2 Value:   ', COALESCE(week.gph_hier_flavor_format_desc,
      '-Null'), '   -- Hadoop Value:   ', COALESCE(shared.gph_hier_flavor_format_desc,
      '-Null'))
END
  gph_hier_flavor_format_desc_Differences,
  week.gph_hier_package_size_desc proc2_gph_hier_package_size_desc,
  shared.gph_hier_package_size_desc Hadoop_gph_hier_package_size_desc,
  CASE
    WHEN ((IFNULL(week.gph_hier_package_size_desc, 'TestNull') = IFNULL( shared.gph_hier_package_size_desc, 'TestNull')) ) THEN ' Matched '
  ELSE
  CONCAT('UNMATCHED: Proc 2 Value:   ', COALESCE(week.gph_hier_package_size_desc,
      '-Null'), '   -- Hadoop Value:   ', COALESCE(shared.gph_hier_package_size_desc,
      '-Null'))
END
  gph_hier_package_size_desc_Differences,
  week.gph_hier_top_desc proc2_gph_hier_top_desc,
  shared.gph_hier_top_desc Hadoop_gph_hier_top_desc,
  CASE
    WHEN ((IFNULL(week.gph_hier_top_desc, 'TestNull') = IFNULL( shared.gph_hier_top_desc, 'TestNull')) ) THEN ' Matched '
  ELSE
  CONCAT('UNMATCHED: Proc 2 Value:   ', COALESCE(week.gph_hier_top_desc,
      '-Null'), '   -- Hadoop Value:   ', COALESCE(shared.gph_hier_top_desc,
      '-Null'))
END
  gph_hier_top_desc_Differences,
  week.item_name_with_code_tableau_mapping proc2_item_name_with_code_tableau_mapping,
  shared.item_name_with_code_tableau_mapping Hadoop_item_name_with_code_tableau_mapping,
  CASE
    WHEN ((IFNULL(week.item_name_with_code_tableau_mapping, 'TestNull') = IFNULL( shared.item_name_with_code_tableau_mapping, 'TestNull')) ) THEN ' Matched '
  ELSE
  CONCAT('UNMATCHED: Proc 2 Value:   ', COALESCE(week.item_name_with_code_tableau_mapping,
      '-Null'), '   -- Hadoop Value:   ', COALESCE(shared.item_name_with_code_tableau_mapping,
      '-Null'))
END
  item_name_with_code_tableau_mapping_Differences,
  week.latest_completed_fiscal_month_customer_fg proc2_latest_completed_fiscal_month_customer_fg,
  shared.latest_completed_fiscal_month_customer_fg Hadoop_latest_completed_fiscal_month_customer_fg,
  CASE
    WHEN ((IFNULL(week.latest_completed_fiscal_month_customer_fg, 'TestNull') = IFNULL( shared.latest_completed_fiscal_month_customer_fg, 'TestNull')) ) THEN ' Matched '
  ELSE
  CONCAT('UNMATCHED: Proc 2 Value:   ', COALESCE(week.latest_completed_fiscal_month_customer_fg,
      '-Null'), '   -- Hadoop Value:   ', COALESCE(shared.latest_completed_fiscal_month_customer_fg,
      '-Null'))
END
  latest_completed_fiscal_month_customer_fg_Differences,
  week.latest_completed_fiscal_quarter_customer_fg proc2_latest_completed_fiscal_quarter_customer_fg,
  shared.latest_completed_fiscal_quarter_customer_fg Hadoop_latest_completed_fiscal_quarter_customer_fg,
  CASE
    WHEN ((IFNULL(week.latest_completed_fiscal_quarter_customer_fg, 'TestNull') = IFNULL( shared.latest_completed_fiscal_quarter_customer_fg, 'TestNull')) ) THEN ' Matched '
  ELSE
  CONCAT('UNMATCHED: Proc 2 Value:   ', COALESCE(week.latest_completed_fiscal_quarter_customer_fg,
      '-Null'), '   -- Hadoop Value:   ', COALESCE(shared.latest_completed_fiscal_quarter_customer_fg,
      '-Null'))
END
  latest_completed_fiscal_quarter_customer_fg_Differences,
  week.latest_completed_fiscal_year_customer_fg proc2_latest_completed_fiscal_year_customer_fg,
  shared.latest_completed_fiscal_year_customer_fg Hadoop_latest_completed_fiscal_year_customer_fg,
  CASE
    WHEN ((IFNULL(week.latest_completed_fiscal_year_customer_fg, 'TestNull') = IFNULL( shared.latest_completed_fiscal_year_customer_fg, 'TestNull')) ) THEN ' Matched '
  ELSE
  CONCAT('UNMATCHED: Proc 2 Value:   ', COALESCE(week.latest_completed_fiscal_year_customer_fg,
      '-Null'), '   -- Hadoop Value:   ', COALESCE(shared.latest_completed_fiscal_year_customer_fg,
      '-Null'))
END
  latest_completed_fiscal_year_customer_fg_Differences,
  week.ly_sales_eqc_units proc2_ly_sales_eqc_units,
  shared.ly_sales_eqc_units Hadoop_ly_sales_eqc_units,
  CASE
    WHEN ((IFNULL(week.ly_sales_eqc_units, -99999) = IFNULL( shared.ly_sales_eqc_units, -99999)) ) THEN 'Matched '
  ELSE
  CONCAT('UNMATCHED: Proc 2 col Value ', COALESCE(week.ly_sales_eqc_units,
      -99999), ' Hadoop Value ', COALESCE(shared.ly_sales_eqc_units,
      -99999))
END
  ly_sales_eqc_units_Differences,
  week.ly_sales_units proc2_ly_sales_units,
  shared.ly_sales_units Hadoop_ly_sales_units,
  CASE
    WHEN ( (IFNULL(week.ly_sales_units, -99999) = IFNULL( shared.ly_sales_units, -99999)) ) THEN 'Matched '
  ELSE
  CONCAT('UNMATCHED: Proc 2 col Value ', COALESCE(week.ly_sales_units,
      -99999), ' Hadoop Value ', COALESCE(shared.ly_sales_units,
      -99999))
END
  ly_sales_units_Differences,
  week.ly_sales_value proc2_ly_sales_value,
  shared.ly_sales_value Hadoop_ly_sales_value,
  CASE
    WHEN ((IFNULL(week.ly_sales_value, -99999.99) = IFNULL( shared.ly_sales_value, -99999.99)) ) THEN 'Matched '
  ELSE
  CONCAT('UNMATCHED: Proc 2 col Value ', COALESCE(week.ly_sales_value,
      -99999.99), ' Hadoop Value ', COALESCE(shared.ly_sales_value,
      -99999.99))
END
  ly_sales_value_Differences,
  week.ly_sales_value_usd proc2_ly_sales_value_usd,
  shared.ly_sales_value_usd Hadoop_ly_sales_value_usd,
  CASE
    WHEN ((IFNULL(week.ly_sales_value_usd, -99999.99) = IFNULL( shared.ly_sales_value_usd, -99999.99)) ) THEN 'Matched '
  ELSE
  CONCAT('UNMATCHED: Proc 2 col Value ', COALESCE(week.ly_sales_value_usd,
      -99999.99), ' Hadoop Value ', COALESCE(shared.ly_sales_value_usd,
      -99999.99))
END
  ly_sales_value_usd_Differences,
  week.manufacturer proc2_manufacturer,
  shared.manufacturer Hadoop_manufacturer,
  CASE
    WHEN ((IFNULL(week.manufacturer, 'TestNull') = IFNULL( shared.manufacturer, 'TestNull')) ) THEN ' Matched '
  ELSE
  CONCAT('UNMATCHED: Proc 2 Value:   ', COALESCE(week.manufacturer,
      '-Null'), '   -- Hadoop Value:   ', COALESCE(shared.manufacturer,
      '-Null'))
END
  manufacturer_Differences,
  week.manufacturer_brand_tableau_mapping proc2_manufacturer_brand_tableau_mapping,
  shared.manufacturer_brand_tableau_mapping Hadoop_manufacturer_brand_tableau_mapping,
  CASE
    WHEN ((IFNULL(week.manufacturer_brand_tableau_mapping, 'TestNull') = IFNULL( shared.manufacturer_brand_tableau_mapping, 'TestNull')) ) THEN ' Matched '
  ELSE
  CONCAT('UNMATCHED: Proc 2 Value:   ', COALESCE(week.manufacturer_brand_tableau_mapping,
      '-Null'), '   -- Hadoop Value:   ', COALESCE(shared.manufacturer_brand_tableau_mapping,
      '-Null'))
END
  manufacturer_brand_tableau_mapping_Differences,
  week.material_cd proc2_material_cd,
  shared.material_cd Hadoop_material_cd,
  CASE
    WHEN ((IFNULL(week.material_cd, 'TestNull') = IFNULL( shared.material_cd, 'TestNull')) ) THEN ' Matched '
  ELSE
  CONCAT('UNMATCHED: Proc 2 Value:   ', COALESCE(week.material_cd,
      '-Null'), '   -- Hadoop Value:   ', COALESCE(shared.material_cd,
      '-Null'))
END
  material_cd_Differences,
  week.material_nbr proc2_material_nbr,
  shared.material_nbr Hadoop_material_nbr,
  CASE
    WHEN ((IFNULL(week.material_nbr, 'TestNull') = IFNULL( shared.material_nbr, 'TestNull')) ) THEN ' Matched '
  ELSE
  CONCAT('UNMATCHED: Proc 2 Value:   ', COALESCE(week.material_nbr,
      '-Null'), '   -- Hadoop Value:   ', COALESCE(shared.material_nbr,
      '-Null'))
END
  material_nbr_Differences,
  week.material_short_desc proc2_material_short_desc,
  shared.material_short_desc Hadoop_material_short_desc,
  CASE
    WHEN ((IFNULL(week.material_short_desc, 'TestNull') = IFNULL( shared.material_short_desc, 'TestNull')) ) THEN ' Matched '
  ELSE
  CONCAT('UNMATCHED: Proc 2 Value:   ', COALESCE(week.material_short_desc,
      '-Null'), '   -- Hadoop Value:   ', COALESCE(shared.material_short_desc,
      '-Null'))
END
  material_short_desc_Differences,
  week.notes proc2_notes,
  shared.notes Hadoop_notes,
  CASE
    WHEN ((IFNULL(week.notes, 'TestNull') = IFNULL( shared.notes, 'TestNull')) ) THEN ' Matched '
  ELSE
  CONCAT('UNMATCHED: Proc 2 Value:   ', COALESCE(week.notes,
      '-Null'), '   -- Hadoop Value:   ', COALESCE(shared.notes,
      '-Null'))
END
  notes_Differences,
  week.product_category_derived_desc proc2_product_category_derived_desc,
  shared.product_category_derived_desc Hadoop_product_category_derived_desc,
  CASE
    WHEN ((IFNULL(week.product_category_derived_desc, 'TestNull') = IFNULL( shared.product_category_derived_desc, 'TestNull')) ) THEN ' Matched '
  ELSE
  CONCAT('UNMATCHED: Proc 2 Value:   ', COALESCE(week.product_category_derived_desc,
      '-Null'), '   -- Hadoop Value:   ', COALESCE(shared.product_category_derived_desc,
      '-Null'))
END
  product_category_derived_desc_Differences,
  week.product_sector_desc proc2_product_sector_desc,
  shared.product_sector_desc Hadoop_product_sector_desc,
  CASE
    WHEN ((IFNULL(week.product_sector_desc, 'TestNull') = IFNULL( shared.product_sector_desc, 'TestNull')) ) THEN ' Matched '
  ELSE
  CONCAT('UNMATCHED: Proc 2 Value:   ', COALESCE(week.product_sector_desc,
      '-Null'), '   -- Hadoop Value:   ', COALESCE(shared.product_sector_desc,
      '-Null'))
END
  product_sector_desc_Differences,
  week.product_sub_segment_derived_desc proc2_product_sub_segment_derived_desc,
  shared.product_sub_segment_derived_desc Hadoop_product_sub_segment_derived_desc,
  CASE
    WHEN ((IFNULL(week.product_sub_segment_derived_desc, 'TestNull') = IFNULL( shared.product_sub_segment_derived_desc, 'TestNull')) ) THEN ' Matched '
  ELSE
  CONCAT('UNMATCHED: Proc 2 Value:   ', COALESCE(week.product_sub_segment_derived_desc,
      '-Null'), '   -- Hadoop Value:   ', COALESCE(shared.product_sub_segment_derived_desc,
      '-Null'))
END
  product_sub_segment_derived_desc_Differences,
  week.report_fg proc2_report_fg,
  shared.report_fg Hadoop_report_fg,
  CASE
    WHEN ((IFNULL(week.report_fg, 'TestNull') = IFNULL( shared.report_fg, 'TestNull')) ) THEN ' Matched '
  ELSE
  CONCAT('UNMATCHED: Proc 2 Value:   ', COALESCE(week.report_fg,
      '-Null'), '   -- Hadoop Value:   ', COALESCE(shared.report_fg,
      '-Null'))
END
  report_fg_Differences,
  week.resolved_brand proc2_resolved_brand,
  shared.resolved_brand Hadoop_resolved_brand,
  CASE
    WHEN ((IFNULL(week.resolved_brand, 'TestNull') = IFNULL( shared.resolved_brand, 'TestNull')) ) THEN ' Matched '
  ELSE
  CONCAT('UNMATCHED: Proc 2 Value:   ', COALESCE(week.resolved_brand,
      '-Null'), '   -- Hadoop Value:   ', COALESCE(shared.resolved_brand,
      '-Null'))
END
  resolved_brand_Differences,
  week.resolved_category proc2_resolved_category,
  shared.resolved_category Hadoop_resolved_category,
  CASE
    WHEN ((IFNULL(week.resolved_category, 'TestNull') = IFNULL( shared.resolved_category, 'TestNull')) ) THEN ' Matched '
  ELSE
  CONCAT('UNMATCHED: Proc 2 Value:   ', COALESCE(week.resolved_category,
      '-Null'), '   -- Hadoop Value:   ', COALESCE(shared.resolved_category,
      '-Null'))
END
  resolved_category_Differences,
  week.resolved_product_name proc2_resolved_product_name,
  shared.resolved_product_name Hadoop_resolved_product_name,
  CASE
    WHEN ((IFNULL(week.resolved_product_name, 'TestNull') = IFNULL( shared.resolved_product_name, 'TestNull')) ) THEN ' Matched '
  ELSE
  CONCAT('UNMATCHED: Proc 2 Value:   ', COALESCE(week.resolved_product_name,
      '-Null'), '   -- Hadoop Value:   ', COALESCE(shared.resolved_product_name,
      '-Null'))
END
  resolved_product_name_Differences,
  week.retailer proc2_retailer,
  shared.retailer Hadoop_retailer,
  CASE
    WHEN ((IFNULL(week.retailer, 'TestNull') = IFNULL( shared.retailer, 'TestNull')) ) THEN ' Matched '
  ELSE
  CONCAT('UNMATCHED: Proc 2 Value:   ', COALESCE(week.retailer,
      '-Null'), '   -- Hadoop Value:   ', COALESCE(shared.retailer,
      '-Null'))
END
  retailer_Differences,
  week.rolling_13_by_customer_fg proc2_rolling_13_by_customer_fg,
  shared.rolling_13_by_customer_fg Hadoop_rolling_13_by_customer_fg,
  CASE
    WHEN ((IFNULL(week.rolling_13_by_customer_fg, 'TestNull') = IFNULL( shared.rolling_13_by_customer_fg, 'TestNull')) ) THEN ' Matched '
  ELSE
  CONCAT('UNMATCHED: Proc 2 Value:   ', COALESCE(week.rolling_13_by_customer_fg,
      '-Null'), '   -- Hadoop Value:   ', COALESCE(shared.rolling_13_by_customer_fg,
      '-Null'))
END
  rolling_13_by_customer_fg_Differences,
  week.rolling_26_by_customer_fg proc2_rolling_26_by_customer_fg,
  shared.rolling_26_by_customer_fg Hadoop_rolling_26_by_customer_fg,
  CASE
    WHEN ((IFNULL(week.rolling_26_by_customer_fg, 'TestNull') = IFNULL( shared.rolling_26_by_customer_fg, 'TestNull')) ) THEN ' Matched '
  ELSE
  CONCAT('UNMATCHED: Proc 2 Value:   ', COALESCE(week.rolling_26_by_customer_fg,
      '-Null'), '   -- Hadoop Value:   ', COALESCE(shared.rolling_26_by_customer_fg,
      '-Null'))
END
  rolling_26_by_customer_fg_Differences,
  week.rolling_52_by_customer_fg proc2_rolling_52_by_customer_fg,
  shared.rolling_52_by_customer_fg Hadoop_rolling_52_by_customer_fg,
  CASE
    WHEN ((IFNULL(week.rolling_52_by_customer_fg, 'TestNull') = IFNULL( shared.rolling_52_by_customer_fg, 'TestNull')) ) THEN ' Matched '
  ELSE
  CONCAT('UNMATCHED: Proc 2 Value:   ', COALESCE(week.rolling_52_by_customer_fg,
      '-Null'), '   -- Hadoop Value:   ', COALESCE(shared.rolling_52_by_customer_fg,
      '-Null'))
END
  rolling_52_by_customer_fg_Differences,
  week.segment proc2_segment,
  shared.segment Hadoop_segment,
  CASE
    WHEN ((IFNULL(week.segment, 'TestNull') = IFNULL( shared.segment, 'TestNull')) ) THEN ' Matched '
  ELSE
  CONCAT('UNMATCHED: Proc 2 Value:   ', COALESCE(week.segment,
      '-Null'), '   -- Hadoop Value:   ', COALESCE(shared.segment,
      '-Null'))
END
  segment_Differences,
  week.share_category_relevancy_flag proc2_share_category_relevancy_flag,
  shared.share_category_relevancy_flag Hadoop_share_category_relevancy_flag,
  CASE
    WHEN ((IFNULL(week.share_category_relevancy_flag, 'TestNull') = IFNULL( shared.share_category_relevancy_flag, 'TestNull')) ) THEN ' Matched '
  ELSE
  CONCAT('UNMATCHED: Proc 2 Value:   ', COALESCE(week.share_category_relevancy_flag,
      '-Null'), '   -- Hadoop Value:   ', COALESCE(shared.share_category_relevancy_flag,
      '-Null'))
END
  share_category_relevancy_flag_Differences,
  week.sls_hier_accrual_group_desc proc2_sls_hier_accrual_group_desc,
  shared.sls_hier_accrual_group_desc Hadoop_sls_hier_accrual_group_desc,
  CASE
    WHEN ((IFNULL(week.sls_hier_accrual_group_desc, 'TestNull') = IFNULL( shared.sls_hier_accrual_group_desc, 'TestNull')) ) THEN ' Matched '
  ELSE
  CONCAT('UNMATCHED: Proc 2 Value:   ', COALESCE(week.sls_hier_accrual_group_desc,
      '-Null'), '   -- Hadoop Value:   ', COALESCE(shared.sls_hier_accrual_group_desc,
      '-Null'))
END
  sls_hier_accrual_group_desc_Differences,
  week.sls_hier_category_desc proc2_sls_hier_category_desc,
  shared.sls_hier_category_desc Hadoop_sls_hier_category_desc,
  CASE
    WHEN ((IFNULL(week.sls_hier_category_desc, 'TestNull') = IFNULL( shared.sls_hier_category_desc, 'TestNull')) ) THEN ' Matched '
  ELSE
  CONCAT('UNMATCHED: Proc 2 Value:   ', COALESCE(week.sls_hier_category_desc,
      '-Null'), '   -- Hadoop Value:   ', COALESCE(shared.sls_hier_category_desc,
      '-Null'))
END
  sls_hier_category_desc_Differences,
  week.sls_hier_division_desc proc2_sls_hier_division_desc,
  shared.sls_hier_division_desc Hadoop_sls_hier_division_desc,
  CASE
    WHEN ((IFNULL(week.sls_hier_division_desc, 'TestNull') = IFNULL( shared.sls_hier_division_desc, 'TestNull')) ) THEN ' Matched '
  ELSE
  CONCAT('UNMATCHED: Proc 2 Value:   ', COALESCE(week.sls_hier_division_desc,
      '-Null'), '   -- Hadoop Value:   ', COALESCE(shared.sls_hier_division_desc,
      '-Null'))
END
  sls_hier_division_desc_Differences,
  week.sls_hier_ppg_desc proc2_sls_hier_ppg_desc,
  shared.sls_hier_ppg_desc Hadoop_sls_hier_ppg_desc,
  CASE
    WHEN ((IFNULL(week.sls_hier_ppg_desc, 'TestNull') = IFNULL( shared.sls_hier_ppg_desc, 'TestNull')) ) THEN ' Matched '
  ELSE
  CONCAT('UNMATCHED: Proc 2 Value:   ', COALESCE(week.sls_hier_ppg_desc,
      '-Null'), '   -- Hadoop Value:   ', COALESCE(shared.sls_hier_ppg_desc,
      '-Null'))
END
  sls_hier_ppg_desc_Differences,
  week.sls_hier_sub_accrual_desc proc2_sls_hier_sub_accrual_desc,
  shared.sls_hier_sub_accrual_desc Hadoop_sls_hier_sub_accrual_desc,
  CASE
    WHEN ((IFNULL(week.sls_hier_sub_accrual_desc, 'TestNull') = IFNULL( shared.sls_hier_sub_accrual_desc, 'TestNull')) ) THEN ' Matched '
  ELSE
  CONCAT('UNMATCHED: Proc 2 Value:   ', COALESCE(week.sls_hier_sub_accrual_desc,
      '-Null'), '   -- Hadoop Value:   ', COALESCE(shared.sls_hier_sub_accrual_desc,
      '-Null'))
END
  sls_hier_sub_accrual_desc_Differences,
  week.sls_hier_sub_category_desc proc2_sls_hier_sub_category_desc,
  shared.sls_hier_sub_category_desc Hadoop_sls_hier_sub_category_desc,
  CASE
    WHEN ((IFNULL(week.sls_hier_sub_category_desc, 'TestNull') = IFNULL( shared.sls_hier_sub_category_desc, 'TestNull')) ) THEN ' Matched '
  ELSE
  CONCAT('UNMATCHED: Proc 2 Value:   ', COALESCE(week.sls_hier_sub_category_desc,
      '-Null'), '   -- Hadoop Value:   ', COALESCE(shared.sls_hier_sub_category_desc,
      '-Null'))
END
  sls_hier_sub_category_desc_Differences,
  week.standard_currency_code proc2_standard_currency_code,
  shared.standard_currency_code Hadoop_standard_currency_code,
  CASE
    WHEN ((IFNULL(week.standard_currency_code, 'TestNull') = IFNULL( shared.standard_currency_code, 'TestNull')) ) THEN ' Matched '
  ELSE
  CONCAT('UNMATCHED: Proc 2 Value:   ', COALESCE(week.standard_currency_code,
      '-Null'), '   -- Hadoop Value:   ', COALESCE(shared.standard_currency_code,
      '-Null'))
END
  standard_currency_code_Differences,
  week.standard_currency_symbol proc2_standard_currency_symbol,
  shared.standard_currency_symbol Hadoop_standard_currency_symbol,
  CASE
    WHEN ((IFNULL(week.standard_currency_symbol, 'TestNull') = IFNULL( shared.standard_currency_symbol, 'TestNull')) ) THEN ' Matched '
  ELSE
  CONCAT('UNMATCHED: Proc 2 Value:   ', COALESCE(week.standard_currency_symbol,
      '-Null'), '   -- Hadoop Value:   ', COALESCE(shared.standard_currency_symbol,
      '-Null'))
END
  standard_currency_symbol_Differences,
  week.ty_sales_eqc_units proc2_ty_sales_eqc_units,
  shared.ty_sales_eqc_units Hadoop_ty_sales_eqc_units,
  CASE
    WHEN ((IFNULL(week.ty_sales_eqc_units, -99999) = IFNULL( shared.ty_sales_eqc_units, -99999)) ) THEN 'Matched '
  ELSE
  CONCAT('UNMATCHED: Proc 2 col Value ', COALESCE(week.ty_sales_eqc_units,
      -99999), ' Hadoop Value ', COALESCE(shared.ty_sales_eqc_units,
      -99999))
END
  ty_sales_eqc_units_Differences,
  week.ty_sales_units proc2_ty_sales_units,
  shared.ty_sales_units Hadoop_ty_sales_units,
  CASE
    WHEN ((IFNULL(week.ty_sales_units, -99999) = IFNULL( shared.ty_sales_units, -99999)) ) THEN ' Matched '
  ELSE
  CONCAT('UNMATCHED: Proc 2 Value:   ', COALESCE(week.ty_sales_units,
      -99999), '   -- Hadoop Value:   ', COALESCE(shared.ty_sales_units,
      -99999))
END
  ty_sales_units_Differences,
  week.ty_sales_units proc2_ty_sales_value,
  shared.ty_sales_units Hadoop_ty_sales_value,
  CASE
    WHEN ((IFNULL(week.ty_sales_value, -99999.99) = IFNULL( shared.ty_sales_value, -99999.99)) ) THEN 'Matched '
  ELSE
  CONCAT('UNMATCHED: Proc 2 col Value ', COALESCE(week.ty_sales_value,
      -99999.99), ' Hadoop Value ', COALESCE(shared.ty_sales_value,
      -99999.99))
END
  ty_sales_value_Differences,
  week.ty_sales_value_usd proc2_ty_sales_value_usd,
  shared.ty_sales_value_usd Hadoop_ty_sales_value_usd,
  CASE
    WHEN ((IFNULL(week.ty_sales_value_usd, -99999.99) = IFNULL( shared.ty_sales_value_usd, -99999.99)) ) THEN 'Matched '
  ELSE
  CONCAT('UNMATCHED: Proc 2 col Value ', COALESCE(week.ty_sales_value_usd,
      -99999.99), ' Hadoop Value ', COALESCE(shared.ty_sales_value_usd,
      -99999.99))
END
  ty_sales_value_usd_Differences,
  week.xref_brand proc2_xref_brand,
  shared.xref_brand Hadoop_xref_brand,
  CASE
    WHEN ((IFNULL(week.xref_brand, 'TestNull') = IFNULL( shared.xref_brand, 'TestNull')) ) THEN ' Matched '
  ELSE
  CONCAT('UNMATCHED: Proc 2 Value:   ', COALESCE(week.xref_brand,
      '-Null'), '   -- Hadoop Value:   ', COALESCE(shared.xref_brand,
      '-Null'))
END
  xref_brand_Differences,
  week.xref_sub_brand proc2_xref_sub_brand,
  shared.xref_sub_brand Hadoop_xref_sub_brand,
  CASE
    WHEN ((IFNULL(week.xref_sub_brand, 'TestNull') = IFNULL( shared.xref_sub_brand, 'TestNull')) ) THEN ' Matched '
  ELSE
  CONCAT('UNMATCHED: Proc 2 Value:   ', COALESCE(week.xref_sub_brand,
      '-Null'), '   -- Hadoop Value:   ', COALESCE(shared.xref_sub_brand,
      '-Null'))
END
  xref_sub_brand_Differences,
  week.zone_hierarchy proc2_zone_hierarchy,
  shared.zone_hierarchy Hadoop_zone_hierarchy,
  CASE
    WHEN ((IFNULL(week.zone_hierarchy, 'TestNull') = IFNULL( shared.zone_hierarchy, 'TestNull')) ) THEN ' Matched '
  ELSE
  CONCAT('UNMATCHED: Proc 2 Value:   ', COALESCE(week.zone_hierarchy,
      '-Null'), '   -- Hadoop Value:   ', COALESCE(shared.zone_hierarchy,
      '-Null'))
END
  zone_hierarchy_Differences
FROM
  `""",bq_project_name,""".""",bq_processed_dataset_name,""".""",bq_table_name,"""` week
JOIN (
  SELECT
    *
  FROM
    `""",bq_edw_project_name,""".""",bq_gss_dataset_name,""".ecom_global_mba_sales_and_share_validated`
  WHERE
    customer_name = '""",customer_name,"""'
    AND fiscal_year_week_nbr >= CAST('""",min_fiscal_year_week_nbr,"""' AS INT64)
    AND fiscal_year_week_nbr <= CAST('""",max_fiscal_year_week_nbr,"""' AS INT64)) shared
ON
  COALESCE(week.upc,
    '')= COALESCE(shared.upc,
    '' )
  AND week.fiscal_year_week_nbr = shared.fiscal_year_week_nbr
  AND COALESCE(week.source_item_name,
    '') = COALESCE(shared.source_item_name,
    '')
  AND COALESCE(week.manufacturer,
    '') = COALESCE(shared.manufacturer,
    '')
  AND COALESCE(week.source_item_code,
    '') = COALESCE(shared.source_item_code,
    '')
  AND COALESCE(week.customer_account,
    '') = COALESCE(shared.customer_account,
    '')
  AND COALESCE(week.resolved_category,
    '') = COALESCE(shared.resolved_category,
    '')
  AND COALESCE(week.global_category_parent,
    '') = COALESCE(shared.global_category_parent,
    '')
  AND COALESCE(week.resolved_brand,
    '') = COALESCE(shared.resolved_brand,
    '')
  AND COALESCE(week.zone_hierarchy,
    '') = COALESCE(shared.zone_hierarchy,
    ''))
        """   );

    EXECUTE IMMEDIATE 
CONCAT(
    """INSERT INTO `""",bq_project_name,""".""",bq_transient_dataset_name,""".""",target_test_table,"""`""",
    query_to_match_data,
    """
    select upc,fiscal_year_week_nbr,source_item_name,manufacturer,source_item_code,customer_account,resolved_category,global_category_parent,resolved_brand,zone_hierarchy,'upc' as column_name,CAST(proc2_upc AS STRING), CAST(Hadoop_upc AS STRING) from temp where upc_Differences like '%UNMATCHED%' UNION ALL
select upc,fiscal_year_week_nbr,source_item_name,manufacturer,source_item_code,customer_account,resolved_category,global_category_parent,resolved_brand,zone_hierarchy,'source_item_name' as column_name,CAST(proc2_source_item_name AS STRING), CAST(Hadoop_source_item_name AS STRING) from temp where source_item_name_Differences like '%UNMATCHED%' UNION ALL
select upc,fiscal_year_week_nbr,source_item_name,manufacturer,source_item_code,customer_account,resolved_category,global_category_parent,resolved_brand,zone_hierarchy,'source_item_code' as column_name,CAST(proc2_source_item_code AS STRING), CAST(Hadoop_source_item_code AS STRING) from temp where source_item_code_Differences like '%UNMATCHED%' UNION ALL
select upc,fiscal_year_week_nbr,source_item_name,manufacturer,source_item_code,customer_account,resolved_category,global_category_parent,resolved_brand,zone_hierarchy,'country' as column_name,CAST(proc2_country AS STRING), CAST(Hadoop_country AS STRING) from temp where country_Differences like '%UNMATCHED%' UNION ALL
select upc,fiscal_year_week_nbr,source_item_name,manufacturer,source_item_code,customer_account,resolved_category,global_category_parent,resolved_brand,zone_hierarchy,'segment' as column_name,CAST(proc2_segment AS STRING), CAST(Hadoop_segment AS STRING) from temp where segment_Differences like '%UNMATCHED%' UNION ALL
select upc,fiscal_year_week_nbr,source_item_name,manufacturer,source_item_code,customer_account,resolved_category,global_category_parent,resolved_brand,zone_hierarchy,'channel' as column_name,CAST(proc2_channel AS STRING), CAST(Hadoop_channel AS STRING) from temp where channel_Differences like '%UNMATCHED%' UNION ALL
select upc,fiscal_year_week_nbr,source_item_name,manufacturer,source_item_code,customer_account,resolved_category,global_category_parent,resolved_brand,zone_hierarchy,'customer_share_flag' as column_name,CAST(proc2_customer_share_flag AS STRING), CAST(Hadoop_customer_share_flag AS STRING) from temp where customer_share_flag_Differences like '%UNMATCHED%' UNION ALL
select upc,fiscal_year_week_nbr,source_item_name,manufacturer,source_item_code,customer_account,resolved_category,global_category_parent,resolved_brand,zone_hierarchy,'standard_currency_symbol ' as column_name,CAST(proc2_standard_currency_symbol  AS STRING), CAST(Hadoop_standard_currency_symbol  AS STRING) from temp where standard_currency_symbol_Differences like '%UNMATCHED%' UNION ALL
select upc,fiscal_year_week_nbr,source_item_name,manufacturer,source_item_code,customer_account,resolved_category,global_category_parent,resolved_brand,zone_hierarchy,'standard_currency_code ' as column_name,CAST(proc2_standard_currency_code  AS STRING), CAST(Hadoop_standard_currency_code  AS STRING) from temp where standard_currency_code_Differences like '%UNMATCHED%' UNION ALL
select upc,fiscal_year_week_nbr,source_item_name,manufacturer,source_item_code,customer_account,resolved_category,global_category_parent,resolved_brand,zone_hierarchy,'customer_desc ' as column_name,CAST(proc2_customer_desc  AS STRING), CAST(Hadoop_customer_desc  AS STRING) from temp where customer_desc_Differences like '%UNMATCHED%' UNION ALL
select upc,fiscal_year_week_nbr,source_item_name,manufacturer,source_item_code,customer_account,resolved_category,global_category_parent,resolved_brand,zone_hierarchy,'retailer ' as column_name,CAST(proc2_retailer  AS STRING), CAST(Hadoop_retailer  AS STRING) from temp where retailer_Differences like '%UNMATCHED%' UNION ALL
select upc,fiscal_year_week_nbr,source_item_name,manufacturer,source_item_code,customer_account,resolved_category,global_category_parent,resolved_brand,zone_hierarchy,'grain ' as column_name,CAST(proc2_grain  AS STRING), CAST(Hadoop_grain  AS STRING) from temp where grain_Differences like '%UNMATCHED%' UNION ALL
select upc,fiscal_year_week_nbr,source_item_name,manufacturer,source_item_code,customer_account,resolved_category,global_category_parent,resolved_brand,zone_hierarchy,'report_fg ' as column_name,CAST(proc2_report_fg  AS STRING), CAST(Hadoop_report_fg  AS STRING) from temp where report_fg_Differences like '%UNMATCHED%' UNION ALL
select upc,fiscal_year_week_nbr,source_item_name,manufacturer,source_item_code,customer_account,resolved_category,global_category_parent,resolved_brand,zone_hierarchy,'notes ' as column_name,CAST(proc2_notes  AS STRING), CAST(Hadoop_notes  AS STRING) from temp where notes_Differences like '%UNMATCHED%' UNION ALL
select upc,fiscal_year_week_nbr,source_item_name,manufacturer,source_item_code,customer_account,resolved_category,global_category_parent,resolved_brand,zone_hierarchy,'customer_parent ' as column_name,CAST(proc2_customer_parent  AS STRING), CAST(Hadoop_customer_parent  AS STRING) from temp where customer_parent_Differences like '%UNMATCHED%' UNION ALL
select upc,fiscal_year_week_nbr,source_item_name,manufacturer,source_item_code,customer_account,resolved_category,global_category_parent,resolved_brand,zone_hierarchy,'customer_account ' as column_name,CAST(proc2_customer_account  AS STRING), CAST(Hadoop_customer_account  AS STRING) from temp where customer_account_Differences like '%UNMATCHED%' UNION ALL
select upc,fiscal_year_week_nbr,source_item_name,manufacturer,source_item_code,customer_account,resolved_category,global_category_parent,resolved_brand,zone_hierarchy,'global_category_parent ' as column_name,CAST(proc2_global_category_parent  AS STRING), CAST(Hadoop_global_category_parent  AS STRING) from temp where global_category_parent_Differences like '%UNMATCHED%' UNION ALL
select upc,fiscal_year_week_nbr,source_item_name,manufacturer,source_item_code,customer_account,resolved_category,global_category_parent,resolved_brand,zone_hierarchy,'zone_hierarchy ' as column_name,CAST(proc2_zone_hierarchy  AS STRING), CAST(Hadoop_zone_hierarchy  AS STRING) from temp where zone_hierarchy_Differences like '%UNMATCHED%' UNION ALL
select upc,fiscal_year_week_nbr,source_item_name,manufacturer,source_item_code,customer_account,resolved_category,global_category_parent,resolved_brand,zone_hierarchy,'customer_sales_flag ' as column_name,CAST(proc2_customer_sales_flag  AS STRING), CAST(Hadoop_customer_sales_flag  AS STRING) from temp where customer_sales_flag_Differences like '%UNMATCHED%' UNION ALL
select upc,fiscal_year_week_nbr,source_item_name,manufacturer,source_item_code,customer_account,resolved_category,global_category_parent,resolved_brand,zone_hierarchy,'customer_name ' as column_name,CAST(proc2_customer_name  AS STRING), CAST(Hadoop_customer_name  AS STRING) from temp where customer_name_Differences like '%UNMATCHED%' UNION ALL
select upc,fiscal_year_week_nbr,source_item_name,manufacturer,source_item_code,customer_account,resolved_category,global_category_parent,resolved_brand,zone_hierarchy,'currency_code ' as column_name,CAST(proc2_currency_code  AS STRING), CAST(Hadoop_currency_code  AS STRING) from temp where currency_code_Differences like '%UNMATCHED%' UNION ALL
select upc,fiscal_year_week_nbr,source_item_name,manufacturer,source_item_code,customer_account,resolved_category,global_category_parent,resolved_brand,zone_hierarchy,'currency_symbol ' as column_name,CAST(proc2_currency_symbol  AS STRING), CAST(Hadoop_currency_symbol  AS STRING) from temp where currency_symbol_Differences like '%UNMATCHED%' 
""");

EXECUTE IMMEDIATE 
CONCAT(
    """INSERT INTO `""",bq_project_name,""".""",bq_transient_dataset_name,""".""",target_test_table,"""`""",
    query_to_match_data,
    """
    select upc,fiscal_year_week_nbr,source_item_name,manufacturer,source_item_code,customer_account,resolved_category,global_category_parent,resolved_brand,zone_hierarchy,'ean_upc_cd' as column_name,CAST(proc2_ean_upc_cd AS STRING), CAST(Hadoop_ean_upc_cd AS STRING) from temp where ean_upc_cd_Differences like '%UNMATCHED%' UNION ALL
select upc,fiscal_year_week_nbr,source_item_name,manufacturer,source_item_code,customer_account,resolved_category,global_category_parent,resolved_brand,zone_hierarchy,'base_product_cd' as column_name,CAST(proc2_base_product_cd AS STRING), CAST(Hadoop_base_product_cd AS STRING) from temp where base_product_cd_Differences like '%UNMATCHED%' UNION ALL
select upc,fiscal_year_week_nbr,source_item_name,manufacturer,source_item_code,customer_account,resolved_category,global_category_parent,resolved_brand,zone_hierarchy,'base_product_desc' as column_name,CAST(proc2_base_product_desc AS STRING), CAST(Hadoop_base_product_desc AS STRING) from temp where base_product_desc_Differences like '%UNMATCHED%' UNION ALL
select upc,fiscal_year_week_nbr,source_item_name,manufacturer,source_item_code,customer_account,resolved_category,global_category_parent,resolved_brand,zone_hierarchy,'material_cd' as column_name,CAST(proc2_material_cd AS STRING), CAST(Hadoop_material_cd AS STRING) from temp where material_cd_Differences like '%UNMATCHED%' UNION ALL
select upc,fiscal_year_week_nbr,source_item_name,manufacturer,source_item_code,customer_account,resolved_category,global_category_parent,resolved_brand,zone_hierarchy,'material_short_desc' as column_name,CAST(proc2_material_short_desc AS STRING), CAST(Hadoop_material_short_desc AS STRING) from temp where material_short_desc_Differences like '%UNMATCHED%' UNION ALL
select upc,fiscal_year_week_nbr,source_item_name,manufacturer,source_item_code,customer_account,resolved_category,global_category_parent,resolved_brand,zone_hierarchy,'material_nbr' as column_name,CAST(proc2_material_nbr AS STRING), CAST(Hadoop_material_nbr AS STRING) from temp where material_nbr_Differences like '%UNMATCHED%' UNION ALL
select upc,fiscal_year_week_nbr,source_item_name,manufacturer,source_item_code,customer_account,resolved_category,global_category_parent,resolved_brand,zone_hierarchy,'sls_hier_division_desc' as column_name,CAST(proc2_sls_hier_division_desc AS STRING), CAST(Hadoop_sls_hier_division_desc AS STRING) from temp where sls_hier_division_desc_Differences like '%UNMATCHED%' UNION ALL
select upc,fiscal_year_week_nbr,source_item_name,manufacturer,source_item_code,customer_account,resolved_category,global_category_parent,resolved_brand,zone_hierarchy,'sls_hier_category_desc' as column_name,CAST(proc2_sls_hier_category_desc AS STRING), CAST(Hadoop_sls_hier_category_desc AS STRING) from temp where sls_hier_category_desc_Differences like '%UNMATCHED%' UNION ALL
select upc,fiscal_year_week_nbr,source_item_name,manufacturer,source_item_code,customer_account,resolved_category,global_category_parent,resolved_brand,zone_hierarchy,'sls_hier_sub_category_desc' as column_name,CAST(proc2_sls_hier_sub_category_desc AS STRING), CAST(Hadoop_sls_hier_sub_category_desc AS STRING) from temp where sls_hier_sub_category_desc_Differences like '%UNMATCHED%' UNION ALL
select upc,fiscal_year_week_nbr,source_item_name,manufacturer,source_item_code,customer_account,resolved_category,global_category_parent,resolved_brand,zone_hierarchy,'sls_hier_accrual_group_desc' as column_name,CAST(proc2_sls_hier_accrual_group_desc AS STRING), CAST(Hadoop_sls_hier_accrual_group_desc AS STRING) from temp where sls_hier_accrual_group_desc_Differences like '%UNMATCHED%' UNION ALL
select upc,fiscal_year_week_nbr,source_item_name,manufacturer,source_item_code,customer_account,resolved_category,global_category_parent,resolved_brand,zone_hierarchy,'sls_hier_sub_accrual_desc' as column_name,CAST(proc2_sls_hier_sub_accrual_desc AS STRING), CAST(Hadoop_sls_hier_sub_accrual_desc AS STRING) from temp where sls_hier_sub_accrual_desc_Differences like '%UNMATCHED%' UNION ALL
select upc,fiscal_year_week_nbr,source_item_name,manufacturer,source_item_code,customer_account,resolved_category,global_category_parent,resolved_brand,zone_hierarchy,'sls_hier_ppg_desc' as column_name,CAST(proc2_sls_hier_ppg_desc AS STRING), CAST(Hadoop_sls_hier_ppg_desc AS STRING) from temp where sls_hier_ppg_desc_Differences like '%UNMATCHED%' UNION ALL
select upc,fiscal_year_week_nbr,source_item_name,manufacturer,source_item_code,customer_account,resolved_category,global_category_parent,resolved_brand,zone_hierarchy,'gph_hier_top_desc' as column_name,CAST(proc2_gph_hier_top_desc AS STRING), CAST(Hadoop_gph_hier_top_desc AS STRING) from temp where gph_hier_top_desc_Differences like '%UNMATCHED%' UNION ALL
select upc,fiscal_year_week_nbr,source_item_name,manufacturer,source_item_code,customer_account,resolved_category,global_category_parent,resolved_brand,zone_hierarchy,'gph_hier_family_desc' as column_name,CAST(proc2_gph_hier_family_desc AS STRING), CAST(Hadoop_gph_hier_family_desc AS STRING) from temp where gph_hier_family_desc_Differences like '%UNMATCHED%' UNION ALL
select upc,fiscal_year_week_nbr,source_item_name,manufacturer,source_item_code,customer_account,resolved_category,global_category_parent,resolved_brand,zone_hierarchy,'gph_hier_category_desc' as column_name,CAST(proc2_gph_hier_category_desc AS STRING), CAST(Hadoop_gph_hier_category_desc AS STRING) from temp where gph_hier_category_desc_Differences like '%UNMATCHED%' UNION ALL
select upc,fiscal_year_week_nbr,source_item_name,manufacturer,source_item_code,customer_account,resolved_category,global_category_parent,resolved_brand,zone_hierarchy,'gph_hier_flavor_format_desc' as column_name,CAST(proc2_gph_hier_flavor_format_desc AS STRING), CAST(Hadoop_gph_hier_flavor_format_desc AS STRING) from temp where gph_hier_flavor_format_desc_Differences like '%UNMATCHED%' UNION ALL
select upc,fiscal_year_week_nbr,source_item_name,manufacturer,source_item_code,customer_account,resolved_category,global_category_parent,resolved_brand,zone_hierarchy,'gph_hier_package_size_desc' as column_name,CAST(proc2_gph_hier_package_size_desc AS STRING), CAST(Hadoop_gph_hier_package_size_desc AS STRING) from temp where gph_hier_package_size_desc_Differences like '%UNMATCHED%' UNION ALL
select upc,fiscal_year_week_nbr,source_item_name,manufacturer,source_item_code,customer_account,resolved_category,global_category_parent,resolved_brand,zone_hierarchy,'base_uom_to_eqc_fctr' as column_name,CAST(proc2_base_uom_to_eqc_fctr AS STRING), CAST(Hadoop_base_uom_to_eqc_fctr AS STRING) from temp where base_uom_to_eqc_fctr_Differences like '%UNMATCHED%' UNION ALL
select upc,fiscal_year_week_nbr,source_item_name,manufacturer,source_item_code,customer_account,resolved_category,global_category_parent,resolved_brand,zone_hierarchy,'base_uom_to_ecv_fctr' as column_name,CAST(proc2_base_uom_to_ecv_fctr AS STRING), CAST(Hadoop_base_uom_to_ecv_fctr AS STRING) from temp where base_uom_to_ecv_fctr_Differences like '%UNMATCHED%' UNION ALL
select upc,fiscal_year_week_nbr,source_item_name,manufacturer,source_item_code,customer_account,resolved_category,global_category_parent,resolved_brand,zone_hierarchy,'ean_upc_derived_cd' as column_name,CAST(proc2_ean_upc_derived_cd AS STRING), CAST(Hadoop_ean_upc_derived_cd AS STRING) from temp where ean_upc_derived_cd_Differences like '%UNMATCHED%' UNION ALL
select upc,fiscal_year_week_nbr,source_item_name,manufacturer,source_item_code,customer_account,resolved_category,global_category_parent,resolved_brand,zone_hierarchy,'divested_fg' as column_name,CAST(proc2_divested_fg AS STRING), CAST(Hadoop_divested_fg AS STRING) from temp where divested_fg_Differences like '%UNMATCHED%' UNION ALL
select upc,fiscal_year_week_nbr,source_item_name,manufacturer,source_item_code,customer_account,resolved_category,global_category_parent,resolved_brand,zone_hierarchy,'bph20_desc ' as column_name,CAST(proc2_bph20_desc  AS STRING), CAST(Hadoop_bph20_desc  AS STRING) from temp where bph20_desc_Differences like '%UNMATCHED%' UNION ALL
select upc,fiscal_year_week_nbr,source_item_name,manufacturer,source_item_code,customer_account,resolved_category,global_category_parent,resolved_brand,zone_hierarchy,'bph30_desc ' as column_name,CAST(proc2_bph30_desc  AS STRING), CAST(Hadoop_bph30_desc  AS STRING) from temp where bph30_desc_Differences like '%UNMATCHED%' UNION ALL
select upc,fiscal_year_week_nbr,source_item_name,manufacturer,source_item_code,customer_account,resolved_category,global_category_parent,resolved_brand,zone_hierarchy,'bph40_desc ' as column_name,CAST(proc2_bph40_desc  AS STRING), CAST(Hadoop_bph40_desc  AS STRING) from temp where bph40_desc_Differences like '%UNMATCHED%' UNION ALL
select upc,fiscal_year_week_nbr,source_item_name,manufacturer,source_item_code,customer_account,resolved_category,global_category_parent,resolved_brand,zone_hierarchy,'bph50_desc ' as column_name,CAST(proc2_bph50_desc  AS STRING), CAST(Hadoop_bph50_desc  AS STRING) from temp where bph50_desc_Differences like '%UNMATCHED%' UNION ALL
select upc,fiscal_year_week_nbr,source_item_name,manufacturer,source_item_code,customer_account,resolved_category,global_category_parent,resolved_brand,zone_hierarchy,'bph60_desc ' as column_name,CAST(proc2_bph60_desc  AS STRING), CAST(Hadoop_bph60_desc  AS STRING) from temp where bph60_desc_Differences like '%UNMATCHED%' UNION ALL
select upc,fiscal_year_week_nbr,source_item_name,manufacturer,source_item_code,customer_account,resolved_category,global_category_parent,resolved_brand,zone_hierarchy,'bph70_desc ' as column_name,CAST(proc2_bph70_desc  AS STRING), CAST(Hadoop_bph70_desc  AS STRING) from temp where bph70_desc_Differences like '%UNMATCHED%'
""");


EXECUTE IMMEDIATE 
CONCAT(
    """INSERT INTO `""",bq_project_name,""".""",bq_transient_dataset_name,""".""",target_test_table,"""`""",
    query_to_match_data,
    """
    select upc,fiscal_year_week_nbr,source_item_name,manufacturer,source_item_code,customer_account,resolved_category,global_category_parent,resolved_brand,zone_hierarchy,'gmi_category_desc' as column_name,CAST(proc2_gmi_category_desc AS STRING), CAST(Hadoop_gmi_category_desc AS STRING) from temp where gmi_category_desc_Differences like '%UNMATCHED%' UNION ALL
select upc,fiscal_year_week_nbr,source_item_name,manufacturer,source_item_code,customer_account,resolved_category,global_category_parent,resolved_brand,zone_hierarchy,'gmi_sub_category_desc' as column_name,CAST(proc2_gmi_sub_category_desc AS STRING), CAST(Hadoop_gmi_sub_category_desc AS STRING) from temp where gmi_sub_category_desc_Differences like '%UNMATCHED%' UNION ALL
select upc,fiscal_year_week_nbr,source_item_name,manufacturer,source_item_code,customer_account,resolved_category,global_category_parent,resolved_brand,zone_hierarchy,'gmi_segment_desc' as column_name,CAST(proc2_gmi_segment_desc AS STRING), CAST(Hadoop_gmi_segment_desc AS STRING) from temp where gmi_segment_desc_Differences like '%UNMATCHED%' UNION ALL
select upc,fiscal_year_week_nbr,source_item_name,manufacturer,source_item_code,customer_account,resolved_category,global_category_parent,resolved_brand,zone_hierarchy,'gmi_brand_desc' as column_name,CAST(proc2_gmi_brand_desc AS STRING), CAST(Hadoop_gmi_brand_desc AS STRING) from temp where gmi_brand_desc_Differences like '%UNMATCHED%' UNION ALL
select upc,fiscal_year_week_nbr,source_item_name,manufacturer,source_item_code,customer_account,resolved_category,global_category_parent,resolved_brand,zone_hierarchy,'gmi_global_brand_desc' as column_name,CAST(proc2_gmi_global_brand_desc AS STRING), CAST(Hadoop_gmi_global_brand_desc AS STRING) from temp where gmi_global_brand_desc_Differences like '%UNMATCHED%' UNION ALL
select upc,fiscal_year_week_nbr,source_item_name,manufacturer,source_item_code,customer_account,resolved_category,global_category_parent,resolved_brand,zone_hierarchy,'gmi_manufacturer_desc' as column_name,CAST(proc2_gmi_manufacturer_desc AS STRING), CAST(Hadoop_gmi_manufacturer_desc AS STRING) from temp where gmi_manufacturer_desc_Differences like '%UNMATCHED%' UNION ALL
select upc,fiscal_year_week_nbr,source_item_name,manufacturer,source_item_code,customer_account,resolved_category,global_category_parent,resolved_brand,zone_hierarchy,'gmi_global_manufacturer_desc' as column_name,CAST(proc2_gmi_global_manufacturer_desc AS STRING), CAST(Hadoop_gmi_global_manufacturer_desc AS STRING) from temp where gmi_global_manufacturer_desc_Differences like '%UNMATCHED%' UNION ALL
select upc,fiscal_year_week_nbr,source_item_name,manufacturer,source_item_code,customer_account,resolved_category,global_category_parent,resolved_brand,zone_hierarchy,'brand_high_desc' as column_name,CAST(proc2_brand_high_desc AS STRING), CAST(Hadoop_brand_high_desc AS STRING) from temp where brand_high_desc_Differences like '%UNMATCHED%' UNION ALL
select upc,fiscal_year_week_nbr,source_item_name,manufacturer,source_item_code,customer_account,resolved_category,global_category_parent,resolved_brand,zone_hierarchy,'brand_low_desc' as column_name,CAST(proc2_brand_low_desc AS STRING), CAST(Hadoop_brand_low_desc AS STRING) from temp where brand_low_desc_Differences like '%UNMATCHED%' UNION ALL
select upc,fiscal_year_week_nbr,source_item_name,manufacturer,source_item_code,customer_account,resolved_category,global_category_parent,resolved_brand,zone_hierarchy,'gmi_megacategory_desc' as column_name,CAST(proc2_gmi_megacategory_desc AS STRING), CAST(Hadoop_gmi_megacategory_desc AS STRING) from temp where gmi_megacategory_desc_Differences like '%UNMATCHED%' 
""");

EXECUTE IMMEDIATE 
CONCAT(
    """INSERT INTO `""",bq_project_name,""".""",bq_transient_dataset_name,""".""",target_test_table,"""`""",
    query_to_match_data,
    """
    select upc,fiscal_year_week_nbr,source_item_name,manufacturer,source_item_code,customer_account,resolved_category,global_category_parent,resolved_brand,zone_hierarchy,'xref_brand' as column_name,CAST(proc2_xref_brand AS STRING), CAST(Hadoop_xref_brand AS STRING) from temp where xref_brand_Differences like '%UNMATCHED%' UNION ALL
select upc,fiscal_year_week_nbr,source_item_name,manufacturer,source_item_code,customer_account,resolved_category,global_category_parent,resolved_brand,zone_hierarchy,'xref_sub_brand' as column_name,CAST(proc2_xref_sub_brand AS STRING), CAST(Hadoop_xref_sub_brand AS STRING) from temp where xref_sub_brand_Differences like '%UNMATCHED%' UNION ALL
select upc,fiscal_year_week_nbr,source_item_name,manufacturer,source_item_code,customer_account,resolved_category,global_category_parent,resolved_brand,zone_hierarchy,'manufacturer' as column_name,CAST(proc2_manufacturer AS STRING), CAST(Hadoop_manufacturer AS STRING) from temp where manufacturer_Differences like '%UNMATCHED%' UNION ALL
select upc,fiscal_year_week_nbr,source_item_name,manufacturer,source_item_code,customer_account,resolved_category,global_category_parent,resolved_brand,zone_hierarchy,'global_category' as column_name,CAST(proc2_global_category AS STRING), CAST(Hadoop_global_category AS STRING) from temp where global_category_Differences like '%UNMATCHED%' UNION ALL
select upc,fiscal_year_week_nbr,source_item_name,manufacturer,source_item_code,customer_account,resolved_category,global_category_parent,resolved_brand,zone_hierarchy,'global_sub_category' as column_name,CAST(proc2_global_sub_category AS STRING), CAST(Hadoop_global_sub_category AS STRING) from temp where global_sub_category_Differences like '%UNMATCHED%' UNION ALL
select upc,fiscal_year_week_nbr,source_item_name,manufacturer,source_item_code,customer_account,resolved_category,global_category_parent,resolved_brand,zone_hierarchy,'share_category_relevancy_flag' as column_name,CAST(proc2_share_category_relevancy_flag AS STRING), CAST(Hadoop_share_category_relevancy_flag AS STRING) from temp where share_category_relevancy_flag_Differences like '%UNMATCHED%' UNION ALL
select upc,fiscal_year_week_nbr,source_item_name,manufacturer,source_item_code,customer_account,resolved_category,global_category_parent,resolved_brand,zone_hierarchy,'resolved_brand ' as column_name,CAST(proc2_resolved_brand  AS STRING), CAST(Hadoop_resolved_brand  AS STRING) from temp where resolved_brand_Differences like '%UNMATCHED%' UNION ALL
select upc,fiscal_year_week_nbr,source_item_name,manufacturer,source_item_code,customer_account,resolved_category,global_category_parent,resolved_brand,zone_hierarchy,'resolved_category ' as column_name,CAST(proc2_resolved_category  AS STRING), CAST(Hadoop_resolved_category  AS STRING) from temp where resolved_category_Differences like '%UNMATCHED%' UNION ALL
select upc,fiscal_year_week_nbr,source_item_name,manufacturer,source_item_code,customer_account,resolved_category,global_category_parent,resolved_brand,zone_hierarchy,'resolved_product_name ' as column_name,CAST(proc2_resolved_product_name  AS STRING), CAST(Hadoop_resolved_product_name  AS STRING) from temp where resolved_product_name_Differences like '%UNMATCHED%' 
""");

EXECUTE IMMEDIATE 
CONCAT(
    """INSERT INTO `""",bq_project_name,""".""",bq_transient_dataset_name,""".""",target_test_table,"""`""",
    query_to_match_data,
    """
    select upc,fiscal_year_week_nbr,source_item_name,manufacturer,source_item_code,customer_account,resolved_category,global_category_parent,resolved_brand,zone_hierarchy,'ty_sales_eqc_units ' as column_name,CAST(proc2_ty_sales_eqc_units  AS STRING), CAST(Hadoop_ty_sales_eqc_units  AS STRING) from temp where ty_sales_eqc_units_Differences like '%UNMATCHED%' UNION ALL
select upc,fiscal_year_week_nbr,source_item_name,manufacturer,source_item_code,customer_account,resolved_category,global_category_parent,resolved_brand,zone_hierarchy,'ly_sales_eqc_units ' as column_name,CAST(proc2_ly_sales_eqc_units  AS STRING), CAST(Hadoop_ly_sales_eqc_units  AS STRING) from temp where ly_sales_eqc_units_Differences like '%UNMATCHED%' UNION ALL
select upc,fiscal_year_week_nbr,source_item_name,manufacturer,source_item_code,customer_account,resolved_category,global_category_parent,resolved_brand,zone_hierarchy,'change_in_sales_eqc ' as column_name,CAST(proc2_change_in_sales_eqc  AS STRING), CAST(Hadoop_change_in_sales_eqc  AS STRING) from temp where change_in_sales_eqc_Differences like '%UNMATCHED%' UNION ALL
select upc,fiscal_year_week_nbr,source_item_name,manufacturer,source_item_code,customer_account,resolved_category,global_category_parent,resolved_brand,zone_hierarchy,'ty_sales_units ' as column_name,CAST(proc2_ty_sales_units  AS STRING), CAST(Hadoop_ty_sales_units  AS STRING) from temp where ty_sales_units_Differences like '%UNMATCHED%' UNION ALL
select upc,fiscal_year_week_nbr,source_item_name,manufacturer,source_item_code,customer_account,resolved_category,global_category_parent,resolved_brand,zone_hierarchy,'ly_sales_units ' as column_name,CAST(proc2_ly_sales_units  AS STRING), CAST(Hadoop_ly_sales_units  AS STRING) from temp where ly_sales_units_Differences like '%UNMATCHED%' UNION ALL
select upc,fiscal_year_week_nbr,source_item_name,manufacturer,source_item_code,customer_account,resolved_category,global_category_parent,resolved_brand,zone_hierarchy,'change_in_sales_units ' as column_name,CAST(proc2_change_in_sales_units  AS STRING), CAST(Hadoop_change_in_sales_units  AS STRING) from temp where change_in_sales_units_Differences like '%UNMATCHED%' UNION ALL
select upc,fiscal_year_week_nbr,source_item_name,manufacturer,source_item_code,customer_account,resolved_category,global_category_parent,resolved_brand,zone_hierarchy,'ty_sales_value ' as column_name,CAST(proc2_ty_sales_value  AS STRING), CAST(Hadoop_ty_sales_value  AS STRING) from temp where ty_sales_value_Differences like '%UNMATCHED%' UNION ALL
select upc,fiscal_year_week_nbr,source_item_name,manufacturer,source_item_code,customer_account,resolved_category,global_category_parent,resolved_brand,zone_hierarchy,'ly_sales_value ' as column_name,CAST(proc2_ly_sales_value  AS STRING), CAST(Hadoop_ly_sales_value  AS STRING) from temp where ly_sales_value_Differences like '%UNMATCHED%' UNION ALL
select upc,fiscal_year_week_nbr,source_item_name,manufacturer,source_item_code,customer_account,resolved_category,global_category_parent,resolved_brand,zone_hierarchy,'change_in_sales_value ' as column_name,CAST(proc2_change_in_sales_value  AS STRING), CAST(Hadoop_change_in_sales_value  AS STRING) from temp where change_in_sales_value_Differences like '%UNMATCHED%' UNION ALL
select upc,fiscal_year_week_nbr,source_item_name,manufacturer,source_item_code,customer_account,resolved_category,global_category_parent,resolved_brand,zone_hierarchy,'ty_sales_value_usd ' as column_name,CAST(proc2_ty_sales_value_usd  AS STRING), CAST(Hadoop_ty_sales_value_usd  AS STRING) from temp where ty_sales_value_usd_Differences like '%UNMATCHED%' UNION ALL
select upc,fiscal_year_week_nbr,source_item_name,manufacturer,source_item_code,customer_account,resolved_category,global_category_parent,resolved_brand,zone_hierarchy,'ly_sales_value_usd ' as column_name,CAST(proc2_ly_sales_value_usd  AS STRING), CAST(Hadoop_ly_sales_value_usd  AS STRING) from temp where ly_sales_value_usd_Differences like '%UNMATCHED%' UNION ALL
select upc,fiscal_year_week_nbr,source_item_name,manufacturer,source_item_code,customer_account,resolved_category,global_category_parent,resolved_brand,zone_hierarchy,'change_in_sales_value_usd ' as column_name,CAST(proc2_change_in_sales_value_usd  AS STRING), CAST(Hadoop_change_in_sales_value_usd  AS STRING) from temp where change_in_sales_value_usd_Differences like '%UNMATCHED%' 
""");

EXECUTE IMMEDIATE 
CONCAT(
    """INSERT INTO `""",bq_project_name,""".""",bq_transient_dataset_name,""".""",target_test_table,"""`""",
    query_to_match_data,
    """
    select upc,fiscal_year_week_nbr,source_item_name,manufacturer,source_item_code,customer_account,resolved_category,global_category_parent,resolved_brand,zone_hierarchy,'fiscal_month_verbose_tableau_mapping ' as column_name,CAST(proc2_fiscal_month_verbose_tableau_mapping  AS STRING), CAST(Hadoop_fiscal_month_verbose_tableau_mapping  AS STRING) from temp where fiscal_month_verbose_tableau_mapping_Differences like '%UNMATCHED%' UNION ALL
select upc,fiscal_year_week_nbr,source_item_name,manufacturer,source_item_code,customer_account,resolved_category,global_category_parent,resolved_brand,zone_hierarchy,'fiscal_week_begin_dt_tableau_mapping' as column_name,CAST(proc2_fiscal_week_begin_dt_tableau_mapping AS STRING), CAST(Hadoop_fiscal_week_begin_dt_tableau_mapping AS STRING) from temp where fiscal_week_begin_dt_tableau_mapping_Differences like '%UNMATCHED%' UNION ALL
select upc,fiscal_year_week_nbr,source_item_name,manufacturer,source_item_code,customer_account,resolved_category,global_category_parent,resolved_brand,zone_hierarchy,'item_name_with_code_tableau_mapping ' as column_name,CAST(proc2_item_name_with_code_tableau_mapping  AS STRING), CAST(Hadoop_item_name_with_code_tableau_mapping  AS STRING) from temp where item_name_with_code_tableau_mapping_Differences like '%UNMATCHED%' UNION ALL
select upc,fiscal_year_week_nbr,source_item_name,manufacturer,source_item_code,customer_account,resolved_category,global_category_parent,resolved_brand,zone_hierarchy,' manufacturer_brand_tableau_mapping ' as column_name,CAST(proc2_manufacturer_brand_tableau_mapping  AS STRING), CAST(Hadoop_manufacturer_brand_tableau_mapping  AS STRING) from temp where  manufacturer_brand_tableau_mapping_Differences like '%UNMATCHED%' 
""");

EXECUTE IMMEDIATE 
CONCAT(
    """INSERT INTO `""",bq_project_name,""".""",bq_transient_dataset_name,""".""",target_test_table,"""`""",
    query_to_match_data,
    """
    select upc,fiscal_year_week_nbr,source_item_name,manufacturer,source_item_code,customer_account,resolved_category,global_category_parent,resolved_brand,zone_hierarchy,'fiscal_date_customer_max ' as column_name,CAST(proc2_fiscal_date_customer_max  AS STRING), CAST(Hadoop_fiscal_date_customer_max  AS STRING) from temp where fiscal_date_customer_max_Differences like '%UNMATCHED%' UNION ALL
select upc,fiscal_year_week_nbr,source_item_name,manufacturer,source_item_code,customer_account,resolved_category,global_category_parent,resolved_brand,zone_hierarchy,'rolling_13_by_customer_fg ' as column_name,CAST(proc2_rolling_13_by_customer_fg  AS STRING), CAST(Hadoop_rolling_13_by_customer_fg  AS STRING) from temp where rolling_13_by_customer_fg_Differences like '%UNMATCHED%' UNION ALL
select upc,fiscal_year_week_nbr,source_item_name,manufacturer,source_item_code,customer_account,resolved_category,global_category_parent,resolved_brand,zone_hierarchy,'rolling_26_by_customer_fg ' as column_name,CAST(proc2_rolling_26_by_customer_fg  AS STRING), CAST(Hadoop_rolling_26_by_customer_fg  AS STRING) from temp where rolling_26_by_customer_fg_Differences like '%UNMATCHED%' UNION ALL
select upc,fiscal_year_week_nbr,source_item_name,manufacturer,source_item_code,customer_account,resolved_category,global_category_parent,resolved_brand,zone_hierarchy,'rolling_52_by_customer_fg ' as column_name,CAST(proc2_rolling_52_by_customer_fg  AS STRING), CAST(Hadoop_rolling_52_by_customer_fg  AS STRING) from temp where rolling_52_by_customer_fg_Differences like '%UNMATCHED%' UNION ALL
select upc,fiscal_year_week_nbr,source_item_name,manufacturer,source_item_code,customer_account,resolved_category,global_category_parent,resolved_brand,zone_hierarchy,'latest_completed_fiscal_month_customer_fg ' as column_name,CAST(proc2_latest_completed_fiscal_month_customer_fg  AS STRING), CAST(Hadoop_latest_completed_fiscal_month_customer_fg  AS STRING) from temp where latest_completed_fiscal_month_customer_fg_Differences like '%UNMATCHED%' UNION ALL
select upc,fiscal_year_week_nbr,source_item_name,manufacturer,source_item_code,customer_account,resolved_category,global_category_parent,resolved_brand,zone_hierarchy,'latest_completed_fiscal_quarter_customer_fg ' as column_name,CAST(proc2_latest_completed_fiscal_quarter_customer_fg  AS STRING), CAST(Hadoop_latest_completed_fiscal_quarter_customer_fg  AS STRING) from temp where latest_completed_fiscal_quarter_customer_fg_Differences like '%UNMATCHED%' UNION ALL
select upc,fiscal_year_week_nbr,source_item_name,manufacturer,source_item_code,customer_account,resolved_category,global_category_parent,resolved_brand,zone_hierarchy,'latest_completed_fiscal_year_customer_fg ' as column_name,CAST(proc2_latest_completed_fiscal_year_customer_fg  AS STRING), CAST(Hadoop_latest_completed_fiscal_year_customer_fg  AS STRING) from temp where latest_completed_fiscal_year_customer_fg_Differences like '%UNMATCHED%' 
""");

END;
