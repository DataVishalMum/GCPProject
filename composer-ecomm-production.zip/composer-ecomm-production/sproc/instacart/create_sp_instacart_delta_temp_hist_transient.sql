  /* Purpose OF the stored proc : Delta Temp History Table
	History OF Changes : 06/01 first version 
	                     06/24 Added Second history Table 
                       09/03 Removed source_item_name from primary key; Aggregated sales and units from bq_source2_tablename(ecom_instcrt_sls_v) table;
	Author : Aswathi Nambiar 
	
CALL
  transient.sp_instacart_delta_temp_hist (-99,
    'shareddata-prd-cb5872',
	'shareddata-prd-cb5872',
    'ecomm-dlf-dev-01cd47',
	'shared_data_ecom',
	'sales_ecomm_instacart_sales',
    'transient',
    'ecom_instacart_sales_raw_v',
	'ecom_instcrt_sls_v',
	'instacart_delta_temp',
	'INSTACART');

  */
CREATE PROCEDURE IF NOT EXISTS
  transient.sp_instacart_delta_temp_hist ( job_run_id INT64,
    bq_source1_project_name STRING,
	bq_source2_project_name STRING,
	bq_target_project_name string,
    bq_source1_dataset_name STRING,
	bq_source2_dataset_name STRING,
    bq_transient_dataset_name STRING,
    bq_source1_tablename STRING,
	bq_source2_tablename STRING,
    bq_delta_temp_tablename STRING,
    customer_name STRING)
BEGIN
  -- Truncate Delta Temp Table
EXECUTE IMMEDIATE
  CONCAT("""TRUNCATE TABLE  `""",bq_target_project_name,"""`.""",bq_transient_dataset_name,""".""",bq_delta_temp_tablename); 
  /*Insert Details for passed customer into 'instacart_delta_temp' table having ingest date greater than extract_start_date 
from data_extract_config table */
EXECUTE IMMEDIATE
  CONCAT( """insert into  `""",bq_target_project_name,"""`.""",bq_transient_dataset_name,""".""",bq_delta_temp_tablename,"""
( 
WITH
  product_titles AS (
        SELECT
        upc,
        source_item_code,
        MAX(CASE when max_report_date = report_date then source_item_name else null end) as source_item_name
      FROM (
        SELECT
          upc,
          product_id AS source_item_code,
          product_title AS source_item_name,
		  report_date,
          MAX(report_date) over (partition by upc,product_id) as max_report_date
        FROM
        `""",bq_source1_project_name,"""`.""",bq_source1_dataset_name,""".""",bq_source1_tablename,"""
      ) i group by upc,
				source_item_code )
SELECT
  * EXCEPT(rnk_1,hadoop_update_ts)
FROM (
  SELECT
    A.*,
	'History load' original_file_name,
	'01/01/0001' file_dt,
	GENERATE_UUID() rctl_uuid,
	current_timestamp ingest_date,
	'History load' rctl_file_name,
    '""",job_run_id,"""' AS created_by,
    current_datetime AS created_datetime,
    '""",job_run_id,"""' AS modified_by,
    current_datetime AS modified_datetime,
	-- the following ranking is done to avoid duplicates if there are duplicates
	-- for the same vendor file natural key in the raw table replicated from hadoop. 
	-- The data is partitioned on the natural key of the vendor file. 
	-- The data is then ordered descending on pynamic_version_ts which is 
	-- the create timestamp of the record in the raw table.  
	-- Picking rank = 1 will result in the record with latest create timestamp 
	-- to be selected in case duplicate records exist in the raw table 
	-- ***across different create timestamps***.
	
	ROW_NUMBER() over (
							partition by 
										report_date,
										upc,
										source_item_code
							order by 
								hadoop_update_ts desc
						) rnk_1
  FROM (
    SELECT
      'WEEK' AS grain,
      'UNKNOWN' AS retailer,
      '""",customer_name,"""' AS customer_name,
      r.brand,
      r.upc,
      p.source_item_name,
      r.product_id AS source_item_code,
      CAST(r.report_date AS timestamp) AS report_date,
      SUM(CAST(REGEXP_REPLACE(r.sales_dollars, '$', '') AS FLOAT64)) AS ty_sales_value,
      SUM(CAST(CAST(r.sales_units AS NUMERIC) AS INT64)) AS ty_sales_units,
	  hadoop_update_ts
    FROM
      `""",bq_source1_project_name,"""`.""",bq_source1_dataset_name,""".""",bq_source1_tablename,""" r
    JOIN
      product_titles p
    ON
      r.upc = p.upc
      AND r.product_id = p.source_item_code
    GROUP BY
      r.brand,
      r.upc,
      p.source_item_name,
      r.product_id,
      report_date,
      hadoop_update_ts

	  union all

-- union with historical instacart data feed (FTP data feed before monthly files)
	SELECT
	  'WEEK' AS grain,
	  'UNKNOWN' AS retailer,
	  '""",customer_name,"""' AS customer_name,
	  hist.brnd_nm AS brand,
	  hist.upc,
	  hist.itm_desc AS source_item_name,
	  CAST(hist.instcrt_prd_id AS string) AS source_item_code,
	  CAST(hist.dlvr_dt AS timestamp) AS report_date,
	  SUM(hist.fnl_chg_amt) AS ty_sales_value,
	  SUM(hist.ord_itm_pikd_qty) AS ty_sales_units,
	  CAST('2020-08-03' AS timestamp) AS hadoop_update_ts
	FROM
	  `""",bq_source2_project_name,"""`.""",bq_source2_dataset_name,""".""",bq_source2_tablename,""" hist
	WHERE
	  hist.dlvr_dt BETWEEN '2017-02-27'
	  AND '2020-08-02'
  GROUP BY 
	  hist.brnd_nm,
	  hist.upc,
	  hist.itm_desc,
	  hist.instcrt_prd_id,
	  hist.dlvr_dt
  )A )a
WHERE
  rnk_1 = 1  
  )
""") ;
EXCEPTION WHEN ERROR THEN
    SELECT  
	ERROR (
		CONCAT(
    			@@error.message ,' ' ,
    			@@error.statement_text, ' ' ,
    			@@error.formatted_stack_trace ,' '
			)
		)
	;

END;