  /* Purpose OF the stored proc : Exclude Incomplete Weeks 
  History OF Changes : 05/19 
                       07/06 Dim_date change
  first version Author : Aswathi Nambiar
  
CALL
  transient.sp_instacart_complete_weeks_temp (-99,
    'ecomm-dlf-dev-01cd47',
    'transient',
    'instacart_complete_weeks_temp',
    'instacart_processed_zero',
	'edw-qa-c89f9d',
    'enterprise',
	'INSTACART',
	'INSTACART') 
*/
	
CREATE PROCEDURE IF NOT EXISTS
  transient.sp_instacart_complete_weeks_temp ( job_run_id INT64,
    bq_project_name STRING,
    bq_transient_dataset_name STRING,
    bq_target_table_name STRING,
    bq_source_table_name STRING,
	bq_edw_project_name STRING,
	bq_enterprise_dataset_name STRING,
	customer_name STRING,
	feed_name STRING
	)
BEGIN
DECLARE
  fiscal_dt STRING; 

EXECUTE IMMEDIATE
  CONCAT("""
  SELECT
    vendor_file_fiscal_date
  FROM
    `""",bq_project_name,"""`.""",bq_transient_dataset_name,""".gmi_customer_metadata_reference
  WHERE
    feed_name =UPPER('""",feed_name,"""') """) INTO fiscal_dt;
EXECUTE IMMEDIATE
  CONCAT("""TRUNCATE TABLE  `""",bq_project_name,"""`.""",bq_transient_dataset_name,""".""",bq_target_table_name); 
  /*
INSERT only complete weeks data in this temp table */
EXECUTE IMMEDIATE
  CONCAT( """INSERT INTO  `""",bq_project_name,"""`.""",bq_transient_dataset_name,""".""",bq_target_table_name,""" (
WITH
  fiscal_data AS (
-- Joining processed zero with ficsal calendar table to get fiscal_week_begin_dt
  SELECT
    processed_zero.*,
    fiscal_week_begin_dt
  FROM
    `""",bq_project_name,"""`.""",bq_transient_dataset_name,""".""",bq_source_table_name,""" processed_zero
  LEFT JOIN
    `""",bq_edw_project_name,"""`.""",bq_enterprise_dataset_name,""".dim_date f
  ON
    f.fiscal_year_variant_cd = '07'
    AND f.language_cd ='EN'
    AND processed_zero.""",fiscal_dt,""" = CAST(fiscal_dt as timestamp) ),
-- Check if each week has week end date as Sunday
  complete_weeks AS (
  SELECT
    fiscal_week_begin_dt,
    DATE_DIFF(max( """,fiscal_dt,"""),CAST(fiscal_week_begin_dt AS TIMESTAMP), DAY) AS no_of_days_diff
  FROM
    fiscal_data
  GROUP BY
    fiscal_week_begin_dt
  HAVING
    no_of_days_diff = 6)
SELECT
  a.* EXCEPT(created_by,
    created_datetime,
    modified_by,
    modified_datetime,
    fiscal_week_begin_dt),
  '""",job_run_id,"""' AS created_by,
  current_datetime AS created_datetime,
  '""",job_run_id,"""' AS modified_by,
  current_datetime AS modified_datetime
FROM
  fiscal_data a
JOIN
  complete_weeks b
ON
  a.fiscal_week_begin_dt = b.fiscal_week_begin_dt 
 ) """) ;
EXCEPTION WHEN ERROR THEN
    SELECT  
	ERROR (
		CONCAT(
    			@@error.message ,' ' ,
    			@@error.statement_text, ' ' ,
    			@@error.formatted_stack_trace ,' '
			)
		)
	;

END;