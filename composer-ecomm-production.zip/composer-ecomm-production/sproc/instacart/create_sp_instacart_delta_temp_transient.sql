  /* Purpose OF the stored proc : Delta Temp Table
	History OF Changes : 05/18 first version 
	                     06/08 Removed rctl_uuid from group by clause
	                     06/28 Standarizing source_item_name
                       09/03 Removed source_item_name from primary key
	Author : Aswathi Nambiar 
	
CALL
  transient.sp_data_extract_config_insert(-99,
    'ecomm-dlf-dev-01cd47',
    'raw',
    'transient',
    'instacart_sales');
CALL
  transient.sp_instacart_delta_temp(-99,
    'ecomm-dlf-dev-01cd47'
    'raw',
    'transient',
    'instacart_sales',
	'instacart_delta_temp',
	'INSTACART');
CALL
  transient.sp_data_extract_config_update(-99,
    'ecomm-dlf-dev-01cd47',
    'transient',
    'instacart_sales');

  */
CREATE PROCEDURE IF NOT EXISTS
  transient.sp_instacart_delta_temp ( job_run_id INT64,
    bq_project_name STRING,
    bq_raw_dataset_name STRING,
    bq_transient_dataset_name STRING,
    bq_raw_table_name STRING,
    bq_delta_temp_tablename STRING,
    customer_name STRING)
BEGIN
  -- declare variables
DECLARE
  extract_start_date,
  extract_end_date Timestamp;
  -- Get Extract start datetime for incoming table from data_extract_config table
EXECUTE IMMEDIATE
  CONCAT("""select extract_start_datetime from `""",bq_project_name,"""`.""",bq_transient_dataset_name,""".""","""data_extract_config where table_name = '""",bq_raw_table_name,"""' and status = 'running' 
and active_flag = 'Y'""") INTO extract_start_date;
  -- Get Extract end datetime for incoming table from data_extract_config table
EXECUTE IMMEDIATE
  CONCAT("""select extract_end_datetime from `""",bq_project_name,"""`.""",bq_transient_dataset_name,""".""", """data_extract_config where table_name = '""",bq_raw_table_name,"""' and status = 'running'  and active_flag = 'Y'""") INTO extract_end_date;
  -- Truncate Delta Temp Table
EXECUTE IMMEDIATE
  CONCAT("""TRUNCATE TABLE  `""",bq_project_name,"""`.""",bq_transient_dataset_name,""".""",bq_delta_temp_tablename); 
  /*Insert Details for passed customer into 'instacart_delta_temp' table having ingest date greater than extract_start_date 
from data_extract_config table */
EXECUTE IMMEDIATE
  CONCAT( """insert into  `""",bq_project_name,"""`.""",bq_transient_dataset_name,""".""",bq_delta_temp_tablename,"""
( 
WITH
  product_titles AS (
      SELECT
        upc,
        source_item_code,
        MAX(CASE when max_report_date = report_date then source_item_name else null end) as source_item_name
      FROM (
        SELECT
          upc,
          product_id AS source_item_code,
          product_title AS source_item_name,
		  report_date,
          MAX(report_date) over (partition by upc,product_id) as max_report_date
        FROM
          `""",bq_project_name,"""`.""",bq_raw_dataset_name,""".""",bq_raw_table_name,""" 
        WHERE
          ingest_date > '""",extract_start_date,"""'
          AND ingest_date <= '""",extract_end_date,"""'  
         ) i group by upc,
					  source_item_code )
SELECT
  * EXCEPT(rnk_1,
    rnk_2)
FROM (
  SELECT
    A.*,
    '""",job_run_id,"""' AS created_by,
    current_datetime AS created_datetime,
    '""",job_run_id,"""' AS modified_by,
    current_datetime AS modified_datetime,
    DENSE_RANK() OVER (PARTITION BY report_date, upc, source_item_code ORDER BY PARSE_TIMESTAMP("%m-%d-%Y %H:%M:%S", file_dt) DESC ) rnk_1,
    ROW_NUMBER() OVER (PARTITION BY report_date, upc, source_item_code, PARSE_TIMESTAMP("%m-%d-%Y %H:%M:%S", file_dt)
    ORDER BY
      ingest_date DESC ) rnk_2
  FROM (
    SELECT
      'WEEK' AS grain,
      'UNKNOWN' AS retailer,
      '""",customer_name,"""' AS customer_name,
      r.brand,
      r.upc,
      p.source_item_name,
      r.product_id AS source_item_code,
      CAST(r.report_date AS timestamp) AS report_date,
      SUM(CAST(REGEXP_REPLACE(r.sales_dollars, '$', '') AS FLOAT64)) AS ty_sales_value,
      SUM(CAST(CAST(r.sales_units AS NUMERIC)AS INT64)) AS ty_sales_units,
      original_file_name,
      file_dt,
      MAX(CASE
          WHEN r.product_title = p.source_item_name THEN rctl_uuid
        ELSE
        NULL
      END
        ) AS rctl_uuid,
      TIMESTAMP(ingest_date) AS ingest_date,
      rctl_file_name
    FROM
      `""",bq_project_name,"""`.""",bq_raw_dataset_name,""".""",bq_raw_table_name,"""  r
    JOIN
      product_titles p
    ON
      r.upc = p.upc
      AND r.product_id = p.source_item_code
      WHERE ingest_date > '""",extract_start_date,"""'
      AND ingest_date <= '""",extract_end_date,"""' 
    GROUP BY
      r.brand,
      r.upc,
      p.source_item_name,
      r.product_id,
      report_date,
      original_file_name,
      file_dt, 
      ingest_date,
      rctl_file_name )A )a
WHERE
  rnk_1 = 1
  AND rnk_2 = 1
  
  )
""") ;
EXCEPTION WHEN ERROR THEN
    SELECT  
	ERROR (
		CONCAT(
    			@@error.message ,' ' ,
    			@@error.statement_text, ' ' ,
    			@@error.formatted_stack_trace ,' '
			)
		)
	;

END;