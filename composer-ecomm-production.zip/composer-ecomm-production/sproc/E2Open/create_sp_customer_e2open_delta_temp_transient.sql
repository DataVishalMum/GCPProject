/*
Purpose of the stored proc: 
	Delta Data extraction for 'kroger e2open' 
History of Changes:
	05/14/21 – first version
	03/23/22 - Remove unneeded fiscal calendar attributes (Nelson W.)
Author : 
	Shubham Saxena
*/

CREATE OR REPLACE PROCEDURE transient.ecomm_sproc_ana_e2open_delta_temp
( 
	DEST_PROJECT STRING,
	DEST_DATASET STRING,
    SRC_PROJECT STRING,
    INTERMEDIATE_PROJECT STRING,
    SRC_DATASET STRING,
    INTERMEDIATE_DATASET STRING,
	SRC_TABLE STRING,
    DEST_TABLE STRING,
    FEED_NAME STRING
)
OPTIONS(
description = """
How to Call:
	CALL transient.ecomm_sproc_ana_e2open_delta_temp
    (
    'ecomm-dlf-dev-01cd47', --DEST_PROJECT
    'transient',            --DEST_DATASET
    'shareddata-prd-cb5872', --SRC_PROJECT
    'edw-dev-c119a7', --INTERMEDIATE_PROJECT
    'retail_kroger', --SRC_DATASET
    'enterprise',  --INTERMEDIATE_DATASET
    'e2open_storefacts_kroger_us', --SRC_TABLE
    'kroger_e2open_delta_temp' --DEST_TABLE
    'kroger'  --FEED_NAME
    )
"""
)

BEGIN
DECLARE JOB_RUN_ID DEFAULT 999999;
DECLARE BQ_PROJECT_NAME DEFAULT DEST_PROJECT;
DECLARE BQ_TRANSIENT_DATASET_NAME DEFAULT DEST_DATASET;
DECLARE BQ_SHARED_PROJECT_NAME DEFAULT SRC_PROJECT;
DECLARE BQ_EDW_PROJECT_NAME DEFAULT INTERMEDIATE_PROJECT;
DECLARE BQ_RETAILER_DATASET_NAME DEFAULT SRC_DATASET;
DECLARE BQ_ENTERPRISE_DATASET_NAME DEFAULT INTERMEDIATE_DATASET;
DECLARE BQ_SOURCE_TABLE_NAME DEFAULT SRC_TABLE;
DECLARE BQ_TARGET_TABLE_NAME DEFAULT DEST_TABLE;
DECLARE
     EXTRACT_START_DATE
	,EXTRACT_END_DATE Timestamp;

SET FEED_NAME = UPPER(FEED_NAME);

EXECUTE IMMEDIATE CONCAT("""TRUNCATE TABLE `""",BQ_PROJECT_NAME,""".""",BQ_TRANSIENT_DATASET_NAME,""".""",BQ_TARGET_TABLE_NAME,"""`""");

/* Get Extract start datetime for incoming table from data_extract_config table */
EXECUTE IMMEDIATE
  CONCAT("""select extract_start_datetime from `""",BQ_PROJECT_NAME,"""`.""",BQ_TRANSIENT_DATASET_NAME,""".""","""data_extract_config
where table_name = '""",BQ_SOURCE_TABLE_NAME,"""' and status = 'running' 
and active_flag = 'Y'""") INTO EXTRACT_START_DATE;

/* Get Extract end datetime for incoming table from data_extract_config table */
EXECUTE IMMEDIATE
  CONCAT("""select extract_end_datetime from `""",BQ_PROJECT_NAME,"""`.""",BQ_TRANSIENT_DATASET_NAME,""".""", """data_extract_config 
  where table_name = '""",BQ_SOURCE_TABLE_NAME,"""' and status = 'running'  and active_flag = 'Y'""") INTO EXTRACT_END_DATE;

-- Fetch all the delta records from the raw table and required columns from the fiscal calendar and calendar day table.
-- store_number is casted to STRING to accomodate leading zeroes
-- pos_sales are rounded off to 6 decimal digits similar to existing hadoop logic
-- Aggregating the complete data on week level using natural keys - gmi_upc,gmi_upc_desc,store_number,division,fiscal_year_week_nbr

EXECUTE IMMEDIATE 
    CONCAT("""
    INSERT INTO `""",BQ_PROJECT_NAME,""".""",BQ_TRANSIENT_DATASET_NAME,""".""",BQ_TARGET_TABLE_NAME,"""`
    with src_data as (SELECT
  fch.date_sk,
  e2o.gmi_upc,
  e2o.gmi_upc_desc,
  CASE
    WHEN e2o.retailer = 'Walmart' THEN 'WALMART_OPD'
    WHEN e2o.retailer = "Sam's Club" THEN 'SAMS_CLUB'
  ELSE
  UPPER(e2o.retailer)
END
  AS customer_name,
  e2o.division,
  e2o.division_desc,
  e2o.banner,
  CAST(e2o.store_nbr AS string) AS store_number,
  e2o.store_address AS store_street_address,
  e2o.store_city,
  e2o.store_state,
  e2o.store_zip AS store_zipcode,
  e2o.auth_flg,
  e2o.pos_qty pos_qty,
  ROUND(CAST(e2o.pos_sales AS NUMERIC),6) pos_sales,
  e2o.currency_cd,
  CAST(e2o.inventory_on_hand_units AS int64) average_inventory_on_hand_units,
  fch.fiscal_dt,
  fch.fiscal_month_in_year_nbr,
  fch.fiscal_year_nbr,
  fch.fiscal_week_in_year_nbr,
  fch.fiscal_week_begin_dt,
  fch.fiscal_year_week_nbr,
  fch.fiscal_year_month_nbr,
  CAST(""",JOB_RUN_ID,""" AS string) AS created_by,
  current_datetime AS created_datetime,
  CAST(""",JOB_RUN_ID,""" AS string) AS modified_by,
  current_datetime AS modified_datetime

  -- the following ranking is done to avoid duplicates if there are duplicates
	-- for the same vendor natural key in the raw table replicated from hadoop.
	-- The data is partitioned on the natural key of the vendor.
	-- The data is then ordered descending on hadoop_update_ts which is
	-- the create timestamp of the record in the raw table.
	-- Picking rank = 1 will result in the record with latest create timestamp
	-- to be selected in case duplicate records exist in the raw table
	-- ***across different create timestamps***.

	, row_number() over (
							partition by
										e2o.gmi_upc,e2o.gmi_upc_desc,e2o.store_nbr,e2o.division,e2o.fiscal_dt
							order by
							 	gcp_create_ts desc, auth_flg desc, fch.calendar_year_nbr desc
						) rnk_1
  from `""",BQ_SHARED_PROJECT_NAME,""".""",BQ_RETAILER_DATASET_NAME,""".""",BQ_SOURCE_TABLE_NAME,"""` e2o
  left join `""",BQ_EDW_PROJECT_NAME,""".""",BQ_ENTERPRISE_DATASET_NAME,""".dim_date` fch
  on CAST(e2o.fiscal_dt AS DATE) = fch.fiscal_dt
 where e2o.retailer_week_end_dt >= '2018-01-01'
   and fch.language_cd='EN'
   and fch.fiscal_year_variant_cd='07'
   and (e2o.retailer in ('Walmart','Meijer',"Sam's Club")
        or (e2o.retailer = 'Kroger'
            and e2o.store_city is not null
            and e2o.store_state is not null
            and e2o.pos_sales != 0))
	and DATE (gcp_create_ts) > DATE ('""",EXTRACT_START_DATE,"""')
    and DATE (gcp_create_ts) <= DATE ('""",EXTRACT_END_DATE,"""'))
    select * except(rnk_1) from src_data where rnk_1 = 1
""");

EXCEPTION WHEN ERROR THEN
        EXECUTE IMMEDIATE CONCAT(
            """INSERT INTO processed.ecomm_admin_sproc_error_details (
		        SELECT
			        '""",FEED_NAME,"""' AS FEED_NAME,
                    split(split(@@error.formatted_stack_trace,'transient.')[OFFSET (1)],'[')[OFFSET(0)],
			        @@error.statement_text,
			        @@error.message,
			        current_timestamp()
	        );
	    """);

	    SELECT
	        ERROR (
	            CONCAT(
	            		@@error.message ,' ' ,
	            		@@error.statement_text, ' ' ,
	            		@@error.formatted_stack_trace ,' '
	            	)
	        );

END;