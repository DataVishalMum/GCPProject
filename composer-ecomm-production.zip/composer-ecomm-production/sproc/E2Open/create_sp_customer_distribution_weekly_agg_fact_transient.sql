/*
Purpose of the stored proc: 
	Delta Data extraction for 'kroger e2open' 
History of Changes:
	03/28/22 - first version

Author :
	Shubham Saxena
*/

CREATE OR REPLACE PROCEDURE transient.ecomm_sproc_ana_distribution_weekly_agg_fact
(
	DEST_PROJECT STRING,
	DEST_DATASET STRING,
	SRC_TABLE STRING,
    DEST_TABLE STRING,
    FEED_NAME STRING
)
OPTIONS(
description = """
How to Call:
	CALL transient.ecomm_sproc_ana_distribution_weekly_agg_fact
    (
    'ecomm-dlf-dev-01cd47',  --DEST_PROJECT
    'processed',             --DEST_DATASET
    'kroger_e2open_daily_fact',  --SRC_TABLE
    'kroger_e2open_weekly_agg_fact'  --DEST_TABLE
    'kroger'                         --FEED_NAME
    )
"""
)

BEGIN
DECLARE JOB_RUN_ID DEFAULT 999999;
DECLARE BQ_PROJECT_NAME DEFAULT DEST_PROJECT;
DECLARE BQ_PROCESSED_DATASET_NAME DEFAULT DEST_DATASET;
DECLARE RAW_TABLE_NAME DEFAULT SRC_TABLE;
DECLARE TARGET_TABLE_NAME DEFAULT DEST_TABLE;
SET FEED_NAME = UPPER(FEED_NAME);

-- Truncate the target table
EXECUTE IMMEDIATE CONCAT("""TRUNCATE TABLE `""",BQ_PROJECT_NAME,""".""",BQ_PROCESSED_DATASET_NAME,""".""",TARGET_TABLE_NAME,"""`""");

-- Aggregating the complete data on week level using natural keys - gmi_upc,gmi_upc_desc,store_number,division,fiscal_year_week_nbr

EXECUTE IMMEDIATE
    CONCAT("""
    INSERT INTO `""",BQ_PROJECT_NAME,""".""",BQ_PROCESSED_DATASET_NAME,""".""",TARGET_TABLE_NAME,"""`
        with harmonized_data as (
        	select DISTINCT *
        	from
        	`""",BQ_PROJECT_NAME,""".""",BQ_PROCESSED_DATASET_NAME,""".""",RAW_TABLE_NAME,"""`
        	),
        agg_sales as (
            select gmi_upc,
                store_number,
                fiscal_week_begin_dt,
                store_street_address,
                sum(pos_qty) pos_qty,
                sum(pos_sales) pos_sales,
                avg(average_inventory_on_hand_units) average_inventory_on_hand_units,
                if(max(is_authorization) = 1, true, false) as authorization_flg
            from harmonized_data
            group by
                gmi_upc,
                store_number,
                fiscal_week_begin_dt,
                store_street_address
        )
        select * EXCEPT (rn)
        from (
            select *,
                   row_number() over(partition by gmi_upc,store_number,store_street_address,fiscal_week_begin_dt order by fiscal_week_begin_dt desc) as rn
                  ,CAST(""",JOB_RUN_ID,""" AS STRING) AS created_by
                  ,current_datetime AS created_datetime
                  ,CAST(""",JOB_RUN_ID,""" AS STRING) AS modified_by
                  ,current_datetime AS modified_datetime
            from (
                select
                    src.gmi_upc
                    ,src.gmi_upc_desc
                    ,src.customer_name
                    ,src.division
                    ,src.division_desc
                    ,src.banner
                    ,src.store_number
                    ,src.store_street_address
                    ,src.store_city
                    ,src.store_state
                    ,src.store_zipcode
                    ,agg.authorization_flg
                    ,agg.pos_qty
                    ,agg.pos_sales
                    ,src.currency_cd
                    ,cast(round(agg.average_inventory_on_hand_units) AS INT64)
                    ,src.fiscal_month_in_year_nbr
                    ,src.fiscal_year_nbr
                    ,src.fiscal_week_in_year_nbr
                    ,src.fiscal_week_begin_dt
                    ,src.fiscal_year_month_nbr
                    ,src.fiscal_year_week_nbr
                    ,src.source_product_hash
                    ,src.base_product_cd
                    ,src.base_product_desc
                    ,src.material_cd
                    ,src.material_short_desc
                    ,src.material_nbr
                    ,src.ean_upc_cd
                    ,src.sls_hier_division_desc
                    ,src.sls_hier_category_desc
                    ,src.sls_hier_sub_category_desc
                    ,src.sls_hier_ppg_desc
                    ,src.old_base_product_cd
                    ,src.old_base_product_desc
                    ,src.old_material_cd
                    ,src.old_material_short_desc
                    ,src.old_material_nbr
                    ,src.old_ean_upc_cd
                    ,src.old_sls_hier_division_desc
                    ,src.old_sls_hier_category_desc
                    ,src.old_sls_hier_sub_category_desc
                    ,src.old_sls_hier_ppg_desc
                from harmonized_data src
                join agg_sales agg
                    on
                        src.fiscal_week_begin_dt=agg.fiscal_week_begin_dt
                    and src.gmi_upc=agg.gmi_upc
                    and src.store_number=agg.store_number
                    and src.store_street_address=agg.store_street_address
            )q
        )a where a.rn=1
""");


EXCEPTION WHEN ERROR THEN
        EXECUTE IMMEDIATE CONCAT(
            """INSERT INTO processed.ecomm_admin_sproc_error_details (
		        SELECT
			        '""",FEED_NAME,"""' AS FEED_NAME,
                    split(split(@@error.formatted_stack_trace,'transient.')[OFFSET (1)],'[')[OFFSET(0)],
			        @@error.statement_text,
			        @@error.message,
			        current_timestamp()
	        );
	    """);

	    SELECT
	        ERROR (
	            CONCAT(
	            		@@error.message ,' ' ,
	            		@@error.statement_text, ' ' ,
	            		@@error.formatted_stack_trace ,' '
	            	)
	        );

END;