/*
Purpose of the stored proc: 
	Delta Data extraction for 'kroger_delivery_sales' customer
History of Changes:
	28/05 – first version 
Author : 
	Swati Thakur
How to Call:
	CALL
	transient.sp_kroger_delivery_delta_temp_hist
	(
		4208,
		'ecomm-dlf-dev-01cd47',
		'transient',
		'KROGER_DELIVERY',
		'shareddata-prd-cb5872',
		'shared_data_ecom',
		'ecom_kroger_delivery_sales_raw_v'    
	)
*/


CREATE PROCEDURE IF NOT EXISTS transient.sp_kroger_delivery_delta_temp_hist 
( 
	job_run_id INT64,
	bq_project_name string,
	bq_transient_dataset_name string,	
	customer_name string, 
	bq_prod_project_name string,
	bq_prod_dataset_name string,
	raw_table_name string
)
BEGIN
-- declare variables
DECLARE 
	extract_start_date,
	extract_end_date Timestamp;

DECLARE
	sql STRING;

/* Delta Temp Table is Truncate & Load */
EXECUTE IMMEDIATE
CONCAT("""TRUNCATE TABLE  `""" ,bq_project_name,"""`.""",bq_transient_dataset_name,""".""","""kroger_delivery_delta_temp""");



	/*Insert Details for passed customer into 'kroger_delivery_delta_temp'  */

Set sql = concat("""insert into  `""" ,bq_project_name,"""`.""",bq_transient_dataset_name,""".""","""kroger_delivery_delta_temp 
( 
with dr as 
(
	select
	 'WEEK' as grain
	,'Kroger' as retailer  
	, '""",customer_name,"""' AS customer_name
	, split(kd.product,' ')[OFFSET(0)] as UPC
	, substr(kd.product,length(kd.product)*-1+13,length(kd.product)) as product_title	
	, timestamp(parse_date('%m-%d-%Y' ,split(kd.kroger_fiscal_week,' ')[OFFSET(4)]))  as report_date 
	, kd.geography_store_attributes		
	, kd.basket_channel					
	, kd.product			
	, substr(kd.product,length(kd.product)*-1+13,length(kd.product))  AS source_item_name
	, split(kd.product,' ')[OFFSET(0)] AS source_item_code
	, coalesce(cast(kd.dollar_sales_cur as Numeric),0) as ty_sales_value  
	, coalesce(cast(kd.units as INT64),0) as ty_sales_units
	, 'History load' original_file_name
	, '01/01/0001' file_dt
	, current_timestamp ingest_date
	, 'History load' rctl_file_name	
	, GENERATE_UUID() rctl_uuid	
	, '""",job_run_id,"""' created_by 
	, current_datetime created_datetime 
	, '""",job_run_id,"""' modified_by 
	, current_datetime modified_datetime 
	
	-- the following ranking is done to avoid duplicates if there are duplicates
	-- for the same vendor file natural key in the raw table replicated from hadoop. 
	-- The data is partitioned on the natural key of the vendor file. 
	-- The data is then ordered descending on hadoop_update_ts which is 
	-- the create timestamp of the record in the raw table.  
	-- Picking rank = 1 will result in the record with latest create timestamp 
	-- to be selected in case duplicate records exist in the raw table 
	-- ***across different create timestamps***.
	
	, row_number() over (
							partition by 
										product,timestamp(parse_date('%m-%d-%Y' ,split(kd.kroger_fiscal_week,' ')[OFFSET(4)])) 
							order by 
								TIMESTAMP(kd.hadoop_update_ts ) desc
						) rnk_1
	
	
	from `""" ,bq_prod_project_name,"""`.""",bq_prod_dataset_name,""".""",raw_table_name,""" kd 

)
  select
     grain 
	,retailer    
	,customer_name 
	,upc	
	,product_title	
	,report_date	
	,geography_store_attributes	
	,basket_channel	
	,product	
	,source_item_name		
	,source_item_code		  
	,ty_sales_value  
	,ty_sales_units  
	,original_file_name		
	,file_dt		
	,ingest_date  
	,rctl_file_name 
	,rctl_uuid		
	,created_by 
	,created_datetime  
	,modified_by 
	,modified_datetime  
    from
    	dr 
	where 
		rnk_1 = 1 
 )
""");


EXECUTE IMMEDIATE sql;

EXCEPTION WHEN ERROR THEN
    SELECT  
	ERROR (
		CONCAT(
    			@@error.message ,' ' ,
    			@@error.statement_text, ' ' ,
    			@@error.formatted_stack_trace ,' '
			)
		)
	;

END






