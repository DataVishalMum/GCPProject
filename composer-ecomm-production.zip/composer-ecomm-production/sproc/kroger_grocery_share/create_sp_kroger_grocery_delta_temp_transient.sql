/*
Purpose of the stored proc: 
	Delta Data extraction for 'kroger_grocery_share' customer
History of Changes:
	04/16 – first version
  05/10 - Renamed the procedure name and delta_temp table name from kroger_grocery_share to kroger_grocery 
Author : 
	Rakesh Reddy Kalluru
How to Call:
		CALL transient.sp_kroger_grocery_delta_temp
(0, 'ecomm-dlf-dev-01cd47', 'raw', 'transient','processed', 'kroger_grocery_share','kroger_mkt6_share','lkp_kroger_fiscal_calendar');

*/

CREATE PROCEDURE IF NOT EXISTS transient.sp_kroger_grocery_delta_temp(job_run_id INT64, bq_project_name STRING, bq_raw_dataset_name STRING, bq_transient_dataset_name STRING, bq_processed_dataset_name STRING, customer_name STRING, raw_table_name STRING, calendar_table_name STRING)
BEGIN
-- declare variables
DECLARE extract_start_date,extract_end_date Timestamp;
--Stores the logic as a sql.
DECLARE sql STRING;


/* Get Extract start datetime for incoming table from data_extract_config table */
EXECUTE IMMEDIATE
  CONCAT("""select extract_start_datetime from `""",bq_project_name,"""`.""",bq_transient_dataset_name,""".""","""data_extract_config
where table_name = '""",raw_table_name,"""' and status = 'running' 
and active_flag = 'Y'""") INTO extract_start_date;

/* Get Extract end datetime for incoming table from data_extract_config table */
EXECUTE IMMEDIATE
  CONCAT("""select extract_end_datetime from `""",bq_project_name,"""`.""",bq_transient_dataset_name,""".""", """data_extract_config 
  where table_name = '""",raw_table_name,"""' and status = 'running'  and active_flag = 'Y'""") INTO extract_end_date;


EXECUTE IMMEDIATE
CONCAT("""TRUNCATE TABLE  `""" ,bq_project_name,"""`.""",bq_transient_dataset_name,""".""","""kroger_grocery_delta_temp""");

	/*Insert Details for passed customer into 'kroger_grocery_delta_temp' table having ingest date greater than extract_start_date 
from data_extract_config table */
set sql =
CONCAT(
"""insert into `""" ,bq_project_name,"""`.""",bq_transient_dataset_name,""".""","""kroger_grocery_delta_temp 
( 
with final as 
(
 select
  'WEEK' AS grain,
  'Kroger' AS retailer,
  'KROGER_GROCERY_SHARE' AS customer_name,
  parse_timestamp("%m/%d/%Y", cl.gmi_week_start_dt) as gmi_week_start_dt,
  parse_timestamp("%m/%d/%Y", cl.gmi_week_end_dt) as gmi_week_end_dt,
  sh.week_begin_dt,
  sh.period_desc,
  sh.primary_department,
  sh.recap_department,
  sh.department,
  sh.commodity,
  sh.subcommodity,
  sh.parent_owner_desc,
  sh.mfr_desc,
  sh.mfr_cd,
  sh.itm_scn_prc_grp,
  sh.itm_scn_prc_grp_desc,
  CAST(sh.upc AS string) AS upc,
  CAST(sh.upc AS string) AS source_item_code,
  sh.item_description AS source_item_name,
  SAFE_CAST(sh.scanned_retail_dollars_cur AS float64) AS scanned_retail_dollars_cur,
  SAFE_CAST(sh.scanned_movement_cur AS int64) AS scanned_movement_cur,
  SAFE_CAST(sh.gross_margin_dollars_cur AS float64) AS gross_margin_dollars_cur,
  SAFE_CAST(sh.scanned_retail_dollars_pre AS float64) AS scanned_retail_dollars_pre,
  SAFE_CAST(sh.scanned_movement_pre AS int64) AS scanned_movement_pre,
  SAFE_CAST(sh.gross_margin_dollars_pre AS float64) AS gross_margin_dollars_pre,
  SAFE_CAST(sh.clicklist_scanned_retail_dollars_cur AS float64) AS ty_sales_value,
  SAFE_CAST(sh.clicklist_scanned_movement_cur AS int64) AS ty_sales_units,
  SAFE_CAST(sh.clicklist_scanned_lbs_cur AS float64) AS clicklist_scanned_lbs_cur,
  SAFE_CAST(sh.clicklist_gross_margin_dollars_cur AS float64) AS clicklist_gross_margin_dollars_cur,
  SAFE_CAST(sh.clicklist_scanned_retail_dollars_pre AS float64) AS clicklist_scanned_retail_dollars_pre,
  SAFE_CAST(sh.clicklist_scanned_movement_pre AS int64) AS clicklist_scanned_movement_pre,
  SAFE_CAST(sh.clicklist_scanned_lbs_pre AS float64) AS clicklist_scanned_lbs_pre,
  SAFE_CAST(sh.clicklist_gross_margin_dollars_pre AS float64) AS clicklist_gross_margin_dollars_pre,
  INITCAP(REGEXP_REPLACE(SUBSTRING(original_file_name,
        12,
        STRPOS(original_file_name,'_kroger')-12), "_"," ")) AS source_category
    , original_file_name
	, file_dt
	, sh.rctl_uuid
	, timestamp(sh.ingest_date) ingest_date
	, sh.rctl_file_name	
	, '""",job_run_id,"""' created_by 
	, current_datetime created_datetime 
	, '""",job_run_id,"""' modified_by 
	, current_datetime modified_datetime 
  -- the following ranking is done to avoid duplicates if multiple files
	-- are loaded in one run. The data is partitioned on the natural key 
	-- of the file. The data is then ordered descending on file_dt which is 
	-- the timestamp on the file.  Picking rank = 1 will result in the record 
	-- with latest file_dt being picked in case duplicate records
	-- exist in the raw table ***across different files***.
	, row_number() over (
							partition by UPC, commodity,subcommodity,
										parse_timestamp("%m/%d/%Y", cl.gmi_week_start_dt)
							order by 
								PARSE_timestamp("%m-%d-%Y %H:%M:%E*S", file_dt) desc
						) rnk_1 	
	-- the following ranking is done to avoid duplicates if the ****same file
	-- is loaded multiple times****. The data is partitioned on the natural key 
	-- of the file and the file_dt which is the timestamp on the file
	-- The data is then ordered descending on ingest_date which is the current timestamp
	-- coming from the ingestion framework.  Picking rank = 1 will result
	-- in the record with latest ingest_date being picked in case duplicate records
	-- exist in the raw table.  THIS SCENARIO WILL TYPICALLY NOT OCCUR.
	-- Please note the use of ROW_NUMBER function to pick one record.
	
	, row_number() over (
							partition by UPC, commodity,subcommodity, 
										parse_timestamp("%m/%d/%Y", cl.gmi_week_start_dt),
										PARSE_timestamp("%m-%d-%Y %H:%M:%E*S", file_dt)
							order by 
								 sh.ingest_date desc
						) rnk_2
	from 
		`""" ,bq_project_name,"""`.""",bq_raw_dataset_name,""".""",raw_table_name,""" sh
    JOIN
  `""" ,bq_project_name,"""`.""",bq_processed_dataset_name,""".""",calendar_table_name,""" cl
ON
  cl.kroger_desc = sh.week_begin_dt 
	where 
		sh.ingest_date > '""",extract_start_date,"""' 
	and sh.ingest_date  <= '""",extract_end_date,"""'
)
    select
	 grain 
	,retailer	  
	,customer_name
	,gmi_week_start_dt,
    gmi_week_end_dt,
    week_begin_dt as source_week_begin_dt,
    period_desc,
    primary_department,
    recap_department,
    department,
    commodity,
    subcommodity,
    parent_owner_desc,
    mfr_desc,
    mfr_cd,
    itm_scn_prc_grp,
    itm_scn_prc_grp_desc,
    upc,
    source_item_code,
    source_item_name,
    scanned_retail_dollars_cur,
    scanned_movement_cur,
    gross_margin_dollars_cur,
    scanned_retail_dollars_pre,
    scanned_movement_pre,
    gross_margin_dollars_pre,
    ty_sales_value,
    ty_sales_units,
    clicklist_scanned_lbs_cur,
    clicklist_gross_margin_dollars_cur,
    clicklist_scanned_retail_dollars_pre,
    clicklist_scanned_movement_pre,
    clicklist_scanned_lbs_pre,
    clicklist_gross_margin_dollars_pre,
    source_category
	, original_file_name
	, file_dt
	, ingest_date
	, rctl_file_name
	, rctl_uuid	
	, created_by 
	, created_datetime 
	, modified_by 
	, modified_datetime 
    from 
		final 
	where 
		rnk_1 = 1 and rnk_2 = 1
 )
""") ;

select sql;

EXECUTE IMMEDIATE sql;

EXCEPTION WHEN ERROR THEN
    SELECT  
	ERROR (
		CONCAT(
    			@@error.message ,' ' ,
    			@@error.statement_text, ' ' ,
    			@@error.formatted_stack_trace ,' '
			)
		)
	;

END;