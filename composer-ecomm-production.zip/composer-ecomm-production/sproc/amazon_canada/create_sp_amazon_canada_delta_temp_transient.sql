 /* Purpose OF the stored proc : Delta Temp Table
	History OF Changes : 03/30 first version 
	                     06/21 ty_sales_units datatype conversion changed & report_date calculation updated
	Author : Aswathi Nambiar 
	
CALL
  transient.sp_data_extract_config_insert(-99,
    'ecomm-dlf-dev-01cd47',
    'raw',
    'transient',
    'amazon_canada_sales');
CALL
  transient.sp_amazon_canada_delta_temp(-99,
    'ecomm-dlf-dev-01cd47',
    'raw',
    'transient',
    'amazon_canada_sales',
	'processed',
    'lkp_amazon_canada_mapping',
	'amazon_canada_delta_temp',
	'AMAZON_CANADA');
CALL
  transient.sp_data_extract_config_update(-99,
    'ecomm-dlf-dev-01cd47',
    'transient',
    'amazon_canada_sales');

  */
CREATE PROCEDURE IF NOT EXISTS
  transient.sp_amazon_canada_delta_temp ( job_run_id INT64,
    bq_project_name STRING,
    bq_raw_dataset_name STRING,
    bq_transient_dataset_name STRING,
    bq_raw_table_name STRING,
	bq_lkp_dataset_name STRING,
	bq_lkp_table_name STRING,
	bq_delta_temp_tablename STRING,
	customer_name STRING)
BEGIN
-- declare variables
DECLARE extract_start_date,extract_end_date Timestamp;

-- Get Extract start datetime for incoming table from data_extract_config table
EXECUTE IMMEDIATE CONCAT("""select extract_start_datetime from `""",bq_project_name,"""`.""",bq_transient_dataset_name,""".""","""data_extract_config where table_name = '""",bq_raw_table_name,"""' and status = 'running' 
and active_flag = 'Y'""") into extract_start_date;

-- Get Extract end datetime for incoming table from data_extract_config table
EXECUTE IMMEDIATE CONCAT("""select extract_end_datetime from `""",bq_project_name,"""`.""",bq_transient_dataset_name,""".""",
"""data_extract_config where table_name = '""",bq_raw_table_name,"""' and status = 'running'  and active_flag = 'Y'""") into extract_end_date;

-- Truncate Delta Temp Table
EXECUTE IMMEDIATE
CONCAT("""TRUNCATE TABLE  `""" ,bq_project_name,"""`.""",bq_transient_dataset_name,""".""",bq_delta_temp_tablename);

/*Insert Details for passed customer into 'amazon_canada_delta_temp' table having ingest date greater than extract_start_date 
from data_extract_config table */
EXECUTE IMMEDIATE
CONCAT("""insert into  `""" ,bq_project_name,"""`.""",bq_transient_dataset_name,""".""",bq_delta_temp_tablename,"""  
( 
WITH
  raw_data AS (
  SELECT
    'WEEK' AS grain,
    'AMAZON CANADA' AS retailer,
    '""",customer_name,"""' AS customer_name,
    amzn_sales.asin AS source_item_code,
    upc_map.upc,
    upc_map.ean,
    upc_map.brand_code,
    upc_map.brand,
    amzn_sales.product_title AS source_item_name,
    coalesce(safe_cast (amzn_sales.sales AS FLOAT64),
      0) AS ty_sales_value,
    SAFE_CAST(amzn_sales.sales_percent_of_total AS NUMERIC) AS sales_percent_of_total,
    coalesce(safe_cast (amzn_sales.sales_prior_period AS NUMERIC),
      0) AS sales_prior_period,
    coalesce(safe_cast (amzn_sales.sales_last_year AS NUMERIC),
      0) AS sales_last_year,
    coalesce(CAST(CAST(amzn_sales.`shipped_units` AS NUMERIC) AS INT64),
      0) AS ty_sales_units,
    SAFE_CAST(amzn_sales.shipped_units_percent_of_total AS NUMERIC) AS shipped_units_percent_of_total,
    coalesce(SAFE_CAST(amzn_sales.`shipped_units_prior_period` AS INT64),
      0) AS shipped_units_prior_period,
    coalesce(SAFE_CAST(amzn_sales.`shipped_units_last_year` AS INT64),
      0) AS shipped_units_last_year,
    safe_cast (amzn_sales.`customer_returns` AS INT64) AS customer_returns,
    SAFE_CAST(amzn_sales.`free_replacements` AS INT64) AS free_replacements,
	coalesce(safe_cast (avg_sales_price AS NUMERIC),0) AS avg_sales_price,
	coalesce(safe_cast (avg_sales_price_pp AS NUMERIC),0) AS avg_sales_price_pp,
    amzn_sales.original_file_name,
    COALESCE(SAFE.PARSE_TIMESTAMP('%d/%m/%y',TRIM(SPLIT(regexp_replace(report_date,r'(Viewing=)|(\\[)|(\\])', ''),'-')[OFFSET(1)],']')),
	SAFE.PARSE_TIMESTAMP('%Y%m%d',TRIM(SPLIT(regexp_replace(report_date,r'(Viewing=)|(\\[)|(\\])', ''),'-')[OFFSET(1)],']'))) as report_date,
	COALESCE(SAFE.PARSE_DATE('%d/%m/%y',TRIM(SPLIT(regexp_replace(report_date,r'(Viewing=)|(\\[)|(\\])', ''),'-')[OFFSET(0)],']')),
	SAFE.PARSE_DATE('%Y%m%d',TRIM(SPLIT(regexp_replace(report_date,r'(Viewing=)|(\\[)|(\\])', ''),'-')[OFFSET(0)],']'))) as start_date,
	COALESCE(SAFE.PARSE_DATE('%d/%m/%y',TRIM(SPLIT(regexp_replace(report_date,r'(Viewing=)|(\\[)|(\\])', ''),'-')[OFFSET(1)],']')),
	SAFE.PARSE_DATE('%Y%m%d',TRIM(SPLIT(regexp_replace(report_date,r'(Viewing=)|(\\[)|(\\])', ''),'-')[OFFSET(1)],']'))) as end_date,
    amzn_sales.file_dt,
    amzn_sales.rctl_uuid,
    amzn_sales.ingest_date,
    amzn_sales.rctl_file_name,
    CAST(""",job_run_id,""" AS string) AS created_by,
    current_datetime AS created_datetime,
    CAST(""",job_run_id,""" AS string) AS modified_by,
    current_datetime AS modified_datetime
  FROM
    `""" ,bq_project_name,"""`.""",bq_raw_dataset_name,""".""",bq_raw_table_name,""" amzn_sales
  LEFT OUTER JOIN
    `""" ,bq_project_name,"""`.""",bq_lkp_dataset_name,""".""",bq_lkp_table_name,""" upc_map
  ON
    amzn_sales.asin = upc_map.asin 
  WHERE
    amzn_sales.ingest_date > '""",extract_start_date,"""' 
	AND amzn_sales.ingest_date <= '""",extract_end_date,"""' 
    )
SELECT
  * EXCEPT(rnk_1 , rnk_2)
FROM (
  SELECT
    grain,
    retailer,
    customer_name,
    source_item_code,
    upc,
    ean,
    brand_code,
    brand,
    source_item_name,
    ty_sales_value,
    ty_sales_units,
    sales_percent_of_total,
    sales_prior_period,
    sales_last_year,
    shipped_units_percent_of_total,
    shipped_units_prior_period,
    shipped_units_last_year,
    customer_returns,
    free_replacements,
	avg_sales_price,
	avg_sales_price_pp,
    original_file_name,
    report_date,
    start_date,
    end_date,
    file_dt,
    rctl_uuid,
    ingest_date,
    rctl_file_name,
    created_by,
    created_datetime,
    modified_by,
    modified_datetime,
	-- the following ranking is done to avoid duplicates if multiple files
	-- are loaded in one run. The data is partitioned on the natural key 
	-- of the file. The data is then ordered descending on file_dt which is 
	-- the timestamp on the file.  Picking rank = 1 will result in the record 
	-- with latest file_dt being picked in case duplicate records
	-- exist in the raw table ***across different files***.
    DENSE_RANK() OVER (PARTITION BY source_item_code, report_date ORDER BY PARSE_timestamp("%m-%d-%Y %H:%M:%S", file_dt) DESC) AS rnk_1,
	
	-- the following ranking is done to avoid duplicates if the ****same file
	-- is loaded multiple times****. The data is partitioned on the natural key 
	-- of the file and the file_dt which is the timestamp on the file
	-- The data is then ordered descending on ingest_date which is the current timestamp
	-- coming from the ingestion framework.  Picking rank = 1 will result
	-- in the record with latest ingest_date being picked in case duplicate records
	-- exist in the raw table.  THIS SCENARIO WILL TYPICALLY NOT OCCUR.
	-- Please note the use of ROW_NUMBER function to pick one record.
	ROW_NUMBER() OVER (PARTITION BY source_item_code, report_date,PARSE_timestamp("%m-%d-%Y %H:%M:%S", file_dt) ORDER BY ingest_date DESC) AS rnk_2
  FROM
    raw_data k
  )A
WHERE
  rnk_1 = 1  and rnk_2 = 1)
""") ;

EXCEPTION WHEN ERROR THEN
    SELECT  
	ERROR (
		CONCAT(
    			@@error.message ,' ' ,
    			@@error.statement_text, ' ' ,
    			@@error.formatted_stack_trace ,' '
			)
		)
	;

END;