 /* Purpose OF the stored proc : History Load
	History OF Changes : 06/15 first version 
                       06/22 Changed Dense_Rank to Row_number function
	Author : Aswathi Nambiar 
	
CALL
  transient.sp_amazon_canada_delta_temp_hist(-99,
    'ecomm-dlf-dev-01cd47',
	'shareddata-prd-cb5872',
    'sales_ecomm_global_sales_and_share',
    'transient',
    'ecom_amazon_canada_sales_raw_v',
	'processed',
    'lkp_amazon_canada_mapping',
	'amazon_canada_delta_temp',
	'AMAZON_CANADA');

  */
CREATE PROCEDURE IF NOT EXISTS
  transient.sp_amazon_canada_delta_temp_hist ( job_run_id INT64,
    bq_project_name STRING,
	bq_source_project_name string,
    bq_source_dataset_name STRING,
    bq_transient_dataset_name STRING,
    bq_raw_table_name STRING,
	bq_lkp_dataset_name STRING,
	bq_lkp_table_name STRING,
	bq_delta_temp_tablename STRING,
	customer_name STRING)
BEGIN

-- Truncate Delta Temp Table
EXECUTE IMMEDIATE
CONCAT("""TRUNCATE TABLE  `""" ,bq_project_name,"""`.""",bq_transient_dataset_name,""".""",bq_delta_temp_tablename);

-- Insert History records into delta temp table
EXECUTE IMMEDIATE
CONCAT("""insert into  `""" ,bq_project_name,"""`.""",bq_transient_dataset_name,""".""",bq_delta_temp_tablename,"""  
( 
WITH
  raw_data AS (
  SELECT
    'WEEK' AS grain,
    'AMAZON CANADA' AS retailer,
    '""",customer_name,"""' AS customer_name,
    amzn_sales.asin AS source_item_code,
    upc_map.upc,
    upc_map.ean,
    upc_map.brand_code,
    upc_map.brand,
    amzn_sales.product_title AS source_item_name,
    coalesce(safe_cast (amzn_sales.sales AS FLOAT64),
      0) AS ty_sales_value,
    SAFE_CAST(amzn_sales.sales_percent_of_total AS NUMERIC) AS sales_percent_of_total,
    coalesce(safe_cast (amzn_sales.sales_prior_period AS NUMERIC),
      0) AS sales_prior_period,
    coalesce(safe_cast (amzn_sales.sales_last_year AS NUMERIC),
      0) AS sales_last_year,
    coalesce(CAST(CAST(amzn_sales.`shipped_units` AS NUMERIC) AS INT64),
      0) AS ty_sales_units,
    SAFE_CAST(amzn_sales.shipped_units_percent_of_total AS NUMERIC) AS shipped_units_percent_of_total,
    coalesce(SAFE_CAST(amzn_sales.`shipped_units_prior_period` AS INT64),
      0) AS shipped_units_prior_period,
    coalesce(SAFE_CAST(amzn_sales.`shipped_units_last_year` AS INT64),
      0) AS shipped_units_last_year,
    safe_cast (amzn_sales.`customer_returns` AS INT64) AS customer_returns,
    SAFE_CAST(amzn_sales.`free_replacements` AS INT64) AS free_replacements,
	coalesce(safe_cast (avg_sales_price AS NUMERIC),0) AS avg_sales_price,
	coalesce(safe_cast (avg_sales_price_pp AS NUMERIC),0) AS avg_sales_price_pp,
    'History load'  as original_file_name,
    COALESCE(SAFE.PARSE_TIMESTAMP('%d/%m/%y',TRIM(SPLIT(regexp_replace(report_date,r'(Viewing=)|(\\[)|(\\])', ''),'-')[OFFSET(1)],']')),
	SAFE.PARSE_TIMESTAMP('%Y%m%d',TRIM(SPLIT(regexp_replace(report_date,r'(Viewing=)|(\\[)|(\\])', ''),'-')[OFFSET(1)],']'))) as report_date,
	COALESCE(SAFE.PARSE_DATE('%d/%m/%y',TRIM(SPLIT(regexp_replace(report_date,r'(Viewing=)|(\\[)|(\\])', ''),'-')[OFFSET(0)],']')),
	SAFE.PARSE_DATE('%Y%m%d',TRIM(SPLIT(regexp_replace(report_date,r'(Viewing=)|(\\[)|(\\])', ''),'-')[OFFSET(0)],']'))) as start_date,
	COALESCE(SAFE.PARSE_DATE('%d/%m/%y',TRIM(SPLIT(regexp_replace(report_date,r'(Viewing=)|(\\[)|(\\])', ''),'-')[OFFSET(1)],']')),
	SAFE.PARSE_DATE('%Y%m%d',TRIM(SPLIT(regexp_replace(report_date,r'(Viewing=)|(\\[)|(\\])', ''),'-')[OFFSET(1)],']'))) as end_date,
	'01/01/0001' file_dt,
	GENERATE_UUID() rctl_uuid,
	current_timestamp ingest_date,
	'History load' rctl_file_name,
	hadoop_update_ts,
    CAST(""",job_run_id,""" AS string) AS created_by,
    current_datetime AS created_datetime,
    CAST(""",job_run_id,""" AS string) AS modified_by,
    current_datetime AS modified_datetime
  FROM
    `""" ,bq_source_project_name,"""`.""",bq_source_dataset_name,""".""",bq_raw_table_name,""" amzn_sales
  LEFT OUTER JOIN
    `""" ,bq_project_name,"""`.""",bq_lkp_dataset_name,""".""",bq_lkp_table_name,""" upc_map
  ON
    amzn_sales.asin = upc_map.asin 
    )
SELECT
  * EXCEPT(rnk_1)
FROM (
  SELECT
    grain,
    retailer,
    customer_name,
    source_item_code,
    upc,
    ean,
    brand_code,
    brand,
    source_item_name,
    ty_sales_value,
    ty_sales_units,
    sales_percent_of_total,
    sales_prior_period,
    sales_last_year,
    shipped_units_percent_of_total,
    shipped_units_prior_period,
    shipped_units_last_year,
    customer_returns,
    free_replacements,
	avg_sales_price,
	avg_sales_price_pp,
    'History load' original_file_name,
    report_date,
    start_date,
    end_date,
	'01/01/0001' file_dt,
	GENERATE_UUID() rctl_uuid,
	current_timestamp ingest_date,
	'History load' rctl_file_name,
	SAFE_CAST(""",job_run_id,""" AS string) AS created_by,
	current_datetime AS created_datetime,
	SAFE_CAST(""",job_run_id,""" AS string) AS modified_by,
	current_datetime AS modified_datetime,
	ROW_NUMBER() OVER (PARTITION BY source_item_code,report_date ORDER BY hadoop_update_ts DESC ) rnk_1
  FROM
    raw_data k
  )A
WHERE
  rnk_1 = 1)
""") ;

EXCEPTION WHEN ERROR THEN
    SELECT  
	ERROR (
		CONCAT(
    			@@error.message ,' ' ,
    			@@error.statement_text, ' ' ,
    			@@error.formatted_stack_trace ,' '
			)
		)
	;

END;