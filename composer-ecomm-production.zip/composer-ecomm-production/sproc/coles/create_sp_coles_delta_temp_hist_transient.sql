/*

ecom_coles_sales_raw_v
CALL
  transient.sp_coles_delta_temp_hist(99,
    'ecomm-dlf-dev-01cd47',
    'transient',
    'COLES',
    'shareddata-prd-cb5872',
    'shared_data_ecom',
    'ecom_coles_sales_raw_v');
*/
CREATE PROCEDURE IF NOT EXISTS
  transient.sp_coles_delta_temp_hist(job_run_id INT64,
    bq_project_name STRING,
    bq_transient_dataset_name STRING,
    customer_name STRING,
    bq_prod_project_name STRING,
    bq_prod_dataset_name STRING,
    raw_table_name STRING)
BEGIN
EXECUTE IMMEDIATE
  CONCAT("""TRUNCATE TABLE  `""",bq_project_name,"""`.""","""transient.coles_delta_temp"""); 
  /*Insert Details for passed customer into 'coles_delta_temp' table having ingest date greater than extract_start_date 
from data_extract_config table */
EXECUTE IMMEDIATE
  CONCAT("""insert into  `""",bq_project_name,"""`.""",bq_transient_dataset_name,""".""","""coles_delta_temp 
(
WITH
  dr AS (
  SELECT
    'WEEK' AS grain,
    '""",customer_name,"""' AS retailer,
    '""",customer_name,"""' AS customer_name,
    REGEXP_EXTRACT(cs.coles_product,'[1-9][0-9]*') AS source_item_code,
    REGEXP_EXTRACT(cs.coles_product,'[^ ]*( .*)') AS source_item_name,
	  cs.coles_category,
    cs.coles_geography,
    cast(DATE_SUB(DATE (CAST(PARSE_DATE("%d-%m-%Y",cs.coles_weekdate) AS date)), INTERVAL 8 DAY) as timestamp) AS coles_weekdate,
    cs.coles_product AS coles_product,
    cs.coles_category AS source_category,
    cs.coles_subcategory,
    cs.coles_ean AS coles_ean,
    cs.coles_manufacturer,
    cs.coles_brand,
    CAST(cs.Sales AS FLOAT64) AS ty_sales_value,
    CAST(cs.Units AS INT64) AS ty_sales_units,
    'History load' as original_file_name,
    '01/01/0001' as file_dt,
    current_timestamp as ingest_date,
    'History load' as rctl_file_name,
    GENERATE_UUID() as rctl_uuid,
    CAST(""",job_run_id,""" AS string) created_by,
    current_datetime created_datetime,
    CAST(""",job_run_id,""" AS string) modified_by,
    current_datetime modified_datetime,
    -- the following ranking is done to avoid duplicates if multiple files
    -- are loaded in one run. The data is partitioned on the natural key 
    -- of the file. The data is then ordered descending on hadoop_update_ts which is 
    -- the timestamp on the file.  Picking rank = 1 will result in the record 
    -- with latest file_dt being picked in case duplicate records
    -- exist in the raw table ***across different files***.

    ROW_NUMBER() OVER (PARTITION BY cast(PARSE_DATE("%d-%m-%Y",
      cs.coles_weekdate) as timestamp), coles_product, coles_category, coles_subcategory, coles_ean ORDER BY hadoop_update_ts DESC) rnk_1

  FROM
      `""",bq_prod_project_name,"""`.""",bq_prod_dataset_name,""".""",raw_table_name,""" cs
 )
SELECT
  grain,
  retailer,
  customer_name,
  source_item_code,
  source_item_name,
  coles_category,
  coles_geography,
  coles_weekdate,
  coles_product,
  source_category,
  coles_subcategory,
  coles_ean,
  coles_manufacturer,
  coles_brand,
  ty_sales_value,
  ty_sales_units,
  original_file_name,
  file_dt,
  ingest_date,
  rctl_file_name,
  rctl_uuid,
  created_by,
  created_datetime,
  modified_by,
  modified_datetime
FROM
  dr
WHERE
  rnk_1 = 1
   )
""") ; EXCEPTION
    WHEN ERROR THEN SELECT ERROR ( CONCAT( @@error.message,' ', @@error.statement_text, ' ', @@error.formatted_stack_trace,' ' ) ) ;
END
  ;