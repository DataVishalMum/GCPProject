 /* Purpose OF the stored proc : Delta Temp Table
	History OF Changes : 04/19 first version
  	                   05/4 pulled MBA names (i.e. source_item_code) all the way back to delta temp
					   06/10- Added the Missing report_date formatting logic

	Author : Anne Lifton
			 Swati Thakur
	
CALL
  transient.sp_data_extract_config_insert(-99,
    'ecomm-dlf-dev-01cd47',
    'raw',
    'transient',
    'amazon_fresh_sales');
CALL
  transient.sp_amazon_fresh_delta_temp(-99,
    'ecomm-dlf-dev-01cd47',
    'raw',
    'transient',
    'amazon_fresh_sales',
	'processed',
    'lkp_amazon_catalog_mapping',
	'amazon_fresh_delta_temp',
	'AMAZON_FRESH');
CALL
  transient.sp_data_extract_config_update(-99,
    'ecomm-dlf-dev-01cd47',
    'transient',
    'amazon_fresh_sales')

  */
CREATE PROCEDURE IF NOT EXISTS
  transient.sp_amazon_fresh_delta_temp ( job_run_id INT64,
    bq_project_name STRING,
    bq_raw_dataset_name STRING,
    bq_transient_dataset_name STRING,
    bq_raw_table_name STRING,
	bq_lkp_dataset_name STRING,
	bq_lkp_table_name STRING,
	bq_delta_temp_tablename STRING,
	customer_name STRING)
BEGIN
-- declare variables
DECLARE extract_start_date,extract_end_date Timestamp;

-- Get Extract start datetime for incoming table from data_extract_config table
EXECUTE IMMEDIATE CONCAT("""select extract_start_datetime from `""",bq_project_name,"""`.""",bq_transient_dataset_name,""".""","""data_extract_config where table_name = '""",bq_raw_table_name,"""' and status = 'running' 
and active_flag = 'Y'""") into extract_start_date;

-- Get Extract end datetime for incoming table from data_extract_config table
EXECUTE IMMEDIATE CONCAT("""select extract_end_datetime from `""",bq_project_name,"""`.""",bq_transient_dataset_name,""".""",
"""data_extract_config where table_name = '""",bq_raw_table_name,"""' and status = 'running'  and active_flag = 'Y'""") into extract_end_date;

-- Truncate Delta Temp Table
EXECUTE IMMEDIATE
CONCAT("""TRUNCATE TABLE  `""" ,bq_project_name,"""`.""",bq_transient_dataset_name,""".""",bq_delta_temp_tablename);

/*Insert Details for passed customer into 'amazon_fresh_delta_temp' table having ingest date greater than extract_start_date
from data_extract_config table */
EXECUTE IMMEDIATE
CONCAT("""insert into  `""" ,bq_project_name,"""`.""",bq_transient_dataset_name,""".""",bq_delta_temp_tablename,"""  
( 
WITH
  dr AS (
  SELECT
    'WEEK' AS grain,
    'Amazon' AS retailer,
    '""",customer_name,"""' AS customer_name,
    #note that asin and source_item_code are the same, to reduce extra rows, asin was removed
    afs.asin as source_item_code,
    m.pkg_upc AS upc,
    afs.producttitle as source_item_name,
    SAFE_CAST(REGEXP_REPLACE(afs.revenue, r"[^0-9.]", '') as DECIMAL) as ty_sales_value,
    afs.revenueperoftotal,
    afs.revenuepriorperiod,
    afs.revenuelastyear,
    SAFE_CAST(REGEXP_REPLACE(afs.units, r"[^0-9]", '') as INT64) as ty_sales_units,
    SAFE_CAST(REGEXP_REPLACE(afs.units, r"[^0-9]", '') as INT64)* SAFE_CAST(m.eaches_in_title as INT64) adjusted_units,
    afs.unitsperoftotal,
    afs.unitspriorperiod,
    afs.unitslastyear,
    afs.subcategorysalesrank,
    SAFE_CAST (REGEXP_REPLACE(afs.asp, r"\\$", '')as DECIMAL) as asp,
    afs.asppriorperiod,
    afs.changeinimpressionpriorperiod,
    afs.changeinimpressionlastyr,
    afs.displayedinstock,
    afs.displayedinstockperoftotal,
    afs.displayinstockpriorperiod,
    afs.original_file_name,
	(case 
            when length(afs.reportdate) = 10 
            then safe_cast(afs.reportdate  as timestamp)
            else SAFE_CAST(PARSE_DATE('%x', afs.reportdate) AS Timestamp) end ) as report_date,
    afs.file_dt,
    afs.rctl_uuid,
    afs.ingest_date,
    afs.rctl_file_name,
    SAFE_CAST(""",job_run_id,""" AS string) AS created_by,
    current_datetime AS created_datetime,
    SAFE_CAST(""",job_run_id,""" AS string) AS modified_by,
    current_datetime AS modified_datetime
    	-- the following ranking is done to avoid duplicates if multiple files
	-- are loaded in one run. The data is partitioned on the natural key 
	-- of the file. The data is then ordered descending on file_dt which is 
	-- the timestamp on the file.  Picking rank = 1 will result in the record 
	-- with latest file_dt being picked in case duplicate records
	-- exist in the raw table ***across different files***.
	
	, dense_rank() over (
							partition by afs.asin,
              m.pkg_upc,
							SAFE_CAST(PARSE_DATE('%x', afs.reportdate) AS Timestamp)
							order by 
								PARSE_timestamp("%m-%d-%Y %H:%M:%S", afs.file_dt) desc
						) rnk_1
	
	-- the following ranking is done to avoid duplicates if the ****same file
	-- is loaded multiple times****. The data is partitioned on the natural key 
	-- of the file and the file_dt which is the timestamp on the file
	-- The data is then ordered descending on ingest_date which is the current timestamp
	-- coming from the ingestion framework.  Picking rank = 1 will result
	-- in the record with latest ingest_date being picked in case duplicate records
	-- exist in the raw table.  THIS SCENARIO WILL TYPICALLY NOT OCCUR.
	-- Please note the use of ROW_NUMBER function to pick one record.
	-- This function will be needed when the entire RAW table is read to reprocess history.
	
	, row_number() over (
							partition by afs.asin,
                m.pkg_upc,
								SAFE_CAST(PARSE_DATE('%x', afs.reportdate) AS Timestamp),
								PARSE_timestamp("%m-%d-%Y %H:%M:%S", afs.file_dt)
							order by 
								 afs.ingest_date desc
						) rnk_2
  FROM
    `""" ,bq_project_name,"""`.""",bq_raw_dataset_name,""".""",bq_raw_table_name,""" afs
  LEFT OUTER JOIN
    `""" ,bq_project_name,"""`.""",bq_lkp_dataset_name,""".""",bq_lkp_table_name,""" m
  ON
     m.asin = afs.asin and m.vendor = 'GENXD'
  WHERE
    afs.ingest_date > '""",extract_start_date,"""' 
	AND afs.ingest_date <= '""",extract_end_date,"""' 
    )
SELECT
    grain,
    retailer,
    customer_name,
    source_item_code,
    upc,
    source_item_name,
    ty_sales_value,
    revenueperoftotal,
    revenuepriorperiod,
    revenuelastyear,
    ty_sales_units,
    adjusted_units,
    unitsperoftotal,
    unitspriorperiod,
    unitslastyear,
    subcategorysalesrank,
    asp,
    asppriorperiod,
    changeinimpressionpriorperiod,
    changeinimpressionlastyr,
    displayedinstock,
    displayedinstockperoftotal,
    displayinstockpriorperiod,
    original_file_name,
    report_date,
    file_dt,
    rctl_uuid,
    ingest_date,
    rctl_file_name,
    created_by,
    created_datetime,
    modified_by,
    modified_datetime,
    from 
		dr 
	where 
		rnk_1 = 1  and rnk_2 = 1)

""") ;

EXCEPTION WHEN ERROR THEN
    SELECT  
	ERROR (
		CONCAT(
    			@@error.message ,' ' ,
    			@@error.statement_text, ' ' ,
    			@@error.formatted_stack_trace ,' '
			)
		)
	;

END;