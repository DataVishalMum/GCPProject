/*
Purpose of the stored proc: 
	Delta Data extraction for 'cornershop_canada' customer
History of Changes:
	10/10 – first version
Author : 
	Pawan Rathod
How to Call:
		call transient.sp_cornershop_canada_delta_temp
		(
		 99,
		'ecomm-dlf-dev-01cd47',
		'raw',
		'transient' ,
		'cornershop_canada_sales',
		'cornershop_canada_delta_temp',
		'CORNERSHOP_CANADA'
		);

*/

CREATE PROCEDURE IF NOT EXISTS
  transient.sp_cornershop_canada_delta_temp ( job_run_id int64,
    bq_project_name string,
    bq_raw_dataset_name string,
    bq_transient_dataset_name string,
    bq_raw_table_name string,
    bq_delta_temp_tablename string,
    customer_name string )
BEGIN

-- declare variables
DECLARE 
	 extract_start_date
	,extract_end_date Timestamp;

/* Get Extract start datetime for incoming table from data_extract_config table */
EXECUTE IMMEDIATE
  CONCAT("""select extract_start_datetime from `""",bq_project_name,"""`.""",bq_transient_dataset_name,""".""","""data_extract_config
where table_name = '""",bq_raw_table_name,"""' and status = 'running'
and active_flag = 'Y'""") INTO extract_start_date;

/* Get Extract end datetime for incoming table from data_extract_config table */
EXECUTE IMMEDIATE
  CONCAT("""select extract_end_datetime from `""",bq_project_name,"""`.""",bq_transient_dataset_name,""".""", """data_extract_config 
  where table_name = '""",bq_raw_table_name,"""' and status = 'running'  and active_flag = 'Y'""") INTO extract_end_date;

/* Delta Temp Table is Truncate & Load */
EXECUTE IMMEDIATE
CONCAT("""TRUNCATE TABLE  `""" ,bq_project_name,"""`.""",bq_transient_dataset_name,""".""",bq_delta_temp_tablename);

	/*Insert Details for passed customer into 'cornershop_canada_delta_temp' table having ingest date greater than extract_start_date
from data_extract_config table */
EXECUTE IMMEDIATE
CONCAT("""insert into  `""" ,bq_project_name,"""`.""",bq_transient_dataset_name,""".""",bq_delta_temp_tablename,
"""
(
   WITH
     dr AS (
     SELECT
       'MONTH' AS grain,
       'CORNERSHOP_CANADA' AS retailer,
       '""",customer_name,"""' AS customer_name,
       CASE WHEN ARRAY_LENGTH(SPLIT(barcodes,";")) > 1 THEN TRIM(SPLIT(barcodes,";")[OFFSET(1)]) ELSE TRIM(barcodes) end AS source_item_code,
       CASE WHEN ARRAY_LENGTH(SPLIT(barcodes,";")) > 1 THEN TRIM(SPLIT(barcodes,";")[OFFSET(1)]) ELSE TRIM(barcodes) end AS upc,
       --The below code converts 1st of every month to 1st Monday of that Month e.g. 2021-10-01 will be converted to 2021-10-04
       CASE WHEN EXTRACT(DAYOFWEEK FROM cast(month as date))=2 THEN CAST(PARSE_DATE('%Y-%m-%d',month) AS TIMESTAMP)
       ELSE CAST(DATE_TRUNC(DATE_ADD(PARSE_DATE('%Y-%m-%d',month), INTERVAL 1 WEEK), WEEK(MONDAY)) AS TIMESTAMP) END AS report_date,
       name AS source_item_name,
       brand AS source_category,
       store AS store,
       branch AS branch,
       city AS city,
       format AS format,
       coalesce(SAFE_CAST(orders AS INT64),
         0) AS orders,
       coalesce(SAFE_CAST(units_requested AS INT64),
         0) AS units_requested,
       found_rate AS found_rate,
       coalesce(SAFE_CAST(sales AS FLOAT64),
         0) AS ty_sales_value,
       coalesce(SAFE_CAST(SAFE_CAST(found_units AS numeric) AS INT64),
         0) AS ty_sales_units,
       original_file_name,
       file_dt,
       rctl_uuid,
       TIMESTAMP(ingest_date) ingest_date,
       rctl_file_name,
       '""",job_run_id,"""' created_by,
       current_datetime created_datetime,
       '""",job_run_id,"""' modified_by,
       current_datetime modified_datetime,

	   -- the following ranking is done to avoid duplicates if multiple files
	   -- are loaded in one run. The data is partitioned on the natural key
	   -- of the file. The data is then ordered descending on file_dt which is
	   -- the timestamp on the file.  Picking rank = 1 will result in the record
	   -- with latest file_dt being picked in case duplicate records
	   -- exist in the raw table ***across different files***.

       DENSE_RANK() OVER (PARTITION BY name,barcodes,branch,month
                          ORDER BY PARSE_TIMESTAMP("%m-%d-%Y %H:%M:%S", file_dt) DESC
                          ) AS rnk_1,

	   -- the following ranking is done to avoid duplicates if the ****same file
	   -- is loaded multiple times****. The data is partitioned on the natural key
	   -- of the file and the file_dt which is the timestamp on the file
	   -- The data is then ordered descending on ingest_date which is the current timestamp
	   -- coming from the ingestion framework.  Picking rank = 1 will result
	   -- in the record with latest ingest_date being picked in case duplicate records
	   -- exist in the raw table.  THIS SCENARIO WILL TYPICALLY NOT OCCUR.
	   -- Please note the use of ROW_NUMBER function to pick one record.
	   -- This function will be needed when the entire RAW table is read to reprocess history.

       ROW_NUMBER() OVER (PARTITION BY
                          name,
						  barcodes,
                          branch,
                          month,
                          PARSE_TIMESTAMP("%m-%d-%Y %H:%M:%S", file_dt)
                          ORDER BY ingest_date DESC
                          ) rnk_2

       FROM
         `""" ,bq_project_name,"""`.""",bq_raw_dataset_name,""".""",bq_raw_table_name,"""
       WHERE
             ingest_date > '""",extract_start_date,"""'
	     AND ingest_date <= '""",extract_end_date,"""')
   SELECT
     grain,
     retailer,
     customer_name,
     source_item_code,
     upc,
     report_date,
     source_item_name,
     source_category,
     store,
     branch,
     city,
     format,
     orders,
     units_requested,
     found_rate,
     ty_sales_value,
     ty_sales_units,
     original_file_name,
     file_dt,
     ingest_date,
     rctl_file_name,
     rctl_uuid,
     created_by,
     created_datetime,
     modified_by,
     modified_datetime
   FROM
     dr
   WHERE
     rnk_1 = 1
     AND rnk_2 = 1
 )
""") ;

EXCEPTION WHEN ERROR THEN
    SELECT  
	ERROR (
		CONCAT(
    			@@error.message ,' ' ,
    			@@error.statement_text, ' ' ,
    			@@error.formatted_stack_trace ,' '
			)
		)
	;

END;

