/*
Purpose of the stored proc:
	Delta Data extraction for 'cornershop_canada' customer
History of Changes:
	10/11 – first version
Author :
	Pawan Rathod
How to Call:
		call transient.sp_cornershop_canada_delta_temp_hist
		(
		 -99,
		'ecomm-dlf-dev-01cd47',
		'transient' ,
		'CORNERSHOP_CANADA',
		'shareddata-prd-cb5872',
		'sales_ecomm_global_sales_and_share',
		'ecom_cornershop_canada_raw_v'
		)

*/


CREATE PROCEDURE IF NOT EXISTS transient.sp_cornershop_canada_delta_temp_hist
(
	job_run_id INT64,
	bq_project_name string,
	bq_transient_dataset_name string,
	customer_name string,
	bq_prod_project_name string,
	bq_prod_dataset_name string,
	raw_table_name string
)
BEGIN


/* Delta Temp Table is Truncate & Load */
EXECUTE IMMEDIATE
CONCAT("""TRUNCATE TABLE  `""" ,bq_project_name,"""`.""",bq_transient_dataset_name,""".""","""cornershop_canada_delta_temp""");

	/*Insert Details for passed customer into 'cornershop_canada_delta_temp' table having ingest date greater than extract_start_date
from data_extract_config table */
EXECUTE IMMEDIATE
CONCAT(
"""insert into  `""" ,bq_project_name,"""`.""",bq_transient_dataset_name,""".""","""cornershop_canada_delta_temp
(
   WITH
     dr AS (
	SELECT
       'MONTH' AS grain,
       'CORNERSHOP_CANADA' AS retailer,
       '""",customer_name,"""' AS customer_name,
       CASE WHEN ARRAY_LENGTH(SPLIT(barcodes,";")) > 1 THEN TRIM(SPLIT(barcodes,";")[OFFSET(1)]) ELSE TRIM(barcodes) end AS source_item_code,
       CASE WHEN ARRAY_LENGTH(SPLIT(barcodes,";")) > 1 THEN TRIM(SPLIT(barcodes,";")[OFFSET(1)]) ELSE TRIM(barcodes) end AS upc,
       --The below code converts 1st of every month to 1st Monday of that Month e.g. 2021-10-01 will be converted to 2021-10-04
       CASE WHEN EXTRACT(DAYOFWEEK FROM cast(month as date))=2 THEN CAST(PARSE_DATE('%Y-%m-%d',month) AS TIMESTAMP)
       ELSE CAST(DATE_TRUNC(DATE_ADD(PARSE_DATE('%Y-%m-%d',month), INTERVAL 1 WEEK), WEEK(MONDAY)) AS TIMESTAMP) END AS report_date,
       name AS source_item_name,
       brand AS source_category,
       store AS store,
       branch AS branch,
       city AS city,
       format AS format,
       coalesce(SAFE_CAST(orders AS INT64),
         0) AS orders,
       coalesce(SAFE_CAST(units_requested AS INT64),
         0) AS units_requested,
       found_rate AS found_rate,
       coalesce(SAFE_CAST(sales AS FLOAT64),
         0) AS ty_sales_value,
       coalesce(SAFE_CAST(SAFE_CAST(found_units AS numeric) AS INT64),
         0) AS ty_sales_units,
       'History load' original_file_name,
       '01/01/0001' file_dt,
       GENERATE_UUID() rctl_uuid,
       current_timestamp ingest_date,
       'History load' rctl_file_name,
       '""",job_run_id,"""' created_by,
       current_datetime created_datetime,
       '""",job_run_id,"""' modified_by,
       current_datetime modified_datetime,

	-- the following ranking is done to avoid duplicates if there are duplicates
	-- for the same vendor file natural key in the raw table replicated from hadoop.
	-- The data is partitioned on the natural key of the vendor file.
	-- The data is then ordered descending on pynamic_version_ts which is
	-- the create timestamp of the record in the raw table.
	-- Picking rank = 1 will result in the record with latest create timestamp
	-- to be selected in case duplicate records exist in the raw table
	-- ***across different create timestamps***.

       ROW_NUMBER() over (
							partition by
										name,
										barcodes,
                                        branch,
                                        month
							ORDER BY hadoop_update_ts DESC
						) rnk_1

	from
		`""" ,bq_prod_project_name,"""`.""",bq_prod_dataset_name,""".""",raw_table_name,"""
)
    SELECT
     grain,
     retailer,
     customer_name,
     source_item_code,
     upc,
     report_date,
     source_item_name,
     source_category,
     store,
     branch,
     city,
     format,
     orders,
     units_requested,
     found_rate,
     ty_sales_value,
     ty_sales_units,
     original_file_name,
     file_dt,
     ingest_date,
     rctl_file_name,
     rctl_uuid,
     created_by,
     created_datetime,
     modified_by,
     modified_datetime
    from
		dr
	where
		rnk_1 = 1
 )
""") ;

EXCEPTION WHEN ERROR THEN
    SELECT
	ERROR (
		CONCAT(
    			@@error.message ,' ' ,
    			@@error.statement_text, ' ' ,
    			@@error.formatted_stack_trace ,' '
			)
		)
	;

END;
