 /* Purpose OF the stored proc : Delta Temp Table to extract history
	History OF Changes : 
	06/04 first version 
	Author : Rakesh Reddy K
	
CALL
  transient.sp_kroger_market6_sales_delta_temp_hist(-99,
    'ecomm-dlf-dev-01cd47',
    'transient',
	'shareddata-prd-cb5872',
	'sales_ecomm_global_sales_and_share',
    'ecom_kroger_sales_mkt6_raw_v',
	'processed',
    'lkp_kroger_fiscal_calendar',
	'kroger_market6_sales_delta_temp',
	'KROGER');

  */
CREATE PROCEDURE IF NOT EXISTS
  transient.sp_kroger_market6_sales_delta_temp_hist ( job_run_id INT64,
  bq_project_name STRING,
  bq_transient_dataset_name STRING,
  bq_prod_project_name string,
  bq_prod_dataset_name string,
  bq_raw_table_name STRING,
  bq_lkp_dataset_name STRING,
  bq_lkp_table_name STRING,
  bq_delta_temp_tablename STRING,
  customer_name STRING)
BEGIN

-- Truncate Delta Temp Table
EXECUTE IMMEDIATE
CONCAT("""TRUNCATE TABLE  `""" ,bq_project_name,"""`.""",bq_transient_dataset_name,""".""",bq_delta_temp_tablename);

/*Insert Details for passed customer into 'kroger_market6_sales_delta_temp' table having ingest date greater than extract_start_date 
from data_extract_config table */
EXECUTE IMMEDIATE
CONCAT(
"""insert into  `""" ,bq_project_name,"""`.""",bq_transient_dataset_name,""".""",bq_delta_temp_tablename,"""
( 
WITH
  raw_data AS (
  SELECT
    'WEEK' AS grain,
    'Kroger' AS retailer,
    '""",customer_name,"""' AS customer_name,
    k.kroger_desc,
    k.period_desc,
    PARSE_TIMESTAMP('%m/%d/%Y',c.gmi_week_start_dt) AS gmi_week_start_dt,
    PARSE_TIMESTAMP('%m/%d/%Y',c.gmi_week_end_dt) AS gmi_week_end_dt,
    k.primary_department,
    k.recap_department,
    k.department,
    k.commodity AS source_category,
    k.subcommodity AS source_sub_category,
    k.parent_owner_desc AS manufacturer,
    k.mfr_desc,
    k.mfr_cd AS source_item_code,
    k.itm_scn_prc_grp,
    k.itm_scn_prc_grp_desc,
    k.upc,
    k.item_description AS source_item_name,
    SAFE_CAST(k.scanned_retail_dollars_cur AS FLOAT64) AS scanned_retail_dollars_cur,
    SAFE_CAST(k.scanned_movement_cur AS INT64) AS scanned_movement_cur,
    SAFE_CAST(k.gross_margin_dollars_cur AS FLOAT64) AS gross_margin_dollars_cur,
    SAFE_CAST(k.scanned_retail_dollars_pre AS FLOAT64) AS scanned_retail_dollars_pre,
    SAFE_CAST(k.scanned_movement_pre AS INT64) AS scanned_movement_pre,
    SAFE_CAST(k.gross_margin_dollars_pre AS FLOAT64) AS gross_margin_dollars_pre,
    SAFE_CAST(k.clicklist_scanned_retail_dollars_cur AS FLOAT64) AS ty_sales_value,
    SAFE_CAST(k.clicklist_scanned_movement_cur AS INT64) AS ty_sales_units,
    SAFE_CAST(k.clicklist_scanned_lbs_cur AS FLOAT64) AS clicklist_scanned_lbs_cur,
    SAFE_CAST(k.clicklist_gross_margin_dollars_cur AS FLOAT64) AS clicklist_gross_margin_dollars_cur,
    SAFE_CAST(k.clicklist_scanned_retail_dollars_pre AS FLOAT64) AS clicklist_scanned_retail_dollars_pre,
    SAFE_CAST(k.clicklist_scanned_movement_pre AS INT64) AS clicklist_scanned_movement_pre,
    SAFE_CAST(k.clicklist_scanned_lbs_pre AS FLOAT64) AS clicklist_scanned_lbs_pre,
    SAFE_CAST(k.clicklist_gross_margin_dollars_pre AS FLOAT64) AS clicklist_gross_margin_dollars_pre
	, 'History load' original_file_name
	, '01/01/0001' file_dt
	, GENERATE_UUID() rctl_uuid
	, current_timestamp ingest_date
	, 'History load' rctl_file_name	
	, '""",job_run_id,"""' created_by 
	, current_datetime created_datetime 
	, '""",job_run_id,"""' modified_by 
	, current_datetime modified_datetime 
    , row_number() OVER (PARTITION BY PARSE_TIMESTAMP('%m/%d/%Y',c.gmi_week_start_dt),
      upc,
      subcommodity,
      item_description
    ORDER BY
      (TIMESTAMP_SECONDS(cast(k.pynamic_version_ts as INT64))) desc) rnk_1
  FROM
    `""",bq_prod_project_name,"""`.""",bq_prod_dataset_name,""".""",bq_raw_table_name,""" k
  JOIN
    `""",bq_project_name,"""`.""",bq_lkp_dataset_name,""".""",bq_lkp_table_name,""" c
  ON
    k.kroger_desc = c.kroger_desc)
SELECT
  grain,
  retailer,
  customer_name,
  kroger_desc,
  period_desc,
  gmi_week_start_dt,
  gmi_week_end_dt,
  primary_department,
  recap_department,
  department,
  source_category,
  source_sub_category,
  manufacturer,
  mfr_desc,
  source_item_code,
  itm_scn_prc_grp,
  itm_scn_prc_grp_desc,
  upc,
  source_item_name,
  scanned_retail_dollars_cur,
  scanned_movement_cur,
  gross_margin_dollars_cur,
  scanned_retail_dollars_pre,
  scanned_movement_pre,
  gross_margin_dollars_pre,
  ty_sales_value,
  ty_sales_units,
  clicklist_scanned_lbs_cur,
  clicklist_gross_margin_dollars_cur,
  clicklist_scanned_retail_dollars_pre,
  clicklist_scanned_movement_pre,
  clicklist_scanned_lbs_pre,
  clicklist_gross_margin_dollars_pre,
  original_file_name,
  file_dt,
  rctl_uuid,
  ingest_date,
  rctl_file_name,
  created_by,
  created_datetime,
  modified_by,
  modified_datetime
FROM
  raw_data
WHERE
  rnk_1 = 1
)
""") ;


EXCEPTION WHEN ERROR THEN
    SELECT  
	ERROR (
		CONCAT(
    			@@error.message ,' ' ,
    			@@error.statement_text, ' ' ,
    			@@error.formatted_stack_trace ,' '
			)
		)
	;

END;