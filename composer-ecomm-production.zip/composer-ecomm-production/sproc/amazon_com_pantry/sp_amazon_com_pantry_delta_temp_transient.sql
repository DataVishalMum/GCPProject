/*
Purpose of the stored proc: 
	Prcoess delta data for amazon com and pantry and insert the data in delta temp table.
History of Changes:
	04/19 – first version 
Author : 
	Navdisha Singla

Call for Amazon Pantry -
CALL transient.sp_amazon_com_pantry_delta_temp
(-99,
	'ecomm-dlf-dev-01cd47',
	'raw',
	'transient',
    'processed',
	'AMAZON_PANTRY',	
	'Pantry',  
	'amazon_pantry_sales',
    'amazon_pantry_delta_temp')
*/
CREATE PROCEDURE IF NOT EXISTS transient.sp_amazon_com_pantry_delta_temp
(job_run_id INT64,
	bq_project_name string,
	bq_raw_dataset_name string,
	bq_transient_dataset_name string,
    bq_processed_dataset_name string,
	customer_name string,	
	amazon_platform string, 
	raw_table_name string,
    target_table_name string)

BEGIN
DECLARE 
extract_start_date
	,extract_end_date Timestamp;

DECLARE vendor,retailer STRING;

-- Truncate target table
EXECUTE IMMEDIATE 
    CONCAT("""TRUNCATE TABLE `""",bq_project_name,""".""",bq_transient_dataset_name,""".""",target_table_name,"""`""");

/* Get Extract start datetime for incoming table from data_extract_config table */
EXECUTE IMMEDIATE
  CONCAT("""select extract_start_datetime from `""",bq_project_name,"""`.""",bq_transient_dataset_name,""".""","""data_extract_config
where table_name = '""",raw_table_name,"""' and status = 'running' 
and active_flag = 'Y'""") INTO extract_start_date;

/* Get Extract end datetime for incoming table from data_extract_config table */
EXECUTE IMMEDIATE
  CONCAT("""select extract_end_datetime from `""",bq_project_name,"""`.""",bq_transient_dataset_name,""".""", """data_extract_config 
  where table_name = '""",raw_table_name,"""' and status = 'running'  and active_flag = 'Y'""") INTO extract_end_date;
 
-- Extract Vendor details for amazon com and pantry. These are used when fetching data from amazon catalog mapping table.
EXECUTE IMMEDIATE 
  CONCAT("""Select 
  CASE WHEN '""",amazon_platform,"""' = 'Classic' THEN  'GENMI'
  WHEN '""",amazon_platform,"""' = 'Pantry' THEN  'GER1U'
  END AS vendor""") INTO vendor;

-- We have different retailer values for amazon com and pantry
EXECUTE IMMEDIATE
	CONCAT("""Select
	CASE WHEN '""",amazon_platform,"""' = 'Classic' THEN  'AMAZON CORE'
  	WHEN '""",amazon_platform,"""' = 'Pantry' THEN  'AMAZON PANTRY'
  	END AS vendor""") INTO retailer;
/*
- Sales calculation - We are calculating sales as addition of first party and third party sales if the manufacturer is not General Mills
                      If the manufacturer is general mills, the sales are calculated twice. once as the first part sales and once as the third party sales
                      This is done because a generalmills product is sols by both General Mills and Amazon 
- Fetching the cleansed/standardized UPC and product title from the standardized amazon lookup table.
- Cleansing the EAN before inserting it into delta table.
*/
EXECUTE IMMEDIATE
CONCAT("""
INSERT INTO `""",bq_project_name,""".""",bq_transient_dataset_name,""".""",target_table_name,"""`
with src_data as (select *,
 dense_rank() over (
							partition by 
										retailer_product_code,
										CAST(PARSE_DATE('%Y-%m-%d',date) AS timestamp)
							order by 
								PARSE_timestamp("%m-%d-%Y %H:%M:%S", file_dt) desc
						) rnk_1
						
	
		, row_number() over (
							partition by 
										retailer_product_code,
										CAST(PARSE_DATE('%Y-%m-%d',date) AS timestamp),
										PARSE_timestamp("%m-%d-%Y %H:%M:%S", file_dt)
							order by 
								 ingest_date desc
						) rnk_2 from `"""
 ,bq_project_name,""".""",bq_raw_dataset_name,""".""",raw_table_name,"""`
 where ingest_date > '""",extract_start_date,"""' 
 and ingest_date <= '""",extract_end_date,"""'
 and amazon_platform = '""",amazon_platform,"""'
 and custom_category <> 'Unique Product Sales'
 
 -- The below condition filters any blue buffalo data
 -- This is implemented as per the suggestion by Neal

      and (product_title not like '%Blue%Buffalo%'
or (upc not like '%840243%' and upc not like '%859610%'))),

 cleansed_ean as (select ean,""",bq_processed_dataset_name,""".checkingUpcEan(cast(ean as STRING),10,15) cleansed_ean from (select distinct ean from src_data)),
 third_party_data as (SELECT
    CASE
      WHEN manufacturer = 'General Mills' THEN CAST(src._1p__sales_ordered AS FLOAT64)
    ELSE
    (coalesce(CAST(src._1p__sales_ordered AS FLOAT64),0) + coalesce(SAFE_CAST(src._3p__sales_ordered AS FLOAT64),0))
    --(CAST(src._1p__sales_ordered AS FLOAT64) + CAST(src._3p__sales_ordered AS FLOAT64))
  END
    ty_sales_value,
    CASE
      WHEN manufacturer = 'General Mills' THEN CAST(src._1p_unit_sales_ordered AS INT64)
    ELSE
    (CAST(src._1p_unit_sales_ordered AS INT64) + CAST(src._3p_unit_sales_ordered AS INT64))
  END
    ty_sales_units,
    'N' AS is_3p,
    src.product_title AS source_item_name,
    src.retailer_product_code AS source_item_code,
	src.custom_category	source_category,
    amazon_platform,
    manufacturer,
    date
  FROM
    src_data src
  WHERE
    amazon_platform = '""",amazon_platform,"""' and rnk_1 = 1 and rnk_2 = 1
  UNION ALL
  SELECT
    CAST(src._3p__sales_ordered AS FLOAT64) AS ty_sales_value,
    CAST(src._3p_unit_sales_ordered AS INT64) AS ty_sales_units,
    'Y' AS is_3p,
    src.product_title AS source_item_name,
    src.retailer_product_code AS source_item_code,
	src.custom_category	source_category,
    amazon_platform,
    '3P GMI Sales' manufacturer,
    date
  FROM
    src_data src
  WHERE
    amazon_platform = '""",amazon_platform,"""'
    AND manufacturer = 'General Mills' and rnk_1 = 1 and rnk_2 = 1)
select
'DAY' AS grain ,
'""",retailer,"""' AS retailer,
'""",customer_name,"""' AS customer_name,
CAST(PARSE_DATE('%Y-%m-%d',src.date) AS timestamp) date,
src.custom_category source_category,
src.amazon_platform,
COALESCE(lkp.calculated_upc,clean_ean.cleansed_ean) upc,
clean_ean.cleansed_ean ean,
src.retailer_product_code source_item_code,
src.product_title source_item_name,
third_party.is_3p,
third_party.manufacturer,
third_party.ty_sales_value,
third_party.ty_sales_units,
cast(src._1p__sales_ordered as float64) _1p__sales_ordered,
cast(src._3p__sales_ordered as float64) _3p__sales_ordered,
cast(src.total__sales_ordered as float64) total__sales_ordered,
cast(src._1p_unit_sales_ordered as int64) _1p_unit_sales_ordered,
cast(src._3p_unit_sales_ordered as int64) _3p_unit_sales_ordered,
(cast(src._1p_unit_sales_ordered as int64)  * cast(COALESCE(mpp.eaches_in_title, '1') as int64)) frst_prty_adjusted_unit_sls,
(cast(src._3p_unit_sales_ordered as int64) * cast(COALESCE(mpp.eaches_in_title, '1') as int64)) thrd_prty_adjusted_unit_sls,
cast(src.total_unit_sales_ordered as int64) total_unit_sales_ordered,
src.product_model_number,
src.price price,
src.url url,
src.brand,
src.sub_brand,
src.sub_sub_brand,
src.account_category,
src.account_category_2,
src.account_category_3,
src.account_category_4,
src.account_category_5,
src.account_category_6,
src.op_unit_expanded_gmi_categories,
src.category_expanded_gmi_categories,
src.subcategory_expanded_gmi_categories,
lkp.cleansed_product_title,
mpp.product_group as amazon_catalog_product_group,
src.original_file_name,
src.file_dt,
src.rctl_uuid,
timestamp(src.ingest_date) ingest_date,
src.rctl_file_name,
'""",job_run_id,"""' created_by,
current_datetime created_datetime,
'""",job_run_id,"""' modified_by,
current_datetime modified_datetime
from src_data src
LEFT JOIN `""",bq_project_name,""".""",bq_transient_dataset_name,""".amazon_standardized_data_lookup` lkp
on COALESCE(src.upc,'') = COALESCE(lkp.upc,'')
AND COALESCE(src.product_title,'') = COALESCE(lkp.product_title,'')
AND COALESCE(src.retailer_product_code,'') = COALESCE(lkp.retailer_product_code,'')
AND COALESCE(src.amazon_platform,'') = COALESCE(lkp.amazon_platform,'')
left join cleansed_ean clean_ean
on src.ean = clean_ean.ean
LEFT JOIN third_party_data third_party
on COALESCE(src.retailer_product_code,'') = COALESCE(third_party.source_item_code,'')
and src.date = third_party.date
LEFT JOIN `""",bq_project_name,""".""",bq_processed_dataset_name,""".lkp_amazon_catalog_mapping` mpp on mpp.asin = src.retailer_product_code and mpp.vendor = '""",vendor,"""'
AND src.amazon_platform = '""",amazon_platform,"""'
WHERE src.custom_category <> 'Unique Product Sales'
AND (src.amazon_platform <> 'Classic' or COALESCE(mpp.product_group, 'NULL') <> 'Fresh_Perishable')
AND src.rnk_1 = 1 and src.rnk_2 = 1
""");
 EXCEPTION WHEN ERROR THEN
    SELECT  
	ERROR (
		CONCAT(
    			@@error.message ,' ' ,
    			@@error.statement_text, ' ' ,
    			@@error.formatted_stack_trace ,' '
			)
		)
	;
END;