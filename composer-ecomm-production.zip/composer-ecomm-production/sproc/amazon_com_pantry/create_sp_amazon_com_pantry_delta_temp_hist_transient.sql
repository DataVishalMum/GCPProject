/*
Purpose of the stored proc: 
	Prcoess history data for amazon com and pantry and insert the data in delta temp table.
History of Changes:
	06/01 – first version 
  06/22 - replaced dense_rank windowing function with row_number to remove duplicates
Author : 
	Navdisha Singla

Call for Amazon Pantry -
CALL transient.sp_amazon_com_pantry_delta_temp_hist
(-99,
	'ecomm-dlf-dev-01cd47',
	'transient',
  'processed',
  'shareddata-prd-cb5872',
  'shared_data_ecom',
	'AMAZON_PANTRY',	
	'Pantry',  
	'ecom_prftro_sle_shr_raw_v',
  'amazon_pantry_delta_temp')

  Amazon Com -
  CALL transient.sp_amazon_com_pantry_delta_temp_hist
(-99,
	'ecomm-dlf-dev-01cd47',
	'transient',
  'processed',
  'shareddata-prd-cb5872',
  'shared_data_ecom',
	'AMAZON_COM',	
	'Classic',  
	'ecom_prftro_sle_shr_raw_v',
  'amazon_com_delta_temp')
*/
CREATE PROCEDURE IF NOT EXISTS transient.sp_amazon_com_pantry_delta_temp_hist
(job_run_id INT64,
	bq_project_name string,
	bq_transient_dataset_name string,
  bq_processed_dataset_name string,
  bq_edw_project_name string,
  bq_ecom_dataset_name string,
	customer_name string,	
	amazon_platform string, 
	hist_table_name string,
  target_table_name string)

BEGIN

DECLARE vendor,retailer STRING;

-- Truncate target table
EXECUTE IMMEDIATE 
    CONCAT("""TRUNCATE TABLE `""",bq_project_name,""".""",bq_transient_dataset_name,""".""",target_table_name,"""`""");
 
-- Extract Vendor details for amazon com and pantry. These are used when fetching data from amazon catalog mapping table.
EXECUTE IMMEDIATE 
  CONCAT("""Select 
  CASE WHEN '""",amazon_platform,"""' = 'Classic' THEN  'GENMI'
  WHEN '""",amazon_platform,"""' = 'Pantry' THEN  'GER1U'
  END AS vendor""") INTO vendor;

-- We have different retailer values for amazon com and pantry
EXECUTE IMMEDIATE
	CONCAT("""Select
	CASE WHEN '""",amazon_platform,"""' = 'Classic' THEN  'AMAZON CORE'
  	WHEN '""",amazon_platform,"""' = 'Pantry' THEN  'AMAZON PANTRY'
  	END AS vendor""") INTO retailer;
/*
- Sales calculation - We are calculating sales as addition of first party and third party sales if the manufacturer is not General Mills
                      If the manufacturer is general mills, the sales are calculated twice. once as the first part sales and once as the third party sales
                      This is done because a generalmills product is sols by both General Mills and Amazon 
- Fetching the cleansed/standardized UPC and product title from the standardized amazon lookup table.
- Cleansing the EAN before inserting it into delta table.
*/
EXECUTE IMMEDIATE
CONCAT("""
INSERT INTO `""",bq_project_name,""".""",bq_transient_dataset_name,""".""",target_table_name,"""`
with src_data as (select *
 -- the following ranking is done to avoid duplicates if there are duplicates
	-- for the same vendor file natural key in the raw table replicated from hadoop. 
	-- The data is partitioned on the natural key of the vendor file. 
	-- The data is then ordered descending on hadoop_update_ts which is 
	-- the create timestamp of the record in the raw table.  
	-- Picking rank = 1 will result in the record with latest create timestamp 
	-- to be selected in case duplicate records exist in the raw table 
	-- ***across different create timestamps***.
  -- row_number() removes exact duplicates from the source
	
	, row_number() over (
							partition by 
										retailer_product_code,
                    CAST(PARSE_DATE('%Y-%m-%d',date) AS timestamp)
							order by 
								hadoop_update_ts desc
						) rnk_1 from `"""
 ,bq_edw_project_name,""".""",bq_ecom_dataset_name,""".""",hist_table_name,"""`
 where amazon_platform = '""",amazon_platform,"""'
 and custom_category <> 'Unique Product Sales'

 -- The below condition filters any blue buffalo data
 -- This is implemented as per the suggestion by Neal

      and (product_title not like '%Blue%Buffalo%'
or (upc not like '%840243%' and upc not like '%859610%'))),

 cleansed_ean as (select ean,""",bq_processed_dataset_name,""".checkingUpcEan(cast(ean as STRING),10,15) cleansed_ean from (select distinct ean from src_data)),
 third_party_data as (SELECT
    CASE
    WHEN manufacturer = 'General Mills' THEN SAFE_CAST(src._1p__sales_ordered AS FLOAT64)
  ELSE
  (coalesce(CAST(src._1p__sales_ordered AS FLOAT64),0) + coalesce(SAFE_CAST(src._3p__sales_ordered AS FLOAT64),0))
   --(CAST(src._1p__sales_ordered AS FLOAT64) + SAFE_CAST(src._3p__sales_ordered AS FLOAT64))
  END
    ty_sales_value,
    CASE
      WHEN manufacturer = 'General Mills' THEN CAST(IF(src._1p_unit_sales_ordered= 'N/A' ,'0' ,src._1p_unit_sales_ordered) AS NUMERIC)
    ELSE
    (CAST(IF(src._1p_unit_sales_ordered= 'N/A' ,'0' ,src._1p_unit_sales_ordered) AS NUMERIC) + CAST(IF(src._3p_unit_sales_ordered= 'N/A' ,'0' ,src._3p_unit_sales_ordered) AS NUMERIC))
  END
    ty_sales_units,
    'N' AS is_3p,
    src.product_title AS source_item_name,
    src.retailer_product_code AS source_item_code,
	src.custom_category	source_category,
    amazon_platform,
    manufacturer,
    date
  FROM
    src_data src
  WHERE
    amazon_platform = '""",amazon_platform,"""'
    and rnk_1= 1
  UNION ALL
  SELECT
    CAST(src._3p__sales_ordered AS FLOAT64) AS ty_sales_value,
    CAST(src._3p_unit_sales_ordered AS INT64) AS ty_sales_units,
    'Y' AS is_3p,
    src.product_title AS source_item_name,
    src.retailer_product_code AS source_item_code,
	src.custom_category	source_category,
    amazon_platform,
    '3P GMI Sales' manufacturer,
    date
  FROM
    src_data src
  WHERE
    amazon_platform = '""",amazon_platform,"""'
    AND manufacturer = 'General Mills'
    and rnk_1 = 1)
select
'DAY' AS grain ,
'""",retailer,"""' AS retailer,
'""",customer_name,"""' AS customer_name,
CAST(PARSE_DATE('%Y-%m-%d',src.date) AS timestamp) date,
third_party.source_category,
src.amazon_platform,
COALESCE(lkp.calculated_upc,clean_ean.cleansed_ean) upc,
clean_ean.cleansed_ean ean,
third_party.source_item_code,
third_party.source_item_name,
third_party.is_3p,
third_party.manufacturer,
third_party.ty_sales_value,
cast(third_party.ty_sales_units AS INT64),
SAFE_CAST(src._1p__sales_ordered as float64) _1p__sales_ordered,
SAFE_CAST(src._3p__sales_ordered as float64) _3p__sales_ordered,
SAFE_CAST(src.total__sales_ordered as float64) total__sales_ordered,
cast(cast(IF(src._1p_unit_sales_ordered = 'N/A' ,'0' ,src._1p_unit_sales_ordered) as numeric) AS int64) _1p_unit_sales_ordered,
cast(cast(IF(src._3p_unit_sales_ordered = 'N/A' ,'0' ,src._3p_unit_sales_ordered) as numeric) AS int64) _3p_unit_sales_ordered,
(cast(cast(IF(src._1p_unit_sales_ordered = 'N/A' ,'0' ,src._1p_unit_sales_ordered) as numeric) AS int64)  * cast(COALESCE(mpp.eaches_in_title, '1') as int64)) frst_prty_adjusted_unit_sls,
(cast(cast(IF(src._3p_unit_sales_ordered = 'N/A' ,'0' ,src._3p_unit_sales_ordered) as numeric) AS int64) * cast(COALESCE(mpp.eaches_in_title, '1') as int64)) thrd_prty_adjusted_unit_sls,
cast(cast(IF(src.total__sales_ordered = 'N/A' ,'0' ,src.total__sales_ordered) as numeric) AS int64) total_unit_sales_ordered,
src.product_model_number,
src.price price,
src.url url,
src.brand,
src.sub_brand,
src.sub_sub_brand,
src.account_category,
src.account_category_2,
src.account_category_3,
src.account_category_4,
src.account_category_5,
src.account_category_6,
src.op_unit_expanded_gmi_categories,
src.category_expanded_gmi_categories,
src.subcategory_expanded_gmi_categories,
lkp.cleansed_product_title,
mpp.product_group as amazon_catalog_product_group,
'History load' original_file_name,
'01/01/0001' file_dt,
GENERATE_UUID() rctl_uuid,
current_timestamp ingest_date,
'History load' rctl_file_name,
'""",job_run_id,"""' created_by,
current_datetime created_datetime,
'""",job_run_id,"""' modified_by,
current_datetime modified_datetime
from src_data src
LEFT JOIN `""",bq_project_name,""".""",bq_transient_dataset_name,""".amazon_standardized_data_lookup` lkp
on 
COALESCE(src.upc,'') = COALESCE(lkp.upc,'')
AND COALESCE(src.product_title,'') = COALESCE(lkp.product_title,'')
AND COALESCE(src.retailer_product_code,'') = COALESCE(lkp.retailer_product_code,'')
AND COALESCE(src.amazon_platform,'') = COALESCE(lkp.amazon_platform,'')
left join cleansed_ean clean_ean
on src.ean = clean_ean.ean
LEFT JOIN third_party_data third_party
on COALESCE(src.retailer_product_code,'') = COALESCE(third_party.source_item_code,'')
and src.date = third_party.date
LEFT JOIN `""",bq_project_name,""".""",bq_processed_dataset_name,""".lkp_amazon_catalog_mapping` mpp on mpp.asin = src.retailer_product_code and mpp.vendor = '""",vendor,"""'
AND src.amazon_platform = '""",amazon_platform,"""'
WHERE src.custom_category <> 'Unique Product Sales'
AND (src.amazon_platform <> 'Classic' or COALESCE(mpp.product_group, 'NULL') <> 'Fresh_Perishable')
and src.rnk_1 = 1
""");
 EXCEPTION WHEN ERROR THEN
    SELECT  
	ERROR (
		CONCAT(
    			@@error.message ,' ' ,
    			@@error.statement_text, ' ' ,
    			@@error.formatted_stack_trace ,' '
			)
		)
	;
END;