/*
Purpose of the stored proc: 
	This stored procedure processes the history data
	Map the source UPC to cleansed UPC
    Calculate the correct value of the UPC using harmonized UPC table and amazon catalog mapping table
    Map source product title to cleansed product title
    Standardize product title and UPC, so that UPC and product title make a unique pair

History of Changes:
	06/01 – first version 
Author : 
	Navdisha Singla

Call statement for Pantry -
CALL transient.sp_amazon_standardized_data_lookup_hist
( 
	-99,
	'ecomm-dlf-dev-01cd47',
	'transient',
    'processed',
	'shareddata-prd-cb5872',
	'shared_data_ecom',	
	'Pantry', 
	'ecom_prftro_sle_shr_raw_v'
)
Call statement for Com -
CALL transient.sp_amazon_standardized_data_lookup_hist
( 
	-99,
	'ecomm-dlf-dev-01cd47',
	'transient',
    'processed',
	'shareddata-prd-cb5872',
	'shared_data_ecom',	
	'Classic', 
	'ecom_prftro_sle_shr_raw_v'
)
*/
CREATE PROCEDURE IF NOT EXISTS transient.sp_amazon_standardized_data_lookup_hist
( 
	job_run_id INT64,
	bq_project_name string,
	bq_transient_dataset_name string,
    bq_processed_dataset_name string,	
	bq_edw_project_name string,
    bq_ecom_dataset_name string,
	amazon_platform string, 
	hist_table_name string
)
BEGIN

DECLARE vendor,sql STRING;

-- Fetch the vendor value for amazon com and pantry. This is used while fetching data from amazon catalog mapping table
EXECUTE IMMEDIATE 
  CONCAT("""Select 
  CASE WHEN '""",amazon_platform,"""' = 'Classic' THEN  'GENMI'
  WHEN '""",amazon_platform,"""' = 'Pantry' THEN  'GER1U'
  END AS vendor""") INTO vendor;
/*
Map the source UPC to cleansed UPC
Calculate the correct value of the UPC using harmonized UPC table and amazon catalog mapping table
Map source product title to cleansed product title
Standardize product title and UPC, so that UPC and product title make a unique pair
If the product title already exists, it updates it, otherwise inserts a new record.
*/

SET sql =
CONCAT("""
MERGE INTO
  `""",bq_project_name,""".""",bq_transient_dataset_name,""".amazon_standardized_data_lookup` AS lkp_data
USING
  (
  WITH
    src_data AS (
    SELECT
      DISTINCT upc,
      product_title,
      retailer_product_code,
      CAST(PARSE_DATE('%Y-%m-%d',date) AS timestamp) date,
      amazon_platform
    FROM
      `""",bq_edw_project_name,""".""",bq_ecom_dataset_name,""".""",hist_table_name,"""`

    -- We are NOT filtering on amazon platform because we need both the platforms to calculate equivalent UPC is the UPC is NULL

    WHERE
      custom_category <> 'Unique Product Sales'

    -- The below condition filters any blue buffalo data
    -- This is implemented as per the suggestion by Neal

      and (product_title not like '%Blue%Buffalo%'
or (upc not like '%840243%' and upc not like '%859610%'))),

    cleansed_data AS (
    SELECT
      upc,
      product_title,
      date,
      retailer_product_code,
      amazon_platform,
      """,bq_processed_dataset_name,""".checkingUpcEan(upc,
        10,
        14) cleansed_upc,
      """,bq_processed_dataset_name,""".amazonProductTitle(product_title) cleansed_prod_title
    FROM
      src_data),

  -- Self tuning logic
  -- Fetches the latest UPC for a product title 

    upc_master AS (
    SELECT
      product_title,
      cleansed_upc,
      ROW_NUMBER() OVER (PARTITION BY product_title ORDER BY date DESC) AS rnk
    FROM
      cleansed_data
    WHERE
      LENGTH(cleansed_upc) >= 10
      AND product_title IS NOT NULL ),

    self_tuned AS (
    SELECT

    -- We fetch the latest UPC if exists, otherwise the cleansed source UPC.

      COALESCE(upc_master.cleansed_upc,
        cleansed.cleansed_upc) upc_self_tuned,
      cleansed.*
    FROM
      cleansed_data cleansed
    LEFT OUTER JOIN
      upc_master upc_master
    ON
      cleansed.product_title = upc_master.product_title
      AND upc_master.rnk = 1)

  SELECT
    * EXCEPT(rnk)
  FROM (
    SELECT
      DISTINCT s.upc,
      s.cleansed_upc,
      coalesce(mpc.pkg_upc,
        s.cleansed_upc,
        s.upc_self_tuned,
        xref.upc) AS calculated_upc,
      s.product_title,
      s.cleansed_prod_title cleansed_product_title,
      s.amazon_platform,
      s.retailer_product_code,
      ROW_NUMBER() OVER (PARTITION BY s.cleansed_upc, s.product_title, s.retailer_product_code,s.amazon_platform ORDER BY s.date DESC) rnk
    FROM
      self_tuned s
    LEFT OUTER JOIN
      `""",bq_edw_project_name,""".""",bq_ecom_dataset_name,""".ecom_data_harmonized_upc_xref` xref
    ON
      s.cleansed_prod_title = xref.product_title
    LEFT OUTER JOIN
      `""",bq_project_name,""".""",bq_processed_dataset_name,""".lkp_amazon_catalog_mapping` mpc
    ON
      mpc.asin = s.retailer_product_code
      AND mpc.vendor = '""",vendor,"""')
  WHERE
    rnk = 1
    AND coalesce(cleansed_upc,
      product_title,
      retailer_product_code,
      'null') <> 'null')delta_data
ON
  COALESCE(lkp_data.upc,
    'null') = COALESCE(delta_data.upc,
    'null')
  AND COALESCE(lkp_data.product_title,
    'null') = COALESCE(delta_data.product_title,
    'null')
  AND COALESCE(lkp_data.retailer_product_code,
    'null') = COALESCE(delta_data.retailer_product_code,
    'null')
    AND COALESCE(lkp_data.amazon_platform,
    'null') = COALESCE(delta_data.amazon_platform,
    'null')
  WHEN MATCHED THEN UPDATE SET lkp_data.upc = delta_data.upc,
   lkp_data.cleansed_upc = delta_data.cleansed_upc,
    lkp_data.calculated_upc = delta_data.calculated_upc,
	 lkp_data.product_title = delta_data.product_title,
	  lkp_data.cleansed_product_title = delta_data.cleansed_product_title,
	   lkp_data.amazon_platform = delta_data.amazon_platform,
	    modified_by = '""",job_run_id,"""',
		 modified_datetime = current_datetime()
  WHEN NOT MATCHED
  THEN
INSERT
  (upc,
    cleansed_upc,
    calculated_upc,
    product_title,
    cleansed_product_title,
    amazon_platform,
	retailer_product_code,
    created_by,
    created_datetime,
    modified_by,
    modified_datetime)
VALUES
  (delta_data.upc,
  delta_data.cleansed_upc,
  delta_data.calculated_upc,
  delta_data.product_title,
  delta_data.cleansed_product_title,
  delta_data.amazon_platform,
  delta_data.retailer_product_code,
  '""",job_run_id,"""',
  current_datetime(),
  '""",job_run_id,"""',
  current_datetime())""");
EXECUTE IMMEDIATE sql;
EXCEPTION WHEN ERROR THEN
    SELECT  
	ERROR (
		CONCAT(
    			@@error.message ,' ' ,
    			@@error.statement_text, ' ' ,
    			@@error.formatted_stack_trace ,' '
			)
		)
	;
END;