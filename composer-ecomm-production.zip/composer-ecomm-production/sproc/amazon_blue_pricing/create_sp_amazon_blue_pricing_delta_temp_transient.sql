/*
Purpose of the stored proc: 
	Delta Data extraction for 'amazon_blue' customer
History of Changes:
	10/10 – first version
Author : 
	Pawan Rathod
How to Call:
		call transient.sp_amazon_blue_delta_temp
		(
		 99,
		'ecomm-dlf-dev-01cd47',
		'raw',
		'transient' ,
		'amazon_blue_sales',
		'amazon_blue_delta_temp',
		'AMAZON_BLUE_PRICING'
		);

One time : INSERT INTO `ecomm-dlf-dev-01cd47.transient.gmi_customer_metadata_reference` VALUES ('AMAZON_BLUE_PRICING','AMAZON_BLUE_PRICING','upc,report_date','customer_name,upc,source_item_name','upc,fiscal_year_week_nbr,source_item_name,manufacturer,customer_account,resolved_category,global_category_parent,resolved_brand,zone_hierarchy','customer_name,source_item_name,upc,source_product_hash','report_date','','AMAZON_BLUE_PRICING','','ty_cogs_value,ly_cogs_value','gss_sales_share_blue_report');
insert into `ecomm-dlf-dev-01cd47.transient.data_extract_config`  values ( 'amazon_blue_pricing_sales', cast ('1800-01-01 00:00:00' as timestamp), cast ('1800-01-01 00:00:00' as timestamp), 'Y','complete','GMI',current_timestamp,'GMI',current_timestamp ) ;
*/

CREATE PROCEDURE IF NOT EXISTS
  transient.sp_amazon_blue_pricing_delta_temp ( job_run_id int64,
    bq_project_name string,
    bq_raw_dataset_name string,
    bq_transient_dataset_name string,
    bq_raw_table_name string,
    bq_delta_temp_tablename string,
    customer_name string )
BEGIN

-- declare variables
DECLARE 
	 extract_start_date
	,extract_end_date Timestamp;

/* Get Extract start datetime for incoming table from data_extract_config table */
EXECUTE IMMEDIATE
  CONCAT("""select extract_start_datetime from `""",bq_project_name,"""`.""",bq_transient_dataset_name,""".""","""data_extract_config
where table_name = '""",bq_raw_table_name,"""' and status = 'running'
and active_flag = 'Y'""") INTO extract_start_date;

/* Get Extract end datetime for incoming table from data_extract_config table */
EXECUTE IMMEDIATE
  CONCAT("""select extract_end_datetime from `""",bq_project_name,"""`.""",bq_transient_dataset_name,""".""", """data_extract_config 
  where table_name = '""",bq_raw_table_name,"""' and status = 'running'  and active_flag = 'Y'""") INTO extract_end_date;

/* Delta Temp Table is Truncate & Load */
EXECUTE IMMEDIATE
CONCAT("""TRUNCATE TABLE  `""" ,bq_project_name,"""`.""",bq_transient_dataset_name,""".""",bq_delta_temp_tablename);

	/*Insert Details for passed customer into 'amazon_blue_delta_temp' table having ingest date greater than extract_start_date
from data_extract_config table */
EXECUTE IMMEDIATE
CONCAT("""insert into  `""" ,bq_project_name,"""`.""",bq_transient_dataset_name,""".""",bq_delta_temp_tablename,
"""
(
   WITH
     dr AS (
     SELECT
       'WEEK' AS grain,
       'AMAZON_BLUE_PRICING' AS retailer,
       '""",customer_name,"""' AS customer_name,
       CAST(DATE_ADD(COALESCE(SAFE.PARSE_DATE('%D',TRIM(report_date)),SAFE.PARSE_DATE('%F',TRIM(report_date))), INTERVAL 1 DAY) as TIMESTAMP) AS report_date,
       azn.asin AS asin,
       azn.ean AS ean,
       bb.nielsenupc AS upc,
       azn.upc AS nielsen_upc,
       azn.product_title AS source_item_name,
       COALESCE(bb.nielsenupc,azn.upc) AS source_item_code,
       azn.brand AS brand,
       azn.subcategory AS subcategory,
       azn.category AS source_category,
       COALESCE(SAFE_CAST(regexp_replace(azn.shipped_COGS, r"[^0-9.]", '') AS FLOAT64),0) AS ty_cogs_value,
       COALESCE(SAFE_CAST(regexp_replace(azn.shippedCOGS_last_yr, r"[^0-9.]", '') AS FLOAT64),0) AS shipped_COGS_last_yr,
       COALESCE(SAFE_CAST(regexp_replace(azn.shipped_COGS_percent_of_tot, r"[^0-9.]", '') AS FLOAT64),0) AS shipped_COGS_percent_of_tot,
       COALESCE(SAFE_CAST(regexp_replace(azn.shipped_COGS_prior_period, r"[^0-9.]", '') AS FLOAT64),0) AS shipped_COGS_prior_period,
       COALESCE(SAFE_CAST(regexp_replace(azn.shipped_units_percent_of_tot, r"[^0-9.]", '') AS FLOAT64),0) AS shipped_units_percent_of_tot,
       COALESCE(SAFE_CAST(regexp_replace(azn.shipped_units_prior_period, r"[^0-9.]", '') AS FLOAT64),0) AS shipped_units_prior_period,
       COALESCE(SAFE_CAST(regexp_replace(azn.shipped_units_last_yr, r"[^0-9.]", '') AS FLOAT64),0) AS shipped_units_last_yr,

       COALESCE(SAFE_CAST(ROUND(SAFE_CAST(regexp_replace(azn.customer_returns, r"[^0-9.]", '')  AS FLOAT64)) AS INT64),0) AS customer_returns,
       COALESCE(SAFE_CAST(ROUND(SAFE_CAST(regexp_replace(azn.free_replacements, r"[^0-9.]", '')  AS FLOAT64)) AS INT64),0) AS free_replacements,

       COALESCE(SAFE_CAST(regexp_replace(azn.avg_sales_price, r"[^0-9.]", '')  AS FLOAT64),0) AS avg_sales_price,
       COALESCE(SAFE_CAST(regexp_replace(azn.avg_sales_price_prior_period, r"[^0-9.]", '')  AS FLOAT64),0) AS avg_sales_price_prior_period,

       COALESCE(SAFE_CAST(regexp_replace(azn.avg_sales_price, r"[^0-9.]", '') AS FLOAT64),0) * COALESCE(SAFE_CAST(ROUND(SAFE_CAST(regexp_replace(azn.shipped_units, r"[^0-9.]", '') AS FLOAT64)) AS INT64),0) AS ty_sales_value,
       COALESCE(SAFE_CAST(ROUND(SAFE_CAST(regexp_replace(azn.shipped_units, r"[^0-9.]", '')  AS FLOAT64)) AS INT64),0) AS ty_sales_units,
       azn.original_file_name,
       azn.file_dt,
       azn.rctl_uuid,
       TIMESTAMP(azn.ingest_date) ingest_date,
       azn.rctl_file_name,
       '""",job_run_id,"""' created_by,
       current_datetime created_datetime,
       '""",job_run_id,"""' modified_by,
       current_datetime modified_datetime,

	   -- the following ranking is done to avoid duplicates if multiple files
	   -- are loaded in one run. The data is partitioned on the natural key
	   -- of the file. The data is then ordered descending on file_dt which is
	   -- the timestamp on the file.  Picking rank = 1 will result in the record
	   -- with latest file_dt being picked in case duplicate records
	   -- exist in the raw table ***across different files***.

       DENSE_RANK() OVER (PARTITION BY azn.upc,report_date
                          ORDER BY PARSE_TIMESTAMP("%m-%d-%Y %H:%M:%S", azn.file_dt) DESC
                          ) AS rnk_1,

	   -- the following ranking is done to avoid duplicates if the ****same file
	   -- is loaded multiple times****. The data is partitioned on the natural key
	   -- of the file and the file_dt which is the timestamp on the file
	   -- The data is then ordered descending on ingest_date which is the current timestamp
	   -- coming from the ingestion framework.  Picking rank = 1 will result
	   -- in the record with latest ingest_date being picked in case duplicate records
	   -- exist in the raw table.  THIS SCENARIO WILL TYPICALLY NOT OCCUR.
	   -- Please note the use of ROW_NUMBER function to pick one record.
	   -- This function will be needed when the entire RAW table is read to reprocess history.

       ROW_NUMBER() OVER (PARTITION BY
                          azn.upc,
                          report_date,
                          azn.product_title,
                          PARSE_TIMESTAMP("%m-%d-%Y %H:%M:%S", azn.file_dt)
                          ORDER BY azn.ingest_date DESC, COALESCE(SAFE_CAST(regexp_replace(azn.avg_sales_price, r"[^0-9.]", '') AS FLOAT64),0) * COALESCE(SAFE_CAST(ROUND(SAFE_CAST(regexp_replace(azn.shipped_units, r"[^0-9.]", '') AS FLOAT64)) AS INT64),0) DESC
                          ) rnk_2

       FROM
         `""" ,bq_project_name,"""`.""",bq_raw_dataset_name,""".""",bq_raw_table_name,""" azn
       LEFT JOIN
         `""" ,bq_project_name,"""`.processed.lkp_stonehenge_product_master bb on bb.platformproductidentifier = azn.asin
       WHERE
             azn.ingest_date > '""",extract_start_date,"""'
	     AND azn.ingest_date <= '""",extract_end_date,"""' AND (UPPER(bb.platformname) = 'AMAZON 1ST PARTY' or bb.platformname is null))
   SELECT
     grain,
     retailer,
     customer_name,
     report_date,
     asin,
     ean,
     upc,
     nielsen_upc,
     source_item_name,
     source_item_code,
     brand,
     subcategory,
     source_category,
     ty_cogs_value,
     shipped_COGS_last_yr,
     shipped_COGS_percent_of_tot,
     shipped_COGS_prior_period,
     shipped_units_percent_of_tot,
     shipped_units_prior_period,
     shipped_units_last_yr,
     customer_returns,
     free_replacements,
     avg_sales_price,
     avg_sales_price_prior_period,
     ty_sales_value,
     ty_sales_units,
     original_file_name,
     file_dt,
     ingest_date,
     rctl_file_name,
     rctl_uuid,
     created_by,
     created_datetime,
     modified_by,
     modified_datetime
   FROM
     dr
   WHERE
     rnk_1 = 1
     AND rnk_2 = 1
 )
""") ;

EXCEPTION WHEN ERROR THEN
    SELECT  
	ERROR (
		CONCAT(
    			@@error.message ,' ' ,
    			@@error.statement_text, ' ' ,
    			@@error.formatted_stack_trace ,' '
			)
		)
	;

END;

