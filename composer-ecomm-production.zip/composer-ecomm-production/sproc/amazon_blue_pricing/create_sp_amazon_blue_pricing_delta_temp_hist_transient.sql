/*
Purpose of the stored proc:
	Delta Data extraction for 'amazon_blue' customer
History of Changes:
	10/11 – first version
Author :
	Pawan Rathod
How to Call:
		call transient.sp_amazon_blue_delta_temp_hist
		(
		 -99,
		'ecomm-dlf-dev-01cd47',
		'transient' ,
		'AMAZON_BLUE_PRICING',
		'shareddata-prd-cb5872',
		'sales_ecomm_global_sales_and_share',
		'ecom_blue_amazon_pricing_v'
		)

*/


CREATE PROCEDURE IF NOT EXISTS transient.sp_amazon_blue_pricing_delta_temp_hist
(
	job_run_id INT64,
	bq_project_name string,
	bq_transient_dataset_name string,
	customer_name string,
	bq_prod_project_name string,
	bq_prod_dataset_name string,
	raw_table_name string
)
BEGIN


/* Delta Temp Table is Truncate & Load */
EXECUTE IMMEDIATE
CONCAT("""TRUNCATE TABLE  `""" ,bq_project_name,"""`.""",bq_transient_dataset_name,""".""","""amazon_blue_delta_temp""");

	/*Insert Details for passed customer into 'amazon_blue_delta_temp' table having ingest date greater than extract_start_date
from data_extract_config table */
EXECUTE IMMEDIATE
CONCAT(
"""insert into  `""" ,bq_project_name,"""`.""",bq_transient_dataset_name,""".""","""amazon_blue_delta_temp
(
   WITH
     dr AS (
	SELECT
       'WEEK' AS grain,
       'AMAZON_BLUE_PRICING' AS retailer,
       '""",customer_name,"""' AS customer_name,
       CAST(DATE_ADD(PARSE_DATE('%m/%d/%Y',trim(azn.report_date)), INTERVAL 1 DAY) as TIMESTAMP) AS report_date,
       azn.asin AS asin,
       azn.ean AS ean,
       azn.upc AS upc,
       bb.nielsenupc AS nielsen_upc,
       azn.product_title AS source_item_name,
       COALESCE(azn.upc,bb.nielsenupc) AS source_item_code,
       azn.brand AS brand,
       azn.subcategory AS subcategory,
       azn.category AS source_category,
       COALESCE(SAFE_CAST(azn.shipped_COGS AS FLOAT64),0) AS ty_cogs_value,
       COALESCE(SAFE_CAST(azn.shippedCOGS_last_yr AS FLOAT64),0) AS ly_cogs_value,
       COALESCE(SAFE_CAST(azn.shipped_COGS_percent_of_tot AS FLOAT64),0) AS shipped_COGS_percent_of_tot,
       COALESCE(SAFE_CAST(azn.shipped_COGS_prior_period AS FLOAT64),0) AS shipped_COGS_prior_period,
       COALESCE(SAFE_CAST(azn.shipped_units_percent_of_tot AS FLOAT64),0) AS shipped_units_percent_of_tot,
       COALESCE(SAFE_CAST(azn.shipped_units_prior_period AS FLOAT64),0) AS shipped_units_prior_period,
       COALESCE(SAFE_CAST(azn.shipped_units_last_yr AS FLOAT64),0) AS shipped_units_last_yr,
       COALESCE(SAFE_CAST(ROUND(SAFE_CAST(azn.ordered_units AS DECIMAL)) AS INT64),0) AS ordered_units,
       COALESCE(SAFE_CAST(azn.ordered_units_percent_of_tot AS FLOAT64),0) AS ordered_units_percent_of_tot,
       COALESCE(SAFE_CAST(azn.ordered_units_prior_period AS FLOAT64),0) AS ordered_units_prior_period,
       COALESCE(SAFE_CAST(azn.ordered_units_last_yr AS FLOAT64),0) AS ordered_units_last_yr,
       COALESCE(SAFE_CAST(ROUND(SAFE_CAST(azn.customer_returns AS DECIMAL)) AS INT64),0) AS customer_returns,
       COALESCE(SAFE_CAST(ROUND(SAFE_CAST(azn.free_replacements AS DECIMAL)) AS INT64),0) AS free_replacements,
       COALESCE(SAFE_CAST(ROUND(SAFE_CAST(azn.subcategory_sales_rank AS DECIMAL)) AS INT64),0) AS subcategory_sales_rank,
       COALESCE(SAFE_CAST(azn.avg_sales_price AS FLOAT64),0) AS avg_sales_price,
       COALESCE(SAFE_CAST(azn.avg_sales_price_prior_period AS FLOAT64),0) AS avg_sales_price_prior_period,
       COALESCE(SAFE_CAST(ROUND(SAFE_CAST(azn.glance_views AS DECIMAL)) AS INT64),0) AS glance_views,
       COALESCE(SAFE_CAST(azn.change_in_GV_prior_period AS FLOAT64),0) AS change_in_GV_prior_period,
       COALESCE(SAFE_CAST(azn.change_in_GV_last_year AS FLOAT64),0) AS change_in_GV_last_year,
       COALESCE(SAFE_CAST(azn.conversion_rate AS FLOAT64),0) AS conversion_rate,
       COALESCE(SAFE_CAST(azn.rep_OOS AS FLOAT64),0) AS rep_OOS,
       COALESCE(SAFE_CAST(azn.rep_OOS_percent_of_total AS FLOAT64),0) AS rep_OOS_percent_of_total,
       COALESCE(SAFE_CAST(azn.rep_OOS_prior_period AS FLOAT64),0) AS rep_OOS_prior_period,
       COALESCE(SAFE_CAST(azn.LBB_price AS FLOAT64),0) AS LBB_price,
       COALESCE(SAFE_CAST(azn.avg_sales_price AS FLOAT64),0) * COALESCE(SAFE_CAST(ROUND(SAFE_CAST(azn.shipped_units AS DECIMAL)) AS INT64),0) AS ty_sales_value,
       COALESCE(SAFE_CAST(ROUND(SAFE_CAST(azn.shipped_units AS DECIMAL)) AS INT64),0) AS ty_sales_units,
       'History load' original_file_name,
       '01/01/0001' file_dt,
       GENERATE_UUID() rctl_uuid,
       current_timestamp ingest_date,
       'History load' rctl_file_name,
       '""",job_run_id,"""' created_by,
       current_datetime created_datetime,
       '""",job_run_id,"""' modified_by,
       current_datetime modified_datetime,

	-- the following ranking is done to avoid duplicates if there are duplicates
	-- for the same vendor file natural key in the raw table replicated from hadoop.
	-- The data is partitioned on the natural key of the vendor file.
	-- The data is then ordered descending on pynamic_version_ts which is
	-- the create timestamp of the record in the raw table.
	-- Picking rank = 1 will result in the record with latest create timestamp
	-- to be selected in case duplicate records exist in the raw table
	-- ***across different create timestamps***.

       ROW_NUMBER() over (
							partition by
										azn.upc,
										report_date
							ORDER BY hadoop_update_ts DESC, COALESCE(SAFE_CAST(azn.avg_sales_price AS FLOAT64),0) * COALESCE(SAFE_CAST(ROUND(SAFE_CAST(azn.shipped_units AS DECIMAL)) AS INT64),0) DESC
						) rnk_1

	   FROM
		`""" ,bq_prod_project_name,"""`.""",bq_prod_dataset_name,""".""",raw_table_name,""" azn
       LEFT JOIN
         `""" ,bq_project_name,"""`.processed.lkp_stonehenge_product_master bb on bb.platformproductidentifier = azn.asin
       WHERE (UPPER(bb.platformname) = 'AMAZON 1ST PARTY' or bb.platformname is null)
)
    SELECT
     grain,
     retailer,
     customer_name,
     report_date,
     asin,
     ean,
     upc,
     nielsen_upc,
     source_item_name,
     source_item_code,
     brand,
     subcategory,
     source_category,
     ty_cogs_value,
     ly_cogs_value,
     shipped_COGS_percent_of_tot,
     shipped_COGS_prior_period,
     shipped_units_percent_of_tot,
     shipped_units_prior_period,
     shipped_units_last_yr,
     ordered_units,
     ordered_units_percent_of_tot,
     ordered_units_prior_period,
     ordered_units_last_yr,
     customer_returns,
     free_replacements,
     subcategory_sales_rank,
     avg_sales_price,
     avg_sales_price_prior_period,
     glance_views,
     change_in_GV_prior_period,
     change_in_GV_last_year,
     conversion_rate,
     rep_OOS,
     rep_OOS_percent_of_total,
     rep_OOS_prior_period,
     LBB_price,
     ty_sales_value,
     ty_sales_units,
     original_file_name,
     file_dt,
     ingest_date,
     rctl_file_name,
     rctl_uuid,
     created_by,
     created_datetime,
     modified_by,
     modified_datetime
    from
		dr
	where
		rnk_1 = 1
 )
""") ;

EXCEPTION WHEN ERROR THEN
    SELECT
	ERROR (
		CONCAT(
    			@@error.message ,' ' ,
    			@@error.statement_text, ' ' ,
    			@@error.formatted_stack_trace ,' '
			)
		)
	;

END;
