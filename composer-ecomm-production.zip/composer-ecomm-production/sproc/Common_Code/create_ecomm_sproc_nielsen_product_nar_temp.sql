  /* 
  Purpose OF the stored proc : 
		Nielsen Product Temp TABLE DATA insertion 
  History OF Changes : 
        03/23 first version
		06/09 Changed Nielsen connect source table name
		05/10 - Updated composer related params and added sproc error mechanism
  Author : 
		Pawan Rathod

  */
CREATE OR REPLACE PROCEDURE
  transient.ecomm_sproc_nielsen_product_nar_temp (
    SRC_PROJECT STRING,
    SRC_DATASET STRING,
    XREF_DATASET STRING,
    DEST_TABLE STRING,
	SRC_LOOKUP_PROJECT STRING,
	SRC_LOOKUP_DATASET STRING,
	CUSTOMER_NAME STRING,
	FEED_NAME STRING
)
OPTIONS(
description = """

 How to call:

     CALL transient.ecomm_sproc_nielsen_product_nar_temp (
        "ecomm-dlf-dev-01cd47", -- SRC_PROJECT
        "transient", -- SRC_DATASET
        "processed", -- XREF_DATASET
        "kroger_ship_nielsen_product_temp", -- DEST_TABLE
        "edw-dev-c119a7", -- SRC_LOOKUP_PROJECT
        "syndicated_nielsen", -- SRC_LOOKUP_DATASET
        "KROGER_SHIP", -- CUSTOMER_NAME
        "KROGER_SHIP" -- FEED_NAME
	)

"""
)
BEGIN

DECLARE JOB_RUN_ID DEFAULT 999999;
DECLARE BQ_PROJECT_NAME DEFAULT SRC_PROJECT;
DECLARE BQ_TRANSIENT_DATASET_NAME DEFAULT SRC_DATASET;
DECLARE BQ_PROCESSED_DATASET_NAME DEFAULT XREF_DATASET;
DECLARE BQ_NIELSEN_TABLE_NAME DEFAULT DEST_TABLE;
DECLARE BQ_EDW_PROJECT_NAME DEFAULT SRC_LOOKUP_PROJECT;
DECLARE BQ_EDW_DATASET_NAME DEFAULT SRC_LOOKUP_DATASET;

SET CUSTOMER_NAME = UPPER(CUSTOMER_NAME);

SET FEED_NAME = UPPER(FEED_NAME);

  -- Truncate Neilsen Product Temp TABLE
EXECUTE IMMEDIATE
  CONCAT("""TRUNCATE TABLE  `""",BQ_PROJECT_NAME,"""`.""",BQ_TRANSIENT_DATASET_NAME,""".""",BQ_NIELSEN_TABLE_NAME); 
 --INSERT details INTO Customer specific Nielsen product temp TABLE
EXECUTE IMMEDIATE
  CONCAT( """INSERT INTO  `""",BQ_PROJECT_NAME,"""`.""",BQ_TRANSIENT_DATASET_NAME,""".""",BQ_NIELSEN_TABLE_NAME,""" (
    WITH
      source_data AS (
      SELECT
        DISTINCT customer_upc as upc,
		--- Deriving 10 digit upc values . Removes leading 0's and checks if the length is >= 10 
        CASE
          WHEN LENGTH(LTRIM(customer_upc,'0'))>=10 THEN SUBSTRING(LTRIM(customer_upc,'0'), 1, 10)
        ELSE
        NULL
      END
        AS upc_10  
   FROM
      `""",BQ_PROJECT_NAME,""".""",BQ_PROCESSED_DATASET_NAME,""".dim_source_to_enterprise_upc_xref` xref_upc
	WHERE
	      xref_upc.customer_name = '""",CUSTOMER_NAME,"""'
      -- Filters active records
      AND xref_upc.current_flg = 'Y'
	),
      niel_prod AS (
      SELECT
        upc_10,
		country_cd,
		source_database_cd ,
		product_key ,
        gmi_category_desc,
        gmi_sub_category_desc,
        gmi_segment_desc,
        gmi_brand_desc,
        gmi_global_brand_desc,
        gmi_product_desc,
        gmi_manufacturer_desc,
        gmi_global_manufacturer_desc,
        brand_high_desc,
        brand_low_desc,
        gmi_megacategory_desc,
        ean_upc_derived_cd
      FROM (
        SELECT
		  --- 10 digit upc check 
          CASE
            WHEN SAFE_CAST(ean_upc_derived_cd AS INT64) IS NOT NULL AND LENGTH(LTRIM(ean_upc_derived_cd,'0'))>=10 THEN subSTRING(LTRIM(ean_upc_derived_cd,'0'), 1, 10)
          ELSE
          NULL
        END
          AS upc_10,
		  country_cd,
		  '' as source_database_cd ,
		  product_key ,		  
          gmi_category_desc,
          gmi_sub_category_desc,
          gmi_segment_desc,
          gmi_brand_desc,
          gmi_global_brand_desc,
          gmi_product_desc,
          gmi_manufacturer_desc,
          gmi_global_manufacturer_desc,
          brand_high_desc,
          brand_low_desc,
          gmi_megacategory_desc,
          ean_upc_derived_cd,
		  --- Pick any 1 row for a specific upc
          ROW_NUMBER() OVER(PARTITION BY CASE WHEN (SAFE_CAST(ean_upc_derived_cd AS INT64) IS NOT NULL AND LENGTH(LTRIM(ean_upc_derived_cd,'0'))>=10) THEN subSTRING(LTRIM(ean_upc_derived_cd,'0'), 1, 10)
            ELSE
            NULL
          END
            ) AS rnum
        FROM
          `""" ,BQ_EDW_PROJECT_NAME,"""`.""",BQ_EDW_DATASET_NAME,""".dim_nielsen_connect_pos_us_product
        WHERE
          upc_cd != '')
      WHERE
        rnum = 1)
    SELECT
      source_data.upc,
	  niel_prod.country_cd,
	  niel_prod.source_database_cd ,
	  niel_prod.product_key ,	  
      niel_prod.gmi_category_desc,
      niel_prod.gmi_sub_category_desc,
      niel_prod.gmi_segment_desc,
      niel_prod.gmi_brand_desc,
      niel_prod.gmi_global_brand_desc,
      niel_prod.gmi_product_desc,
      niel_prod.gmi_manufacturer_desc,
      niel_prod.gmi_global_manufacturer_desc,
      niel_prod.brand_high_desc,
      niel_prod.brand_low_desc,
      niel_prod.gmi_megacategory_desc,
      niel_prod.ean_upc_derived_cd,
      CAST(""",JOB_RUN_ID,""" AS string) AS created_by,
      CURRENT_DATETIME AS created_datetime,
      CAST(""",JOB_RUN_ID,""" AS string) AS modified_by,
      CURRENT_DATETIME AS modified_datetime
    FROM
      source_data
    LEFT OUTER JOIN
      niel_prod
    ON
      (source_data.upc_10 = niel_prod.upc_10) ) """) ; 

EXCEPTION WHEN ERROR THEN
        EXECUTE IMMEDIATE CONCAT(
            """INSERT INTO processed.sproc_error_details (
		        SELECT
			        '""",FEED_NAME,"""' AS FEED_NAME,
                    split(split(@@error.formatted_stack_trace,'transient.')[OFFSET (1)],'[')[OFFSET(0)],
			        @@error.statement_text,
			        @@error.message,
			        current_timestamp()
	        );
	    """);

	    SELECT
	        ERROR (
	            CONCAT(
	            		@@error.message ,' ' ,
	            		@@error.statement_text, ' ' ,
	            		@@error.formatted_stack_trace ,' '
	            	)
	        );

END