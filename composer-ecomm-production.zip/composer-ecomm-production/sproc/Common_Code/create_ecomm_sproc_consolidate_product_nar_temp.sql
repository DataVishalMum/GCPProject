  /* 
  Purpose OF the stored proc : 
		Consolidated Product Temp TABLE DATA insertion 
  History OF Changes : 
		03/26 first version 
    04/29 - Added amazon com/pantry specific logic to compute manufacturer
    05/07 - Added Amazon com/pantry specific logic to compute 'is_gmi_flag'
	05/20 - Added Feed name parameter
	05/10 - Updated composer related params and added sproc error mechanism
  Author : 
		Pawan Rathod
  
*/
	
CREATE OR REPLACE PROCEDURE
  transient.ecomm_sproc_consolidate_product_nar_temp (
    SRC_PROJECT STRING,
    SRC_DATASET STRING,
    SRC_LOOKUP_DATASET STRING,
    DEST_TABLE STRING,
    SRC_TABLE STRING,
    INTERMEDIATE_TABLE STRING,
    XREF_TABLE STRING,
    CUSTOMER_NAME STRING,
	FEED_NAME STRING
)
OPTIONS(
description = """

 How to call:

     CALL transient.ecomm_sproc_consolidate_product_nar_temp (
        'ecomm-dlf-dev-01cd47', -- SRC_PROJECT
        'transient', -- SRC_DATASET
        'processed', -- SRC_LOOKUP_DATASET
        'kroger_ship_consolidate_product_temp', -- DEST_TABLE
        'kroger_ship_processed_zero', -- SRC_TABLE
        'kroger_ship_product_temp', -- INTERMEDIATE_TABLE
        'kroger_ship_nielsen_product_temp', -- XREF_TABLE
        'KROGER_SHIP', -- CUSTOMER_NAME
	    'KROGER_SHIP' -- FEED_NAME
      )

"""
)
BEGIN

DECLARE JOB_RUN_ID DEFAULT 999999;
DECLARE BQ_PROJECT_NAME DEFAULT SRC_PROJECT;
DECLARE BQ_TRANSIENT_DATASET_NAME DEFAULT SRC_DATASET;
DECLARE BQ_PROCESSED_DATASET_NAME DEFAULT SRC_LOOKUP_DATASET;
DECLARE BQ_CONSOLIDATE_PRODUCT_TABLENAME DEFAULT DEST_TABLE;
DECLARE BQ_PROCESSED0_TEMP_TABLENAME DEFAULT SRC_TABLE;
DECLARE BQ_PRODUCT_TEMP_TABLENAME DEFAULT INTERMEDIATE_TABLE;
DECLARE BQ_NIELSEN_PRODUCT_TABLENAME DEFAULT XREF_TABLE;

DECLARE
  CUSTOMER_SPECIFIC_SELECT ,FISCAL_DT,IS_GMI_FLAG STRING;

SET CUSTOMER_NAME = UPPER(CUSTOMER_NAME);

SET FEED_NAME = UPPER(FEED_NAME);

SET
  CUSTOMER_SPECIFIC_SELECT=""; 
-- Find the customer specific date column 
EXECUTE IMMEDIATE
  CONCAT("""
  SELECT
    vendor_file_fiscal_date
  FROM
    `""",BQ_PROJECT_NAME,"""`.""",BQ_TRANSIENT_DATASET_NAME,""".gmi_customer_metadata_reference
  WHERE
    FEED_NAME =UPPER('""",FEED_NAME,"""') """) INTO FISCAL_DT;
-- Truncate Consolidate Product Temp TABLE
EXECUTE IMMEDIATE
  CONCAT("""TRUNCATE TABLE  `""",BQ_PROJECT_NAME,"""`.""",BQ_TRANSIENT_DATASET_NAME,""".""",BQ_CONSOLIDATE_PRODUCT_TABLENAME);
/*
- Manufacturer column logic for AMAZON_COM & AMAZON_PANTRY
  - For amazon com, the value of manufacturer depends on sls_hier_category_desc column
  - For amazon pantry, the value is handled in the delta temp layer itself
  - There is no change for any other customer
- 'IS_GMI_FLAG' specific logic for amazon com/pantry - it is blank for third party products (is_3p = 'Y')
*/
IF
  UPPER(CUSTOMER_NAME) = "AMAZON_COM" THEN
SET
  CUSTOMER_SPECIFIC_SELECT="""processed0.* EXCEPT (manufacturer), CASE
    WHEN processed0.is_3p = 'N' THEN CASE
    WHEN processed0.manufacturer = 'General Mills'
  AND product.sls_hier_category_desc IN ('3BOU FRZ',
    'FROZEN',
    'MBOU FRZ',
    'YOGURT') THEN 'Gen Mills Amazon Fresh'
  ELSE
  processed0.manufacturer
END
    WHEN processed0.is_3p = 'Y' THEN '3P GMI Sales'
  ELSE
  processed0.manufacturer
END
  AS manufacturer,"""; 
  SET IS_GMI_FLAG = """CASE WHEN processed0.is_3p = 'Y' THEN  ''
  ELSE product.is_gmi_flag END AS is_gmi_flag,""";
  ELSEIF UPPER(CUSTOMER_NAME) = "AMAZON_PANTRY" THEN
SET
  CUSTOMER_SPECIFIC_SELECT="""processed0.* EXCEPT (manufacturer), processed0.manufacturer manufacturer,""";
SET
 IS_GMI_FLAG = """CASE WHEN processed0.is_3p = 'Y' THEN  ''
  ELSE product.is_gmi_flag END AS is_gmi_flag,""";
ELSE 
SET CUSTOMER_SPECIFIC_SELECT = """processed0.*,""";
SET
    IS_GMI_FLAG = """product.is_gmi_flag,""";
END IF; 

-- INSERT details INTO Customer specific Consolidate product temp TABLE
EXECUTE IMMEDIATE
  CONCAT( """INSERT INTO  `""",BQ_PROJECT_NAME,"""`.""",BQ_TRANSIENT_DATASET_NAME,""".""",BQ_CONSOLIDATE_PRODUCT_TABLENAME,""" (
    WITH
      processed0 AS (
      WITH
        dr AS (
        SELECT
          k.* EXCEPT( fact_sk,
            ty_sales_value,
            ty_sales_units,
            """,FISCAL_DT,""",
            created_by,
            created_datetime,
            modified_by,
            modified_datetime ),
          ROW_NUMBER() OVER(PARTITION BY k.source_product_hash ORDER BY """,FISCAL_DT,""" DESC) rnk
        FROM
          `""",BQ_PROJECT_NAME,"""`.""",BQ_TRANSIENT_DATASET_NAME,""".""",BQ_PROCESSED0_TEMP_TABLENAME,""" k )
      SELECT
        * EXCEPT(rnk)
      FROM
        dr
      WHERE
        RNK = 1 )
    SELECT
       """,CUSTOMER_SPECIFIC_SELECT,"""
      customer.segment,
      customer.customer_share_flag,
      customer.report_fg,
      customer.customer_sales_flag,
      customer.country,
      customer.channel,
      customer.ad_security_role,
      customer.customer_desc,
      customer.customer_parent,
      customer.customer_account,
      customer.notes,
	  customer.currency_code,
	  customer.currency_symbol,
      product.xref_upc_sk,
      product.ean_upc_cd,
      product.base_product_ean_upc_derived_cd,
      product.base_product_cd,
      product.base_product_desc,
      product.material_cd,
      product.material_short_desc,
      product.material_nbr,
      product.sls_hier_division_desc,
      product.sls_hier_category_desc,
      product.sls_hier_sub_category_desc,
      product.sls_hier_accrual_group_desc,
      product.sls_hier_sub_accrual_desc,
      product.sls_hier_ppg_desc,
      product.gph_hier_top_desc,
      product.gph_hier_family_desc,
      product.gph_hier_category_desc,
      product.gph_hier_flavor_format_desc,
      product.gph_hier_package_size_desc,
      product.base_uom_to_eqc_fctr,
      product.base_uom_to_ecv_fctr,
      product.all_cd,
      product.all_desc,
      product.sls_hier_sub_category_desc_ly,
      product.sls_hier_division_desc_ly,
      product.sls_hier_category_desc_ly,
      product.bph1_hier_bph20_desc,
      product.bph1_hier_bph30_desc,
      product.bph1_hier_bph40_desc,
      product.bph1_hier_bph50_desc,
      product.bph1_hier_bph60_desc,
      product.bph1_hier_bph70_desc,
      product.material_type_cd,
      product.sls_hier_division_cd,
      product.sls_hier_category_cd,
      product.sls_hier_sub_category_cd,
      product.sls_hier_accrual_group_cd,
      product.sls_hier_ppg_cd,
      product.gph_hier_top_cd,
      product.gph_hier_family_cd,
      product.gph_hier_category_cd,
      product.gph_hier_flavor_format_cd,
      product.gph_hier_package_size_cd,
      product.ean_upc_derived_cd,
      product.hier_cd,
      product.language_cd,
      product.version_cd,
      product.hier_level_cd,
      product.divested_fg,
      """,IS_GMI_FLAG,"""
      nielsen.country_cd AS nielsen_country_cd,
      nielsen.source_database_cd AS nielsen_source_database_cd,
      nielsen.product_key AS nielsen_product_key,
      nielsen.gmi_category_desc,
      nielsen.gmi_sub_category_desc,
      nielsen.gmi_segment_desc,
      nielsen.gmi_brand_desc,
      nielsen.gmi_global_brand_desc,
      nielsen.gmi_product_desc,
      nielsen.gmi_manufacturer_desc,
      nielsen.gmi_global_manufacturer_desc,
      nielsen.brand_high_desc,
      nielsen.brand_low_desc,
      nielsen.gmi_megacategory_desc,
      nielsen.ean_upc_derived_cd AS nielsen_ean_upc_derived_cd,
      CAST(""",job_run_id,""" AS string) AS created_by,
      CURRENT_DATETIME AS created_datetime,
      CAST(""",job_run_id,""" AS string) AS modified_by,
      CURRENT_DATETIME AS modified_datetime
    FROM
      processed0
    LEFT JOIN
      `""",BQ_PROJECT_NAME,"""`.""",BQ_TRANSIENT_DATASET_NAME,""".""",BQ_PRODUCT_TEMP_TABLENAME,""" product
    ON
      processed0.upc = product.upc
    LEFT JOIN
      `""",BQ_PROJECT_NAME,"""`.""",BQ_PROCESSED_DATASET_NAME,""".lkp_customer customer
    ON
      customer.CUSTOMER_NAME = processed0.CUSTOMER_NAME
    LEFT JOIN
      `""",BQ_PROJECT_NAME,"""`.""",BQ_TRANSIENT_DATASET_NAME,""".""",BQ_NIELSEN_PRODUCT_TABLENAME,""" nielsen
    ON
      nielsen.upc = processed0.upc )""") ;

EXCEPTION WHEN ERROR THEN
        EXECUTE IMMEDIATE CONCAT(
            """INSERT INTO processed.sproc_error_details (
		        SELECT
			        '""",FEED_NAME,"""' AS FEED_NAME,
                    split(split(@@error.formatted_stack_trace,'transient.')[OFFSET (1)],'[')[OFFSET(0)],
			        @@error.statement_text,
			        @@error.message,
			        current_timestamp()
	        );
	    """);

	    SELECT
	        ERROR (
	            CONCAT(
	            		@@error.message ,' ' ,
	            		@@error.statement_text, ' ' ,
	            		@@error.formatted_stack_trace ,' '
	            	)
	        );

END