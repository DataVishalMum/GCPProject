    /* 
    Purpose OF the stored proc : 
    Roll-Up the data from processed-1 layer to weekly grain. Process the complete data to map the surrogate keys, derived columns to each record. 
    History OF Changes : 
            03/26 first version
            04/07 Removed SKs, added all the columns matching the current GSS
            04/12 Standardized the columns to generalize the code for NAR and EUAU.
            04/14 Changed SP name from sp_customer_fact_weekly_agg to sp_customer_weekly_agg_fact
            04/19 Changed the condition for 'base_uom_to_eqc_fctr' as it's data type has changed to Numeric
            04/20 Referring ty_sales_value instead of ty_sales_value_usd as it's renamed in proc-1 layer
            04/23 Changed the dataset for information schema from transient to processed
            04/26 Handled currency exchange logic for all the customers where currency code is not USD
            04/26 Changed the grain for Walmart Canada to Month
            05/17 Harmonized source_item_name to upc and source_item_code
            05/19 Removed ty_sales_eqc_units calculation as it is taken care in proc-1
            05/20 Adding FEED_NAME as a parameter
            05/20 Added a big IF condition, so that if we do not have records in the proc-1 table, the proc-2 table doesn't get truncated.
            05/25 Changed the dataset for 'currency_exchange_rates_by_day' to 'shared_data_enterprise'
            06/02 Added a colaesce to the join condition used in calculating LY metrics
            06/22 replaced self join to calculate LY metrics with the LEAD windowing function
            07/07 - Enterprise dimension changes
			07/07 - Integrated Ly sales without Ty sales Logic
			01/19 - Added Dynamic Column Addition changes
			05/10 - Updated composer related params and added sproc error mechanism

Author :
       Pawan Rathod

    */
    
CREATE OR REPLACE PROCEDURE
transient.ecomm_sproc_customer_weekly_agg_fact (
    SRC_PROJECT STRING,
    SRC_DATASET STRING,
    DEST_DATASET STRING,
    SRC_LOOKUP_PROJECT string,
    SRC_LOOKUP_DATASET string,
    SRC_TABLE STRING,
    DEST_TABLE STRING,
    XREF_TABLE STRING,
    CUSTOMER_NAME STRING,
    FEED_NAME STRING
)
OPTIONS(
description = """

 How to call:

     CALL transient.ecomm_sproc_customer_weekly_agg_fact (
		"ecomm-dlf-dev-01cd47", -- SRC_PROJECT
        "transient", -- SRC_DATASET
        "processed", -- DEST_DATASET
        "edw-qa-c89f9d", -- SRC_LOOKUP_PROJECT
        "enterprise", -- SRC_LOOKUP_DATASET
        "amazon_pantry_fact", -- SRC_TABLE
        "amazon_pantry_weekly_agg_fact", -- DEST_TABLE
        "gmi_customer_metadata_reference", -- XREF_TABLE
        "AMAZON_PANTRY", -- CUSTOMER_NAME
        "AMAZON_PANTRY" -- FEED_NAME
	)
"""
)
BEGIN

DECLARE JOB_RUN_ID DEFAULT 999999;
DECLARE BQ_PROJECT_NAME DEFAULT SRC_PROJECT;
DECLARE BQ_TRANSIENT_DATASET_NAME DEFAULT SRC_DATASET;
DECLARE BQ_PROCESSED_DATASET_NAME DEFAULT DEST_DATASET;
DECLARE BQ_EDW_PROJECT_NAME DEFAULT SRC_LOOKUP_PROJECT;
DECLARE BQ_ENTERPRISE_DATASET_NAME DEFAULT SRC_LOOKUP_DATASET;
DECLARE SOURCE_TABLE_NAME DEFAULT SRC_TABLE;
DECLARE TARGET_TABLE_NAME DEFAULT DEST_TABLE;
DECLARE NATURAL_KEY_LOOKUP_TABLE DEFAULT XREF_TABLE;

DECLARE
MAX_FISCAL_WEEK_END_DT,
MONTH_BEGIN_DT,
MONTH_END_DT,
QUARTER_BEGIN_DT,
QUARTER_END_DT,
YEAR_BEGIN_DT,
YEAR_END_DT timestamp;
    
DECLARE
ROLLING13START,
ROLLING26START,
ROLLING52START date;
    
DECLARE
CUSTOMER_FLAGS,
NATURAL_KEY,
NATURAL_KEY_JOIN,
AGG_NATURAL_KEY_JOIN,
AGG_NATURAL_KEY,
SOURCE_ITEM_CODE,
EUAU_BUSINESS_OPERATING_UNIT_DESC,
EUAU_BUSINESS_PRODUCT_GROUP_DESC,
EUAU_BUSINESS_PRODUCT_SUB_GROUP_DESC,
PRODUCT_CATEGORY_DERIVED_DESC,
PRODUCT_SECTOR_DESC,
PRODUCT_SUB_SEGMENT_DERIVED_DESC,
BASE_PRODUCT_CD,
MATERIAL_NBR,
SLS_HIER_DIVISION_DESC,
SLS_HIER_CATEGORY_DESC,
SLS_HIER_SUB_CATEGORY_DESC,
SLS_HIER_ACCRUAL_GROUP_DESC,
SLS_HIER_SUB_ACCRUAL_DESC,
SLS_HIER_PPG_DESC,
GMI_CATEGORY_DESC,
GMI_SUB_CATEGORY_DESC,
GMI_SEGMENT_DESC,
GMI_BRAND_DESC,
GMI_GLOBAL_BRAND_DESC,
GMI_MANUFACTURER_DESC,
GMI_GLOBAL_MANUFACTURER_DESC,
BRAND_HIGH_DESC,
BRAND_LOW_DESC,
GMI_MEGACATEGORY_DESC,
EAN_UPC_DERIVED_CD,
BASE_UOM_TO_ECV_FCTR,
GRAIN,
SOURCE_ITEM_CODE_JOIN,
NATURAL_KEY_LY
STRING;

DECLARE REGION_SPECIFIC_COLUMNS,REGION_SPECIFIC_AGG_COLUMNS,AGG_SALES,DATA_AGG STRING DEFAULT '';

DECLARE SOURCE_TABLE_COUNT INT64;

SET CUSTOMER_NAME = UPPER(CUSTOMER_NAME);

SET FEED_NAME = UPPER(FEED_NAME);


-- We are checking the source count here. If the source count is zero, we do not proceed with rest of the commands and terminate the procedure.
-- This ensures that the table is not truncated if there are no records in the source and also eliminates any NULL exceptions.

EXECUTE IMMEDIATE
CONCAT("""Select count(*) from `""",BQ_PROJECT_NAME,""".""",BQ_PROCESSED_DATASET_NAME,""".""",SOURCE_TABLE_NAME,"""`""")
INTO SOURCE_TABLE_COUNT;

IF SOURCE_TABLE_COUNT != 0 THEN
-- Truncate the processed-2 TABLE
EXECUTE IMMEDIATE
CONCAT("""TRUNCATE TABLE `""",BQ_PROJECT_NAME,""".""",BQ_PROCESSED_DATASET_NAME,""".""",TARGET_TABLE_NAME,"""`""");
-- FETCH the max fiscal week end  date TO calculate customer flags
EXECUTE IMMEDIATE
CONCAT("""
SELECT
    MAX(fiscal_week_end_dt) AS fiscal_week_end_dt
FROM
    `""",BQ_PROJECT_NAME,""".""",BQ_PROCESSED_DATASET_NAME,""".""",SOURCE_TABLE_NAME,"""`""") INTO MAX_FISCAL_WEEK_END_DT;
    -- FETCH the date ranges TO calculate customer flags using  the max fiscal week end date
CALL
transient.ecomm_sproc_date_ranges(BQ_EDW_PROJECT_NAME,
BQ_ENTERPRISE_DATASET_NAME,
    MAX_FISCAL_WEEK_END_DT,
    MONTH_BEGIN_DT,
    MONTH_END_DT,
    QUARTER_BEGIN_DT,
    QUARTER_END_DT,
    YEAR_BEGIN_DT,
    YEAR_END_DT,
    ROLLING13START,
    ROLLING26START,
    ROLLING52START);
    /* Logic TO calculate customer flags
rolling_13/26/52 flags - if the data lies withing last 13/26/52 weeks respectively, these are populated as Y else N
latest_completed_fiscal_month_fg/quarter/year flags - If the data lies within last month/quarter/year, these are calculated as Y else N
*/
SET
CUSTOMER_FLAGS = CONCAT("""
SELECT
    fiscal_week_begin_dt, '""",MAX_FISCAL_WEEK_END_DT,"""' AS fiscal_date_customer_max,
    CASE
    WHEN (fiscal_week_begin_dt >= '""",ROLLING13START,"""') AND fiscal_week_begin_dt <= '""",MAX_FISCAL_WEEK_END_DT,"""' THEN 'Y'
    ELSE
    'N'
END
    AS rolling_13_fg,
    CASE
    WHEN (fiscal_week_begin_dt >= '""",ROLLING26START,"""') AND fiscal_week_begin_dt <= '""",MAX_FISCAL_WEEK_END_DT,"""' THEN 'Y'
    ELSE
    'N'
END
    AS rolling_26_fg,
    CASE
    WHEN (fiscal_week_begin_dt >= '""",ROLLING52START,"""') AND fiscal_week_begin_dt <= '""",MAX_FISCAL_WEEK_END_DT,"""' THEN 'Y'
    ELSE
    'N'
END
    AS rolling_52_fg,
    CASE
    WHEN (fiscal_week_begin_dt >= '""",MONTH_BEGIN_DT,"""' AND fiscal_week_begin_dt <= '""",MONTH_END_DT,"""') THEN 'Y'
    ELSE
    'N'
END
    AS latest_completed_fiscal_month_fg,
    CASE
    WHEN (fiscal_week_begin_dt >= '""",QUARTER_BEGIN_DT,"""' AND fiscal_week_begin_dt <= '""",QUARTER_END_DT,"""') THEN 'Y'
    ELSE
    'N'
END
    AS latest_completed_fiscal_quarter_fg,
    CASE
    WHEN (fiscal_week_begin_dt >= '""",YEAR_BEGIN_DT,"""' AND fiscal_week_begin_dt <= '""",YEAR_END_DT,"""') THEN 'Y'
    ELSE
    'N'
END
    AS latest_completed_fiscal_year_fg
FROM (
    SELECT
    DISTINCT fiscal_week_begin_dt
    FROM
    `""",BQ_PROJECT_NAME,""".""",BQ_PROCESSED_DATASET_NAME,""".""", SOURCE_TABLE_NAME,"""`)""");

-- Fetch the natural keys using the naturalkey lookup table
EXECUTE IMMEDIATE
CONCAT("""
SELECT
    processed_two_natural_key
FROM
    `""",BQ_PROJECT_NAME,""".""",BQ_TRANSIENT_DATASET_NAME,""".""",NATURAL_KEY_LOOKUP_TABLE,"""`
WHERE
    CUSTOMER_NAME = '""",CUSTOMER_NAME,"""'
    and FEED_NAME = '""",FEED_NAME,"""'""") INTO NATURAL_KEY;

    -- Fetch the natural key join using the natural-key lookup table using customer name and feed name.
    -- Use coalesce for all the string columns, so that join condition doesn't fail when the column value is NULL
EXECUTE IMMEDIATE
CONCAT("""
WITH
    fetch_nk AS (
    SELECT
    NATURAL_KEY
    FROM
    UNNEST((
        SELECT
        SPLIT(processed_two_natural_key,',') NATURAL_KEY
        FROM
        `""",BQ_PROJECT_NAME,""".""",BQ_TRANSIENT_DATASET_NAME,""".""",NATURAL_KEY_LOOKUP_TABLE,"""`
        WHERE
        CUSTOMER_NAME ='""",CUSTOMER_NAME,"""'
        and FEED_NAME = '""",FEED_NAME,"""')) AS NATURAL_KEY),
string_nk AS (
SELECT
    RTRIM(string_agg ('COALESCE(src.' || NATURAL_KEY || ',\\'\\') = COALESCE(agg.' || NATURAL_KEY || ',\\'\\') and ',
        ' '),' and ' ) natural_key_str
FROM (
    SELECT
    column_name NATURAL_KEY
    FROM
    """,BQ_PROCESSED_DATASET_NAME,""".INFORMATION_SCHEMA.COLUMNS
    WHERE
    table_name = '""",SOURCE_TABLE_NAME,"""'
    AND data_type = 'STRING'
    AND column_name IN (
    SELECT
        *
    FROM
        fetch_nk))),
non_string_sk AS (
SELECT
    RTRIM(string_agg ('src.' || NATURAL_KEY || ' = agg.' || NATURAL_KEY || ' and ',
        ' '),' and ' ) natural_key_non_str
FROM (
    SELECT
    column_name NATURAL_KEY
    FROM
    """,BQ_PROCESSED_DATASET_NAME,""".INFORMATION_SCHEMA.COLUMNS
    WHERE
    table_name = '""",SOURCE_TABLE_NAME,"""'
    AND data_type <> 'STRING'
    AND column_name IN (
    SELECT
        *
    FROM
        fetch_nk)))
SELECT
CONCAT(natural_key_str,' and ',natural_key_non_str)
FROM
non_string_sk,
string_nk""") INTO NATURAL_KEY_JOIN;

    -- Fetch the natural keys to aggregate the metric data
    -- Added coalesce to all the columns, so that join condition doesn't fail when the column value is NULL
    EXECUTE IMMEDIATE
CONCAT("""WITH fetch_nk AS (SELECT
    NATURAL_KEY
    FROM
    UNNEST((
        SELECT
        SPLIT(processed_two_natural_key,',') NATURAL_KEY
        FROM
        `""",BQ_PROJECT_NAME,""".""",BQ_TRANSIENT_DATASET_NAME,""".""",NATURAL_KEY_LOOKUP_TABLE,"""`
        WHERE
        CUSTOMER_NAME ='""",CUSTOMER_NAME,"""'
        and FEED_NAME = '""",FEED_NAME,"""')) AS NATURAL_KEY
    where NATURAL_KEY <> 'fiscal_year_week_nbr')
        SELECT
    RTRIM(string_agg ('COALESCE(src.' || NATURAL_KEY || ',\\'\\') = COALESCE(b.' || NATURAL_KEY || ',\\'\\') and ',
        ' '),' and ' )
FROM
    fetch_nk""") INTO AGG_NATURAL_KEY_JOIN;

-- Fetch the natural key to aggregate the data
EXECUTE IMMEDIATE
CONCAT("""select REGEXP_REPLACE(CONCAT('src.',processed_two_natural_key),',',',src.')
FROM
`""",BQ_PROJECT_NAME,""".""",BQ_TRANSIENT_DATASET_NAME,""".""",NATURAL_KEY_LOOKUP_TABLE,"""`
    where CUSTOMER_NAME = '""",CUSTOMER_NAME,"""'
    and FEED_NAME = '""",FEED_NAME,"""'""") INTO AGG_NATURAL_KEY;

EXECUTE IMMEDIATE
CONCAT("""select REGEXP_REPLACE(CONCAT('src.',processed_two_natural_key),',',',src.')
FROM
`""",BQ_PROJECT_NAME,""".""",BQ_TRANSIENT_DATASET_NAME,""".""",NATURAL_KEY_LOOKUP_TABLE,"""`
    where CUSTOMER_NAME = '""",CUSTOMER_NAME,"""'
    and FEED_NAME = '""",FEED_NAME,"""'""") INTO AGG_NATURAL_KEY;

-- Below query generates the natural key for a customer which is used in the LEAD function
-- to calculate ly sales and units. Here we are excluding 'fiscal_year_week_nbr' column
-- because it is used to order the values. 'fiscal_week_in_year_nbr' column is added to
-- partition the rows by the same week in different years.
EXECUTE IMMEDIATE
CONCAT("""
WITH fetch_nk AS (SELECT
    NATURAL_KEY
    FROM
    UNNEST((
        SELECT
        SPLIT(processed_two_natural_key,',') NATURAL_KEY
        FROM
        `""",BQ_PROJECT_NAME,""".""",BQ_TRANSIENT_DATASET_NAME,""".""",NATURAL_KEY_LOOKUP_TABLE,"""`
        WHERE
        CUSTOMER_NAME ='""",CUSTOMER_NAME,"""'
        and FEED_NAME = '""",FEED_NAME,"""')) AS NATURAL_KEY
    where NATURAL_KEY <> 'fiscal_year_week_nbr')
    select CONCAT(string_agg('src.'|| NATURAL_KEY),',src.fiscal_week_in_year_nbr')
FROM fetch_nk""") INTO NATURAL_KEY_LY;

-- Change the grain to 'MONTH' for Walmart Canada
    EXECUTE IMMEDIATE
    CONCAT("""
    Select CASE WHEN '""",CUSTOMER_NAME,"""' = 'WALMART_CANADA' THEN 'MONTH'
    ELSE 'WEEK'
    END AS grain
    """) INTO GRAIN;

    /* Populate the below columns as NULL if they are not present in the source table*/
EXECUTE IMMEDIATE  CONCAT("""   WITH dr AS ( SELECT   COUNT(*) cnt FROM   """,BQ_PROCESSED_DATASET_NAME,""".INFORMATION_SCHEMA.COLUMNS WHERE   table_name = '""",SOURCE_TABLE_NAME,"""'   AND column_name = 'source_item_code')   SELECT CASE   WHEN cnt = 0 THEN 'NULL' ELSE 'src.source_item_code'   END   FROM dr""") INTO SOURCE_ITEM_CODE;
EXECUTE IMMEDIATE  CONCAT("""   WITH dr AS ( SELECT   COUNT(*) cnt FROM   """,BQ_PROCESSED_DATASET_NAME,""".INFORMATION_SCHEMA.COLUMNS WHERE   table_name = '""",SOURCE_TABLE_NAME,"""'   AND column_name = 'euau_business_operating_unit_desc')   SELECT CASE   WHEN cnt = 0 THEN 'NULL' ELSE 'src.euau_business_operating_unit_desc'   END   FROM dr""") INTO EUAU_BUSINESS_OPERATING_UNIT_DESC;
EXECUTE IMMEDIATE  CONCAT("""   WITH dr AS ( SELECT   COUNT(*) cnt FROM   """,BQ_PROCESSED_DATASET_NAME,""".INFORMATION_SCHEMA.COLUMNS WHERE   table_name = '""",SOURCE_TABLE_NAME,"""'   AND column_name = 'euau_business_product_group_desc')   SELECT CASE   WHEN cnt = 0 THEN 'NULL' ELSE 'src.euau_business_product_group_desc'   END   FROM dr""") INTO EUAU_BUSINESS_PRODUCT_GROUP_DESC;
EXECUTE IMMEDIATE  CONCAT("""   WITH dr AS ( SELECT   COUNT(*) cnt FROM   """,BQ_PROCESSED_DATASET_NAME,""".INFORMATION_SCHEMA.COLUMNS WHERE   table_name = '""",SOURCE_TABLE_NAME,"""'   AND column_name = 'euau_business_product_sub_group_desc')   SELECT CASE   WHEN cnt = 0 THEN 'NULL' ELSE 'src.euau_business_product_sub_group_desc'   END   FROM dr""") INTO EUAU_BUSINESS_PRODUCT_SUB_GROUP_DESC;
EXECUTE IMMEDIATE  CONCAT("""   WITH dr AS ( SELECT   COUNT(*) cnt FROM   """,BQ_PROCESSED_DATASET_NAME,""".INFORMATION_SCHEMA.COLUMNS WHERE   table_name = '""",SOURCE_TABLE_NAME,"""'   AND column_name = 'product_category_derived_desc')   SELECT CASE   WHEN cnt = 0 THEN 'NULL' ELSE 'src.product_category_derived_desc'   END   FROM dr""") INTO PRODUCT_CATEGORY_DERIVED_DESC;
EXECUTE IMMEDIATE  CONCAT("""   WITH dr AS ( SELECT   COUNT(*) cnt FROM   """,BQ_PROCESSED_DATASET_NAME,""".INFORMATION_SCHEMA.COLUMNS WHERE   table_name = '""",SOURCE_TABLE_NAME,"""'   AND column_name = 'product_sector_desc')   SELECT CASE   WHEN cnt = 0 THEN 'NULL' ELSE 'src.product_sector_desc'   END   FROM dr""") INTO PRODUCT_SECTOR_DESC;
EXECUTE IMMEDIATE  CONCAT("""   WITH dr AS ( SELECT   COUNT(*) cnt FROM   """,BQ_PROCESSED_DATASET_NAME,""".INFORMATION_SCHEMA.COLUMNS WHERE   table_name = '""",SOURCE_TABLE_NAME,"""'   AND column_name = 'product_sub_segment_derived_desc')   SELECT CASE   WHEN cnt = 0 THEN 'NULL' ELSE 'src.product_sub_segment_derived_desc'   END   FROM dr""") INTO PRODUCT_SUB_SEGMENT_DERIVED_DESC;
EXECUTE IMMEDIATE  CONCAT("""   WITH dr AS ( SELECT   COUNT(*) cnt FROM   """,BQ_PROCESSED_DATASET_NAME,""".INFORMATION_SCHEMA.COLUMNS WHERE   table_name = '""",SOURCE_TABLE_NAME,"""'   AND column_name = 'base_product_cd')   SELECT CASE   WHEN cnt = 0 THEN 'NULL' ELSE 'src.base_product_cd'   END   FROM dr""") INTO BASE_PRODUCT_CD;
EXECUTE IMMEDIATE  CONCAT("""   WITH dr AS ( SELECT   COUNT(*) cnt FROM   """,BQ_PROCESSED_DATASET_NAME,""".INFORMATION_SCHEMA.COLUMNS WHERE   table_name = '""",SOURCE_TABLE_NAME,"""'   AND column_name = 'material_nbr')   SELECT CASE   WHEN cnt = 0 THEN 'NULL' ELSE 'src.material_nbr'   END   FROM dr""") INTO MATERIAL_NBR;
EXECUTE IMMEDIATE  CONCAT("""   WITH dr AS ( SELECT   COUNT(*) cnt FROM   """,BQ_PROCESSED_DATASET_NAME,""".INFORMATION_SCHEMA.COLUMNS WHERE   table_name = '""",SOURCE_TABLE_NAME,"""'   AND column_name = 'sls_hier_division_desc')   SELECT CASE   WHEN cnt = 0 THEN 'NULL' ELSE 'src.sls_hier_division_desc'   END   FROM dr""") INTO SLS_HIER_DIVISION_DESC;
EXECUTE IMMEDIATE  CONCAT("""   WITH dr AS ( SELECT   COUNT(*) cnt FROM   """,BQ_PROCESSED_DATASET_NAME,""".INFORMATION_SCHEMA.COLUMNS WHERE   table_name = '""",SOURCE_TABLE_NAME,"""'   AND column_name = 'sls_hier_category_desc')   SELECT CASE   WHEN cnt = 0 THEN 'NULL' ELSE 'src.sls_hier_category_desc'   END   FROM dr""") INTO SLS_HIER_CATEGORY_DESC;
EXECUTE IMMEDIATE  CONCAT("""   WITH dr AS ( SELECT   COUNT(*) cnt FROM   """,BQ_PROCESSED_DATASET_NAME,""".INFORMATION_SCHEMA.COLUMNS WHERE   table_name = '""",SOURCE_TABLE_NAME,"""'   AND column_name = 'sls_hier_sub_category_desc')   SELECT CASE   WHEN cnt = 0 THEN 'NULL' ELSE 'src.sls_hier_sub_category_desc'   END   FROM dr""") INTO SLS_HIER_SUB_CATEGORY_DESC;
EXECUTE IMMEDIATE  CONCAT("""   WITH dr AS ( SELECT   COUNT(*) cnt FROM   """,BQ_PROCESSED_DATASET_NAME,""".INFORMATION_SCHEMA.COLUMNS WHERE   table_name = '""",SOURCE_TABLE_NAME,"""'   AND column_name = 'sls_hier_accrual_group_desc')   SELECT CASE   WHEN cnt = 0 THEN 'NULL' ELSE 'src.sls_hier_accrual_group_desc'   END   FROM dr""") INTO SLS_HIER_ACCRUAL_GROUP_DESC;
EXECUTE IMMEDIATE  CONCAT("""   WITH dr AS ( SELECT   COUNT(*) cnt FROM   """,BQ_PROCESSED_DATASET_NAME,""".INFORMATION_SCHEMA.COLUMNS WHERE   table_name = '""",SOURCE_TABLE_NAME,"""'   AND column_name = 'sls_hier_sub_accrual_desc')   SELECT CASE   WHEN cnt = 0 THEN 'NULL' ELSE 'src.sls_hier_sub_accrual_desc'   END   FROM dr""") INTO SLS_HIER_SUB_ACCRUAL_DESC;
EXECUTE IMMEDIATE  CONCAT("""   WITH dr AS ( SELECT   COUNT(*) cnt FROM   """,BQ_PROCESSED_DATASET_NAME,""".INFORMATION_SCHEMA.COLUMNS WHERE   table_name = '""",SOURCE_TABLE_NAME,"""'   AND column_name = 'sls_hier_ppg_desc')   SELECT CASE   WHEN cnt = 0 THEN 'NULL' ELSE 'src.sls_hier_ppg_desc'   END   FROM dr""") INTO SLS_HIER_PPG_DESC;
EXECUTE IMMEDIATE  CONCAT("""   WITH dr AS ( SELECT   COUNT(*) cnt FROM   """,BQ_PROCESSED_DATASET_NAME,""".INFORMATION_SCHEMA.COLUMNS WHERE   table_name = '""",SOURCE_TABLE_NAME,"""'   AND column_name = 'gmi_category_desc')   SELECT CASE   WHEN cnt = 0 THEN 'NULL' ELSE 'src.gmi_category_desc'   END   FROM dr""") INTO GMI_CATEGORY_DESC;
EXECUTE IMMEDIATE  CONCAT("""   WITH dr AS ( SELECT   COUNT(*) cnt FROM   """,BQ_PROCESSED_DATASET_NAME,""".INFORMATION_SCHEMA.COLUMNS WHERE   table_name = '""",SOURCE_TABLE_NAME,"""'   AND column_name = 'gmi_sub_category_desc')   SELECT CASE   WHEN cnt = 0 THEN 'NULL' ELSE 'src.gmi_sub_category_desc'   END   FROM dr""") INTO GMI_SUB_CATEGORY_DESC;
EXECUTE IMMEDIATE  CONCAT("""   WITH dr AS ( SELECT   COUNT(*) cnt FROM   """,BQ_PROCESSED_DATASET_NAME,""".INFORMATION_SCHEMA.COLUMNS WHERE   table_name = '""",SOURCE_TABLE_NAME,"""'   AND column_name = 'gmi_segment_desc')   SELECT CASE   WHEN cnt = 0 THEN 'NULL' ELSE 'src.gmi_segment_desc'   END   FROM dr""") INTO GMI_SEGMENT_DESC;
EXECUTE IMMEDIATE  CONCAT("""   WITH dr AS ( SELECT   COUNT(*) cnt FROM   """,BQ_PROCESSED_DATASET_NAME,""".INFORMATION_SCHEMA.COLUMNS WHERE   table_name = '""",SOURCE_TABLE_NAME,"""'   AND column_name = 'gmi_brand_desc')   SELECT CASE   WHEN cnt = 0 THEN 'NULL' ELSE 'src.gmi_brand_desc'   END   FROM dr""") INTO GMI_BRAND_DESC;
EXECUTE IMMEDIATE  CONCAT("""   WITH dr AS ( SELECT   COUNT(*) cnt FROM   """,BQ_PROCESSED_DATASET_NAME,""".INFORMATION_SCHEMA.COLUMNS WHERE   table_name = '""",SOURCE_TABLE_NAME,"""'   AND column_name = 'gmi_global_brand_desc')   SELECT CASE   WHEN cnt = 0 THEN 'NULL' ELSE 'src.gmi_global_brand_desc'   END   FROM dr""") INTO GMI_GLOBAL_BRAND_DESC;
EXECUTE IMMEDIATE  CONCAT("""   WITH dr AS ( SELECT   COUNT(*) cnt FROM   """,BQ_PROCESSED_DATASET_NAME,""".INFORMATION_SCHEMA.COLUMNS WHERE   table_name = '""",SOURCE_TABLE_NAME,"""'   AND column_name = 'gmi_manufacturer_desc')   SELECT CASE   WHEN cnt = 0 THEN 'NULL' ELSE 'src.gmi_manufacturer_desc'   END   FROM dr""") INTO GMI_MANUFACTURER_DESC;
EXECUTE IMMEDIATE  CONCAT("""   WITH dr AS ( SELECT   COUNT(*) cnt FROM   """,BQ_PROCESSED_DATASET_NAME,""".INFORMATION_SCHEMA.COLUMNS WHERE   table_name = '""",SOURCE_TABLE_NAME,"""'   AND column_name = 'gmi_global_manufacturer_desc')   SELECT CASE   WHEN cnt = 0 THEN 'NULL' ELSE 'src.gmi_global_manufacturer_desc'   END   FROM dr""") INTO GMI_GLOBAL_MANUFACTURER_DESC;
EXECUTE IMMEDIATE  CONCAT("""   WITH dr AS ( SELECT   COUNT(*) cnt FROM   """,BQ_PROCESSED_DATASET_NAME,""".INFORMATION_SCHEMA.COLUMNS WHERE   table_name = '""",SOURCE_TABLE_NAME,"""'   AND column_name = 'brand_high_desc')   SELECT CASE   WHEN cnt = 0 THEN 'NULL' ELSE 'src.brand_high_desc'   END   FROM dr""") INTO BRAND_HIGH_DESC;
EXECUTE IMMEDIATE  CONCAT("""   WITH dr AS ( SELECT   COUNT(*) cnt FROM   """,BQ_PROCESSED_DATASET_NAME,""".INFORMATION_SCHEMA.COLUMNS WHERE   table_name = '""",SOURCE_TABLE_NAME,"""'   AND column_name = 'brand_low_desc')   SELECT CASE   WHEN cnt = 0 THEN 'NULL' ELSE 'src.brand_low_desc'   END   FROM dr""") INTO BRAND_LOW_DESC;
EXECUTE IMMEDIATE  CONCAT("""   WITH dr AS ( SELECT   COUNT(*) cnt FROM   """,BQ_PROCESSED_DATASET_NAME,""".INFORMATION_SCHEMA.COLUMNS WHERE   table_name = '""",SOURCE_TABLE_NAME,"""'   AND column_name = 'gmi_megacategory_desc')   SELECT CASE   WHEN cnt = 0 THEN 'NULL' ELSE 'src.gmi_megacategory_desc'   END   FROM dr""") INTO GMI_MEGACATEGORY_DESC;
EXECUTE IMMEDIATE  CONCAT("""   WITH dr AS ( SELECT   COUNT(*) cnt FROM   """,BQ_PROCESSED_DATASET_NAME,""".INFORMATION_SCHEMA.COLUMNS WHERE   table_name = '""",SOURCE_TABLE_NAME,"""'   AND column_name = 'ean_upc_derived_cd')   SELECT CASE   WHEN cnt = 0 THEN 'NULL' ELSE 'src.ean_upc_derived_cd'   END   FROM dr""") INTO EAN_UPC_DERIVED_CD;
EXECUTE IMMEDIATE  CONCAT("""   WITH dr AS ( SELECT   COUNT(*) cnt FROM   """,BQ_PROCESSED_DATASET_NAME,""".INFORMATION_SCHEMA.COLUMNS WHERE   table_name = '""",SOURCE_TABLE_NAME,"""'   AND column_name = 'base_uom_to_ecv_fctr')   SELECT CASE   WHEN cnt = 0 THEN 'NULL' ELSE 'src.base_uom_to_ecv_fctr'   END   FROM dr""") INTO BASE_UOM_TO_ECV_FCTR;

     -- source item code is not present for all the customers.
     -- We are creating the join statement on source_item_code if it is present.
     -- The below join is used while harmonizing the source_item_name to upc and source_item_code

EXECUTE IMMEDIATE CONCAT("""   WITH
    dr AS (
    SELECT
      COUNT(*) cnt
    FROM
      """,BQ_PROCESSED_DATASET_NAME,""".INFORMATION_SCHEMA.COLUMNS
    WHERE
        table_name = '""",SOURCE_TABLE_NAME,"""'
        AND column_name = 'source_item_code')
    SELECT
      CASE
        WHEN cnt = 0 THEN ''
      ELSE
      'and COALESCE(a.source_item_code,\\'\\') = COALESCE(b.source_item_code,\\'\\')'
    END
    FROM
      dr""") INTO SOURCE_ITEM_CODE_JOIN;

/* Identifying Region Specific columns using naturalkey lookup table and inserting data for only those columns into customer specific weekly_agg_fact Table */

/* Fetching region_specific_columns columns from naturalkey Lookup table and storing into region_specific_columns variable */
 EXECUTE IMMEDIATE
   CONCAT("""
   SELECT
   IF
     (LENGTH(COALESCE(TRIM(REGEXP_REPLACE( CONCAT("'",region_specific_columns,"'"),",","','")),
           '  ')) <= 2,
       'EMPTY',
       REGEXP_REPLACE(CONCAT("'",region_specific_columns,"'"),",","','")) AS region_specific_columns,
   IF
     (LENGTH(COALESCE(TRIM(REGEXP_REPLACE( CONCAT("'",region_specific_agg_columns,"'"),",","','")),
           '  ')) <= 2,
       'EMPTY',
       REGEXP_REPLACE(CONCAT("'",region_specific_agg_columns,"'"),",","','")) AS region_specific_agg_columns,
   FROM
     `""",BQ_PROJECT_NAME,""".""",BQ_TRANSIENT_DATASET_NAME,""".""",NATURAL_KEY_LOOKUP_TABLE,"""`
   WHERE
     CUSTOMER_NAME ='""",CUSTOMER_NAME,"""'
     AND FEED_NAME = '""",FEED_NAME,"""'""") INTO REGION_SPECIFIC_COLUMNS,REGION_SPECIFIC_AGG_COLUMNS;
   /* Validating if region_specific_columns & region_specific_agg_columns columns from naturalkey Lookup table exists or not based on following criteria
     If it does not exists in lookup table : region_specific_columns & region_specific_agg_columns value will be blank and it won't be used further.
     If it exists in lookup table but not in weekly_agg_fact ddl : region_specific_columns value will be blank and it won't be used further.
     If it exists in lookup table as well in weekly_agg_fact ddl : Column names and data_type will be fetched from retailer specific fact table and it will be casted automatically as per weekly_agg_fact table. */
 IF
   REGION_SPECIFIC_COLUMNS <> "EMPTY" AND REGION_SPECIFIC_AGG_COLUMNS <> "EMPTY" THEN
 EXECUTE IMMEDIATE
   CONCAT("""
   WITH
     cte AS (
     SELECT
       column_name,
       data_type
     FROM
       `""",BQ_PROJECT_NAME,"""`.""",BQ_PROCESSED_DATASET_NAME,""".INFORMATION_SCHEMA.COLUMNS
     WHERE
       table_name='""",TARGET_TABLE_NAME,"""'
       AND (column_name IN (""",REGION_SPECIFIC_COLUMNS,""")
         OR column_name IN (""",REGION_SPECIFIC_AGG_COLUMNS,"""))), cte1 AS (
     SELECT
       column_name
     FROM
       `""",BQ_PROJECT_NAME,"""`.""",BQ_PROCESSED_DATASET_NAME,""".INFORMATION_SCHEMA.COLUMNS
     WHERE
       table_name='""",SOURCE_TABLE_NAME,"""'
       AND (column_name IN (""",REGION_SPECIFIC_COLUMNS,""")
         OR column_name IN (""",REGION_SPECIFIC_AGG_COLUMNS,""")))
   SELECT
     COALESCE(CONCAT(STRING_AGG(CASE
             WHEN cte1.column_name IS NULL THEN CONCAT("CAST(NULL AS ",cte.data_type,") AS ",cte.column_name)
             WHEN cte1.column_name IN (""",REGION_SPECIFIC_COLUMNS,""") THEN CONCAT("CAST(src.",cte.column_name," AS ",data_type,") AS ",cte.column_name)
           ELSE
           NULL
         END
           ),','),
       '  ') AS VAL,
     COALESCE(CONCAT(STRING_AGG(CASE
             WHEN cte.column_name IN (""",REGION_SPECIFIC_AGG_COLUMNS,""") THEN CONCAT("agg.",cte.column_name," AS ",cte.column_name)
           ELSE
           NULL
         END
           ),','),
       '  ') AS region_specific_agg_columns,
     REPLACE(COALESCE(CONCAT(STRING_AGG(CASE
             WHEN cte.column_name IN (""",REGION_SPECIFIC_AGG_COLUMNS,""") AND STARTS_WITH(cte.column_name,'ty_') THEN CONCAT("src.",cte.column_name,", LEAD(src.",cte.column_name,
             ",1,null) over (partition by $$$,NATURAL_KEY_LY,$$$ order by src.fiscal_year_week_nbr desc) AS ",REPLACE(cte.column_name,'ty_','ly_'))
           ELSE NULL
         END
           ),','),
       '  '),'$$$','\"\"\"') AS data_agg,
     COALESCE(CONCAT(STRING_AGG(CASE
             WHEN cte1.column_name IS NULL THEN CONCAT("SUM(CAST(NULL AS ",cte.data_type,")) AS ",cte.column_name)
             WHEN cte1.column_name IN (""",REGION_SPECIFIC_AGG_COLUMNS,""") THEN CONCAT("SUM(CAST(p1.",cte.column_name," AS ",data_type,")) AS ",cte.column_name)
           ELSE
           NULL
         END
           ),','),
       '  ') AS agg_sales
   FROM
     cte
   LEFT JOIN
     cte1
   ON
     cte.column_name=cte1.column_name;""") INTO REGION_SPECIFIC_COLUMNS,REGION_SPECIFIC_AGG_COLUMNS,DATA_AGG,AGG_SALES;
 ELSEIF REGION_SPECIFIC_COLUMNS <> "EMPTY" AND REGION_SPECIFIC_AGG_COLUMNS = "EMPTY" THEN
 SET REGION_SPECIFIC_AGG_COLUMNS = '';
 EXECUTE IMMEDIATE
   CONCAT("""
   WITH
     cte AS (
     SELECT
       column_name,
       data_type
     FROM
       `""",BQ_PROJECT_NAME,"""`.""",BQ_PROCESSED_DATASET_NAME,""".INFORMATION_SCHEMA.COLUMNS
     WHERE
       table_name='""",TARGET_TABLE_NAME,"""'
       AND column_name IN (""",REGION_SPECIFIC_COLUMNS,""")), cte1 AS (
     SELECT
       column_name
     FROM
       `""",BQ_PROJECT_NAME,"""`.""",BQ_PROCESSED_DATASET_NAME,""".INFORMATION_SCHEMA.COLUMNS
     WHERE
       table_name='""",SOURCE_TABLE_NAME,"""'
       AND column_name IN (""",REGION_SPECIFIC_COLUMNS,"""))
   SELECT
     COALESCE(CONCAT(STRING_AGG(CASE
             WHEN cte1.column_name IS NULL THEN CONCAT("CAST(NULL AS ",cte.data_type,") AS ",cte.column_name)
             WHEN cte1.column_name IN (""",REGION_SPECIFIC_COLUMNS,""") THEN CONCAT("CAST(src.",cte.column_name," AS ",data_type,") AS ",cte.column_name)
           ELSE
           NULL
         END
           ),','),
       '  ') AS VAL
   FROM
     cte
   LEFT JOIN
     cte1
   ON
     cte.column_name=cte1.column_name;""") INTO REGION_SPECIFIC_COLUMNS;
 ELSEIF REGION_SPECIFIC_COLUMNS = "EMPTY" AND REGION_SPECIFIC_AGG_COLUMNS <> "EMPTY" THEN
 SET REGION_SPECIFIC_COLUMNS = '';
 EXECUTE IMMEDIATE
   CONCAT("""
   WITH
     cte AS (
     SELECT
       column_name,
       data_type
     FROM
       `""",BQ_PROJECT_NAME,"""`.""",BQ_PROCESSED_DATASET_NAME,""".INFORMATION_SCHEMA.COLUMNS
     WHERE
       table_name='""",TARGET_TABLE_NAME,"""'
       AND column_name IN (""",REGION_SPECIFIC_AGG_COLUMNS,""")), cte1 AS (
     SELECT
       column_name
     FROM
       `""",BQ_PROJECT_NAME,"""`.""",BQ_PROCESSED_DATASET_NAME,""".INFORMATION_SCHEMA.COLUMNS
     WHERE
       table_name='""",SOURCE_TABLE_NAME,"""'
       AND column_name IN (""",REGION_SPECIFIC_AGG_COLUMNS,"""))
   SELECT
     COALESCE(CONCAT(STRING_AGG(CASE
             WHEN cte.column_name IN (""",REGION_SPECIFIC_AGG_COLUMNS,""") THEN CONCAT("agg.",cte.column_name," AS ",cte.column_name)
           ELSE
           NULL
         END
           ),','),
       '  ') AS region_specific_agg_columns,
     REPLACE(COALESCE(CONCAT(STRING_AGG(CASE
             WHEN cte.column_name IN (""",REGION_SPECIFIC_AGG_COLUMNS,""") AND STARTS_WITH(cte.column_name,'ty_') THEN CONCAT("src.",cte.column_name,", LEAD(src.",cte.column_name,
             ",1,null) over (partition by """,NATURAL_KEY_LY,""" order by src.fiscal_year_week_nbr desc) AS ",REPLACE(cte.column_name,'ty_','ly_'))
           ELSE NULL
         END
           ),','),
       '  '),'$$$','\"\"\"') AS data_agg,
     COALESCE(CONCAT(STRING_AGG(CASE
             WHEN cte1.column_name IS NULL THEN CONCAT("SUM(CAST(NULL AS ",cte.data_type,")) AS ",cte.column_name)
             WHEN cte1.column_name IN (""",REGION_SPECIFIC_AGG_COLUMNS,""") THEN CONCAT("SUM(CAST(p1.",cte.column_name," AS ",data_type,")) AS ",cte.column_name)
           ELSE
           NULL
         END
           ),','),
       '  ') AS agg_sales
   FROM
     cte
   LEFT JOIN
     cte1
   ON
     cte.column_name=cte1.column_name;""") INTO REGION_SPECIFIC_AGG_COLUMNS,DATA_AGG,AGG_SALES;
 ELSE
 SET
   REGION_SPECIFIC_COLUMNS='';
 SET REGION_SPECIFIC_AGG_COLUMNS='';
 END IF;

/* Roll-up the data to week.
 Aggregate the metric columns on natural key
 Enrich the source table with customer flags,ty/ly aggregated metric data
 Currency Exchange Logic -  Multiply the sales with exchange rate if the currency code is not USD.
 Divested Flag - It was calculated in product table. But it is getting NULL when the join condition fails (it generally happens when UPC is NULL).
                 For such conditions the divested flag is defaulted to N (similar to hadoop)
 Harmonized data - We are harmonizing the source_item_name, so that, for every unique pair of upc and source_item_code,
                     we have a unique 'source_item_name'

 */
 EXECUTE IMMEDIATE
 CONCAT("""INSERT INTO `""",BQ_PROJECT_NAME,""".""",BQ_PROCESSED_DATASET_NAME,""".""",TARGET_TABLE_NAME,"""`
 WITH
 CUSTOMER_FLAGS AS (""",CUSTOMER_FLAGS,"""),
grouped_data as (select
DISTINCT upc,""",SOURCE_ITEM_CODE,""",source_item_name,retailer,
 row_number() over(partition by upc,""",SOURCE_ITEM_CODE,""",retailer order by fiscal_year_week_nbr desc,fact_sk desc) rnk1
from `""",BQ_PROJECT_NAME,""".""",BQ_PROCESSED_DATASET_NAME,""".""",SOURCE_TABLE_NAME,"""` src
 WHERE src.source_item_name is NOT NULL),
harmonized_data as (select DISTINCT a.* except(source_item_name),
b.source_item_name source_item_name  from
`""",BQ_PROJECT_NAME,""".""",BQ_PROCESSED_DATASET_NAME,""".""",SOURCE_TABLE_NAME,"""` a
left join grouped_data b
on COALESCE(a.upc,'') = COALESCE(b.upc,'')
 and COALESCE(a.retailer,'') = COALESCE(b.retailer,'')
""",SOURCE_ITEM_CODE_JOIN,"""
 and b.rnk1 = 1
),
 agg_sales AS (
 SELECT
     """,NATURAL_KEY,""",
     fiscal_year_week_nbr -100 ly_fiscal_year_week_nbr,
     SUM(ty_sales_value) ty_sales_value,
     SUM(ty_sales_units) ty_sales_units,
     SUM(ty_sales_eqc_units) AS ty_sales_eqc_units,
     """,AGG_SALES,"""
     SUM(CASE WHEN p1.currency_code = 'USD' THEN p1.ty_sales_value
     ELSE coalesce(CAST(p1.ty_sales_value * exchange_rate.direct_exchange_rate_to_unit_fctr AS float64),
     0.0) END) AS ty_sales_value_usd,
     currency_code,
     p1.fiscal_year_nbr,
     fiscal_week_in_year_nbr
 FROM
     harmonized_data p1
     left JOIN
     (SELECT
         exchange_rate.fiscal_year_nbr,
         exchange_rate.direct_exchange_rate_to_unit_fctr,
     source_currency_type_cd
         FROM
         `""",BQ_EDW_PROJECT_NAME,"""`.""",BQ_ENTERPRISE_DATASET_NAME,""".dim_currency_exchange_rates  exchange_rate
         WHERE
         exchange_rate_type_cd = 'P'
         AND target_currency_type_cd = 'USD'
     ) exchange_rate
     ON
     p1.fiscal_year_nbr=exchange_rate.fiscal_year_nbr
     AND exchange_rate.source_currency_type_cd = p1.currency_code
 GROUP BY
     """,NATURAL_KEY,""",
     fiscal_year_week_nbr -100,
     currency_code,
     fiscal_year_nbr,
     fiscal_week_in_year_nbr),

     -- LEAD windowing function helps in calculating the LY metrics
     -- We are partitioning by the natural key and 'fiscal_year_in_week_nbr' column
     -- This groups each fiscal week across different years together
     -- We then fetch the 'TY' value of last year which becomes 'LY' value for current year.

    data_agg AS (
    SELECT
        """,AGG_NATURAL_KEY,""",
        src.ty_sales_value,
        src.ly_fiscal_year_week_nbr,
        LEAD (src.ty_sales_value,1,null) over (partition by """,NATURAL_KEY_LY,"""
        order by src.fiscal_year_week_nbr desc) ly_sales_value,
        src.ty_sales_units ty_sales_units,
        LEAD (src.ty_sales_units,1,null) over (partition by """,NATURAL_KEY_LY,"""
        order by src.fiscal_year_week_nbr desc) ly_sales_units,
        src.ty_sales_eqc_units,
        LEAD (src.ty_sales_eqc_units,1,null) over (partition by """,NATURAL_KEY_LY,"""
        order by src.fiscal_year_week_nbr desc) ly_sales_eqc_units,
        """,DATA_AGG,"""
        src.ty_sales_value_usd,
        LEAD (src.ty_sales_value_usd,1,null) over (partition by """,NATURAL_KEY_LY,"""
        order by src.fiscal_year_week_nbr desc) ly_sales_value_usd
    FROM
        agg_sales src
    ),
    src_data AS (
    SELECT
        src.upc,
        src.fiscal_week_begin_dt,
        src.fiscal_week_end_dt,
        src.source_item_name,
        CAST(""",BASE_PRODUCT_CD,""" AS STRING),
        src.base_product_desc,
        src.material_cd,
        src.material_short_desc,
        CAST(""",MATERIAL_NBR,""" AS STRING),
        src.ean_upc_cd,
        src.xref_brand,
        src.xref_sub_brand,
        src.country,
        src.segment,
        src.channel,
        src.customer_share_flag,
        src.standard_currency_symbol,
        src.standard_currency_code,
        src.customer_desc,
        src.retailer,
        src.manufacturer,
        src.fiscal_week_in_year_nbr,
        src.fiscal_month_in_year_short_desc,
        src.fiscal_quarter_nbr,
        src.fiscal_month_in_year_nbr,
        src.fiscal_quarter_in_year_nbr,
        src.fiscal_year_nbr,
        src.fiscal_year_week_nbr,
        CONCAT(src.fiscal_month_in_year_nbr,'-',src.fiscal_month_in_year_short_desc) fiscal_month_number_short_desc,
        CONCAT('Q',src.fiscal_quarter_in_year_nbr) fiscal_quarter_number_short_desc,
        CONCAT('FY',subSTRING(CAST(src.fiscal_year_nbr AS string),
            3,
            4)) fiscal_year,
        src.fiscal_year_short_desc,
        src.fiscal_year_month_nbr,
        src.global_category,
        src.global_sub_category,
        src.share_category_relevancy_flag,
        CAST(""",SLS_HIER_DIVISION_DESC,""" AS STRING),
        CAST(""",SLS_HIER_CATEGORY_DESC,""" AS STRING),
        CAST(""",SLS_HIER_SUB_CATEGORY_DESC,""" AS STRING),
        CAST(""",SLS_HIER_ACCRUAL_GROUP_DESC,""" AS STRING),
        CAST(""",SLS_HIER_SUB_ACCRUAL_DESC,""" AS STRING),
        CAST(""",SLS_HIER_PPG_DESC,""" AS STRING),
        src.gph_hier_category_desc,
        src.gph_hier_flavor_format_desc,
        src.gph_hier_package_size_desc,
        src.gph_hier_family_desc,
        src.gph_hier_top_desc,
        CAST(""",GMI_CATEGORY_DESC,""" AS STRING),
        CAST(""",GMI_SUB_CATEGORY_DESC,""" AS STRING),
        CAST(""",GMI_SEGMENT_DESC,""" AS STRING),
        CAST(""",GMI_BRAND_DESC,""" AS STRING),
        CAST(""",GMI_GLOBAL_BRAND_DESC,""" AS STRING),
        CAST(""",GMI_MANUFACTURER_DESC,""" AS STRING),
        CAST(""",GMI_GLOBAL_MANUFACTURER_DESC,""" AS STRING),
        CAST(""",BRAND_HIGH_DESC,""" AS STRING),
        CAST(""",BRAND_LOW_DESC,""" AS STRING),
        CAST(""",GMI_MEGACATEGORY_DESC,""" AS STRING),
        CAST(""",EAN_UPC_DERIVED_CD,""" AS STRING),
        src.resolved_brand,
        src.resolved_category,
        src.resolved_product_name,
        COALESCE(src.divested_fg,'N'),
        CAST(src.base_uom_to_eqc_fctr AS NUMERIC),
        CAST(""",BASE_UOM_TO_ECV_FCTR,""" AS NUMERIC),
        agg.ty_sales_eqc_units,
        agg.ly_sales_eqc_units,
        (COALESCE(agg.ty_sales_eqc_units,0) - COALESCE(agg.ly_sales_eqc_units,0)) change_in_sales_eqc,
        agg.ty_sales_units,
        agg.ly_sales_units,
        (COALESCE(agg.ty_sales_units,0) - COALESCE(agg.ly_sales_units,0)) change_in_sales_units,
        agg.ty_sales_value,
        agg.ly_sales_value,
        (COALESCE(agg.ty_sales_value,0) - COALESCE(agg.ly_sales_value,0))change_in_sales_value,
        agg.ty_sales_value_usd,
        agg.ly_sales_value_usd,
        (COALESCE(agg.ty_sales_value_usd,0) - COALESCE(agg.ly_sales_value_usd,0)) change_in_sales_value_usd,
        '""",GRAIN,"""',
        src.report_fg,
        src.notes,
        src.bph20_desc,
        src.bph30_desc,
        src.bph40_desc,
        src.bph50_desc,
        src.bph60_desc,
        src.bph70_desc,
        src.customer_parent,
        src.customer_account,
        src.global_category_parent,
        src.zone_hierarchy,
        src.customer_sales_flag,
        src.CUSTOMER_NAME,
        src.currency_code,
        src.currency_symbol,
        CAST(""",SOURCE_ITEM_CODE,""" AS STRING),
        """,REGION_SPECIFIC_COLUMNS,"""
        """,REGION_SPECIFIC_AGG_COLUMNS,"""
        ROW_NUMBER() OVER (PARTITION BY """,AGG_NATURAL_KEY,""") rn
    FROM
        harmonized_data src
    LEFT JOIN
        data_agg agg
    ON
        """,NATURAL_KEY_JOIN,""" )
    SELECT
    ROW_NUMBER() OVER() agg_fact_sk,
    src.* EXCEPT (rn),
    calendar_year_nbr,
    fiscal_date_customer_max,
    rolling_13_fg,
    rolling_26_fg,
    rolling_52_fg,
    latest_completed_fiscal_month_fg,
    latest_completed_fiscal_quarter_fg,
    latest_completed_fiscal_year_fg,
    CAST(""",EUAU_BUSINESS_OPERATING_UNIT_DESC,""" AS STRING),
    CAST(""",EUAU_BUSINESS_PRODUCT_GROUP_DESC,""" AS STRING),
    CAST(""",EUAU_BUSINESS_PRODUCT_SUB_GROUP_DESC,""" AS STRING),
    CAST(""",PRODUCT_CATEGORY_DERIVED_DESC,""" AS STRING),
    CAST(""",PRODUCT_SECTOR_DESC,""" AS STRING),
    CAST(""",PRODUCT_SUB_SEGMENT_DERIVED_DESC,""" AS STRING),
    CASE
        WHEN src.fiscal_month_in_year_nbr = 1 THEN 'P01-Jun'
        WHEN src.fiscal_month_in_year_nbr = 2 THEN 'P02-Jul'
        WHEN src.fiscal_month_in_year_nbr = 3 THEN 'P03-Aug'
        WHEN src.fiscal_month_in_year_nbr = 4 THEN 'P04-Sep'
        WHEN src.fiscal_month_in_year_nbr = 5 THEN 'P05-Oct'
        WHEN src.fiscal_month_in_year_nbr = 6 THEN 'P06-Nov'
        WHEN src.fiscal_month_in_year_nbr = 7 THEN 'P07-Dec'
        WHEN src.fiscal_month_in_year_nbr = 8 THEN 'P08-Jan'
        WHEN src.fiscal_month_in_year_nbr = 9 THEN 'P09-Feb'
        WHEN src.fiscal_month_in_year_nbr = 10 THEN 'P10-Mar'
        WHEN src.fiscal_month_in_year_nbr = 11 THEN 'P11-Apr'
        WHEN src.fiscal_month_in_year_nbr = 12 THEN 'P12-May'
    ELSE
    ' '
    END
    AS fiscal_month_verbose_tableau_mapping,
    CAST(src.fiscal_week_begin_dt AS date) AS fiscal_week_begin_dt_tableau_mapping,

    -- Added NULL check to make sure 'item_name_with_code_tableau_mapping' column is not NULL
    -- when either of the source_item_name or UPC is NULL.
    -- 'item_name_with_code_tableau_mapping' will be NULL if both the columns are NULL

    CASE WHEN CONCAT(COALESCE(src.source_item_name,''),' ',COALESCE(src.upc,'')) = ' ' THEN NULL
    ELSE CONCAT(COALESCE(src.source_item_name,''),' ',COALESCE(src.upc,''))
    END AS item_name_with_code_tableau_mapping,
    CASE
        WHEN manufacturer = 'General Mills' THEN 'General Mills'
    ELSE
    resolved_brand
    END
    AS manufacturer_brand_tableau_mapping,
    '""",job_run_id,"""',
    CURRENT_DATETIME(),
    '""",job_run_id,"""',
    CURRENT_DATETIME()
    FROM
    src_data src
    LEFT JOIN
    CUSTOMER_FLAGS cust_fg
    ON
    src.fiscal_week_begin_dt = cust_fg.fiscal_week_begin_dt
    LEFT JOIN
    `""",BQ_EDW_PROJECT_NAME,""".""",BQ_ENTERPRISE_DATASET_NAME,""".dim_date` cal
    ON
    CAST(src.fiscal_week_begin_dt AS DATE) = cal.calendar_dt
    and language_cd = 'EN'
    and cal.fiscal_year_variant_cd = '07'
    WHERE
    src.rn=1""");

CALL
  transient.ecomm_sproc_insert_ly_for_no_ty_sales (
    BQ_PROJECT_NAME,
    BQ_EDW_PROJECT_NAME,
    BQ_ENTERPRISE_DATASET_NAME,
    BQ_TRANSIENT_DATASET_NAME,
    BQ_PROCESSED_DATASET_NAME,
    TARGET_TABLE_NAME,
    CUSTOMER_NAME,
    FEED_NAME );


END IF;
EXCEPTION WHEN ERROR THEN
        EXECUTE IMMEDIATE CONCAT(
            """INSERT INTO processed.sproc_error_details (
		        SELECT
			        '""",FEED_NAME,"""' AS FEED_NAME,
                    split(split(@@error.formatted_stack_trace,'transient.')[OFFSET (1)],'[')[OFFSET(0)],
			        @@error.statement_text,
			        @@error.message,
			        current_timestamp()
	        );
	    """);

	    SELECT
	        ERROR (
	            CONCAT(
	            		@@error.message ,' ' ,
	            		@@error.statement_text, ' ' ,
	            		@@error.formatted_stack_trace ,' '
	            	)
	        );
    END  ;