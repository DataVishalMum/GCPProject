  /* 
  Purpose OF the stored proc : 
	Perform fuzzy matching of the source UPC with product UPC. Upsert the dimension dim_source_to_enterprise_upc_xref

  History OF Changes : 
        03/23 first version
        04/06 Changed the UPC XREF dimension table structure to remove checksum columns
        04/06 Changed the pre-override table name from 'raw.ecom_xref_nar_source_overwrite_flat' to 'processed.lkp_nar_source_overwrite'
        05/11 Changed the post-override table name from 'raw.ecom_xref_upc_override' to 'processed.lkp_upc_override'. Currently implementing the post override for Shipt customer (similar to hadoop)
        05/25 Added a logic that will check the presence of 'gmi_upc' column in the source. For DA in-store tables,upc column is 'gmi_upc'
        07/07 - Enterprise dimension changes
        09/13 Shipt UPC override logic needs to be revistied! insert_post_override: SHIPT_DO_NOT_DELETE
        05/10 - Updated composer related params and added sproc error mechanism

  Author : 
		Pawan Rathod

  */

CREATE OR REPLACE PROCEDURE
  transient.ecomm_sproc_dim_source_to_enterprise_upc_xref (
    SRC_PROJECT STRING,
    SRC_DATASET STRING,
    DEST_DATASET STRING,
    SRC_LOOKUP_PROJECT STRING,
    SRC_LOOKUP_DATASET STRING,
    CUSTOMER_NAME STRING,
    SRC_TABLE STRING,
    DEST_TABLE STRING,
    FEED_NAME STRING
)
OPTIONS(
description = """

 How to call:

     CALL transient.ecomm_sproc_dim_source_to_enterprise_upc_xref (
		"ecomm-dlf-dev-01cd47", -- SRC_PROJECT
        "transient", -- SRC_DATASET
        "processed", -- DEST_DATASET
        "edw-qa-c89f9d", -- SRC_LOOKUP_PROJECT
        "enterprise", -- SRC_LOOKUP_DATASET
        "AMAZON_COM", -- CUSTOMER_NAME
        "amazon_com_delta_temp", -- CUSTOMER_NAME
        "dim_source_to_enterprise_upc_xref", -- DEST_TABLE
        "AMAZON_COM" -- FEED_NAME
	)
"""
)
BEGIN

DECLARE JOB_RUN_ID DEFAULT 999999;
DECLARE BQ_PROJECT_NAME DEFAULT SRC_PROJECT;
DECLARE BQ_TRANSIENT_DATASET_NAME DEFAULT SRC_DATASET;
DECLARE BQ_PROCESSED_DATASET_NAME DEFAULT DEST_DATASET;
DECLARE BQ_EDW_PROJECT_NAME DEFAULT SRC_LOOKUP_PROJECT;
DECLARE BQ_ENTERPRISE_DATASET_NAME DEFAULT SRC_LOOKUP_DATASET;
DECLARE BQ_DELTA_TEMP_TABLE DEFAULT SRC_TABLE;
DECLARE UPC_XREF_DIM_TABLE_NAME DEFAULT DEST_TABLE;

DECLARE
  GET_SOURCE_UPC,
  SOURCE_UPC_TYPE,
  FUZZY_MATCH,
  UPDATE_NEW_RECORDS,
  UPSERT_TARGET,
  INSERT_POST_OVERRIDE,
  UPSERT_POST_OVERRIDE,
  SOURCE_UPC_COLUMN,
  UPC_COL STRING;


 SET CUSTOMER_NAME = UPPER(CUSTOMER_NAME);

 SET FEED_NAME = UPPER(FEED_NAME);

-- Find source UPC Type. Amazon fresh and Amazon Prime Now customers have a 'ASIN' source UPC type.
EXECUTE IMMEDIATE
 CONCAT( """
SELECT
  CASE
    WHEN UPPER('""",CUSTOMER_NAME,"""')='AMAZON_PRIME_NOW' OR UPPER('""",CUSTOMER_NAME,"""')='AMAZON_FRESH' THEN 'ASIN'
  ELSE
  'UPC'
END
  AS source_upc_type""") INTO SOURCE_UPC_TYPE;

-- DA in-store tables have 'gmi_upc' as the 'upc' column, 
-- Here we consider 'gmi_upc' as the source UPC, if it is present in the source 
-- 'upc_col' variable to hold the source column - upc/gmi_upc 
EXECUTE IMMEDIATE  CONCAT("""   WITH
  dr AS (
  SELECT
    COUNT(*) cnt
  FROM
    """,BQ_TRANSIENT_DATASET_NAME,""".INFORMATION_SCHEMA.COLUMNS
  WHERE
    table_name = '""",BQ_DELTA_TEMP_TABLE,"""'
    AND column_name = 'gmi_upc')
SELECT
  CASE
    WHEN cnt = 0 THEN 'upc'
  ELSE
  'gmi_upc'
END
FROM
  dr""") INTO UPC_COL;

-- Source Item Code holds the ASIN number for Amazon Fresh and Amazon Prime Now. 
-- Source UPC column is the 'source_item_code' column if it is present, otherwise it is the UPC column from the source. (which can be either 'upc' or 'gmi_upc' based on 'upc_col' variable value)
EXECUTE IMMEDIATE
  CONCAT("""
  SELECT
  CASE
    WHEN UPPER('""",CUSTOMER_NAME,"""')='AMAZON_PRIME_NOW' OR UPPER('""",CUSTOMER_NAME,"""')='AMAZON_FRESH' THEN 'source_item_code'
    ELSE '""",UPC_COL,"""' END AS source_upc_column""") INTO SOURCE_UPC_COLUMN;

/* Override the source UPC with the UPC from lookup table. The overwritten UPC becomes the customer UPC.
** If an existing source UPC has a different customer UPC, the existing record is deactivated and a new record is added
** All the new source UPCs are inserted into the table.*/
SET
  GET_SOURCE_UPC = CONCAT("""
  MERGE INTO
    `""",BQ_PROJECT_NAME,""".""",BQ_PROCESSED_DATASET_NAME,""".""",UPC_XREF_DIM_TABLE_NAME,"""` AS lkpUpcXref
  USING
    (
    WITH
      prepSrcUpcTab AS (
      SELECT
        DISTINCT s.""",SOURCE_UPC_COLUMN,""" source_upc,
        COALESCE(override_upc,
          CAST(s.""",UPC_COL,""" AS string)) AS customer_upc,
        '""",CUSTOMER_NAME,"""' AS CUSTOMER_NAME
      FROM
        `""",BQ_PROJECT_NAME,""".""",BQ_TRANSIENT_DATASET_NAME,""".""",BQ_DELTA_TEMP_TABLE,"""` s
      LEFT JOIN
        `""",BQ_PROJECT_NAME,""".""",BQ_PROCESSED_DATASET_NAME,""".lkp_nar_source_overwrite` o
      ON
        s.""",UPC_COL,""" = o.upc
        AND o.CUSTOMER_NAME=s.CUSTOMER_NAME)
    SELECT
      DISTINCT CAST(source_upc AS STRING) AS joinKey,
      CAST(source_upc AS STRING) AS source_upc,
      customer_upc,
      CUSTOMER_NAME
    FROM
      prepSrcUpcTab
    UNION ALL
    SELECT
      DISTINCT '-' AS joinKey,
      CAST(prepSrcUpcTab.source_upc AS STRING) AS source_upc,
      prepSrcUpcTab.customer_upc,
      lkpUpcXref.CUSTOMER_NAME
    FROM
      prepSrcUpcTab
    JOIN (
      SELECT
        DISTINCT source_upc,
        customer_upc,
        CUSTOMER_NAME
      FROM
        `""",BQ_PROJECT_NAME,""".""",BQ_PROCESSED_DATASET_NAME,""".""",UPC_XREF_DIM_TABLE_NAME,"""`
      WHERE
        CUSTOMER_NAME='""",CUSTOMER_NAME,"""'
        AND current_flg='Y') AS lkpUpcXref
    ON
      CAST(prepSrcUpcTab.source_upc AS STRING) = lkpUpcXref.source_upc
    WHERE
      prepSrcUpcTab.customer_upc <> lkpUpcXref.customer_upc) upsertTab
  ON
    upsertTab.joinKey = lkpUpcXref.source_upc
    AND upsertTab.CUSTOMER_NAME =lkpUpcXref.CUSTOMER_NAME
    WHEN MATCHED AND upsertTab.customer_upc <> lkpUpcXref.customer_upc THEN UPDATE SET lkpUpcXref.current_flg ='N', lkpUpcXref.end_date = CURRENT_DATETIME(), lkpUpcXref.comments= 'Found new customer upc has change hence, deactivated.'
    WHEN NOT MATCHED
    AND upsertTab.customer_upc IS NOT NULL THEN
  INSERT
  VALUES
    (-9999,'""",CUSTOMER_NAME,"""',upsertTab.source_upc,'""",SOURCE_UPC_TYPE,"""',upsertTab.customer_upc,NULL,NULL,NULL,'Waiting for new target upc.',NULL,current_datetime(),CAST(NULL AS datetime),'Y','""",job_run_id,"""',CURRENT_DATETIME(),CAST(NULL AS string),CAST(NULL AS datetime))""");
EXECUTE IMMEDIATE
  GET_SOURCE_UPC;

/* Execute fuzzy match ON ALL customer UPCs
** Calculate all the permutations for the ean_upc_Cd and base_product_ean_derived_upc_cd
** If the UPC is exactly matching the ean_upc_cd , priority is 1
** If the UPC is matching with any permutation of the ean_upc_cd, priority is 2
** If the 10 digits of the UPC matches with any permutation of the ean_upc_cd, priority is 3
** If the first 10 digits (excluding the leading 0s) matches with the permutation of ean_upc_cd, priority is 4
** If the UPC matches with any permutation of base_product_ean_upc_cd,priority is 5
** If the 10 digits of UPC matches with any permutation of base_product_ean_upc_cd, priority is 6
** Add the data computed using fuzzy match to a temporary table.
*/
SET
  FUZZY_MATCH = CONCAT("""
  CREATE TABLE IF NOT EXISTS 
    `""",BQ_PROJECT_NAME,""".""",BQ_TRANSIENT_DATASET_NAME,""".dim_upc_xref_temp` AS (
    WITH
      temp AS (
      SELECT
        DISTINCT customer_upc AS overwritten_upc
      FROM
        `""",BQ_PROJECT_NAME,""".""",BQ_PROCESSED_DATASET_NAME,""".""",UPC_XREF_DIM_TABLE_NAME,"""`
      WHERE
        CUSTOMER_NAME ='""",CUSTOMER_NAME,"""'
        AND current_flg='Y'),
      ean_upc_temp AS (
      SELECT
        ARRAY_AGG(z
        LIMIT
          1)[
      OFFSET
        (0)] ROW
      FROM (
        SELECT
          ean_upc_cd,
          base_product_ean_upc_derived_cd,
          t
        FROM (
          SELECT
            ean_upc_cd,
            base_product_ean_upc_derived_cd,
            permEanUpc
          FROM (
            SELECT
              ean_upc_cd,
              base_product_ean_upc_derived_cd,
              """,BQ_PROCESSED_DATASET_NAME,""".permutationUpc(ean_upc_cd,
                [10,
                11,
                12,
                13,
                14]) AS permEanUpc
            FROM
              `""",BQ_EDW_PROJECT_NAME,""".""",BQ_ENTERPRISE_DATASET_NAME,""".dim_product_active`
            WHERE
              source_type_cd = 'NA'
              AND material_type_cd = 'CNPK'
              AND language_cd = 'EN'
              AND ean_upc_cd IS NOT NULL)),
          UNNEST(permEanUpc) AS t
        ORDER BY
          ean_upc_cd)z
      GROUP BY
        z.t),
      base_prod_temp AS (
      SELECT
        ARRAY_AGG(z
        LIMIT
          1)[
      OFFSET
        (0)] ROW
      FROM (
        SELECT
          ean_upc_cd,
          base_product_ean_upc_derived_cd,
          t
        FROM (
          SELECT
            ean_upc_cd,
            base_product_ean_upc_derived_cd,
            permBaseUpc
          FROM (
            SELECT
              ean_upc_cd,
              base_product_ean_upc_derived_cd,
              """,BQ_PROCESSED_DATASET_NAME,""".permutationUpc(base_product_ean_upc_derived_cd,
                [10,
                11,
                12,
                13,
                14]) AS permBaseUpc
            FROM
              `""",BQ_EDW_PROJECT_NAME,""".""",BQ_ENTERPRISE_DATASET_NAME,""".dim_product_active`
            WHERE
              source_type_cd = 'NA'
              AND material_type_cd = 'CNPK'
              AND language_cd = 'EN'
              AND base_product_ean_upc_derived_cd IS NOT NULL)),
          UNNEST(permBaseUpc) AS t
        ORDER BY
          base_product_ean_upc_derived_cd)z
      GROUP BY
        z.t),
      fuzzy AS (
      SELECT
        upc,
        ean_upc_cd,
        base_product_ean_upc_derived_cd,
        rank,
        ROW_NUMBER() OVER (PARTITION BY upc ORDER BY rank) AS priority
      FROM (
        SELECT
          DISTINCT overwritten_upc AS upc,
          ean_upc_cd,
          base_product_ean_upc_derived_cd,
          t,
          rank
        FROM ((
            SELECT
              s.overwritten_upc,
              e.ean_upc_cd,
              e.base_product_ean_upc_derived_cd,
              '' AS t,
              1 AS rank
            FROM
              temp s
            JOIN
              `""",BQ_EDW_PROJECT_NAME,""".""",BQ_ENTERPRISE_DATASET_NAME,""".dim_product_active` e
            ON
              LTRIM(s.overwritten_upc,'0') = LTRIM(e.ean_upc_cd,'0')
            WHERE
              e.source_type_cd = 'NA'
              AND e.material_type_cd = 'CNPK'
              AND e.language_cd = 'EN')
          UNION ALL (
            SELECT
              s.overwritten_upc,
              e.ROW.ean_upc_cd,
              e.ROW.base_product_ean_upc_derived_cd,
              e.ROW.t,
              2 AS rank
            FROM
              temp s
            JOIN
              ean_upc_temp e
            ON
              s.overwritten_upc = e.ROW.t)
          UNION ALL (
            SELECT
              s.overwritten_upc,
              e.ROW.ean_upc_cd,
              e.ROW.base_product_ean_upc_derived_cd,
              e.ROW.t,
              3 AS rank
            FROM
              temp s
            JOIN
              ean_upc_temp e
            ON
              """,BQ_PROCESSED_DATASET_NAME,""".get10DigitUpc(s.overwritten_upc) = e.ROW.t)
          UNION ALL (
            SELECT
              s.overwritten_upc,
              e.ROW.ean_upc_cd,
              e.ROW.base_product_ean_upc_derived_cd,
              e.ROW.t,
              4 AS rank
            FROM
              temp s
            JOIN
              ean_upc_temp e
            ON
              LEFT(CAST(SAFE_CAST(s.overwritten_upc AS INT64)AS STRING),10) = e.ROW.t)
          UNION ALL (
            SELECT
              s.overwritten_upc,
              e.ROW.ean_upc_cd,
              e.ROW.base_product_ean_upc_derived_cd,
              e.ROW.t,
              5 AS rank
            FROM
              temp s
            JOIN
              base_prod_temp e
            ON
              s.overwritten_upc = e.ROW.t)
          UNION ALL (
            SELECT
              s.overwritten_upc,
              e.ROW.ean_upc_cd,
              e.ROW.base_product_ean_upc_derived_cd,
              e.ROW.t,
              6 AS rank
            FROM
              temp s
            JOIN
              base_prod_temp e
            ON
              """,BQ_PROCESSED_DATASET_NAME,""".get10DigitUpc(s.overwritten_upc) = e.ROW.t))
        ORDER BY
          upc))
    SELECT
      lkpXrefTab.source_upc,
      fuzzyResTab.*
    FROM ((
        SELECT
          upc AS customer_upc,
          CASE
            WHEN (rank = 1 OR rank = 2 OR rank = 3 OR rank = 4) THEN ean_upc_cd
            WHEN (rank = 5
            OR rank = 6) THEN base_product_ean_upc_derived_cd
          ELSE
          NULL
        END
          AS target_upc,
          rank AS priority,
          '""",CUSTOMER_NAME,"""' AS CUSTOMER_NAME,
          CASE
            WHEN rank =1 THEN 'upc exactly matches with ean_upc_cd'
            WHEN rank = 2 THEN 'upc matches with permutation of ean_upc_cd'
            WHEN rank = 3 THEN '10 digits of source upc matches with permutation of ean_upc_cd'
            WHEN rank = 4 THEN 'first 10 digits of source upc matches with permutation of ean_upc_cd'
            WHEN rank = 5 THEN 'source upc matches with permutation of base_product_ean_upc_derived_cd'
            WHEN rank = 6 THEN '10 digits of source upc matches with permutation of base_product_ean_upc_derived_cd'
          ELSE
          'No match'
        END
          AS comments,
          CASE
            WHEN (rank = 1 OR rank = 2 OR rank = 3 OR rank = 4) THEN 'ean_upc_cd'
            WHEN (rank = 5
            OR rank = 6) THEN 'base_product_ean_upc_derived_cd'
          ELSE
          NULL
        END
          AS upc_derived_from,
          '""",job_run_id,"""' AS created_by,
          '""",job_run_id,"""' AS modified_by,
          CURRENT_DATETIME() AS created_datetime,
          'Y' AS current_flg
        FROM
          fuzzy
        WHERE
          priority = 1)fuzzyResTab
      JOIN (
        SELECT
          source_upc,
          customer_upc
        FROM
          `""",BQ_PROJECT_NAME,""".""",BQ_PROCESSED_DATASET_NAME,""".""",UPC_XREF_DIM_TABLE_NAME,"""`
        WHERE
          CUSTOMER_NAME ='""",CUSTOMER_NAME,"""'
          AND current_flg='Y') lkpXrefTab
      ON
        fuzzyResTab.customer_upc=lkpXrefTab.customer_upc))""");
EXECUTE IMMEDIATE
  FUZZY_MATCH;

--UPDATE the target data for the NEW UPCs.
SET
  UPDATE_NEW_RECORDS = CONCAT("""
  UPDATE
    `""",BQ_PROJECT_NAME,""".""",BQ_PROCESSED_DATASET_NAME,""".""",UPC_XREF_DIM_TABLE_NAME,"""` AS lkpUpcXref
  SET
    lkpUpcXref.target_upc = updateData.target_upc, lkpUpcXref.priority = updateData.priority, lkpUpcXref.start_date = CURRENT_DATETIME(), lkpUpcXref.end_date = CAST(NULL AS datetime), lkpUpcXref.created_datetime = CURRENT_DATETIME(), lkpUpcXref.comments = updateData.comments, lkpUpcXref.upc_derived_from = updateData.upc_derived_from, lkpUpcXref.modified_by = '""",job_run_id,"""'
  FROM (
    SELECT
      DISTINCT a1.source_upc,
      a1.customer_upc,
      b1.target_upc,
      b1.priority,
      b1.comments,
      b1.upc_derived_from
    FROM (
      SELECT
        DISTINCT source_upc,
        customer_upc
      FROM
        `""",BQ_PROJECT_NAME,""".""",BQ_PROCESSED_DATASET_NAME,""".""",UPC_XREF_DIM_TABLE_NAME,"""`
      WHERE
        target_upc IS NULL
        AND current_flg='Y'
        AND CUSTOMER_NAME='""",CUSTOMER_NAME,"""') AS a1
    JOIN (
      SELECT
        DISTINCT source_upc,
        customer_upc,
        target_upc,
        priority,
        comments,
        upc_derived_from
      FROM
        `""",BQ_PROJECT_NAME,""".""",BQ_TRANSIENT_DATASET_NAME,""".dim_upc_xref_temp`
      WHERE
        CUSTOMER_NAME='""",CUSTOMER_NAME,"""') AS b1
    ON
      a1.customer_upc=b1.customer_upc
      AND a1.source_upc = b1.source_upc ) AS updateData
  WHERE
    lkpUpcXref.customer_upc = updateData.customer_upc
    AND lkpUpcXref.source_upc = updateData.source_upc""");
EXECUTE IMMEDIATE
  UPDATE_NEW_RECORDS;

--Upsert records WHERE target UPC OR priority has changed
SET
  UPSERT_TARGET = CONCAT("""
  MERGE INTO
    `""",BQ_PROJECT_NAME,""".""",BQ_PROCESSED_DATASET_NAME,""".""",UPC_XREF_DIM_TABLE_NAME,"""` AS lkpUpcXref
  USING
    (
    SELECT
      DISTINCT a1.customer_upc AS joinKey,
      a1.source_upc,
      a1.customer_upc,
      b1.target_upc,
      b1.priority,
      b1.comments,
      b1.upc_derived_from
    FROM (
      SELECT
        DISTINCT source_upc,
        customer_upc,
        target_upc,
        priority
      FROM
        `""",BQ_PROJECT_NAME,""".""",BQ_PROCESSED_DATASET_NAME,""".""",UPC_XREF_DIM_TABLE_NAME,"""`
      WHERE
        target_upc IS NOT NULL
        AND current_flg ='Y'
        AND priority <>0
        AND CUSTOMER_NAME = '""",CUSTOMER_NAME,"""') AS a1
    JOIN (
      SELECT
        DISTINCT source_upc,
        customer_upc,
        target_upc,
        priority,
        comments,
        upc_derived_from
      FROM
        `""",BQ_PROJECT_NAME,""".""",BQ_TRANSIENT_DATASET_NAME,""".dim_upc_xref_temp`
      WHERE
        CUSTOMER_NAME='""",CUSTOMER_NAME,"""') AS b1
    ON
      a1.customer_upc = b1.customer_upc
      AND a1.source_upc = b1.source_upc
    WHERE
      a1.target_upc <> b1.target_upc
      OR a1.priority <> b1.priority
    UNION ALL
    SELECT
      DISTINCT '-' AS joinKey,
      a1.source_upc,
      a1.customer_upc,
      b1.target_upc,
      b1.priority,
      b1.comments,
      b1.upc_derived_from
    FROM (
      SELECT
        DISTINCT source_upc,
        customer_upc,
        target_upc,
        priority
      FROM
        `""",BQ_PROJECT_NAME,""".""",BQ_PROCESSED_DATASET_NAME,""".""",UPC_XREF_DIM_TABLE_NAME,"""`
      WHERE
        target_upc IS NOT NULL
        AND current_flg ='Y'
        AND priority <>0
        AND CUSTOMER_NAME = '""",CUSTOMER_NAME,"""') AS a1
    JOIN (
      SELECT
        DISTINCT source_upc,
        customer_upc,
        target_upc,
        priority,
        comments,
        upc_derived_from
      FROM
        `""",BQ_PROJECT_NAME,""".""",BQ_TRANSIENT_DATASET_NAME,""".dim_upc_xref_temp`
      WHERE
        CUSTOMER_NAME='""",CUSTOMER_NAME,"""') AS b1
    ON
      a1.customer_upc = b1.customer_upc
      AND a1.source_upc = b1.source_upc
    WHERE
      a1.target_upc <> b1.target_upc
      OR a1.priority <> b1.priority ) AS upsertData
  ON
    upsertData.joinKey = lkpUpcXref.customer_upc
    AND upsertData.source_upc = lkpUpcXref.source_upc
    AND lkpUpcXref.CUSTOMER_NAME ='""",CUSTOMER_NAME,"""'
    WHEN MATCHED THEN UPDATE SET end_date = CURRENT_DATETIME(), current_flg = 'N', comments= 'Found new match hence, deactivated.', modified_by = '""",job_run_id,"""'
    WHEN NOT MATCHED
    THEN
  INSERT
  VALUES
    (-9999,'""",CUSTOMER_NAME,"""',upsertData.source_upc,'""",SOURCE_UPC_TYPE,"""', upsertData.customer_upc,upsertData.target_upc,NULL,upsertData.priority,upsertData.comments,upsertData.upc_derived_from,CURRENT_DATETIME(),CAST(NULL AS datetime),'Y','""",job_run_id,"""',CURRENT_DATETIME(),'""",job_run_id,"""',CAST(NULL AS datetime))""");
EXECUTE IMMEDIATE
  UPSERT_TARGET;
 
 -- Override the target UPC with the override UPC from a lookup table 
 -- Currently implemented for 'Shipt' customer. Disabled on 13th Sept 2021.
IF
  UPPER(CUSTOMER_NAME) = "SHIPT_DO_NOT_DELETE" THEN   --Shipt UPC override logic needs to be revistied
SET
  INSERT_POST_OVERRIDE = CONCAT("""
  UPDATE
    `""",BQ_PROJECT_NAME,""".""",BQ_PROCESSED_DATASET_NAME,""".""",UPC_XREF_DIM_TABLE_NAME,"""` AS dimUpcXref
  SET
    dimUpcXref.target_upc = updateData.ean_upc_cd_override, dimUpcXref.priority = 0, dimUpcXref.start_date = CURRENT_DATETIME(), dimUpcXref.end_date = CAST(NULL AS datetime), dimUpcXref.override_target_upc = updateData.target_upc, dimUpcXref.comments='UPC from final override file', dimUpcXref.modified_datetime = CURRENT_DATETIME(), dimUpcXref.modified_by = '""",job_run_id,"""'
  FROM (
    SELECT
      a1.target_upc,
      b1.ean_upc_cd,
      b1.ean_upc_cd_override
    FROM (
      SELECT
        DISTINCT target_upc
      FROM
        `""",BQ_PROJECT_NAME,""".""",BQ_PROCESSED_DATASET_NAME,""".""",UPC_XREF_DIM_TABLE_NAME,"""`
      WHERE
        current_flg='Y'
        AND priority<>0) AS a1
    JOIN (
      SELECT
        DISTINCT ean_upc_cd,
        ean_upc_cd_override
      FROM
        `""",BQ_PROJECT_NAME,""".""",BQ_PROCESSED_DATASET_NAME,""".lkp_upc_override`) AS b1
    ON
      a1.target_upc=b1.ean_upc_cd) AS updateData
  WHERE
    dimUpcXref.target_upc = updateData.target_upc""");
EXECUTE IMMEDIATE
  INSERT_POST_OVERRIDE;
 
 -- Upsert the target UPC override COLUMNS
SET
  UPSERT_POST_OVERRIDE = CONCAT("""
  MERGE INTO
    `""",BQ_PROJECT_NAME,""".""",BQ_PROCESSED_DATASET_NAME,""".""",UPC_XREF_DIM_TABLE_NAME,"""` AS upcDim
  USING
    (
    SELECT
      temp1.target_upc AS joinKey,
      temp4.ean_upc_cd_override AS new_override_upc,
      temp1.*
    FROM (
      SELECT
        *
      FROM
        `""",BQ_PROJECT_NAME,""".""",BQ_PROCESSED_DATASET_NAME,""".""",UPC_XREF_DIM_TABLE_NAME,"""`
      WHERE
        CUSTOMER_NAME = '""",CUSTOMER_NAME,"""'
        AND current_flg='Y'
        AND priority=0) AS temp1
    JOIN (
      SELECT
        DISTINCT ean_upc_cd,
        ean_upc_cd_override
      FROM
        `""",BQ_PROJECT_NAME,""".""",BQ_PROCESSED_DATASET_NAME,""".lkp_upc_override`) AS temp4
    ON
      temp1.override_target_upc = temp4.ean_upc_cd
    WHERE
      temp1.target_upc <> temp4.ean_upc_cd_override
    UNION ALL
    SELECT
      '-' AS joinKey,
      temp3.ean_upc_cd_override AS new_override_upc,
      temp2.*
    FROM (
      SELECT
        *
      FROM
        `""",BQ_PROJECT_NAME,""".""",BQ_PROCESSED_DATASET_NAME,""".""",UPC_XREF_DIM_TABLE_NAME,"""`
      WHERE
        CUSTOMER_NAME='""",CUSTOMER_NAME,"""'
        AND current_flg='Y'
        AND priority=0) AS temp2
    JOIN (
      SELECT
        DISTINCT ean_upc_cd,
        ean_upc_cd_override
      FROM
        `""",BQ_PROJECT_NAME,""".""",BQ_PROCESSED_DATASET_NAME,""".lkp_upc_override`) AS temp3
    ON
      temp2.override_target_upc = temp3.ean_upc_cd
    WHERE
      temp2.target_upc <> temp3.ean_upc_cd_override) upsertTab
  ON
    upsertTab.joinKey = upcDim.target_upc
    AND upsertTab.source_upc = upcDim.source_upc
    AND upcDim.CUSTOMER_NAME = '""",CUSTOMER_NAME,"""'
    WHEN MATCHED THEN UPDATE SET end_date = CURRENT_DATETIME(), current_flg = 'N', modified_datetime = CURRENT_DATETIME(), modified_by = '""",job_run_id,"""'
    WHEN NOT MATCHED
    THEN
  INSERT
  VALUES
    (-9999,'""",CUSTOMER_NAME,"""', upsertTab.source_upc, upsertTab.source_upc_type, upsertTab.customer_upc, upsertTab.new_override_upc, upsertTab.override_target_upc, 0,'Found change in final UPC override, hence an updated UPC from final override file',upsertTab.upc_derived_from,CURRENT_DATETIME(), DATETIME_ADD(CURRENT_DATETIME(),
        INTERVAL 50 YEAR), upsertTab.current_flg,'""",job_run_id,"""',CURRENT_DATETIME(),'""",job_run_id,"""', CURRENT_DATETIME())""");
EXECUTE IMMEDIATE
  UPSERT_POST_OVERRIDE;

END IF; 

/*
** Take the maximum surrogate key from the UPC XREF dimension table.
** Update the surrogate key starting from the max_sk for all the new records.
*/
EXECUTE IMMEDIATE
  CONCAT("""
  INSERT INTO
    `""",BQ_PROJECT_NAME,""".""",BQ_PROCESSED_DATASET_NAME,""".""",UPC_XREF_DIM_TABLE_NAME,"""` (
    SELECT
      (coalesce(maxSeqData.max_sk,
          0) +(ROW_NUMBER() OVER())) AS release_sk,
      finalDelta.*
    FROM (
      SELECT
        * EXCEPT (xref_upc_sk)
      FROM
        `""",BQ_PROJECT_NAME,""".""",BQ_PROCESSED_DATASET_NAME,""".""",UPC_XREF_DIM_TABLE_NAME,"""`
      WHERE
        xref_upc_sk =-9999) AS finalDelta
    CROSS JOIN (
      SELECT
        MAX(xref_upc_sk) max_sk
      FROM
        `""",BQ_PROJECT_NAME,""".""",BQ_PROCESSED_DATASET_NAME,""".""",UPC_XREF_DIM_TABLE_NAME,"""`
      WHERE
        xref_upc_sk <>-9999) maxSeqData)""");

-- Delete all the records with surrogate key --> -9999
EXECUTE IMMEDIATE
  CONCAT("""
  DELETE
  FROM
    `""",BQ_PROJECT_NAME,""".""",BQ_PROCESSED_DATASET_NAME,""".""",UPC_XREF_DIM_TABLE_NAME,"""`
  WHERE
    xref_upc_sk = -9999""");

EXCEPTION WHEN ERROR THEN
        EXECUTE IMMEDIATE CONCAT(
            """INSERT INTO processed.ecomm_admin_sproc_error_details (
		        SELECT
			        '""",FEED_NAME,"""' AS FEED_NAME,
                    split(split(@@error.formatted_stack_trace,'transient.')[OFFSET (1)],'[')[OFFSET(0)],
			        @@error.statement_text,
			        @@error.message,
			        current_timestamp()
	        );
	    """);

	    SELECT
	        ERROR (
	            CONCAT(
	            		@@error.message ,' ' ,
	            		@@error.statement_text, ' ' ,
	            		@@error.formatted_stack_trace ,' '
	            	)
	        );

END;