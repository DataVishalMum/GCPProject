/*
  Purpose OF the stored proc : 
		Nielsen Product Temp TABLE DATA insertion 
  History OF Changes : 
        07/04 first version
        05/10 - Updated composer related params and added sproc error mechanism
  Author : 
		Pawan Rathod

*/

CREATE OR REPLACE PROCEDURE transient.ecomm_sproc_nielsen_product_euau_temp(
    SRC_PROJECT STRING,
    SRC_DATASET STRING,
    SRC_TABLE STRING,
    INTERMEDIATE_TABLE STRING,
    SRC_LOOKUP_PROJECT STRING,
    SRC_LOOKUP_DATASET STRING,
    SRC_LOOKUP_TABLE STRING,
    FEED_NAME STRING
)
OPTIONS(
description = """

 How to call:

     CALL transient.ecomm_sproc_nielsen_product_euau_temp (
        "ecomm-dlf-dev-01cd47", -- SRC_PROJECT
        "transient", -- SRC_DATASET
        "coles_nielsen_product_temp", -- SRC_TABLE
        "coles_product_temp", -- INTERMEDIATE_TABLE
        "ecomm-dlf-dev-01cd47", -- SRC_LOOKUP_PROJECT
        "transient", -- SRC_LOOKUP_DATASET
        "nielsen_dim_product_euau", -- SRC_LOOKUP_TABLE
        "COLES" -- FEED_NAME
	)

"""
)
BEGIN

DECLARE JOB_RUN_ID DEFAULT 999999;
DECLARE BQ_PROJECT_NAME DEFAULT SRC_PROJECT;
DECLARE BQ_TRANSIENT_DATASET_NAME DEFAULT SRC_DATASET;
DECLARE BQ_DELTA_TEMP_TABLENAME DEFAULT SRC_TABLE;
DECLARE BQ_PRODUCT_TABLE_NAME DEFAULT INTERMEDIATE_TABLE;
DECLARE BQ_EDW_PROJECT_NAME DEFAULT SRC_LOOKUP_PROJECT;
DECLARE BQ_EDW_DATASET_NAME DEFAULT SRC_LOOKUP_DATASET;
DECLARE BQ_NIELSEN_TABLE_NAME DEFAULT SRC_LOOKUP_TABLE;

-- product international table name
DECLARE
  VAR_PROD_TEMP_TBL DEFAULT BQ_PROJECT_NAME || "."||BQ_TRANSIENT_DATASET_NAME||"."||BQ_PRODUCT_TABLE_NAME;

--Nielsen product table name
DECLARE
  VAR_NIELSEN_TEMP_TBL DEFAULT BQ_EDW_PROJECT_NAME || "."||BQ_EDW_DATASET_NAME||"."||BQ_NIELSEN_TABLE_NAME;

SET FEED_NAME = UPPER(FEED_NAME);

EXECUTE IMMEDIATE
  CONCAT("""TRUNCATE TABLE  `""",BQ_PROJECT_NAME,"""`.""",BQ_TRANSIENT_DATASET_NAME,""".""",BQ_DELTA_TEMP_TABLENAME);
EXECUTE IMMEDIATE
  CONCAT( """insert into  `""",BQ_PROJECT_NAME,"""`.""",BQ_TRANSIENT_DATASET_NAME,""".""",BQ_DELTA_TEMP_TABLENAME,"""(
SELECT
  * EXCEPT(rnum)
FROM (
  SELECT
    pi.source_item_code,
    ni.ean_10 as nielsen_upc_derived_cd,
    nielsen_source_database_cd,
    nielsen_product_long_desc,
    nielsen_product_brand_derived_desc,
	nielsen_product_sub_brand_desc,
    nielsen_product_manufacturer_derived_desc,
    nielsen_product_category_derived_desc,
    nielsen_product_category_view_desc,
    nielsen_general_mills_product_fg,
    nielsen_product_segment_derived_desc,
    nielsen_product_sub_segment_derived_desc,
    nielsen_product_sector_desc,
    CAST(""",JOB_RUN_ID,""" AS string) AS created_by,
    CURRENT_DATETIME AS created_datetime,
    CAST(""",JOB_RUN_ID,""" AS string) AS modified_by,
    CURRENT_DATETIME AS modified_datetime,
    rnum
  FROM
  (
    SELECT
    CASE
WHEN SAFE_CAST(upc_derived_cd AS INT64) IS NOT NULL AND LENGTH(LTRIM(upc_derived_cd,'0'))>=10 THEN SUBSTRING(LTRIM(upc_derived_cd,'0'), 0, 10)
          ELSE
          NULL
        END
          AS ean_10,	  
      source_database_cd AS nielsen_source_database_cd,
      product_long_desc AS nielsen_product_long_desc,
      CASE
        WHEN product_brand_derived_desc IS NULL THEN product_brand_desc
      ELSE
      product_brand_derived_desc
    END
      nielsen_product_brand_derived_desc,
      product_sub_brand_desc AS nielsen_product_sub_brand_desc,
      CASE
        WHEN product_manufacturer_derived_desc IS NULL THEN product_manufacturer_desc
      ELSE
      product_manufacturer_derived_desc
    END
      nielsen_product_manufacturer_derived_desc,
      product_category_derived_desc AS nielsen_product_category_derived_desc,
      product_category_view_desc AS nielsen_product_category_view_desc,
      general_mills_product_fg AS nielsen_general_mills_product_fg,
      product_segment_derived_desc AS nielsen_product_segment_derived_desc,
      product_sub_segment_derived_desc AS nielsen_product_sub_segment_derived_desc,
      product_sector_desc AS nielsen_product_sector_desc,
      ROW_NUMBER() OVER(PARTITION BY CASE WHEN (SAFE_CAST(upc_derived_cd AS INT64) IS NOT NULL AND LENGTH(LTRIM(upc_derived_cd,'0'))>=10) THEN SUBSTRING(LTRIM(upc_derived_cd,'0'), 1, 10)
      ELSE
        NULL
      END ORDER BY product_level_desc DESC
            ) AS rnum
    FROM
     `""" || VAR_NIELSEN_TEMP_TBL || """`) ni
     JOIN 
     `""" || VAR_PROD_TEMP_TBL || """` pi
  ON
    pi.ean_10 = ni.ean_10
)
WHERE
  rnum = 1)
""");

EXCEPTION WHEN ERROR THEN
        EXECUTE IMMEDIATE CONCAT(
            """INSERT INTO processed.sproc_error_details (
		        SELECT
			        '""",FEED_NAME,"""' AS FEED_NAME,
                    split(split(@@error.formatted_stack_trace,'transient.')[OFFSET (1)],'[')[OFFSET(0)],
			        @@error.statement_text,
			        @@error.message,
			        current_timestamp()
	        );
	    """);

	    SELECT
	        ERROR (
	            CONCAT(
	            		@@error.message ,' ' ,
	            		@@error.statement_text, ' ' ,
	            		@@error.formatted_stack_trace ,' '
	            	)
	        );
END;