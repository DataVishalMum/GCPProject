/* 
  Purpose OF the stored proc : 
  Find the date ranges for a fiscal week
  History OF Changes : 
        04/07 Initial Version
        07/07 - Enterprise dimension changes
  Author : 
		Navdisha Singla 

  This SP is called from transient.sp_customer_weekly_agg_fact 
  CALL
  transient.sp_date_ranges(bq_edw_project_name,
  bq_enterprise_dataset_name,
    max_fiscal_week_end_dt,
    month_begin_dt,
    month_end_dt,
    quarter_begin_dt,
    quarter_end_dt,
    year_begin_dt,
    year_end_dt,
    rolling13Start,
    rolling26Start,
    rolling52Start)
    
    */
CREATE OR REPLACE PROCEDURE transient.ecomm_sproc_date_ranges (
    bq_edw_project_name STRING,
    bq_enterprise_dataset_name STRING,
    max_end_date TIMESTAMP,
    OUT month_begin_dt TIMESTAMP,
    OUT month_end_dt TIMESTAMP,
    OUT quarter_begin_dt TIMESTAMP,
    OUT quarter_end_dt TIMESTAMP,
    OUT year_begin_dt TIMESTAMP,
    OUT year_end_dt TIMESTAMP,
    OUT rolling13Start DATE,
    OUT rolling26Start DATE,
    OUT rolling52Start DATE)
BEGIN
  -- Calculate month RANGE
EXECUTE IMMEDIATE
  CONCAT("""SELECT  AS STRUCT CAST(MAX(fiscal_month_begin_dt) AS TIMESTAMP) AS month_begin_dt,  CAST(MAX(fiscal_month_end_dt) AS TIMESTAMP) AS month_end_dt
FROM  `""",bq_edw_project_name,""".""",bq_enterprise_dataset_name,""".dim_date`
WHERE
  fiscal_month_end_dt <= CAST(@end_dt AS DATE)""") INTO month_begin_dt,
  month_end_dt
  USING max_end_date AS end_dt; 
  -- Calculate quarter RANGE
EXECUTE IMMEDIATE
  CONCAT("""SELECT
  AS STRUCT CAST(MAX(fiscal_quarter_begin_dt) AS TIMESTAMP) AS quarter_begin_dt,
  CAST(MAX(fiscal_quarter_end_dt) AS TIMESTAMP) AS quarter_end_dt
FROM
  `""",bq_edw_project_name,""".""",bq_enterprise_dataset_name,""".dim_date`
WHERE
  fiscal_quarter_end_dt <= CAST(@end_dt AS DATE)""") INTO quarter_begin_dt,
  quarter_end_dt
  USING max_end_date AS end_dt;
  -- Calculate year RANGE
EXECUTE IMMEDIATE
  CONCAT("""
SELECT
  AS STRUCT CAST(MAX(fiscal_year_begin_dt) AS TIMESTAMP) AS year_begin_dt,
  CAST(MAX(fiscal_year_end_dt) AS TIMESTAMP) AS year_end_dt
FROM
  `""",bq_edw_project_name,""".""",bq_enterprise_dataset_name,""".dim_date`
WHERE
  fiscal_year_end_dt <= CAST(@end_dt AS DATE)""") INTO year_begin_dt,
  year_end_dt
  USING max_end_date AS end_dt;
  -- Calculate rolling 13, 26 AND 52 ranges.
EXECUTE IMMEDIATE
  """
SELECT
  DATE_SUB(EXTRACT(DATE
    FROM
      @end_date),INTERVAL 13 WEEK) AS rolling13Start,
  DATE_SUB(EXTRACT(DATE
    FROM
      @end_date),INTERVAL 26 WEEK) AS rolling26Start,
  DATE_SUB(EXTRACT(DATE
    FROM
      @end_date),INTERVAL 52 WEEK) AS rolling52Start""" INTO rolling13Start,
  rolling26Start,
  rolling52Start
USING
  max_end_date AS end_date;
END;