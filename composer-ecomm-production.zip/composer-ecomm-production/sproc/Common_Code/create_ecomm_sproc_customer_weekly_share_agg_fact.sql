    /* 
    Purpose OF the stored proc : 
    Process the complete data to map the surrogate keys, derived columns to each record. 
    History OF Changes : 
            05/19 first version
            05/24 - Added a big IF condition, so that if we do not have records in the temp table, the proc-2 table doesn't get truncated.
            06/03 - Added a colaesce to the join condition used in calculating LY metrics
            07/07 - Enterprise dimension changes
			07/07 - Integrated Ly sales without Ty sales Logic
			05/10 - Updated composer related params and added sproc error mechanism

    Author : 
            Pawan Rathod

    */
    
  CREATE OR REPLACE PROCEDURE transient.ecomm_sproc_customer_weekly_share_agg_fact(
    SRC_PROJECT STRING,
    SRC_DATASET STRING,
    DEST_DATASET STRING,
    SRC_LOOKUP_PROJECT STRING,
    SRC_LOOKUP_DATASET STRING,
    SRC_TABLE STRING,
    DEST_TABLE STRING,
    XREF_TABLE STRING,
    CUSTOMER_NAME STRING,
    FEED_NAME STRING
    )
OPTIONS(
description = """

 How to call:

     CALL transient.sp_customer_weekly_share_agg_fact (
        "ecomm-dlf-dev-01cd47", -- SRC_PROJECT
        "transient", -- SRC_DATASET
        "processed", -- DEST_DATASET
        "edw-qa-c89f9d", -- SRC_LOOKUP_PROJECT
        "enterprise", -- SRC_LOOKUP_DATASET
        "shoprite_share_xref_enriched_temp", -- SRC_TABLE
        "shoprite_share_weekly_agg_fact", -- DEST_TABLE
        "gmi_customer_metadata_reference", -- XREF_TABLE
        "SHOPRITE", -- CUSTOMER_NAME
        "SHOPRITE_SHARE" -- FEED_NAME
	)
"""
)
BEGIN
    
    DECLARE JOB_RUN_ID DEFAULT 999999;
    DECLARE BQ_PROJECT_NAME DEFAULT SRC_PROJECT;
    DECLARE BQ_TRANSIENT_DATASET_NAME DEFAULT SRC_DATASET;
    DECLARE BQ_PROCESSED_DATASET_NAME DEFAULT DEST_DATASET;
    DECLARE BQ_EDW_PROJECT_NAME DEFAULT SRC_LOOKUP_PROJECT;
    DECLARE BQ_ENTERPRISE_DATASET_NAME DEFAULT SRC_LOOKUP_DATASET;
    DECLARE SOURCE_TABLE_NAME DEFAULT SRC_TABLE;
    DECLARE TARGET_TABLE_NAME DEFAULT DEST_TABLE;
    DECLARE NATURAL_KEY_LOOKUP_TABLE DEFAULT XREF_TABLE;
    
    DECLARE
    MAX_FISCAL_WEEK_END_DT,
    MONTH_BEGIN_DT,
    MONTH_END_DT,
    QUARTER_BEGIN_DT,
    QUARTER_END_DT,
    YEAR_BEGIN_DT,
    YEAR_END_DT timestamp;
    DECLARE
    ROLLING13START,
    ROLLING26START,
    ROLLING52START date;
    DECLARE
    CUSTOMER_FLAGS,
    NATURAL_KEY,
    NATURAL_KEY_JOIN,
    AGG_NATURAL_KEY_JOIN,
    AGG_NATURAL_KEY,
    SQL STRING;
    
    DECLARE source_table_count INT64;

    SET CUSTOMER_NAME = UPPER(CUSTOMER_NAME);

    SET FEED_NAME = UPPER(FEED_NAME);


    -- We are checking the source count here. If the source count is zero, we do not proceed with rest of the commands and terminate the procedure.
    -- This ensures that the table is not truncated if there are no records in the source and also eliminates any NULL exceptions.

    EXECUTE IMMEDIATE 
    CONCAT("""Select count(*) from `""",BQ_PROJECT_NAME,""".""",BQ_TRANSIENT_DATASET_NAME,""".""",SOURCE_TABLE_NAME,"""`""")
    INTO source_table_count;

    IF source_table_count != 0 THEN

    -- Truncate the processed-2 TABLE
     EXECUTE IMMEDIATE
     CONCAT("""TRUNCATE TABLE `""",BQ_PROJECT_NAME,""".""",BQ_PROCESSED_DATASET_NAME,""".""",TARGET_TABLE_NAME,"""`"""); 
    -- FETCH the max fiscal week end  date TO calculate customer flags
    EXECUTE IMMEDIATE
    CONCAT("""
    SELECT
        MAX(fiscal_week_end_dt) AS fiscal_week_end_dt
    FROM
        `""",BQ_PROJECT_NAME,""".""",BQ_TRANSIENT_DATASET_NAME,""".""",SOURCE_TABLE_NAME,"""`""") INTO MAX_FISCAL_WEEK_END_DT;
        -- FETCH the date ranges TO calculate customer flags using  the max fiscal week end date
    CALL
    transient.ecomm_sproc_date_ranges(BQ_EDW_PROJECT_NAME,
    BQ_ENTERPRISE_DATASET_NAME,
        MAX_FISCAL_WEEK_END_DT,
        MONTH_BEGIN_DT,
        MONTH_END_DT,
        QUARTER_BEGIN_DT,
        QUARTER_END_DT,
        YEAR_BEGIN_DT,
        YEAR_END_DT,
        ROLLING13START,
        ROLLING26START,
        ROLLING52START);
        /* Logic TO calculate customer flags
    rolling_13/26/52 flags - if the data lies withing last 13/26/52 weeks respectively, these are populated as Y else N
    latest_completed_fiscal_month_fg/quarter/year flags - If the data lies within last month/quarter/year, these are calculated as Y else N
    */
    SET
    CUSTOMER_FLAGS = CONCAT("""
    SELECT
        fiscal_week_begin_dt, '""",MAX_FISCAL_WEEK_END_DT,"""' AS fiscal_date_customer_max,
        CASE
        WHEN (fiscal_week_begin_dt >= '""",ROLLING13START,"""') AND fiscal_week_begin_dt <= '""",MAX_FISCAL_WEEK_END_DT,"""' THEN 'Y'
        ELSE
        'N'
    END
        AS rolling_13_fg,
        CASE
        WHEN (fiscal_week_begin_dt >= '""",ROLLING26START,"""') AND fiscal_week_begin_dt <= '""",MAX_FISCAL_WEEK_END_DT,"""' THEN 'Y'
        ELSE
        'N'
    END
        AS rolling_26_fg,
        CASE
        WHEN (fiscal_week_begin_dt >= '""",ROLLING52START,"""') AND fiscal_week_begin_dt <= '""",MAX_FISCAL_WEEK_END_DT,"""' THEN 'Y'
        ELSE
        'N'
    END
        AS rolling_52_fg,
        CASE
        WHEN (fiscal_week_begin_dt >= '""",MONTH_BEGIN_DT,"""' AND fiscal_week_begin_dt <= '""",MONTH_END_DT,"""') THEN 'Y'
        ELSE
        'N'
    END
        AS latest_completed_fiscal_month_fg,
        CASE
        WHEN (fiscal_week_begin_dt >= '""",QUARTER_BEGIN_DT,"""' AND fiscal_week_begin_dt <= '""",QUARTER_END_DT,"""') THEN 'Y'
        ELSE
        'N'
    END
        AS latest_completed_fiscal_quarter_fg,
        CASE
        WHEN (fiscal_week_begin_dt >= '""",YEAR_BEGIN_DT,"""' AND fiscal_week_begin_dt <= '""",YEAR_END_DT,"""') THEN 'Y'
        ELSE
        'N'
    END
        AS latest_completed_fiscal_year_fg
    FROM (
        SELECT
        DISTINCT fiscal_week_begin_dt
        FROM
        `""",BQ_PROJECT_NAME,""".""",BQ_TRANSIENT_DATASET_NAME,""".""", SOURCE_TABLE_NAME,"""`)""");
    
    -- Fetch the natural keys using the naturalkey lookup table  
    EXECUTE IMMEDIATE
    CONCAT("""
    SELECT
        processed_two_natural_key
    FROM
        `""",BQ_PROJECT_NAME,""".""",BQ_TRANSIENT_DATASET_NAME,""".""",NATURAL_KEY_LOOKUP_TABLE,"""`
    WHERE
        feed_name = '""",FEED_NAME,"""'""") INTO NATURAL_KEY;
        
        -- Fetch the natural key join using the natural-key lookup table
        -- Use coalesce for all the string columns, so that join condition doesn't fail when the column value is NULL
    EXECUTE IMMEDIATE
    CONCAT("""
    WITH
        fetch_nk AS (
        SELECT
        natural_key
        FROM
        UNNEST((
            SELECT
            SPLIT(processed_two_natural_key,',') natural_key
            FROM
            `""",BQ_PROJECT_NAME,""".""",BQ_TRANSIENT_DATASET_NAME,""".""",NATURAL_KEY_LOOKUP_TABLE,"""`
            WHERE
            feed_name ='""",FEED_NAME,"""')) AS natural_key),
    string_nk AS (
    SELECT
        RTRIM(string_agg ('COALESCE(src.' || natural_key || ',\\'\\') = COALESCE(agg.' || natural_key || ',\\'\\') and ',
            ' '),' and ' ) natural_key_str
    FROM (
        SELECT
        column_name natural_key
        FROM
        """,BQ_TRANSIENT_DATASET_NAME,""".INFORMATION_SCHEMA.COLUMNS
        WHERE
        table_name = '""",SOURCE_TABLE_NAME,"""'
        AND data_type = 'STRING'
        AND column_name IN (
        SELECT
            *
        FROM
            fetch_nk))),
    non_string_sk AS (
    SELECT
        RTRIM(string_agg ('src.' || natural_key || ' = agg.' || natural_key || ' and ',
            ' '),' and ' ) natural_key_non_str
    FROM (
        SELECT
        column_name natural_key
        FROM
        """,BQ_TRANSIENT_DATASET_NAME,""".INFORMATION_SCHEMA.COLUMNS
        WHERE
        table_name = '""",SOURCE_TABLE_NAME,"""'
        AND data_type <> 'STRING'
        AND column_name IN (
        SELECT
            *
        FROM
            fetch_nk)))
    SELECT
    CONCAT(natural_key_str,' and ',natural_key_non_str)
    FROM
    non_string_sk,
    string_nk""") INTO NATURAL_KEY_JOIN;

    -- Fetch the natural keys to aggregate the metric data
    -- Added coalesce to all the columns, so that join condition doesn't fail when the column value is NULL
    EXECUTE IMMEDIATE
    CONCAT("""WITH fetch_nk AS (SELECT
        natural_key
        FROM
        UNNEST((
            SELECT
            SPLIT(processed_two_natural_key,',') natural_key
            FROM
            `""",BQ_PROJECT_NAME,""".""",BQ_TRANSIENT_DATASET_NAME,""".""",NATURAL_KEY_LOOKUP_TABLE,"""`
            WHERE
            feed_name ='""",FEED_NAME,"""')) AS natural_key
        where natural_key <> 'fiscal_year_week_nbr')
            SELECT
        RTRIM(string_agg ('COALESCE(src.' || natural_key || ',\\'\\') = COALESCE(b.' || natural_key || ',\\'\\') and ',
            ' '),' and ' )
    FROM
        fetch_nk""") INTO AGG_NATURAL_KEY_JOIN;

    -- Fetch the natural key to aggregate the data
    EXECUTE IMMEDIATE 
    CONCAT("""select REGEXP_REPLACE(CONCAT('src.',processed_two_natural_key),',',',src.')
    FROM 
    `""",BQ_PROJECT_NAME,""".""",BQ_TRANSIENT_DATASET_NAME,""".""",NATURAL_KEY_LOOKUP_TABLE,"""`
        where feed_name = '""",FEED_NAME,"""'""") INTO AGG_NATURAL_KEY;


    /* Populate the below columns as NULL if they are not present in the source table*/
    /* Roll-up the data to week. 
    Aggregate the metric columns on natural key
    Enrich the source table with customer flags,ty/ly aggregated metric data
    */
    set SQL =
    CONCAT("""insert into `""",BQ_PROJECT_NAME,""".""",BQ_PROCESSED_DATASET_NAME,""".""",TARGET_TABLE_NAME,"""`
    WITH
    customer_flags AS (""",CUSTOMER_FLAGS,"""),
    agg_sales AS (
    SELECT
        """,NATURAL_KEY,""",
        fiscal_year_week_nbr -100 ly_fiscal_year_week_nbr,
        SUM(ty_sales_value) ty_sales_value,
        SUM(ty_sales_units) ty_sales_units,
        currency_code,
        fiscal_year_nbr
    FROM
        `""",BQ_PROJECT_NAME,""".""",BQ_TRANSIENT_DATASET_NAME,""".""",SOURCE_TABLE_NAME,"""` p1
    GROUP BY
        """,NATURAL_KEY,""",
        fiscal_year_week_nbr -100,
        currency_code,
        fiscal_year_nbr),
    data_agg AS (
    SELECT
        """,AGG_NATURAL_KEY,""",
        src.ty_sales_value,
        src.ly_fiscal_year_week_nbr,
        b.ty_sales_value ly_sales_value,
        src.ty_sales_units ty_sales_units,
        b.ty_sales_units ly_sales_units,
        CASE WHEN src.currency_code = 'USD' THEN src.ty_sales_value
        ELSE coalesce(CAST(src.ty_sales_value * exchange_rate.direct_exchange_rate_to_unit_fctr AS float64),
        0.0) END AS ty_sales_value_usd,
        CASE WHEN src.currency_code = 'USD' THEN b.ty_sales_value
        ELSE coalesce(CAST(b.ty_sales_value * exchange_rate.direct_exchange_rate_to_unit_fctr AS float64),
        0.0) END AS ly_sales_value_usd
    FROM
        agg_sales src
    LEFT JOIN
        agg_sales b
    ON
        src.ly_fiscal_year_week_nbr = b.fiscal_year_week_nbr
        AND """,AGG_NATURAL_KEY_JOIN,"""
    LEFT JOIN
        (SELECT
            exchange_rate.fiscal_year_nbr,
            exchange_rate.direct_exchange_rate_to_unit_fctr,
        source_currency_type_cd
            FROM
            `""",BQ_EDW_PROJECT_NAME,"""`.""",BQ_ENTERPRISE_DATASET_NAME,""".dim_currency_exchange_rates  exchange_rate	 
            WHERE
            exchange_rate_type_cd = 'P'
            AND target_currency_type_cd = 'USD'
        ) exchange_rate
        ON
        src.fiscal_year_nbr=exchange_rate.fiscal_year_nbr
        AND exchange_rate.source_currency_type_cd = src.currency_code
    ),
    src_data AS (
    SELECT
        src.fiscal_week_begin_dt,
        src.fiscal_week_end_dt,
        src.country,
        src.segment,
        src.channel,
        src.customer_share_flag,
        '$' standard_currency_symbol,
        'USD' as standard_currency_code,
        src.customer_desc,
        src.manufacturer,
        src.fiscal_week_in_year_nbr,
        src.fiscal_month_in_year_short_desc,
        src.fiscal_quarter_nbr,
        src.fiscal_month_in_year_nbr,
        src.fiscal_quarter_in_year_nbr,
        src.fiscal_year_nbr,
        src.fiscal_year_week_nbr,
        CONCAT(src.fiscal_month_in_year_nbr,'-',src.fiscal_month_in_year_short_desc) fiscal_month_number_short_desc,
        CONCAT('Q',src.fiscal_quarter_in_year_nbr) fiscal_quarter_number_short_desc,
        CONCAT('FY',SUBSTRING(CAST(src.fiscal_year_nbr AS string),
            3,
            4)) fiscal_year,
        src.fiscal_year_short_desc,
        src.fiscal_year_month_nbr,
        src.global_category,
        src.global_sub_category,
        src.share_category_relevancy_flag,
        src.resolved_category,
        src.divested_fg,
        agg.ty_sales_units,
        agg.ly_sales_units,
        (COALESCE(agg.ty_sales_units,0) - COALESCE(agg.ly_sales_units,0)) change_in_sales_units,
        agg.ty_sales_value,
        agg.ly_sales_value,
        (COALESCE(agg.ty_sales_value,0) - COALESCE(agg.ly_sales_value,0))change_in_sales_value,
        agg.ty_sales_value_usd,
        agg.ly_sales_value_usd,
        (COALESCE(agg.ty_sales_value_usd,0) - COALESCE(agg.ly_sales_value_usd,0)) change_in_sales_value_usd,
        'WEEK' as grain,
        src.report_fg,
        src.notes,
        src.customer_parent,
        src.customer_account,
        src.global_category_parent,
        src.zone_hierarchy,
        src.customer_sales_flag,
        src.customer_name,
        src.currency_code,
        src.currency_symbol,
        ROW_NUMBER() OVER (PARTITION BY """,AGG_NATURAL_KEY,""") rn
    FROM
        `""",BQ_PROJECT_NAME,""".""",BQ_TRANSIENT_DATASET_NAME,""".""",SOURCE_TABLE_NAME,"""` src
    LEFT JOIN
        data_agg agg
    ON
        """,NATURAL_KEY_JOIN,""" )
    SELECT
    ROW_NUMBER() OVER() agg_fact_sk,
    src.* EXCEPT (rn),
    calendar_year_nbr,
    fiscal_date_customer_max,
    rolling_13_fg,
    rolling_26_fg,
    rolling_52_fg,
    latest_completed_fiscal_month_fg,
    latest_completed_fiscal_quarter_fg,
    latest_completed_fiscal_year_fg,
    CASE
        WHEN src.fiscal_month_in_year_nbr = 1 THEN 'P01-Jun'
        WHEN src.fiscal_month_in_year_nbr = 2 THEN 'P02-Jul'
        WHEN src.fiscal_month_in_year_nbr = 3 THEN 'P03-Aug'
        WHEN src.fiscal_month_in_year_nbr = 4 THEN 'P04-Sep'
        WHEN src.fiscal_month_in_year_nbr = 5 THEN 'P05-Oct'
        WHEN src.fiscal_month_in_year_nbr = 6 THEN 'P06-Nov'
        WHEN src.fiscal_month_in_year_nbr = 7 THEN 'P07-Dec'
        WHEN src.fiscal_month_in_year_nbr = 8 THEN 'P08-Jan'
        WHEN src.fiscal_month_in_year_nbr = 9 THEN 'P09-Feb'
        WHEN src.fiscal_month_in_year_nbr = 10 THEN 'P10-Mar'
        WHEN src.fiscal_month_in_year_nbr = 11 THEN 'P11-Apr'
        WHEN src.fiscal_month_in_year_nbr = 12 THEN 'P12-May'
    ELSE
    ' '
    END
    AS fiscal_month_verbose_tableau_mapping,
    CAST(src.fiscal_week_begin_dt AS date) AS fiscal_week_begin_dt_tableau_mapping,
    '""",JOB_RUN_ID,"""',
    CURRENT_DATETIME(),
    '""",JOB_RUN_ID,"""',
    CURRENT_DATETIME()
    FROM
    src_data src
    LEFT JOIN 
    customer_flags cust_fg
    ON
    src.fiscal_week_begin_dt = cust_fg.fiscal_week_begin_dt
    LEFT JOIN
    `""",BQ_EDW_PROJECT_NAME,""".""",BQ_ENTERPRISE_DATASET_NAME,""".dim_date` cal
    ON
    CAST(src.fiscal_week_begin_dt AS DATE) = cal.calendar_dt
    and language_cd = 'EN'    
    and cal.fiscal_year_variant_cd = '07'
    WHERE
    src.rn=1""");

    select SQL;

    EXECUTE IMMEDIATE SQL;
	
	CALL
  transient.ecomm_sproc_insert_shares_ly_for_no_ty_sales ( JOB_RUN_ID,
    BQ_PROJECT_NAME,
    BQ_EDW_PROJECT_NAME,
    BQ_ENTERPRISE_DATASET_NAME,
    BQ_TRANSIENT_DATASET_NAME,
    BQ_PROCESSED_DATASET_NAME,
    TARGET_TABLE_NAME,
    CUSTOMER_NAME,
    FEED_NAME );

    END IF;

EXCEPTION WHEN ERROR THEN
        EXECUTE IMMEDIATE CONCAT(
            """INSERT INTO processed.sproc_error_details (
		        SELECT
			        '""",FEED_NAME,"""' AS FEED_NAME,
                    split(split(@@error.formatted_stack_trace,'transient.')[OFFSET (1)],'[')[OFFSET(0)],
			        @@error.statement_text,
			        @@error.message,
			        current_timestamp()
	        );
	    """);

	    SELECT
	        ERROR (
	            CONCAT(
	            		@@error.message ,' ' ,
	            		@@error.statement_text, ' ' ,
	            		@@error.formatted_stack_trace ,' '
	            	)
	        );
END;