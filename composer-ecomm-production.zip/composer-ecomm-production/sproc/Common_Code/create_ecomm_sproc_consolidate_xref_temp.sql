/*

Purpose of the stored proc:
	1. This is a generic flow for all the customers.
    2. Overwrites the consolidate_xref_temp of to get all the 3 xref table attributes.

History of Changes:
	04/07/2021 – first version
    05/20/2021 - Updated customer_name to feed_name for filtering on gmi_customer_metadata_reference table
    05/10 - Updated composer related params and added sproc error mechanism

Author :
	Pawan Rathod

*/
CREATE OR REPLACE PROCEDURE transient.ecomm_sproc_consolidate_xref_temp(
    SRC_PROJECT STRING,
    SRC_DATASET STRING,
    DEST_TABLE STRING,
    SRC_TABLE STRING,
    CUSTOMER_NAME STRING,
    FEED_NAME STRING
)
OPTIONS(
description = """

 How to call:

     CALL transient.ecomm_sproc_consolidate_xref_temp (
        "ecomm-dlf-dev-01cd47", -- SRC_PROJECT
        "transient", -- SRC_DATASET
        "kroger_ship_consolidate_xref_temp", -- DEST_TABLE
        "kroger_ship_consolidate_product_temp", -- SRC_TABLE
        "KROGER_SHIP", -- CUSTOMER_NAME
        "KROGER_SHIP" -- FEED_NAME
      )
"""
)
BEGIN

DECLARE JOB_RUN_ID DEFAULT 999999;
DECLARE BQ_PROJECT_NAME DEFAULT SRC_PROJECT;
DECLARE BQ_TRANSIENT_DATASET_NAME DEFAULT SRC_DATASET;
DECLARE BQ_CONSOLIDATE_XREF_TABLENAME DEFAULT DEST_TABLE;
DECLARE BQ_CONSOLIDATE_PRODUCT_TABLENAME DEFAULT SRC_TABLE;

DECLARE
  ECOMM_DLF_TRANSIENT_DS STRING DEFAULT CONCAT("`",BQ_PROJECT_NAME,"`.",BQ_TRANSIENT_DATASET_NAME,".");

DECLARE
  SQL,
  DIM_XREF_NATURAL_KEY,
  KEY_COLUMNS,
  TABLE_NAMES_TO_CHECK,
  PRIORITY_COLS_CATEGORY,
  PRIORITY_COLS_BRAND,
  PRIORITY_COLS_RESOLVED_PRD_NAME,
  XREF_BRAND_COLS,
  XREF_CATEGORY_COLS,
  XREF_OVERRIDE_COLS,
  TABLE_NAME_PREFIX STRING;

SET CUSTOMER_NAME = UPPER(CUSTOMER_NAME);

SET FEED_NAME = UPPER(FEED_NAME);

-- All xref_brand output attributes
SET
  XREF_BRAND_COLS = ",xref_brand.xref_brand AS brand_xref_brand, xref_brand.xref_sub_brand AS brand_xref_sub_brand, xref_brand.xref_manufacturer AS brand_xref_manufacturer,";
-- All xref_category output attributes
SET
  XREF_CATEGORY_COLS = "xref_cat.global_category_parent AS cat_global_category_parent, xref_cat.global_category AS cat_global_category, xref_cat.global_sub_category AS cat_global_sub_category, xref_cat.share_category_relevancy_flag AS cat_share_category_relevancy_flag, xref_cat.share_split AS cat_share_split, xref_cat.business_comment_1 AS cat_business_comment_1,";
-- All xref_override output attributes
SET
  XREF_OVERRIDE_COLS = "xref_override.xref_manufacturer AS override_xref_manufacturer, xref_override.global_category AS override_global_category, xref_override.global_sub_category AS override_global_sub_category, xref_override.share_category_relevancy_flag AS override_share_category_relevancy_flag, xref_override.xref_brand AS override_xref_brand, xref_override.xref_sub_brand AS override_xref_sub_brand, xref_override.euau_business_operating_unit_desc AS override_euau_business_operating_unit_desc, xref_override.euau_business_product_group_desc AS override_euau_business_product_group_desc, xref_override.euau_business_product_sub_group_desc AS override_euau_business_product_sub_group_desc, xref_override.bph20_desc AS override_bph20_desc, xref_override.bph30_desc AS override_bph30_desc, xref_override.bph40_desc AS override_bph40_desc, xref_override.bph50_desc AS override_bph50_desc, xref_override.bph60_desc AS override_bph60_desc, xref_override.bph70_desc AS override_bph70_desc, xref_override.business_comment_1 AS override_business_comment_1"; -- Truncate Consolidate Product Temp TABLE
-- Truncate the table BQ_CONSOLIDATE_XREF_TABLENAME
EXECUTE IMMEDIATE 
  CONCAT("""TRUNCATE TABLE """,ECOMM_DLF_TRANSIENT_DS,BQ_CONSOLIDATE_XREF_TABLENAME);
-- Get the dim_xref_natural_key from gmi_customer_metadata_reference
EXECUTE IMMEDIATE
  CONCAT("SELECT dim_xref_natural_key from ",ECOMM_DLF_TRANSIENT_DS,"gmi_customer_metadata_reference where feed_name = upper('",FEED_NAME,"')") INTO DIM_XREF_NATURAL_KEY;
-- Get the table_name_prefix from gmi_customer_metadata_reference
EXECUTE IMMEDIATE
  CONCAT("SELECT lower(table_name_prefix) from ",ECOMM_DLF_TRANSIENT_DS,"gmi_customer_metadata_reference where feed_name = upper('",FEED_NAME,"')") INTO TABLE_NAME_PREFIX;

-- Generate a Sql to get all the 3 xref table attributes.
SET
  SQL = CONCAT( """INSERT INTO """, ECOMM_DLF_TRANSIENT_DS,BQ_CONSOLIDATE_XREF_TABLENAME, """
  WITH
    xref_brand AS (
    SELECT
      tmp.* EXCEPT(""",DIM_XREF_NATURAL_KEY,""")
    FROM
      """,ECOMM_DLF_TRANSIENT_DS,TABLE_NAME_PREFIX,"""_xref_global_brand_temp tmp
    WHERE
      best = 1 ), xref_category AS (
    SELECT
      tmp.* EXCEPT(""",DIM_XREF_NATURAL_KEY,""")
    FROM
      """,ECOMM_DLF_TRANSIENT_DS,TABLE_NAME_PREFIX,"""_xref_global_category_temp tmp
    WHERE
      best = 1 ), xref_override AS (
    SELECT
      tmp.* EXCEPT(""",DIM_XREF_NATURAL_KEY,""")
    FROM
      """,ECOMM_DLF_TRANSIENT_DS,TABLE_NAME_PREFIX,"""_xref_override_temp tmp
    WHERE
      best = 1 )
  SELECT
    src.source_product_hash, """,DIM_XREF_NATURAL_KEY,XREF_BRAND_COLS,XREF_CATEGORY_COLS,XREF_OVERRIDE_COLS,""",CAST(""",JOB_RUN_ID,""" AS string) AS created_by, CURRENT_DATETIME AS created_datetime, CAST(""",JOB_RUN_ID,""" AS string) AS modified_by, CURRENT_DATETIME AS modified_datetime
  FROM
    """,ECOMM_DLF_TRANSIENT_DS,BQ_CONSOLIDATE_PRODUCT_TABLENAME,""" src
  LEFT OUTER JOIN
    xref_brand
  ON
    (src.source_product_hash = xref_brand.source_product_hash)
  LEFT OUTER JOIN
    xref_category xref_cat
  ON
    (src.source_product_hash = xref_cat.source_product_hash)
  LEFT OUTER JOIN
    xref_override
  ON
    (src.source_product_hash = xref_override.source_product_hash)""");
EXECUTE IMMEDIATE
  SQL;

EXCEPTION WHEN ERROR THEN
        EXECUTE IMMEDIATE CONCAT(
            """INSERT INTO processed.sproc_error_details (
		        SELECT
			        '""",FEED_NAME,"""' AS FEED_NAME,
                    split(split(@@error.formatted_stack_trace,'transient.')[OFFSET (1)],'[')[OFFSET(0)],
			        @@error.statement_text,
			        @@error.message,
			        current_timestamp()
	        );
	    """);

	    SELECT
	        ERROR (
	            CONCAT(
	            		@@error.message ,' ' ,
	            		@@error.statement_text, ' ' ,
	            		@@error.formatted_stack_trace ,' '
	            	)
	        );
END;