/* 
    Purpose : 
    There could be sales for products during the past year for a particular fiscal week,  
	but no sales in a year later for the same fiscal week.  In such a scenario, a record
	needs to be inserted with zero TY (this year) sales 
	
    History OF Changes : 
            06/24 initial version
			07/07 dim_date integration
			07/28 calendar_year_nbr changed to min value where 2 calendar_year_nbr present for a fiscal_year_week_nbr
      08/10 Added logic to handle duplicates when source raw file has ty_sales_value as null
      01/19 Added Dyanmic Column Creation Updates
      05/10 - Updated composer related params and added sproc error mechanism
      
    Author : 
            Pawan Rathod

*/
    
CREATE OR REPLACE PROCEDURE transient.ecomm_sproc_insert_ly_for_no_ty_sales
(
	SRC_PROJECT STRING,
	INTERMEDIATE_PROJECT STRING,
	INTERMEDIATE_DATASET STRING,
	SRC_DATASET STRING,
	DEST_DATASET STRING,
	DEST_TABLE STRING,
	CUSTOMER_NAME STRING,
	FEED_NAME STRING
)
OPTIONS(
description = """

 How to call:

     CALL transient.ecomm_sproc_insert_ly_for_no_ty_sales (
        'ecomm-dlf-dev-01cd47', -- SRC_PROJECT
        'edw-qa-c89f9d', -- INTERMEDIATE_PROJECT
        'enterprise', -- INTERMEDIATE_DATASET
        'transient', -- SRC_DATASET
        'processed', -- DEST_DATASET
        'kroger_delivery_weekly_agg_fact', -- DEST_TABLE
        'KROGER_DELIVERY', -- CUSTOMER_NAME
        'KROGER_DELIVERY' -- FEED_NAME
	)
"""
)
BEGIN

DECLARE JOB_RUN_ID DEFAULT 999999;
DECLARE BQ_PROJECT_NAME DEFAULT SRC_PROJECT;
DECLARE BQ_EDW_PROJECT_NAME DEFAULT INTERMEDIATE_PROJECT;
DECLARE BQ_ENTERPRISE_DATASET_NAME DEFAULT INTERMEDIATE_DATASET;
DECLARE BQ_TRANSIENT_DATASET_NAME DEFAULT SRC_DATASET;
DECLARE BQ_PROCESSED_DATASET_NAME DEFAULT DEST_DATASET;
DECLARE TARGET_TABLE_NAME DEFAULT DEST_TABLE;

DECLARE
MAX_FISCAL_WEEK_END_DT,
MONTH_BEGIN_DT,
MONTH_END_DT,
QUARTER_BEGIN_DT,
QUARTER_END_DT,
YEAR_BEGIN_DT,
YEAR_END_DT timestamp;
DECLARE
ROLLING13START,
ROLLING26START,
ROLLING52START date;
DECLARE
CUSTOMER_FLAGS,
NATURAL_KEY_LY STRING;
DECLARE 
FACT_SK INT64;

DECLARE REGION_SPECIFIC_COLUMNS,REGION_SPECIFIC_AGG_COLUMNS,MISC_COLS STRING DEFAULT '';

SET CUSTOMER_NAME = UPPER(CUSTOMER_NAME);

SET FEED_NAME = UPPER(FEED_NAME);


-- Natural key of processed two table

SET NATURAL_KEY_LY = 'upc,fiscal_week_in_year_nbr,source_item_name,manufacturer,source_item_code,customer_account,resolved_category,global_category_parent,resolved_brand,zone_hierarchy' ;

-- FETCH the max agg_fact_sk to calculate the next fact_sk
EXECUTE IMMEDIATE
CONCAT("""
SELECT
	MAX(agg_fact_sk) AS agg_fact_sk
FROM
	`""",BQ_PROJECT_NAME,""".""",BQ_PROCESSED_DATASET_NAME,""".""",TARGET_TABLE_NAME,"""`""") INTO FACT_SK;
-- FETCH the max fiscal week end  date TO calculate customer flags
EXECUTE IMMEDIATE
CONCAT("""
SELECT
	MAX(fiscal_week_end_dt) AS fiscal_week_end_dt
FROM
	`""",BQ_PROJECT_NAME,""".""",BQ_PROCESSED_DATASET_NAME,""".""",TARGET_TABLE_NAME,"""`""") INTO MAX_FISCAL_WEEK_END_DT;
	-- FETCH the date ranges TO calculate customer flags using  the max fiscal week end date
CALL
  transient.ecomm_sproc_date_ranges(BQ_EDW_PROJECT_NAME,
    BQ_ENTERPRISE_DATASET_NAME,
    MAX_FISCAL_WEEK_END_DT,
    MONTH_BEGIN_DT,
    MONTH_END_DT,
    QUARTER_BEGIN_DT,
    QUARTER_END_DT,
    YEAR_BEGIN_DT,
    YEAR_END_DT,
    ROLLING13START,
    ROLLING26START,
    ROLLING52START);
	/* Logic TO calculate customer flags
rolling_13/26/52 flags - if the data lies withing last 13/26/52 weeks respectively, these are populated as Y else N
latest_completed_fiscal_month_fg/quarter/year flags - If the data lies within last month/quarter/year, these are calculated as Y else N
*/
SET
CUSTOMER_FLAGS = CONCAT("""
SELECT
	fiscal_week_begin_dt, '""",MAX_FISCAL_WEEK_END_DT,"""' AS fiscal_date_customer_max,fiscal_year_week_nbr,
	CASE
	WHEN (fiscal_week_begin_dt >= '""",ROLLING13START,"""') AND fiscal_week_begin_dt <= '""",MAX_FISCAL_WEEK_END_DT,"""' THEN 'Y'
	ELSE
	'N'
END
	AS rolling_13_fg,
	CASE
	WHEN (fiscal_week_begin_dt >= '""",ROLLING26START,"""') AND fiscal_week_begin_dt <= '""",MAX_FISCAL_WEEK_END_DT,"""' THEN 'Y'
	ELSE
	'N'
END
	AS rolling_26_fg,
	CASE
	WHEN (fiscal_week_begin_dt >= '""",ROLLING52START,"""') AND fiscal_week_begin_dt <= '""",MAX_FISCAL_WEEK_END_DT,"""' THEN 'Y'
	ELSE
	'N'
END
	AS rolling_52_fg,
	CASE
	WHEN (fiscal_week_begin_dt >= '""",MONTH_BEGIN_DT,"""' AND fiscal_week_begin_dt <= '""",MONTH_END_DT,"""') THEN 'Y'
	ELSE
	'N'
END
	AS latest_completed_fiscal_month_fg,
	CASE
	WHEN (fiscal_week_begin_dt >= '""",QUARTER_BEGIN_DT,"""' AND fiscal_week_begin_dt <= '""",QUARTER_END_DT,"""') THEN 'Y'
	ELSE
	'N'
END
	AS latest_completed_fiscal_quarter_fg,
	CASE
	WHEN (fiscal_week_begin_dt >= '""",YEAR_BEGIN_DT,"""' AND fiscal_week_begin_dt <= '""",YEAR_END_DT,"""') THEN 'Y'
	ELSE
	'N'
END
	AS latest_completed_fiscal_year_fg
FROM (
	SELECT
	 fiscal_week_begin_dt,fiscal_year_week_nbr
	FROM
	fiscal)a""");

  /* Identifying Region Specific columns using naturalkey lookup table and inserting data for only those columns into customer specific weekly_agg_fact Table */

  /* Fetching region_specific_columns columns from naturalkey Lookup table and storing into misc_cols variable */
  EXECUTE IMMEDIATE
  CONCAT("""
  SELECT
  IF
    (LENGTH(COALESCE(TRIM(REGEXP_REPLACE( CONCAT("'",region_specific_columns,"'"),",","','")),
          '  ')) <= 2,
      "'EMPTY'",
      REGEXP_REPLACE(CONCAT("'",region_specific_columns,"'"),",","','")) AS region_specific_columns,
  IF
    (LENGTH(COALESCE(TRIM(REGEXP_REPLACE( CONCAT("'",region_specific_agg_columns,"'"),",","','")),
          '  ')) <= 2,
      "'EMPTY'",
      REGEXP_REPLACE(CONCAT("'",region_specific_agg_columns,"'"),",","','")) AS region_specific_agg_columns
  FROM
    `""",BQ_PROJECT_NAME,""".""",BQ_TRANSIENT_DATASET_NAME,""".gmi_customer_metadata_reference`
  WHERE
    customer_name ='""",CUSTOMER_NAME,"""'
    AND feed_name = '""",FEED_NAME,"""'""") INTO REGION_SPECIFIC_COLUMNS,
  REGION_SPECIFIC_AGG_COLUMNS;

  SET MISC_COLS = CONCAT("\"",REGION_SPECIFIC_COLUMNS,",",REGION_SPECIFIC_AGG_COLUMNS,"\"");
  SET MISC_COLS = (select REPLACE(REPLACE(REPLACE(MISC_COLS,"'EMPTY',",""),",'EMPTY'",""),"\"",""));

  /* Validating if region_specific_columns columns from naturalkey Lookup table exists or not based on following criteria
    If it exists in lookup table : misc_cols value will be blank and it won't be used further.
    If it exists in lookup table but not in weekly_agg_fact ddl : misc_cols value will be blank and it won't be used further.
    If it exists in lookup table as well in weekly_agg_fact ddl : Column names and data_type will be fetched from retailer specific fact table and it will be casted automatically as per weekly_agg_fact table. */

  EXECUTE IMMEDIATE
  CONCAT("""
  SELECT
    COALESCE(CONCAT(STRING_AGG(
          CASE
            WHEN column_name IN (""",REGION_SPECIFIC_COLUMNS,""")
            THEN CONCAT("CAST(a.",column_name," AS ",data_type,") AS ",column_name)
            WHEN column_name IN (""",REGION_SPECIFIC_AGG_COLUMNS,""")
          AND STARTS_WITH(column_name,'ty_')
          THEN CONCAT("CAST(NULL AS ",data_type,") AS ",column_name)
            WHEN column_name IN (""",REGION_SPECIFIC_AGG_COLUMNS,""") AND STARTS_WITH(column_name,'ly_')
            THEN CONCAT("CAST(a.",REPLACE(column_name,'ly_','ty_')," AS ",data_type,") AS ",column_name)
          ELSE
          NULL
        END
          ),','),
      '  ') AS VAL
  FROM
    `""",BQ_PROJECT_NAME,"""`.""",BQ_PROCESSED_DATASET_NAME,""".INFORMATION_SCHEMA.COLUMNS
  WHERE
    table_name='""",TARGET_TABLE_NAME,"""'
    AND column_name IN (""",MISC_COLS,""");""") INTO MISC_COLS;

/*
Insert the ly records where there is no ty sales
*/

EXECUTE IMMEDIATE
CONCAT("""INSERT INTO `""",BQ_PROJECT_NAME,""".""",BQ_PROCESSED_DATASET_NAME,""".""",TARGET_TABLE_NAME,"""`
(
WITH
  fiscal AS (
  /* Distinct Clause is used as we need week level records to join to weekly_agg_fact table . calendar table has day grain data whereas weekly_agg_fact table has weekly grain */
  SELECT
    DISTINCT CAST(fiscal_week_begin_dt AS timestamp) as fiscal_week_begin_dt,
    CAST(fiscal_week_end_dt as timestamp) as fiscal_week_end_dt,
    fiscal_week_in_year_nbr,
    fiscal_month_in_year_short_desc,
    fiscal_quarter_nbr,
    fiscal_month_in_year_nbr,
    fiscal_quarter_in_year_nbr,
    fiscal_year_nbr,
    fiscal_year_week_nbr,
    CONCAT(fiscal_month_in_year_nbr,'-',fiscal_month_in_year_short_desc) fiscal_month_number_short_desc,
    CONCAT('Q',fiscal_quarter_in_year_nbr) fiscal_quarter_number_short_desc,
    CONCAT('FY',subSTRING(CAST(fiscal_year_nbr AS string),
        3,
        4)) fiscal_year,
    fiscal_year_short_desc,
    fiscal_year_month_nbr,
	min(calendar_year_nbr) over (partition by fiscal_year_week_nbr) as calendar_year_nbr
  FROM
    `""",BQ_EDW_PROJECT_NAME,"""`.""",BQ_ENTERPRISE_DATASET_NAME,""".dim_date
  WHERE
    fiscal_year_variant_cd = '07'
    AND language_cd ='EN'
	-- Date should be less than the max week_end_date in weekly_agg_fact table to avoid inserting future date records
    AND cast(fiscal_dt as timestamp) <= '""",MAX_FISCAL_WEEK_END_DT,"""'),
	customer_flags AS (""",CUSTOMER_FLAGS,""")
SELECT
  """,FACT_SK,""" + (ROW_NUMBER() OVER()) as agg_fact_sk,
  upc,
  fiscal.fiscal_week_begin_dt,
  fiscal.fiscal_week_end_dt,
  source_item_name,
  base_product_cd,
  base_product_desc,
  material_cd,
  material_short_desc,
  material_nbr,
  ean_upc_cd,
  xref_brand,
  xref_sub_brand,
  country,
  segment,
  channel,
  customer_share_flag,
  standard_currency_symbol,
  standard_currency_code,
  customer_desc,
  retailer,
  manufacturer,
  fiscal.fiscal_week_in_year_nbr,
  fiscal.fiscal_month_in_year_short_desc,
  fiscal.fiscal_quarter_nbr,
  fiscal.fiscal_month_in_year_nbr,
  fiscal.fiscal_quarter_in_year_nbr,
  fiscal.fiscal_year_nbr,
  fiscal.fiscal_year_week_nbr,
  fiscal.fiscal_month_number_short_desc,
  fiscal.fiscal_quarter_number_short_desc,
  fiscal.fiscal_year,
  fiscal.fiscal_year_short_desc,
  fiscal.fiscal_year_month_nbr,
  global_category,
  global_sub_category,
  share_category_relevancy_flag,
  sls_hier_division_desc,
  sls_hier_category_desc,
  sls_hier_sub_category_desc,
  sls_hier_accrual_group_desc,
  sls_hier_sub_accrual_desc,
  sls_hier_ppg_desc,
  gph_hier_category_desc,
  gph_hier_flavor_format_desc,
  gph_hier_package_size_desc,
  gph_hier_family_desc,
  gph_hier_top_desc,
  gmi_category_desc,
  gmi_sub_category_desc,
  gmi_segment_desc,
  gmi_brand_desc,
  gmi_global_brand_desc,
  gmi_manufacturer_desc,
  gmi_global_manufacturer_desc,
  brand_high_desc,
  brand_low_desc,
  gmi_megacategory_desc,
  ean_upc_derived_cd,
  resolved_brand,
  resolved_category,
  resolved_product_name,
  divested_fg,
  base_uom_to_eqc_fctr,
  base_uom_to_ecv_fctr,
  NULL AS ty_sales_eqc_units,
  ty_sales_eqc_units AS ly_sales_eqc_units,
  (0 - COALESCE(ty_sales_eqc_units,
      0)) change_in_sales_eqc,
  NULL AS ty_sales_units,
  ty_sales_units AS ly_sales_units,
  (0 - COALESCE(ty_sales_units,
      0)) change_in_sales_units,
  NULL AS ty_sales_value,
  ty_sales_value AS ly_sales_value,
  (0 - COALESCE(ty_sales_value,
      0))change_in_sales_value,
  NULL AS ty_sales_value_usd,
  ty_sales_value_usd AS ly_sales_value_usd,
  (0 - COALESCE(ty_sales_value_usd,
      0)) change_in_sales_value_usd,
  grain,
  report_fg,
  notes,
  bph20_desc,
  bph30_desc,
  bph40_desc,
  bph50_desc,
  bph60_desc,
  bph70_desc,
  customer_parent,
  customer_account,
  global_category_parent,
  zone_hierarchy,
  customer_sales_flag,
  customer_name,
  currency_code,
  currency_symbol,
  source_item_code,
  """,MISC_COLS,"""
  fiscal.calendar_year_nbr,
  cust_fg.fiscal_date_customer_max,
  cust_fg.rolling_13_fg as rolling_13_by_customer_fg,
  cust_fg.rolling_26_fg as rolling_26_by_customer_fg,
  cust_fg.rolling_52_fg as rolling_52_by_customer_fg,
  cust_fg.latest_completed_fiscal_month_fg as latest_completed_fiscal_month_customer_fg,
  cust_fg.latest_completed_fiscal_quarter_fg as latest_completed_fiscal_quarter_customer_fg,
  cust_fg.latest_completed_fiscal_year_fg as latest_completed_fiscal_year_customer_fg,
  euau_business_operating_unit_desc,
  euau_business_product_group_desc,
  euau_business_product_sub_group_desc,
  product_category_derived_desc,
  product_sector_desc,
  product_sub_segment_derived_desc,
      CASE
        WHEN fiscal.fiscal_month_in_year_nbr = 1 THEN 'P01-Jun'
        WHEN fiscal.fiscal_month_in_year_nbr = 2 THEN 'P02-Jul'
        WHEN fiscal.fiscal_month_in_year_nbr = 3 THEN 'P03-Aug'
        WHEN fiscal.fiscal_month_in_year_nbr = 4 THEN 'P04-Sep'
        WHEN fiscal.fiscal_month_in_year_nbr = 5 THEN 'P05-Oct'
        WHEN fiscal.fiscal_month_in_year_nbr = 6 THEN 'P06-Nov'
        WHEN fiscal.fiscal_month_in_year_nbr = 7 THEN 'P07-Dec'
        WHEN fiscal.fiscal_month_in_year_nbr = 8 THEN 'P08-Jan'
        WHEN fiscal.fiscal_month_in_year_nbr = 9 THEN 'P09-Feb'
        WHEN fiscal.fiscal_month_in_year_nbr = 10 THEN 'P10-Mar'
        WHEN fiscal.fiscal_month_in_year_nbr = 11 THEN 'P11-Apr'
        WHEN fiscal.fiscal_month_in_year_nbr = 12 THEN 'P12-May'
    ELSE
    ' '
    END
    AS fiscal_month_verbose_tableau_mapping,
  CAST(fiscal.fiscal_week_begin_dt as date) AS fiscal_week_begin_dt_tableau_mapping,
  item_name_with_code_tableau_mapping,
  manufacturer_brand_tableau_mapping,
  '""",JOB_RUN_ID,"""' AS created_by,
  CURRENT_DATETIME() AS created_datetime,
  '""",JOB_RUN_ID,"""' AS modified_by,
  CURRENT_DATETIME() AS modified_datetime
FROM (
  SELECT
    a.*,

    -- Coalesce of ty_sales_value is done because for some retailers we are receiving ty_sales_value as null in the source file itself .
    -- In such a scenario where source file has null ty_sales_value , lead would interpret that wrongly and insert duplicate record.
    -- Hence ty_sales_value is set to 0 in case its null and then the lead operation is carried out .

    LEAD (COALESCE(a.ty_sales_value,0),1,NULL) OVER (PARTITION BY """,NATURAL_KEY_LY,""" ORDER BY a.fiscal_year_week_nbr ) ty_sales_value_future
  FROM
    `""",BQ_PROJECT_NAME,""".""",BQ_PROCESSED_DATASET_NAME,""".""",TARGET_TABLE_NAME,"""` a
     )a
JOIN
  fiscal 
ON
  -- adding 100 to the fiscal_year_week_nbr in weekly_agg_fact table as we need the records of next year from the fiscal calendar table
  a.fiscal_year_week_nbr+100 = fiscal.fiscal_year_week_nbr
LEFT JOIN 
	customer_flags cust_fg
ON
  a.fiscal_year_week_nbr+100 = cust_fg.fiscal_year_week_nbr
WHERE
  ty_sales_value_future IS NULL
)

"""

);


EXCEPTION WHEN ERROR THEN
        EXECUTE IMMEDIATE CONCAT(
            """INSERT INTO processed.sproc_error_details (
		        SELECT
			        '""",FEED_NAME,"""' AS FEED_NAME,
                    split(split(@@error.formatted_stack_trace,'transient.')[OFFSET (1)],'[')[OFFSET(0)],
			        @@error.statement_text,
			        @@error.message,
			        current_timestamp()
	        );
	    """);

	    SELECT
	        ERROR (
	            CONCAT(
	            		@@error.message ,' ' ,
	            		@@error.statement_text, ' ' ,
	            		@@error.formatted_stack_trace ,' '
	            	)
	        );
	
END  ;