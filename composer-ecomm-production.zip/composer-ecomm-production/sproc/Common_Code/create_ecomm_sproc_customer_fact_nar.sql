/*
Purpose of the stored proc: 
	Consolidate attributes from Processed-0,XREF Derived attributes,Fiscal tables

History of Changes:
	04/05 – first version 
	04/14 - Created 2 seperate SPs & Changed SP name from 
			sp_customer_fact to sp_customer_fact_nar & sp_customer_fact_euau for repective customers
	04/26 - Removed ty_sales_value_usd & ty_sales_eqc_units calculation as this logic is getting handled in Processsd-2 proc
	04/30 - Added the calculation logic  for ty_sales_eqc_units
	05/20 - Added a new parameter 'FEED_NAME' in the call statement
	05/26 - Modified calculation logic for ty_sales_eqc_units
	07/07 - Enterprise dimension changes
	05/10 - Updated composer related params and added sproc error mechanism

Author : 
	Pawan Rathod

*/
CREATE OR REPLACE PROCEDURE transient.ecomm_sproc_customer_fact_nar
(
	SRC_PROJECT string,
	SRC_LOOKUP_PROJECT string,
	SRC_DATASET string,
	SRC_LOOKUP_DATASET string,
	DEST_DATASET string,
	DEST_TABLE string,
	SRC_TABLE string,
	XREF_TABLE string,
	CUSTOMER_NAME string,
	FEED_NAME string
)
OPTIONS(
description = """

 How to call:

     CALL transient.ecomm_sproc_customer_fact_nar (
        "ecomm-dlf-dev-01cd47", -- SRC_PROJECT
        "edw-qa-c89f9d", -- SRC_LOOKUP_PROJECT
        "transient", -- SRC_DATASET
        "enterprise", -- SRC_LOOKUP_DATASET
        "processed", -- DEST_DATASET
        "kroger_ship_fact", -- DEST_TABLE
        "kroger_ship_processed_zero", -- SRC_TABLE
        "kroger_ship_derived_xref_info_temp", -- XREF_TABLE
        "KROGER_SHIP", -- CUSTOMER_NAME
        "KROGER_SHIP" -- FEED_NAME
      )
"""
)
BEGIN
-- declare variables

DECLARE JOB_RUN_ID DEFAULT 999999;
DECLARE BQ_PROJECT_NAME DEFAULT SRC_PROJECT;
DECLARE BQ_EDW_PROJECT_NAME DEFAULT SRC_LOOKUP_PROJECT;
DECLARE BQ_TRANSIENT_DATASET_NAME DEFAULT SRC_DATASET;
DECLARE BQ_ENTERPRISE_DATASET_NAME DEFAULT SRC_LOOKUP_DATASET;
DECLARE BQ_PROCESSED_DATASET_NAME DEFAULT DEST_DATASET;
DECLARE BQ_CUSTOMER_FACT_TABLE DEFAULT DEST_TABLE;
DECLARE BQ_PROCESSED_ZERO_TABLE DEFAULT SRC_TABLE;
DECLARE BQ_DERIVED_XREF_TABLE DEFAULT XREF_TABLE;

DECLARE 
    JOB_RUN_ID_STRING,
    NATURAL_KEYS,
    FISCAL_DT,
    FISCAL_COLS,
    EXCEPT_COLUMN_LIST_1,
    EXCEPT_COLUMN_LIST_2 STRING; 


-- set variables
SET JOB_RUN_ID_STRING = cast(JOB_RUN_ID as string);

SET CUSTOMER_NAME = UPPER(CUSTOMER_NAME);

SET FEED_NAME = UPPER(FEED_NAME);

/* A few columns need not be fetched from Source table, so that there are no duplicate columns fetched */
SET EXCEPT_COLUMN_LIST_1 = 'ty_sales_value, ty_sales_units, source_product_hash, rctl_uuid, created_by, created_datetime, modified_by, modified_datetime'  ;
SET EXCEPT_COLUMN_LIST_2 = 'currency_code, currency_symbol, rctl_uuid, created_by, source_product_hash, created_datetime, modified_by, modified_datetime'  ;

/* Fetching the Natural Keys from gmi_customer_metadata_reference Table */
EXECUTE IMMEDIATE
  CONCAT(""" select  dim_xref_natural_key from `""",BQ_PROJECT_NAME,"""`.""",BQ_TRANSIENT_DATASET_NAME,""".gmi_customer_metadata_reference 
where upper(FEED_NAME)='""",FEED_NAME,"""' """) INTO NATURAL_KEYS;

-- Find the Feed name specific date column from metadata lookup table
EXECUTE IMMEDIATE
  CONCAT("""
  SELECT
    vendor_file_fiscal_date
  FROM
    `""",BQ_PROJECT_NAME,"""`.""",BQ_TRANSIENT_DATASET_NAME,""".gmi_customer_metadata_reference
  WHERE
    FEED_NAME ='""",FEED_NAME,"""' """) INTO FISCAL_DT;

--Parameterising the Fiscal Table columns
SET FISCAL_COLS=
	CONCAT("""fiscal.fiscal_month_in_year_nbr, fiscal.fiscal_year_nbr, fiscal.fiscal_quarter_in_year_nbr, 
	fiscal.fiscal_week_in_year_nbr, fiscal.fiscal_month_in_year_short_desc
	,cast(fiscal.fiscal_week_begin_dt    as TIMESTAMP) fiscal_week_begin_dt
	,cast(fiscal.fiscal_week_end_dt      as TIMESTAMP) fiscal_week_end_dt
	,cast(fiscal.fiscal_month_begin_dt   as TIMESTAMP) fiscal_month_begin_dt
	,cast(fiscal.fiscal_month_end_dt     as TIMESTAMP) fiscal_month_end_dt
	,cast(fiscal.fiscal_quarter_begin_dt as TIMESTAMP) fiscal_quarter_begin_dt
	,cast(fiscal.fiscal_quarter_end_dt   as TIMESTAMP) fiscal_quarter_end_dt
	,cast(fiscal.fiscal_year_begin_dt    as TIMESTAMP) fiscal_year_begin_dt
	,cast(fiscal.fiscal_year_end_dt      as TIMESTAMP) fiscal_year_end_dt
	,fiscal.fiscal_year_short_desc, fiscal.fiscal_quarter_nbr 
	,fiscal.fiscal_year_week_nbr, fiscal.fiscal_year_month_nbr
	,fiscal.fiscal_day_in_week_nbr, fiscal.fiscal_month_week_qty 
	,cast(fiscal. fiscal_dt      as TIMESTAMP) fiscal_dt""") ;

/* Processed-1 Fact table is Truncate and Load */
EXECUTE IMMEDIATE
  CONCAT("""delete from `""",BQ_PROJECT_NAME,"""`.""",BQ_PROCESSED_DATASET_NAME,""".""",BQ_CUSTOMER_FACT_TABLE,""" where true""");
 

/* Consolidating all columns from Processed-0 ,Derived attributes, Fiscal Table into Processed-1 Fact */
EXECUTE IMMEDIATE
  CONCAT("""INSERT INTO
  `""",BQ_PROJECT_NAME,"""`.""",BQ_PROCESSED_DATASET_NAME,""".""",BQ_CUSTOMER_FACT_TABLE,"""
	WITH
	xref_zone AS (
	SELECT
		CUSTOMER_NAME,
		retailer,
		sales_split,
		zone_hierarchy
	FROM (
		SELECT
		UPPER(lkp_nar_zone.CUSTOMER_NAME) CUSTOMER_NAME,
		lkp_nar_zone.retailer,
		coalesce(CAST(lkp_nar_zone.sales_split AS float64),
			1)AS sales_split,
		lkp_nar_zone.zone_hierarchy,
		lkp_nar_zone.xref_order,
		RANK() OVER(PARTITION BY lkp_nar_zone.CUSTOMER_NAME, lkp_nar_zone.retailer ORDER BY lkp_nar_zone.xref_order) AS rank
		FROM
		`""",BQ_PROJECT_NAME,"""`.""",BQ_PROCESSED_DATASET_NAME,""".lkp_nar_zone_mapping lkp_nar_zone
		WHERE
		UPPER(CUSTOMER_NAME)='""",CUSTOMER_NAME,"""') zone
	WHERE
		rank =1)
	SELECT
	processed_zero.* EXCEPT (""",EXCEPT_COLUMN_LIST_1,""") ,
	coalesce(CAST(processed_zero.ty_sales_value * coalesce(zone2.sales_split,
			zone1.sales_split,
			1) AS float64),
		0.0) AS ty_sales_value,
	coalesce(CAST(processed_zero.ty_sales_units * coalesce(zone2.sales_split,
			zone1.sales_split,
			1) AS Int64),
		0) AS ty_sales_units,
	((coalesce(CAST(processed_zero.ty_sales_units * coalesce(zone2.sales_split,
			zone1.sales_split,
			1) AS Int64),
		0)) * CAST(derived_xref.base_uom_to_eqc_fctr AS float64)) AS ty_sales_eqc_units,
	COALESCE(zone2.zone_hierarchy,
		zone1.zone_hierarchy) AS zone_hierarchy,
	derived_xref.currency_code,
	derived_xref.currency_symbol,
	'$' standard_currency_symbol,
	'USD' standard_currency_code,
	derived_xref.* 
	EXCEPT ( """,NATURAL_KEYS,""",""",EXCEPT_COLUMN_LIST_2,"""),
	""",FISCAL_COLS,""",
	derived_xref.rctl_uuid,
	derived_xref.source_product_hash,
	'""",JOB_RUN_ID_STRING,"""' AS created_by,
	current_datetime AS created_datetime,
	'""",JOB_RUN_ID_STRING,"""' AS modified_by,
	current_datetime AS modified_datetime
	FROM
	`""",BQ_PROJECT_NAME,"""`.""",BQ_TRANSIENT_DATASET_NAME,""".""",BQ_DERIVED_XREF_TABLE,""" derived_xref
	JOIN
		`""",BQ_PROJECT_NAME,"""`.""",BQ_TRANSIENT_DATASET_NAME,""".""",BQ_PROCESSED_ZERO_TABLE,""" processed_zero
	ON
		processed_zero.source_product_hash= derived_xref.source_product_hash
	LEFT JOIN
		xref_zone zone1
	ON
		processed_zero.CUSTOMER_NAME = zone1.CUSTOMER_NAME
		AND zone1.retailer IS NULL
	LEFT JOIN
		xref_zone zone2
	ON
		processed_zero.CUSTOMER_NAME = zone2.CUSTOMER_NAME
		AND UPPER( processed_zero.retailer) = UPPER(zone2.retailer)
	LEFT JOIN
		`""",BQ_EDW_PROJECT_NAME,"""`.""",BQ_ENTERPRISE_DATASET_NAME,""".dim_date fiscal
	ON
		fiscal.fiscal_year_variant_cd = '07'
		AND fiscal.language_cd ='EN'
		AND processed_zero.""",FISCAL_DT,"""= cast(fiscal_dt as timestamp)  
	
  """)
		;

EXCEPTION WHEN ERROR THEN
        EXECUTE IMMEDIATE CONCAT(
            """INSERT INTO processed.sproc_error_details (
		        SELECT
			        '""",FEED_NAME,"""' AS FEED_NAME,
                    split(split(@@error.formatted_stack_trace,'transient.')[OFFSET (1)],'[')[OFFSET(0)],
			        @@error.statement_text,
			        @@error.message,
			        current_timestamp()
	        );
	    """);

	    SELECT
	        ERROR (
	            CONCAT(
	            		@@error.message ,' ' ,
	            		@@error.statement_text, ' ' ,
	            		@@error.formatted_stack_trace ,' '
	            	)
	        );
 
End




