/*
Purpose of the stored proc: 
	Perform UNPIVOT & PIVOT Operation on Data

History of Changes:
	05/19 – first version
	05/10 - Updated composer related params and added sproc error mechanism

Author :
	Pawan Rathod

*/

CREATE OR REPLACE PROCEDURE transient.ecomm_sproc_unpivot_pivot
(
	SRC_PROJECT STRING,
	DEST_DATASET STRING,
	SRC_DATASET STRING,
	SRC_TABLE STRING,
	DEST_TABLE STRING,
	PIVOT_COL_NAME STRING,
	PIVOT_COL_VALUE STRING,
	WEEK_BEGIN_DT_VALUE STRING,
	COLUMNS_POSITION_TO_SKIP_IN_PIVOT STRING,
	COLUMN_NAME_TO_SKIP_IN_PIVOT STRING,
	FEED_NAME STRING
)
OPTIONS(
description = """

 How to call:

     CALL transient.ecomm_sproc_unpivot_pivot (
        "ecomm-dlf-dev-01cd47", -- SRC_PROJECT
        "transient", -- DEST_DATASET
        "processed", -- SRC_DATASET
        "tesco_omni_sales_share_snacks", -- SRC_TABLE
        "tesco_omni_sales_share_snacks_final", -- DEST_TABLE
        "measure", -- PIVOT_COL_NAME
        "amount", -- PIVOT_COL_VALUE
        "week_begin_dt", -- WEEK_BEGIN_DT_VALUE
        "1,2,3,4,5,6,7", -- COLUMNS_POSITION_TO_SKIP_IN_PIVOT
        "total, original_file_name", -- COLUMN_NAME_TO_SKIP_IN_PIVOT
        "tesco" -- FEED_NAME
	 )

"""
)
BEGIN

DECLARE WEEK_DT_COLUMN , MEASURE_PIVOT , ORIGINAL_FILE_NAME_COLUMN_VERIFICATION , COLUMNS_TO_INSERT STRING;

DECLARE BQ_PROJECT_NAME DEFAULT SRC_PROJECT;
DECLARE BQ_TRANSIENT_DATASET_NAME DEFAULT DEST_DATASET;
DECLARE BQ_PROCESSED_DATASET_NAME DEFAULT SRC_DATASET;
DECLARE BQ_SOURCE_TABLENAME DEFAULT SRC_TABLE;
DECLARE BQ_DESTINATION_TABLENAME DEFAULT DEST_TABLE;

SET FEED_NAME = UPPER(FEED_NAME);

EXECUTE IMMEDIATE CONCAT("""
            SELECT STRING_AGG(CONCAT("'",TRIM(value),"'"))
            FROM UNNEST(SPLIT (CONCAT('""",COLUMN_NAME_TO_SKIP_IN_PIVOT,"""',',ingest_date'),","))
             AS value
""") INTO COLUMN_NAME_TO_SKIP_IN_PIVOT;

EXECUTE IMMEDIATE
CONCAT("""TRUNCATE TABLE  `""" ,BQ_PROJECT_NAME,"""`.""",BQ_TRANSIENT_DATASET_NAME,""".""",BQ_DESTINATION_TABLENAME);

EXECUTE IMMEDIATE CONCAT("""
  SELECT DISTINCT string_agg(CONCAT('',column_name,''))
  FROM   `""" ,BQ_PROJECT_NAME,"""`.""",BQ_PROCESSED_DATASET_NAME,""".INFORMATION_SCHEMA.COLUMNS
  WHERE table_name = '""",BQ_SOURCE_TABLENAME,"""'
        AND ordinal_position not in (select value from UNNEST([""",COLUMNS_POSITION_TO_SKIP_IN_PIVOT,"""]) as value)
		AND column_name not in (select value from UNNEST([""",COLUMN_NAME_TO_SKIP_IN_PIVOT,""",'ingest_date']) as value)
""") INTO WEEK_DT_COLUMN;

EXECUTE IMMEDIATE CONCAT("""
	CREATE TEMP TABLE UNPIVOT_TEMP as (
		SELECT *
		FROM
		(
			SELECT * FROM `""" ,BQ_PROJECT_NAME,"""`.""",BQ_PROCESSED_DATASET_NAME,""".""",BQ_SOURCE_TABLENAME,"""
		)
		UNPIVOT
		(
			amount
			FOR """,WEEK_BEGIN_DT_VALUE,""" in (""",WEEK_DT_COLUMN,""")
		)
	)
""");

EXECUTE IMMEDIATE CONCAT("""CREATE TEMP TABLE UNPIVOT_DATA as
 (
 SELECT *
	FROM
	(
		SELECT
		* EXCEPT(""",PIVOT_COL_NAME,""",""",WEEK_BEGIN_DT_VALUE,""",""",PIVOT_COL_VALUE,"""),
		DENSE_RANK() OVER(ORDER BY ingest_date DESC) rnk,
		lower(REGEXP_REPLACE(TRIM(REGEXP_REPLACE(""",PIVOT_COL_NAME,""",r"\\W+"," ")),r"\\W+","_")) as measure,
		CASE
			WHEN REGEXP_CONTAINS(REPLACE(TRIM(REPLACE(""",WEEK_BEGIN_DT_VALUE,""",'_',' ')),' ','-'), r'^[0-9]{4}-[0-9]{2}-[0-9]{2}$')
				THEN SAFE_CAST(DATE(REPLACE(TRIM(REPLACE(""",WEEK_BEGIN_DT_VALUE,""",'_',' ')),' ','-')) AS STRING)
			WHEN REGEXP_CONTAINS(REPLACE(TRIM(REPLACE(""",WEEK_BEGIN_DT_VALUE,""",'_',' ')),' ','-'), r'^[0-9]{2}-[0-9]{2}-[0-9]{4}$')
				THEN SAFE_CAST(
						IF(SAFE.PARSE_DATE('%d-%m-%Y', REPLACE(TRIM(REPLACE(""",WEEK_BEGIN_DT_VALUE,""",'_',' ')),' ','-')) is not null ,
							SAFE.PARSE_DATE('%d-%m-%Y', REPLACE(TRIM(REPLACE(""",WEEK_BEGIN_DT_VALUE,""",'_',' ')),' ','-')),
							SAFE.PARSE_DATE('%m-%d-%Y', REPLACE(TRIM(REPLACE(""",WEEK_BEGIN_DT_VALUE,""",'_',' ')),' ','-'))
							)
					AS STRING)
			ELSE SAFE_CAST(""",WEEK_BEGIN_DT_VALUE,""" as STRING)
		END AS week_begin_dt,
		REGEXP_REPLACE(""",PIVOT_COL_VALUE,""",r"[^\\w.]", '') as amount
		FROM `UNPIVOT_TEMP`
	)
	WHERE rnk = 1
)""");

EXECUTE IMMEDIATE
CONCAT
("""SELECT STRING_AGG(CONCAT("'",measure,"'")) measure_piv
	FROM
		(
			SELECT DISTINCT """,PIVOT_COL_NAME,""" FROM `UNPIVOT_DATA` order by measure
		)
""") INTO MEASURE_PIVOT;

EXECUTE IMMEDIATE CONCAT
("""CREATE TEMP TABLE REFRACTORED_DATA as (
        SELECT *
            FROM  `UNPIVOT_DATA`
            PIVOT(SUM(SAFE_CAST(""",PIVOT_COL_VALUE,""" AS FLOAT64)) for """,PIVOT_COL_NAME,""" in (""",MEASURE_PIVOT,"""))
         )
""");

EXECUTE IMMEDIATE
  CONCAT("""
        SELECT
            STRING_AGG(CONCAT("CAST(",column_name,' as ', data_type,")"))
        FROM
            """,BQ_TRANSIENT_DATASET_NAME,""".INFORMATION_SCHEMA.COLUMNS
        WHERE table_name='""",BQ_DESTINATION_TABLENAME,"""'""") INTO COLUMNS_TO_INSERT;

EXECUTE IMMEDIATE
CONCAT ("""INSERT INTO `""",BQ_PROJECT_NAME,"""`.""",BQ_TRANSIENT_DATASET_NAME,""".""",BQ_DESTINATION_TABLENAME,"""
 (
	SELECT """,COLUMNS_TO_INSERT,"""
	FROM `REFRACTORED_DATA`
 )
""");

EXCEPTION WHEN ERROR THEN
        EXECUTE IMMEDIATE CONCAT(
            """INSERT INTO processed.sproc_error_details (
		        SELECT
			        '""",FEED_NAME,"""' AS FEED_NAME,
                    split(split(@@error.formatted_stack_trace,'transient.')[OFFSET (1)],'[')[OFFSET(0)],
			        @@error.statement_text,
			        @@error.message,
			        current_timestamp()
	        );
	    """);

	    SELECT
	        ERROR (
	            CONCAT(
	            		@@error.message ,' ' ,
	            		@@error.statement_text, ' ' ,
	            		@@error.formatted_stack_trace ,' '
	            	)
	        );

END
  
