/*Purpose of the stored proc: 

	- Insert Entries into Data Release control table for distinct fiscal_year_week_nbr records in Incoming Delta data, 
	- Default value for staging_flag set as 'Y' and release flag as 'N'
	
	This Table will referred to release the specific data for Reporting Purpose specific to each customer
	
History of Changes:
	04/30 – first version 
	05/20 - Added 'feed_name' column to release control table & in parameters
	07/07 - Enterprise dimension changes
	08/16 - Changed the source table,removed delta temp & fiscal table join
	05/10 - Updated composer related params and added sproc error mechanism

Author : 
	Pawan Rathod

*/


CREATE OR REPLACE PROCEDURE transient.ecomm_sproc_data_release_control_insert
(
	SRC_PROJECT string,
	DEST_DATASET string,
	SRC_DATASET string,
	SRC_TABLE string,
	CUSTOMER_NAME string,
	FEED_NAME string
	
)
OPTIONS(
description = """

 How to call:

     CALL transient.ecomm_sproc_data_release_control_insert (
		"ecomm-dlf-dev-01cd47", -- SRC_PROJECT
        "processed", -- DEST_DATASET
        "processed", -- SRC_DATASET
        "kroger_ship_weekly_agg_fact", -- SRC_TABLE
        "KROGER_SHIP", -- CUSTOMER_NAME
        "KROGER_SHIP" -- FEED_NAME
	)
"""
)
BEGIN
-- declare variables

DECLARE JOB_RUN_ID DEFAULT 999999;
DECLARE BQ_PROJECT_NAME DEFAULT SRC_PROJECT;
DECLARE BQ_PROCESSED_DATASET_NAME DEFAULT DEST_DATASET;
DECLARE BQ_SRC_DATASET_NAME DEFAULT SRC_DATASET;
DECLARE BQ_SRC_TABLE DEFAULT SRC_TABLE;

DECLARE JOB_RUN_ID_STRING String;

-- set variables
SET CUSTOMER_NAME = UPPER(CUSTOMER_NAME);

SET FEED_NAME = UPPER(FEED_NAME);

SET JOB_RUN_ID_STRING = cast(JOB_RUN_ID as string);

	
-- Insert fresh records from source table into target 'ecom_data_release_control' table 
-- with default flag values: staging_flg as 'Y' & release_flg as 'N'

EXECUTE IMMEDIATE CONCAT(
"""MERGE `""" ,BQ_PROJECT_NAME,"""`.""",BQ_PROCESSED_DATASET_NAME,""".ecom_data_release_control tgt
USING
  (
  SELECT
  fiscal_year_week_nbr ,
  fiscal_year_month_nbr,
  fiscal_year_nbr,
  '""",CUSTOMER_NAME,"""' AS customer_name,
  '""",FEED_NAME,"""' AS feed_name
  FROM
  `""",BQ_PROJECT_NAME,"""`.""",BQ_SRC_DATASET_NAME,""".""",BQ_SRC_TABLE,""" fact
  
  -- Using group by to fetch unique combination of week, month and year numbers
  -- We are not using 'DISTINCT' as 'GROUP BY' is a less costly operation when the volume goes up.

  group by 
  fiscal_year_week_nbr ,
  fiscal_year_month_nbr,
  fiscal_year_nbr
  ) src  
ON
	  tgt.fiscal_year_week_nbr = src.fiscal_year_week_nbr
  AND tgt.customer_name = src.customer_name
  AND tgt.feed_name 	= src.feed_name
  WHEN NOT MATCHED
  THEN
INSERT
  (	 	         
	 customer_name   
	,feed_name
	,fiscal_year_week_nbr 
	,fiscal_year_month_nbr
	,fiscal_year_nbr
	,staging_flg       
	,release_flg       
	,created_by        
	,created_datetime  
	,modified_by      
	,modified_datetime 
	) 
	
VALUES
  (
	'""",CUSTOMER_NAME,"""',
	'""",FEED_NAME,"""',
	src.fiscal_year_week_nbr,
	src.fiscal_year_month_nbr,
	src.fiscal_year_nbr,
	'Y',
	'N',
	'""",JOB_RUN_ID_STRING,"""'
	,current_datetime,
	'""",JOB_RUN_ID_STRING,
	"""',current_datetime
  )
""");
	  
EXCEPTION WHEN ERROR THEN
        EXECUTE IMMEDIATE CONCAT(
            """INSERT INTO processed.ecomm_admin_sproc_error_details (
		        SELECT
			        '""",FEED_NAME,"""' AS FEED_NAME,
                    split(split(@@error.formatted_stack_trace,'transient.')[OFFSET (1)],'[')[OFFSET(0)],
			        @@error.statement_text,
			        @@error.message,
			        current_timestamp()
	        );
	    """);

	    SELECT
	        ERROR (
	            CONCAT(
	            		@@error.message ,' ' ,
	            		@@error.statement_text, ' ' ,
	            		@@error.formatted_stack_trace ,' '
	            	)
	        );

END;