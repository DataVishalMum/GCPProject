/*
Purpose of the stored proc:
    Enrich with global_category,lkp_customer,fiscal_calendar,zone_hierarchy for 'shoprite shares' customer.

History of Changes:
	05/19 – first version 
    05/10 - Updated composer related params and added sproc error mechanism

Author :
	Pawan Rathod

*/

CREATE OR REPLACE PROCEDURE transient.ecomm_sproc_xref_enriched_share_temp(
    SRC_PROJECT STRING,
    DEST_DATASET STRING,
    DEST_LOOKUP_DATASET STRING,
    SRC_LOOKUP_PROJECT STRING,
    SRC_LOOKUP_DATASET STRING,
    SRC_TABLE STRING,
    DEST_TABLE STRING,
    CUSTOMER_NAME STRING,
    FEED_NAME STRING
)
OPTIONS(
description = """

 How to call:

     CALL transient.ecomm_sproc_xref_enriched_share_temp (
        "ecomm-dlf-dev-01cd47", -- SRC_PROJECT
        "transient", -- DEST_DATASET
        "processed", -- DEST_LOOKUP_DATASET
        "edw-qa-c89f9d", -- SRC_LOOKUP_PROJECT
        "enterprise", -- SRC_LOOKUP_DATASET
        "shoprite_share_processed_zero", -- SRC_TABLE
        "shoprite_share_xref_enriched_temp", -- DEST_TABLE
        "SHOPRITE", -- CUSTOMER_NAME
        "SHOPRITE" -- CUSTOMER_NAME
	 )
"""
)
BEGIN

DECLARE JOB_RUN_ID DEFAULT 999999;
DECLARE BQ_PROJECT_NAME DEFAULT SRC_PROJECT;
DECLARE BQ_TRANSIENT_DATASET_NAME DEFAULT DEST_DATASET;
DECLARE BQ_PROCESSED_DATASET_NAME DEFAULT DEST_LOOKUP_DATASET;
DECLARE BQ_EDW_PROJECT_NAME DEFAULT SRC_LOOKUP_PROJECT;
DECLARE BQ_ENTERPRISE_DATASET_NAME DEFAULT SRC_LOOKUP_DATASET;
DECLARE SOURCE_TABLE_NAME DEFAULT SRC_TABLE;
DECLARE TARGET_TABLE_NAME DEFAULT DEST_TABLE;


--Stores the logic as a sql.
DECLARE SQL STRING;

SET CUSTOMER_NAME = UPPER(CUSTOMER_NAME);

SET FEED_NAME = UPPER(FEED_NAME);

EXECUTE IMMEDIATE
CONCAT("""TRUNCATE TABLE  `""" ,BQ_PROJECT_NAME,"""`.""",BQ_TRANSIENT_DATASET_NAME,""".""",TARGET_TABLE_NAME);

/*Insert xref and lookup enriched data into xref enriched table */
set SQL = CONCAT(
"""insert into `""" ,BQ_PROJECT_NAME,"""`.""",BQ_TRANSIENT_DATASET_NAME,""".""",TARGET_TABLE_NAME,
"""(
WITH
  competitor_data AS (
  SELECT
    share_source_category,
    report_date,
    sales_amount,
    sales_units,
    grain
  FROM
  `""" ,BQ_PROJECT_NAME,"""`.""",BQ_TRANSIENT_DATASET_NAME,""".""",SOURCE_TABLE_NAME,"""),
  xref_zone AS (
  SELECT
    customer_name,
    retailer,
    sales_split,
    zone_hierarchy
  FROM (
    SELECT
      z.customer_name,
      z.retailer,
      coalesce(CAST(z.sales_split AS float64),
        1) AS sales_split,
      z.zone_hierarchy,
      z.xref_order,
      RANK() OVER(PARTITION BY z.customer_name ORDER BY z.xref_order) AS rank
    FROM
      `""" ,BQ_PROJECT_NAME,"""`.""",BQ_PROCESSED_DATASET_NAME,""".lkp_nar_zone_mapping z
    WHERE
      retailer IS NULL) a
  WHERE
    rank =1),
  global_category AS (
  SELECT
    key_value_2,
    global_category_parent,
    global_category,
    global_sub_category,
    share_category_relevancy_flag,
    share_split
  FROM
    `""" ,BQ_PROJECT_NAME,"""`.""",BQ_PROCESSED_DATASET_NAME,""".xref_global_category
  WHERE
  -- Here join key values are static and hence they are hard coded and if below column name changes in the xref file then we may need to change the filter values here.
    key_column_2 = 'share_source_category'
    AND key_column_1 = 'customer_name'
    AND key_value_1 = UPPER('""",CUSTOMER_NAME,"""')),
  xref_customer AS (
  SELECT
    customer_name,
    segment,
    customer_share_flag,
    report_fg,
    customer_sales_flag,
    country,
    channel,
    ad_security_role,
    customer_desc,
    customer_parent,
    customer_account,
    notes,
    currency_code,
    currency_symbol
  FROM
    `""" ,BQ_PROJECT_NAME,"""`.""",BQ_PROCESSED_DATASET_NAME,""".lkp_customer),
  fiscal_calendar AS (
  SELECT
    H.fiscal_month_in_year_nbr,
    H.fiscal_year_nbr,
    H.fiscal_quarter_in_year_nbr,
    H.fiscal_week_in_year_nbr,
    H.fiscal_month_in_year_short_desc,
    H.fiscal_week_begin_dt,
    H.fiscal_week_end_dt,
    H.fiscal_month_begin_dt,
    H.fiscal_month_end_dt,
    H.fiscal_quarter_begin_dt,
    H.fiscal_quarter_end_dt,
    H.fiscal_year_begin_dt,
    H.fiscal_year_end_dt,
    H.fiscal_year_short_desc,
    H.fiscal_quarter_nbr,
    H.fiscal_year_week_nbr,
    H.fiscal_year_month_nbr,
    H.fiscal_day_in_week_nbr,
    H.fiscal_month_week_qty,
    H.fiscal_dt,
    H.fiscal_date_nbr,
    H.calendar_date_nbr
  FROM
    `""" ,BQ_EDW_PROJECT_NAME,"""`.""",BQ_ENTERPRISE_DATASET_NAME,""".dim_date H
  WHERE
    H.language_cd = 'EN'
    AND H.fiscal_year_variant_cd = '07')
SELECT
  --lkp_customer
  cust.customer_name,
  cust.segment,
  cust.customer_share_flag,
  cust.report_fg,
  cust.customer_sales_flag,
  cust.country,
  cust.channel,
  cust.ad_security_role,
  cust.customer_desc,
  cust.customer_parent,
  cust.customer_account,
  cust.notes,
  cust.currency_code,
  cust.currency_symbol,
  --calendar
  clndr.fiscal_month_in_year_nbr,
  clndr.fiscal_year_nbr,
  clndr.fiscal_quarter_in_year_nbr,
  clndr.fiscal_week_in_year_nbr,
  clndr.fiscal_month_in_year_short_desc,
  cast(clndr.fiscal_week_begin_dt as timestamp) as fiscal_week_begin_dt,
  cast(clndr.fiscal_week_end_dt as timestamp) as fiscal_week_end_dt,
  cast(clndr.fiscal_month_begin_dt as timestamp) as fiscal_month_begin_dt,
  cast(clndr.fiscal_month_end_dt as timestamp) as fiscal_month_end_dt,
  cast(clndr.fiscal_quarter_begin_dt as timestamp) as fiscal_quarter_begin_dt,
  cast(clndr.fiscal_quarter_end_dt as timestamp) as fiscal_quarter_end_dt,
  cast(clndr.fiscal_year_begin_dt as timestamp) as fiscal_year_begin_dt,
  cast(clndr.fiscal_year_end_dt as timestamp) as fiscal_year_end_dt,
  clndr.fiscal_year_short_desc,
  clndr.fiscal_quarter_nbr,
  clndr.fiscal_year_week_nbr,
  clndr.fiscal_year_month_nbr,
  clndr.fiscal_day_in_week_nbr,
  clndr.fiscal_month_week_qty,
  cast(clndr.fiscal_dt as timestamp) as fiscal_dt,
  clndr.fiscal_date_nbr,
  clndr.calendar_date_nbr,
  --nar_zone
  zone.zone_hierarchy,
  --xref_category
  cat.global_category,
  cat.global_sub_category,
  cat.global_category_parent,
  cast(comp.sales_units* coalesce(zone.sales_split,
    1)*coalesce(CAST(cat.share_split AS float64),
    1) as int64) AS ty_sales_units,
  comp.sales_amount * coalesce(zone.sales_split,
    1)*coalesce(CAST(cat.share_split AS float64),
    1) AS ty_sales_value,
  'Competitor' AS manufacturer,
  LEAST(cust.customer_share_flag,coalesce(cat.share_category_relevancy_flag,
      'N')) AS share_category_relevancy_flag,
  coalesce(cat.global_category,
    share_source_category) AS resolved_category,
  'N' AS divested_fg
  , '""",JOB_RUN_ID,"""' created_by
, current_datetime created_datetime 
, '""",JOB_RUN_ID,"""' modified_by
, current_datetime modified_datetime 
FROM
  competitor_data comp
LEFT OUTER JOIN
  global_category cat
ON
  ( comp.share_source_category= trim(cat.key_value_2))
LEFT OUTER JOIN
  xref_customer cust
ON
  (cust.customer_name = UPPER('""",CUSTOMER_NAME,"""'))
LEFT OUTER JOIN
  fiscal_calendar clndr
ON
  CAST(comp.report_date AS date) = clndr.fiscal_dt
LEFT OUTER JOIN
  xref_zone zone
ON
  (UPPER(zone.customer_name) = cust.customer_name))""");

select SQL;

EXECUTE IMMEDIATE SQL;

EXCEPTION WHEN ERROR THEN
        EXECUTE IMMEDIATE CONCAT(
            """INSERT INTO processed.sproc_error_details (
		        SELECT
			        '""",FEED_NAME,"""' AS FEED_NAME,
                    split(split(@@error.formatted_stack_trace,'transient.')[OFFSET (1)],'[')[OFFSET(0)],
			        @@error.statement_text,
			        @@error.message,
			        current_timestamp()
	        );
	    """);
	    
	    SELECT
	        ERROR (
	            CONCAT(
	            		@@error.message ,' ' ,
	            		@@error.statement_text, ' ' ,
	            		@@error.formatted_stack_trace ,' '
	            	)
	        );
END;