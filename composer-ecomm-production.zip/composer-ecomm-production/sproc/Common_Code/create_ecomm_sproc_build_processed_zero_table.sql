/*
Purpose of the stored proc: 
	Consolidate attributes from audit table and hash key generation
History of Changes:
	2022/02/09 – first version
	05/10 - Updated composer related params and added sproc error mechanism
Author : 
	Pawan Rathod
How to Call:
	call transient.sp_build_processed_zero_table
	(
		'ecomm-dlf-dev-01cd47',
		'transient',
		'processed',
		'kroger_ship_delta_temp',
		'kroger_ship_processed_zero',
		'kroger_ship_processed_zero_archive',
		'KROGER_SHIP',
		'KROGER_SHIP'
	)
*/

CREATE OR REPLACE PROCEDURE transient.ecomm_sproc_build_processed_zero_table
(
	SRC_PROJECT string,
	SRC_DATASET string,
	DEST_DATASET string,
	SRC_TABLE string,
	DEST_TABLE string,
	ARCHIVE_TABLE string,
	CUSTOMER_NAME string,
	FEED_NAME string
)
OPTIONS(
description = """

 How to call:

     CALL transient.ecomm_sproc_build_processed_zero_table (
        'ecomm-dlf-dev-01cd47', -- SRC_PROJECT
		'transient', -- SRC_DATASET
		'processed', -- DEST_DATASET
		'kroger_ship_delta_temp', -- SRC_TABLE
		'kroger_ship_processed_zero', -- DEST_TABLE
		'kroger_ship_processed_zero_archive', -- ARCHIVE_TABLE
		'KROGER_SHIP', -- CUSTOMER_NAME
		'KROGER_SHIP' -- FEED_NAME
      )

"""
)
BEGIN

-- declare variables

DECLARE JOB_RUN_ID DEFAULT 999999;
DECLARE BQ_PROJECT_NAME DEFAULT SRC_PROJECT;
DECLARE BQ_TRANSIENT_DATASET_NAME DEFAULT SRC_DATASET;
DECLARE BQ_PROCESSED_DATASET_NAME DEFAULT DEST_DATASET;
DECLARE BQ_DELTA_TEMP_TABLE DEFAULT SRC_TABLE;
DECLARE BQ_PROCESSED_ZERO_TABLE DEFAULT DEST_TABLE;
DECLARE BQ_ARCHIVE_TABLE DEFAULT ARCHIVE_TABLE;

DECLARE MAX_FACT_SK,REC_COUNT INT64;
DECLARE JOIN_CONDITION,JOIN_CONDITION_REINSTATEMENT, KEYS_WITH_CAST, ORIGINAL_FILE_NAME_COLUMN_VERIFICATION,
		EXCEPT_COLUMN_LIST , FINAL_EXCEPT_COLUMN_LIST,
        FILE_DT_COLUMN_VERIFICATION,INGEST_DATE_COLUMN_VERIFICATION,RCTL_FILE_NAME_COLUMN_VERIFICATION  STRING;

SET CUSTOMER_NAME = UPPER(CUSTOMER_NAME);

SET FEED_NAME = UPPER(FEED_NAME);

/* A few columns need not be fetched from Delta temp table, these will come in EXCEPT_COLUMN_LIST variable */
SET EXCEPT_COLUMN_LIST = 'created_by , created_datetime , modified_by, modified_datetime'  ;

/* Check the presence of 'original_file_name,file_dt,ingest_date,rctl_file_name' columns in delta temp table before adding these to exception list
	file_dt,ingest_date and rctl_file_name are not present in the DA tables. */
EXECUTE IMMEDIATE
  CONCAT("""
  WITH
    dr AS (
    SELECT
      COUNT(*) cnt
    FROM
      """,BQ_TRANSIENT_DATASET_NAME,""".INFORMATION_SCHEMA.COLUMNS
    WHERE
      table_name = '""",BQ_DELTA_TEMP_TABLE,"""'
      AND column_name = 'original_file_name')
  SELECT
    CASE
      WHEN cnt = 0 THEN ' '
    ELSE
    'original_file_name,'
  END
  FROM
    dr""") INTO ORIGINAL_FILE_NAME_COLUMN_VERIFICATION;

EXECUTE IMMEDIATE
  CONCAT("""
  WITH
    dr AS (
    SELECT
      COUNT(*) cnt
    FROM
      """,BQ_TRANSIENT_DATASET_NAME,""".INFORMATION_SCHEMA.COLUMNS
    WHERE
      table_name = '""",BQ_DELTA_TEMP_TABLE,"""'
      AND column_name = 'file_dt')
  SELECT
    CASE
      WHEN cnt = 0 THEN ' '
    ELSE
    'file_dt,'
  END
  FROM
    dr""") INTO FILE_DT_COLUMN_VERIFICATION;

EXECUTE IMMEDIATE
  CONCAT("""
  WITH
    dr AS (
    SELECT
      COUNT(*) cnt
    FROM
      """,BQ_TRANSIENT_DATASET_NAME,""".INFORMATION_SCHEMA.COLUMNS
    WHERE
      table_name = '""",BQ_DELTA_TEMP_TABLE,"""'
      AND column_name = 'ingest_date')
  SELECT
    CASE
      WHEN cnt = 0 THEN ' '
    ELSE
    'ingest_date,'
  END
  FROM
    dr""") INTO INGEST_DATE_COLUMN_VERIFICATION;

EXECUTE IMMEDIATE
  CONCAT("""
  WITH
    dr AS (
    SELECT
      COUNT(*) cnt
    FROM
      """,BQ_TRANSIENT_DATASET_NAME,""".INFORMATION_SCHEMA.COLUMNS
    WHERE
      table_name = '""",BQ_DELTA_TEMP_TABLE,"""'
      AND column_name = 'rctl_file_name')
  SELECT
    CASE
      WHEN cnt = 0 THEN ' '
    ELSE
    'rctl_file_name,'
  END
  FROM
    dr""") INTO RCTL_FILE_NAME_COLUMN_VERIFICATION;

	-- concatenate all the columns to be added to exception list
SET FINAL_EXCEPT_COLUMN_LIST = CONCAT(ORIGINAL_FILE_NAME_COLUMN_VERIFICATION,FILE_DT_COLUMN_VERIFICATION,INGEST_DATE_COLUMN_VERIFICATION,RCTL_FILE_NAME_COLUMN_VERIFICATION,EXCEPT_COLUMN_LIST);

/* Generalising join condition:
	Fetching the Natural keys combination from Metadata Lookup table to create customer specific join condition statement,
	filtered on passed FEED_NAME */

EXECUTE IMMEDIATE
CONCAT ("""WITH
  join_condn AS (
  SELECT
    element
  FROM
    UNNEST(	(
      SELECT
        SPLIT(vendor_file_natural_key,',') sk
      FROM
        `""",BQ_PROJECT_NAME,"""`.""",BQ_TRANSIENT_DATASET_NAME,""".gmi_customer_metadata_reference
      WHERE
        UPPER(FEED_NAME) =UPPER('""",FEED_NAME,"""'))) AS element)
	--Performing RTRIM one character at a time
  --Columns with NULL values dont match up hence COALESCE added. All columns casted to String to handle Timestamp and date columns. If not casting then error shown.
  select
    rtrim(string_agg ('COALESCE(CAST(delta_temp_tbl.' || element || ' AS STRING), \\'\\') = COALESCE(CAST(processed_zero_tbl.' || element || ' AS STRING), \\'\\') and ',
    ' '),' and ' ) from join_condn
""") into JOIN_CONDITION;

--concat xref natural key columns to generate hash key
EXECUTE IMMEDIATE CONCAT("""with natural_keys as (SELECT split(dim_xref_natural_key,',') nks
from transient.gmi_customer_metadata_reference where upper(FEED_NAME) = '""",FEED_NAME,"""')
select String_agg(tf_col) from (select concat("trim(cast(",IF(COALESCE(col,'')<>'',col,'null')," as string))") tf_col from natural_keys,unnest(nks) col)""")
INTO KEYS_WITH_CAST;

--Check if Delta temp table has new records

EXECUTE IMMEDIATE CONCAT
    ("""
            select
                count(*)
            from
                `""",BQ_PROJECT_NAME,"""`.""",BQ_TRANSIENT_DATASET_NAME,""".""",BQ_DELTA_TEMP_TABLE,""" delta_temp_tbl
            join """,BQ_PROCESSED_DATASET_NAME,""".""",BQ_PROCESSED_ZERO_TABLE, """ processed_zero_tbl
	        on
	""",JOIN_CONDITION) into REC_COUNT;


---Fetch Maximum surrogate key from processed fact table
Execute Immediate
concat(""" select coalesce(max(fact_sk),0) from `""",BQ_PROJECT_NAME,"""`.""",BQ_PROCESSED_DATASET_NAME,""".""",BQ_PROCESSED_ZERO_TABLE)
into MAX_FACT_SK;

---Reinstatement Handling
---Delete all records from Processed zero for given search date & file_name in delta temp to handle deleted records in restatements or rolling weeks
---Archive the matching records for given search date & file_name 1. Copy the records to Archive table 2.Delete Records from processed fact table
IF REC_COUNT <> 0 THEN
    EXECUTE IMMEDIATE CONCAT
        ("""
            Insert into `""",BQ_PROJECT_NAME,"""`.""",BQ_PROCESSED_DATASET_NAME,""".""",BQ_ARCHIVE_TABLE, """
                select
                    processed_zero_tbl.*
                    except(
                    	  created_by
                    	, created_datetime
                    	, modified_by
                    	, modified_datetime
                    )
                    ,'""",job_run_id,"""' as created_by
                    , current_datetime as created_datetime
                    ,'""",job_run_id,"""' as modified_by
                    ,current_datetime as modified_datetime
                from
                    `""",BQ_PROJECT_NAME,"""`.""",BQ_TRANSIENT_DATASET_NAME,""".""",BQ_DELTA_TEMP_TABLE,""" delta_temp_tbl
                        join
                    """,BQ_PROCESSED_DATASET_NAME,""".""",BQ_PROCESSED_ZERO_TABLE,""" processed_zero_tbl
         on """,JOIN_CONDITION);

    --Delete already existing matching records from processed-0 fact table
      EXECUTE IMMEDIATE CONCAT
          ("""
              delete from `""",BQ_PROJECT_NAME,"""`.""",BQ_PROCESSED_DATASET_NAME,""".""",BQ_PROCESSED_ZERO_TABLE,"""  processed_zero_tbl
                  where exists
                  (
                  	Select delta_temp_tbl.*
                  	from `""",BQ_PROJECT_NAME,"""`.""",BQ_TRANSIENT_DATASET_NAME,""".""",BQ_DELTA_TEMP_TABLE,""" delta_temp_tbl
                  	where  """,JOIN_CONDITION,"""
                  )
          """);
    ---Reinstatement Handling
    ---Delete all records from Processed zero for given report date in delta temp to handle deleted records in restatements or rolling weeks
    ---Archive the matching records for given report date 1. Copy the records to Archive table 2.Delete Records from processed fact table
      EXECUTE IMMEDIATE CONCAT
          ("""
              WITH
                join_condn_reinstate AS
                (
                      SELECT
                    vendor_file_fiscal_date as element
                  FROM
                    `""",BQ_PROJECT_NAME,"""`.""",BQ_TRANSIENT_DATASET_NAME,""".gmi_customer_metadata_reference
                  WHERE
                    UPPER(FEED_NAME) =UPPER('""",FEED_NAME,"""')
            )
            --Performing RTRIM one character at a time
            --Columns with NULL values dont match up hence COALESCE added. All columns casted to String to handle Timestamp and date columns. If not casting then error shown.
          select
            rtrim(string_agg ('COALESCE(CAST(delta_temp_tbl.' || element || ' AS STRING), \\'\\') = COALESCE(CAST(processed_zero_tbl.' || element || ' AS STRING), \\'\\') and ',
            ' '),' and ' ) from join_condn_reinstate
      """) into JOIN_CONDITION_REINSTATEMENT;

  EXECUTE IMMEDIATE CONCAT
      ("""
          Insert into `""",BQ_PROJECT_NAME,"""`.""",BQ_PROCESSED_DATASET_NAME,""".""",BQ_ARCHIVE_TABLE, """
              select
                processed_zero_tbl.*
                except
                (
  	             created_by
  	            ,created_datetime
  	            ,modified_by
  	            ,modified_datetime
  	          )
  	          ,'""",job_run_id,"""' as created_by
  	          , current_datetime as created_datetime
  	          ,'""",job_run_id,"""' as modified_by
  	          ,current_datetime as modified_datetime
  	        from
  	            `""",BQ_PROJECT_NAME,"""`.""",BQ_TRANSIENT_DATASET_NAME,""".""",BQ_DELTA_TEMP_TABLE,""" delta_temp_tbl
                      join
                  """,BQ_PROCESSED_DATASET_NAME,""".""",BQ_PROCESSED_ZERO_TABLE,""" processed_zero_tbl
                  on
      """,JOIN_CONDITION_REINSTATEMENT);
    --Delete already existing report date from processed-0 fact table
    EXECUTE IMMEDIATE CONCAT
      ("""
          delete from `""",BQ_PROJECT_NAME,"""`.""",BQ_PROCESSED_DATASET_NAME,""".""",BQ_PROCESSED_ZERO_TABLE,"""  processed_zero_tbl
              where exists
              (
              	Select delta_temp_tbl.*
              	from `""",BQ_PROJECT_NAME,"""`.""",BQ_TRANSIENT_DATASET_NAME,""".""",BQ_DELTA_TEMP_TABLE,""" delta_temp_tbl
              	where  """,JOIN_CONDITION_REINSTATEMENT,"""
              )
      """);
END IF;

EXECUTE IMMEDIATE CONCAT
    ("""
        Insert into `""",BQ_PROJECT_NAME,"""`.""",BQ_PROCESSED_DATASET_NAME,""".""",BQ_PROCESSED_ZERO_TABLE,"""
            select
            	(""",MAX_FACT_SK,""" +(ROW_NUMBER() OVER())) as fact_sk
            	,delta_temp_tbl.* except
            	( """,
                    FINAL_EXCEPT_COLUMN_LIST,
            	 """
             	)
            	, transient.udf_compute_sha256_hash([""",KEYS_WITH_CAST,"""])  as source_product_hash
            	,'""",job_run_id,"""' as created_by
            	,current_datetime as created_datetime
            	,'""",job_run_id,"""' as modified_by
            	,current_datetime as modified_datetime
            from  `""",BQ_PROJECT_NAME,"""`.""",BQ_TRANSIENT_DATASET_NAME,""".""",BQ_DELTA_TEMP_TABLE,""" delta_temp_tbl
    """);



EXCEPTION WHEN ERROR THEN
        EXECUTE IMMEDIATE CONCAT(
            """INSERT INTO processed.sproc_error_details (
		        SELECT
			        '""",FEED_NAME,"""' AS FEED_NAME,
                    split(split(@@error.formatted_stack_trace,'transient.')[OFFSET (1)],'[')[OFFSET(0)],
			        @@error.statement_text,
			        @@error.message,
			        current_timestamp()
	        );
	    """);

	    SELECT
	        ERROR (
	            CONCAT(
	            		@@error.message ,' ' ,
	            		@@error.statement_text, ' ' ,
	            		@@error.formatted_stack_trace ,' '
	            	)
	        );
 
End