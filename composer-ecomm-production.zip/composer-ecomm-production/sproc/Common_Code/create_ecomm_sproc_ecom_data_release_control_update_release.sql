/*

Purpose of the stored proc:
	This procedure updates the Release_flg column in ecom_data_release_control table in one go if staging_flg is 'Y'already
	
	- Update Release_flg to 'Y' if staging_flg for passed CUSTOMER_NAME is 'Y' already
	- Multiple Customer names,feed names can be passed in the argument
	- Customer name,Feed name are  optional parameters
	
History of Changes:

	04/30 – first version 
	05/20 - Added 'FEED_NAME' column to release control table & in parameters
	05/10 - Updated composer related params and added sproc error mechanism

Author : 
	Pawan Rathod

*/


CREATE OR REPLACE PROCEDURE transient.ecomm_sproc_data_release_control_update_release
(
	SRC_PROJECT STRING,
	SRC_DATASET STRING,
	CUSTOMER_NAME STRING,
	FEED_NAME STRING
)
OPTIONS(
description = """

 How to call:

     CALL transient.ecomm_sproc_data_release_control_update_release (
		"ecomm-dlf-dev-01cd47", -- SRC_PROJECT
        "processed", -- SRC_DATASET
        "KROGER_SHIP,KROGER_DELIVERY", -- CUSTOMER_NAME
        "KROGER_SHIP,KROGER_DELIVERY" -- FEED_NAME
	)
"""
)
BEGIN
-- declare variables

DECLARE JOB_RUN_ID DEFAULT 999999;
DECLARE BQ_PROJECT_NAME DEFAULT SRC_PROJECT;
DECLARE BQ_PROCESSED_DATASET_NAME DEFAULT SRC_DATASET;

DECLARE
    JOB_RUN_ID_STRING ,
    FINAL_CUSTOMER_NAME,
    FINAL_FEED_NAME,
    JOIN_CONDITION STRING;

-- set variables
SET JOB_RUN_ID_STRING = cast(JOB_RUN_ID as STRING);

SET CUSTOMER_NAME = UPPER(CUSTOMER_NAME);

SET FEED_NAME = UPPER(FEED_NAME);


--Update the release_flag to 'Y' if staging flag for passed customers is 'Y' already
--Customer name,Feed name are optional parameters


if CUSTOMER_NAME is not null or CUSTOMER_NAME <> ''
then 
-- Splitting and re-formatting  Multiple Customer names passed in the argument
EXECUTE IMMEDIATE CONCAT("""
with split_customer_name as 
	(
	 select CUSTOMER_NAME from unnest((select split(('""",CUSTOMER_NAME,"""'),',') cust ))  CUSTOMER_NAME)
select  rtrim(string_agg("'" || CUSTOMER_NAME || "'"),'') from split_customer_name  """)into FINAL_CUSTOMER_NAME;
end if;

if FEED_NAME is not null or FEED_NAME <> ''
then 
-- Splitting and re-formatting  Multiple Feed names passed in the argument
EXECUTE IMMEDIATE CONCAT("""
with split_feed_name as 
	(
	 select FEED_NAME from unnest((select split(('""",FEED_NAME,"""'),',') cust ))  FEED_NAME)
select  rtrim(string_agg("'" || FEED_NAME || "'"),'') from split_feed_name  """)into FINAL_FEED_NAME;
end if;

-- Parameterised the join condition which will vary if any/both of the CUSTOMER_NAME or FEED_NAME parameters are null 
Execute Immediate
concat("""WITH
  join_condn AS ( 
  select case when coalesce(('""",CUSTOMER_NAME,"""'),'') <> '' 
			  then concat("and tgt.CUSTOMER_NAME in (""",FINAL_CUSTOMER_NAME,""")")
			  else ''
		 end   as cust_name,
		 case when coalesce(('""",FEED_NAME,"""'),'') <> '' 
			  then concat("and tgt.FEED_NAME in (""",FINAL_FEED_NAME,""")")
			  else ''
		 end   as FEED_NAME)
	select concat(cust_name,' ',FEED_NAME) from join_condn""") into JOIN_CONDITION;

-- Update Release_flg in ecom_data_release_control table
EXECUTE IMMEDIATE CONCAT("""
	Update `""" ,BQ_PROJECT_NAME,"""`.""",BQ_PROCESSED_DATASET_NAME,""".ecom_data_release_control tgt
	set 
		release_flg = "Y",
		modified_by =  '""",JOB_RUN_ID_STRING,"""',
		modified_datetime = current_datetime()
	where   staging_flg = "Y"  
		and release_flg = "N" 
		""",JOIN_CONDITION
	
);

/*Feed_name & customer _name both are optional parameters
  If both FEED_NAME & CUSTOMER_NAME are null or blank ,update Release_flg irrespective of the CUSTOMER_NAME/FEED_NAME
  in ecom_data_release_control table(if staging_flg is 'Y' already) */

if (FEED_NAME is null or FEED_NAME = '') and (CUSTOMER_NAME is null or CUSTOMER_NAME = '')
then
EXECUTE IMMEDIATE CONCAT("""
	Update `""" ,BQ_PROJECT_NAME,"""`.""",BQ_PROCESSED_DATASET_NAME,""".ecom_data_release_control tgt
	set 
		release_flg = "Y",
		modified_by =  '""",JOB_RUN_ID_STRING,"""',
		modified_datetime = current_datetime()
	where staging_flg = "Y"  and release_flg = "N" 
""");
end if;

EXCEPTION WHEN ERROR THEN
        EXECUTE IMMEDIATE CONCAT(
            """INSERT INTO processed.sproc_error_details (
		        SELECT
			        '""",FEED_NAME,"""' AS FEED_NAME,
                    split(split(@@error.formatted_stack_trace,'transient.')[OFFSET (1)],'[')[OFFSET(0)],
			        @@error.statement_text,
			        @@error.message,
			        current_timestamp()
	        );
	    """);

	    SELECT
	        ERROR (
	            CONCAT(
	            		@@error.message ,' ' ,
	            		@@error.statement_text, ' ' ,
	            		@@error.formatted_stack_trace ,' '
	            	)
	        );

END
