/*

Purpose OF the stored proc :
    Moving data FROM source to target

History OF Changes :
    03/24 first version
    05/10 - Updated composer related params and added sproc error mechanism
Author :
    Pawan Rathod

*/
CREATE OR REPLACE PROCEDURE
  transient.ecomm_sproc_copy_table (
    SRC_PROJECT STRING,
    SRC_DATASET STRING,
    SRC_TABLE STRING,
    DEST_PROJECT STRING,
    DEST_DATASET STRING,
    DEST_TABLE STRING ,
    FEED_NAME STRING
)
OPTIONS(
description = """

 How to call:

     CALL transient.sp_copy_table (
        "ecomm-dlf-dev-01cd47", -- SRC_PROJECT
        "raw", -- SRC_DATASET
        "lkp_kroger_fiscal_calendar_415", -- SRC_TABLE
        "ecomm-dlf-dev-01cd47", -- DEST_PROJECT
        "processed", -- DEST_DATASET
        "lkp_kroger_fiscal_calendar" -- DEST_TABLE
        "LKP_KROGER_FISCAL_CALENDAR" -- FEED_NAME
      )
"""
)
BEGIN

DECLARE JOB_RUN_ID DEFAULT 999999;
DECLARE BQ_SOURCE_PROJECT_NAME DEFAULT SRC_PROJECT;
DECLARE BQ_SOURCE_DATASET_NAME DEFAULT SRC_DATASET;
DECLARE BQ_SOURCE_TABLENAME DEFAULT SRC_TABLE;
DECLARE BQ_TARGET_PROJECT_NAME DEFAULT DEST_PROJECT;
DECLARE BQ_TARGET_DATASET_NAME DEFAULT DEST_DATASET;
DECLARE BQ_TARGET_TABLENAME DEFAULT DEST_TABLE;

SET FEED_NAME = UPPER(FEED_NAME);

-- Truncate Target Table
EXECUTE IMMEDIATE
  CONCAT("""TRUNCATE TABLE  `""",BQ_TARGET_PROJECT_NAME,"""`.""",BQ_TARGET_DATASET_NAME,""".""",BQ_TARGET_TABLENAME); --
--INSERT INTO Target Table from Source Table
EXECUTE IMMEDIATE
  CONCAT( """INSERT INTO  `""",BQ_TARGET_PROJECT_NAME,"""`.""",BQ_TARGET_DATASET_NAME,""".""",BQ_TARGET_TABLENAME,""" (
    WITH
      source AS (
      SELECT
        * EXCEPT (rctl_created_by,
          rctl_created_dttm,
          rctl_modified_by,
          rctl_modified_dttm)
      FROM
        `""",BQ_SOURCE_PROJECT_NAME,"""`.""",BQ_SOURCE_DATASET_NAME,""".""",BQ_SOURCE_TABLENAME,""")
    SELECT
      source.*,
      CAST(""",job_run_id,""" AS string) AS created_by,
      current_datetime AS created_datetime,
      CAST(""",job_run_id,""" AS string) AS modified_by,
      current_datetime AS modified_datetime
    FROM
      source)""" );

EXCEPTION WHEN ERROR THEN
        EXECUTE IMMEDIATE CONCAT(
            """INSERT INTO processed.sproc_error_details (
		        SELECT
			        '""",FEED_NAME,"""' AS FEED_NAME,
			                            split(split(@@error.formatted_stack_trace,'transient.')[OFFSET (1)],'[')[OFFSET(0)],
			        @@error.statement_text,
			        @@error.message,
			        current_timestamp()
	        );
	    """);

	    SELECT
	        ERROR (
	            CONCAT(
	            		@@error.message ,' ' ,
	            		@@error.statement_text, ' ' ,
	            		@@error.formatted_stack_trace ,' '
	            	)
	        );

END