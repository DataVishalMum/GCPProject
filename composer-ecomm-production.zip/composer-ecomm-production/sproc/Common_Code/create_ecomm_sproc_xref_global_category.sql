/*

Purpose of the stored proc:
	Maps data to XREF GLOBAL CATEGORY

History of Changes:
	05/27 – first version

Author :
	Pawan Rathod

*/

CREATE OR REPLACE PROCEDURE transient.ecomm_sproc_xref_global_category
(
	FEED_NAME STRING
)
OPTIONS (
    description = """

        How to call:

             CALL transient.ecomm_sproc_xref_global_category(
                         "LOBLAWS" -- FEED_NAME
             )
    """
)

BEGIN

DECLARE XREF_CTE ARRAY<STRING>;
DECLARE XREF_CTE_COUNTS INT64 DEFAULT 0;
DECLARE CUSTOMER_NAME, GLOBAL_XREF_NATURAL_KEY, SRC_TABLE_NAME, TGT_XREF_TEMP_TABLE_NM, XREF_SELECT_COLUMN_LIST STRING;

DECLARE XREF_KEY_COLUMN_1, XREF_KEY_COLUMN_2, XREF_KEY_COLUMN_3 STRING;
DECLARE XREF_QUERY STRING DEFAULT '';
DECLARE XREF_CTAS STRING DEFAULT ' with ';

SET FEED_NAME = UPPER(FEED_NAME);

/* FETCHING KEY COLUMNS BASED ON FEED_NAME */

EXECUTE IMMEDIATE CONCAT( 
"""
	SELECT 
		customer_name,
		global_xref_natural_key,
		CONCAT(LOWER(table_name_prefix),'_consolidate_product_temp') AS src_table_name,
		CONCAT(LOWER(table_name_prefix),'_xref_global_category_temp') as tgt_xref_temp_table_nm  
	FROM transient.gmi_customer_metadata_reference  
	WHERE feed_name = '""",FEED_NAME,"""'
""") INTO CUSTOMER_NAME, GLOBAL_XREF_NATURAL_KEY, SRC_TABLE_NAME, TGT_XREF_TEMP_TABLE_NM;

/* SETTING XREF SELECT COLUMN LIST */

-- INDIVIDUAL KEYS PER RETAILER AS PER GMI_METADATA_REFERENCE
SET GLOBAL_XREF_NATURAL_KEY = (SELECT STRING_AGG(CONCAT('src.', TRIM(natural_key_val))) FROM UNNEST(SPLIT(GLOBAL_XREF_NATURAL_KEY,',')) as natural_key_val);

-- COMMON LIST OF KEYS ACCORDING TO XREF (i.e. XREF_GLOBAL_CATEGORY in this case)
SET XREF_SELECT_COLUMN_LIST = (SELECT 
	STRING_AGG(CONCAT('xref.',column_name,'')) as dataColumns 
from 
	(
		SELECT 
			1 AS grpKey,
			column_name   
		FROM processed.INFORMATION_SCHEMA.COLUMNS c 
		WHERE 
					c.table_name='xref_global_category' 
				and c.table_schema = 'processed'
	) 
group by grpKey);

SET XREF_SELECT_COLUMN_LIST = CONCAT(XREF_SELECT_COLUMN_LIST,',',GLOBAL_XREF_NATURAL_KEY);

/* GENERATING XREF CTAS BASED ON KEY & VALUE COLUMN IN XREF */

EXECUTE IMMEDIATE CONCAT ("""
with src as 
( 
	SELECT column_name  
	FROM  transient.INFORMATION_SCHEMA.COLUMNS  
	WHERE  table_name='""",SRC_TABLE_NAME,"""'
) 
SELECT ARRAY_AGG(distinct concat(ifnull(key_column_1,'') , ',' , ifnull(key_rule_1,'') , ';' , ifnull(key_column_2,'') , ',' , ifnull(key_rule_2,'') , ';' , ifnull(key_column_3,'') , ',' , ifnull(key_rule_3,'')))
from processed.xref_global_category xref 
where 
	(xref.key_column_1 in (SELECT s.column_name from src s) or key_column_1 is null)
 and (xref.key_column_2 in (SELECT s.column_name from src s) or key_column_2 is null)
 and (xref.key_column_3 in (SELECT s.column_name from src s) or key_column_3 is null)
"""
) INTO XREF_CTE;

FOR xref in (SELECT TRIM(REGEXP_REPLACE(REPLACE(xref_value,',in_string',''),r'[^A-Za-z , _ ]','')) as xref_value from UNNEST(XREF_CTE) as xref_value)
DO


IF XREF_CTE_COUNTS != 0 THEN

SET XREF_CTAS = CONCAT(XREF_CTAS, " , ");

SET XREF_QUERY = CONCAT(XREF_QUERY, " UNION ALL ");

END IF;

EXECUTE IMMEDIATE CONCAT(
	"""
	SELECT 
	TRIM(SPLIT('""",xref.xref_value,"""',',')[OFFSET (0)]) as key_column_1,
	TRIM(SPLIT('""",xref.xref_value,"""',',')[OFFSET (1)]) as key_column_2,
	TRIM(SPLIT('""",xref.xref_value,"""',',')[OFFSET (2)]) as key_column_3
"""
) INTO XREF_KEY_COLUMN_1, XREF_KEY_COLUMN_2, XREF_KEY_COLUMN_3;

IF LENGTH(XREF_KEY_COLUMN_3) = 0 THEN 

SET XREF_CTAS = CONCAT(XREF_CTAS,""" xref_""",CAST(XREF_CTE_COUNTS AS STRING),""" as (
	SELECT  xref.* 
	FROM processed.xref_global_category xref 
	WHERE xref.key_column_1 """,IF(LENGTH(XREF_KEY_COLUMN_1) > 0,CONCAT(" = '",XREF_KEY_COLUMN_1,"'")," IS NULL "),""" 
	and xref.key_column_2 """,IF(LENGTH(XREF_KEY_COLUMN_2) > 0,CONCAT(" = '",XREF_KEY_COLUMN_2,"'")," IS NULL "),""" 
	and xref.key_column_3 IS NULL )
""");

SET XREF_QUERY = CONCAT(XREF_QUERY," SELECT ",XREF_SELECT_COLUMN_LIST," FROM xref_",CAST(XREF_CTE_COUNTS AS STRING)," xref INNER JOIN transient.",SRC_TABLE_NAME," src ON src.",XREF_KEY_COLUMN_1," = xref.key_value_1 AND src.",XREF_KEY_COLUMN_2," =  xref.key_value_2");

ELSE 

SET XREF_CTAS = CONCAT(XREF_CTAS,""" xref_""",CAST(XREF_CTE_COUNTS AS STRING),""" as (
	SELECT  xref.* , concat(replace(LOWER(xref.key_value_3),'~','%'),'%') AS match_expr_3
	FROM processed.xref_global_category xref 
	WHERE xref.key_column_1 """,IF(LENGTH(XREF_KEY_COLUMN_1) > 0,CONCAT(" = '",XREF_KEY_COLUMN_1,"'")," IS NULL "),""" 
	and xref.key_column_2 """,IF(LENGTH(XREF_KEY_COLUMN_2) > 0,CONCAT(" = '",XREF_KEY_COLUMN_2,"'")," IS NULL "),""" 
	and xref.key_column_3 """,CONCAT(" = '",XREF_KEY_COLUMN_3,"'"),""" 
	)
""");

SET XREF_QUERY = CONCAT(XREF_QUERY," SELECT ",XREF_SELECT_COLUMN_LIST," FROM xref_",CAST(XREF_CTE_COUNTS AS STRING)," xref INNER JOIN transient.",SRC_TABLE_NAME," src ON src.",XREF_KEY_COLUMN_1," = xref.key_value_1 AND src.",XREF_KEY_COLUMN_2," =  xref.key_value_2 AND LOWER(src.",XREF_KEY_COLUMN_3,") like xref.match_expr_3");

END IF;

SET XREF_CTE_COUNTS = XREF_CTE_COUNTS + 1;

END FOR;
 
SET GLOBAL_XREF_NATURAL_KEY = REPLACE(GLOBAL_XREF_NATURAL_KEY,'src.','a.');

EXECUTE IMMEDIATE CONCAT("""
	CREATE OR REPLACE TABLE transient.""",TGT_XREF_TEMP_TABLE_NM,""" as """,XREF_CTAS,
			""" SELECT a.* , row_number() OVER( PARTITION BY """,GLOBAL_XREF_NATURAL_KEY,""" ORDER BY a.xref_order) AS best FROM ( """,
			XREF_QUERY,
			""") as a""");

EXCEPTION WHEN ERROR THEN
        EXECUTE IMMEDIATE CONCAT(
            """INSERT INTO processed.sproc_error_details (
		        SELECT
			        '""",FEED_NAME,"""' AS FEED_NAME,
                    split(split(@@error.formatted_stack_trace,'transient.')[OFFSET (1)],'[')[OFFSET(0)],
			        @@error.statement_text,
			        @@error.message,
			        current_timestamp()
	        );
	    """);

	    SELECT
	        ERROR (
	            CONCAT(
	            		@@error.message ,' ' ,
	            		@@error.statement_text, ' ' ,
	            		@@error.formatted_stack_trace ,' '
	            	)
	        );

END;