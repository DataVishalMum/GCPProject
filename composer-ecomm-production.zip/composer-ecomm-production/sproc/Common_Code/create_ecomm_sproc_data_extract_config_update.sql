/*
Purpose of the stored proc: 
	Update the Status for passed customer having current status as 'running'
History of Changes:
	03/10 – first version
	05/10 - Updated composer related params and added sproc error mechanism
Author : 
	Pawan Rathod
*/

CREATE OR REPLACE PROCEDURE transient.ecomm_sproc_data_extract_config_update
  (
    SRC_PROJECT STRING,
    SRC_DATASET STRING,
	SRC_TABLE  STRING,
	FEED_NAME STRING
  )
OPTIONS(
description = """

 How to call:

     CALL transient.ecomm_sproc_data_extract_config_update (
        'ecomm-dlf-dev-01cd47', -- SRC_PROJECT
        'transient', -- SRC_DATASET
        'kroger_ship_sales', -- SRC_TABLE
        'kroger_ship' -- FEED_NAME
      )

"""
)
BEGIN

-- declare variables
DECLARE JOB_RUN_ID DEFAULT 999999;
DECLARE BQ_PROJECT_NAME DEFAULT SRC_PROJECT;
DECLARE BQ_TRANSIENT_DATASET_NAME DEFAULT SRC_DATASET;
DECLARE BQ_TABLE_NAME DEFAULT SRC_TABLE;

DECLARE JOB_RUN_ID_STRING string;

-- set variables
SET JOB_RUN_ID_STRING = cast(JOB_RUN_ID as string);

SET FEED_NAME = UPPER(FEED_NAME);

-- It is assumed that at any given time, there will be 0 or 1 records per table with status "running".
-- Hence , the check on status = 'running' with "IF " conditional statement is not necessary.
-- The filter in the UPDATE statement will suffice and update the record  when the status = 'running'.

--should we put a check here to capture exception?
EXECUTE IMMEDIATE
  CONCAT(
  """UPDATE `""",BQ_PROJECT_NAME,"""`.""",BQ_TRANSIENT_DATASET_NAME,""".data_extract_config 
	SET status ='complete', modified_by = '""",JOB_RUN_ID_STRING, """', modified_datetime = current_timestamp 
	WHERE table_name='""",BQ_TABLE_NAME,"""' AND status='running'"""); 

-- exception handling

EXCEPTION WHEN ERROR THEN
        EXECUTE IMMEDIATE CONCAT(
            """INSERT INTO processed.ecomm_admin_sproc_error_details (
		        SELECT
			        '""",FEED_NAME,"""' AS FEED_NAME,
                    split(split(@@error.formatted_stack_trace,'transient.')[OFFSET (1)],'[')[OFFSET(0)],
			        @@error.statement_text,
			        @@error.message,
			        current_timestamp()
	        );
	    """);

	    SELECT
	        ERROR (
	            CONCAT(
	            		@@error.message ,' ' ,
	            		@@error.statement_text, ' ' ,
	            		@@error.formatted_stack_trace ,' '
	            	)
	        );

END;