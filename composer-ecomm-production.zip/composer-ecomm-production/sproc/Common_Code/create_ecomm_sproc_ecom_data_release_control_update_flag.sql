/*Purpose of the stored proc: 
This procedure updates the staging & release flag values in Data release control table  for provided customer & feed names

	- Update Staging & Release Flag values in 'ecom_data_release_control' table specific to passed customer names corresponding to fiscal_year_week_nbr
	- Multiple Customer names,feed names can be passed in the argument
	
	
History of Changes:
	04/30 – first version 
	05/20 - Added 'feed_name' column to release control table & in parameters
Author : 
	Swati Thakur
How to call:
	call  transient.ecomm_sproc_data_release_control_update_flag
		(
		123,
		'ecomm-dlf-dev-01cd47',
		'processed',
		'KROGER_SHIP,KROGER_DELIVERY',
		'KROGER_SHIP,KROGER_DELIVERY',
		202144,
		'Y',
		'Y'		
		)

*/


CREATE OR REPLACE PROCEDURE transient.ecomm_sproc_data_release_control_update_flag
(
	job_run_id INT64,
	bq_project_name string,
	bq_processed_dataset_name string,
	customer_name string,
	feed_name string,
	fiscal_year_week_nbr INT64,
	staging_flg string,
	release_flg string
	
)
BEGIN
-- declare variables

DECLARE job_run_id_string ,fiscal_dt,final_customer_name,final_feed_name String;

-- set variables
set job_run_id_string = cast(job_run_id as string);

-- Splitting and re-formatting  Multiple Customer names passed in the argument
EXECUTE IMMEDIATE CONCAT("""
with split_customer_name as 
	(
	 select customer_name from unnest((select split(('""",customer_name,"""'),',') cust ))  customer_name)
select  rtrim(string_agg("'" || customer_name || "'"),'') from split_customer_name  """)into final_customer_name;

-- Splitting and re-formatting  Multiple Feed names passed in the argument
EXECUTE IMMEDIATE CONCAT("""
with split_feed_name as 
	(
	 select feed_name from unnest((select split(('""",feed_name,"""'),',') cust ))  feed_name)
select  rtrim(string_agg("'" || feed_name || "'"),'') from split_feed_name  """)into final_feed_name;

-- Update the release_flag & staging_flag to 'Y'/'N' for passed customer name & fiscal_year_week_nbr,only if Staging Flag is already set to 'Y'
-- Customer name is redundant as feed_name holds the unique value
EXECUTE IMMEDIATE CONCAT(
"""Update `""" ,bq_project_name,"""`.""",bq_processed_dataset_name,""".ecom_data_release_control tgt
set 
	staging_flg = (case when coalesce('""",staging_flg,"""','') = "Y" or coalesce('""",staging_flg,"""','') = "N" then '""",staging_flg,"""' end ),
	release_flg = (case when coalesce('""",release_flg,"""','') = "Y" or coalesce('""",release_flg,"""','') = "N" then '""",release_flg,"""' end ),
	modified_by =  '""",job_run_id_string,"""',
	modified_datetime = current_datetime()
where   upper(tgt.customer_name) in (""",final_customer_name,""")
	and upper(tgt.feed_name) in (""",final_feed_name,""")
	and fiscal_year_week_nbr = """,fiscal_year_week_nbr,"""
	and staging_flg= 'Y'
""")
;

EXCEPTION WHEN ERROR THEN
        EXECUTE IMMEDIATE CONCAT(
            """INSERT INTO processed.sproc_error_details (
		        SELECT
			        '""",FEED_NAME,"""' AS FEED_NAME,
                    split(split(@@error.formatted_stack_trace,'transient.')[OFFSET (1)],'[')[OFFSET(0)],
			        @@error.statement_text,
			        @@error.message,
			        current_timestamp()
	        );
	    """);

	    SELECT
	        ERROR (
	            CONCAT(
	            		@@error.message ,' ' ,
	            		@@error.statement_text, ' ' ,
	            		@@error.formatted_stack_trace ,' '
	            	)
	        );

END
