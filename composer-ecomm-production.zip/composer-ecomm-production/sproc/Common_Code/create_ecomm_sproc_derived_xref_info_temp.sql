/*

Purpose of the stored proc:
  1. This is a generic flow for all the customers of NAR and EUAU.
  2. Overwrites the derived_xref_temp.
  3. This proc will bring all the data from product , Nielsen dim, customer xref (Consolidated_temp)
     derived attributes based on product dims and xref attributes(derived logic in this proc).

History of Changes:
	04/07/2021 – first version
    04/22/2021 - Modified manufacturer logic to pick the priority columns dynamically.
    05/11/2021 - Enhanced logic to run the same PROC for the EUAU customers - ['OCADO','ASDA','TESCO','SAINSBURY','COLES','WOOLWORTHS']
    05/20/2021 - Updated customer_name to feed_name for filtering on gmi_customer_metadata_reference table, Added corrrect instacart club table name.
    05/10 - Updated composer related params and added sproc error mechanism

Author :
	Pawan Rathod

*/
CREATE OR REPLACE PROCEDURE transient.ecomm_sproc_derived_xref_info_temp(
    SRC_PROJECT STRING,
    SRC_DATASET STRING,
    XREF_TABLE STRING,
    SRC_TABLE STRING,
    DEST_TABLE STRING,
    CUSTOMER_NAME STRING,
    FEED_NAME STRING,
    DEST_DATASET STRING
)
OPTIONS(
description = """

 How to call:

     CALL transient.ecomm_sproc_derived_xref_info_temp (
		"ecomm-dlf-dev-01cd47", -- SRC_PROJECT
        "transient", -- SRC_DATASET
        "kroger_ship_consolidate_xref_temp", -- XREF_TABLE
        "kroger_ship_consolidate_product_temp", -- SRC_TABLE
        "kroger_ship_derived_xref_info_temp", -- DEST_TABLE
        "KROGER_SHIP", -- CUSTOMER_NAME
        "KROGER_SHIP", -- FEED_NAME
        "processed" -- DEST_DATASET
	)
"""
)
BEGIN

    DECLARE JOB_RUN_ID DEFAULT 999999;
    DECLARE BQ_PROJECT_NAME DEFAULT SRC_PROJECT;
    DECLARE BQ_TRANSIENT_DATASET_NAME DEFAULT SRC_DATASET;
    DECLARE BQ_CONSOLIDATE_XREF_TABLENAME DEFAULT XREF_TABLE;
    DECLARE BQ_CONSOLIDATE_PRODUCT_TABLENAME DEFAULT SRC_TABLE;
    DECLARE BQ_DERIVED_XREF_INFO_TABLENAME DEFAULT DEST_TABLE;
    DECLARE BQ_PROCESSED_DATASET_NAME DEFAULT DEST_DATASET;

DECLARE
  ECOMM_DLF_TRANSIENT_DS STRING DEFAULT CONCAT("`",BQ_PROJECT_NAME,"`.",BQ_TRANSIENT_DATASET_NAME,".");
DECLARE
  ECOMM_DLF_PROCESSED_DS STRING DEFAULT CONCAT("`",BQ_PROJECT_NAME,"`.",BQ_PROCESSED_DATASET_NAME,".");
DECLARE
  SQL,
  DIM_XREF_NATURAL_KEY,
  TABLE_NAMES_TO_CHECK,
  PRIORITY_COLS_CATEGORY,
  PRIORITY_COLS_BRAND,
  PRIORITY_COLS_RESOLVED_PRD_NAME,
  PRIORITY_COLS_MANUFACTURER,
  CUSTOMER_SPECIFIC_SELECT,
  CUSTOMER_SPECIFIC_JOIN,
  LKP_CUSTOMER_COLS,
  NIELSEN_COLS,
  PRODUCT_DIM_COLS,
  MANUFACTURER_COALESCE,
  MANUFACTURER_COMMON,
  BPH_PREFIX STRING;
--All customer names which are from EUAU segment are added to this variable.
--If any new customer needs to be added for EUAU then we should update it in this variable here and structure for product and Nielsen temp tables should follow the COLES customer.
DECLARE EUAU_CUSTOMERS ARRAY<STRING>;

SET CUSTOMER_NAME = UPPER(CUSTOMER_NAME);

SET FEED_NAME = UPPER(FEED_NAME);

SET EUAU_CUSTOMERS = ['OCADO','ASDA','TESCO','SAINSBURY','COLES','WOOLWORTHS'];
--Priority columns for deriving resolved_category
SET
  PRIORITY_COLS_CATEGORY = "override_global_category,cat_global_category,sls_hier_sub_category_desc,gph_hier_category_desc,gmi_category_desc,gmi_sub_category_desc,source_category";
--Priority columns for deriving resolved_brand
SET
  PRIORITY_COLS_BRAND = "override_xref_brand,brand_xref_brand,gmi_brand_desc,gmi_global_brand_desc,nielsen_product_brand_derived_desc";
--Priority columns for deriving resolved_product_name
SET
  PRIORITY_COLS_RESOLVED_PRD_NAME = "bview_brand_view_product_name,nielsen_product_long_desc,base_product_desc,source_item_name";
--Priority columns for deriving manufacturer
SET
  PRIORITY_COLS_MANUFACTURER = "override_xref_manufacturer,brand_xref_manufacturer,manufacturer,bview_manufacturer,nielsen_product_manufacturer_derived_desc";
--Table names to verify column existence.
SET
  TABLE_NAMES_TO_CHECK = CONCAT(BQ_CONSOLIDATE_PRODUCT_TABLENAME,",",BQ_CONSOLIDATE_XREF_TABLENAME);
-- Columns from lkp_customer table
SET LKP_CUSTOMER_COLS = ",src.segment,src.customer_share_flag,src.report_fg,src.customer_sales_flag,src.country,src.channel,src.ad_security_role,src.customer_desc,src.customer_parent,src.notes,src.currency_code,src.currency_symbol,";
-- Columns from Nielsen connect product dim
SET NIELSEN_COLS = "src.nielsen_country_cd,src.nielsen_source_database_cd,src.nielsen_product_key,src.gmi_category_desc,src.gmi_sub_category_desc,src.gmi_segment_desc,src.gmi_brand_desc,src.gmi_global_brand_desc,src.gmi_product_desc,src.gmi_manufacturer_desc,src.gmi_global_manufacturer_desc,src.brand_high_desc,src.brand_low_desc,src.gmi_megacategory_desc,src.nielsen_ean_upc_derived_cd,";
-- Columns from Product_na
SET PRODUCT_DIM_COLS = "src.xref_upc_sk,src.ean_upc_cd,src.base_product_ean_upc_derived_cd,src.base_product_cd,src.base_product_desc,src.material_cd,src.material_short_desc,src.material_nbr,src.sls_hier_division_desc,src.sls_hier_category_desc,src.sls_hier_sub_category_desc,src.sls_hier_accrual_group_desc,src.sls_hier_sub_accrual_desc,src.sls_hier_ppg_desc,src.gph_hier_top_desc,src.gph_hier_family_desc,src.gph_hier_category_desc,src.gph_hier_flavor_format_desc,src.gph_hier_package_size_desc,src.base_uom_to_eqc_fctr,src.base_uom_to_ecv_fctr,src.all_cd,src.all_desc,src.sls_hier_sub_category_desc_ly,src.sls_hier_division_desc_ly,src.sls_hier_category_desc_ly,src.bph1_hier_bph20_desc,src.bph1_hier_bph30_desc,src.bph1_hier_bph40_desc,src.bph1_hier_bph50_desc,src.bph1_hier_bph60_desc,src.bph1_hier_bph70_desc,src.material_type_cd,src.sls_hier_division_cd,src.sls_hier_category_cd,src.sls_hier_sub_category_cd,src.sls_hier_accrual_group_cd,src.sls_hier_ppg_cd,src.gph_hier_top_cd,src.gph_hier_family_cd,src.gph_hier_category_cd,src.gph_hier_flavor_format_cd,src.gph_hier_package_size_cd,src.ean_upc_derived_cd,src.hier_cd,src.language_cd,src.version_cd,src.hier_level_cd,src.divested_fg,src.is_gmi_flag";
--Default is set to bph1.
SET BPH_PREFIX = "bph1";
SET
  CUSTOMER_SPECIFIC_SELECT="";
SET
  CUSTOMER_SPECIFIC_JOIN="";
--Calling stored proc which will take inputs as tables list and columns list and will 
--return columns in the given order which exists in the table.
--Priority columns for deriving resolved_category
CALL
  transient.ecomm_sproc_verify_presence_of_columns(TABLE_NAMES_TO_CHECK,
    PRIORITY_COLS_CATEGORY,
    BQ_PROJECT_NAME,
    BQ_TRANSIENT_DATASET_NAME,
    PRIORITY_COLS_CATEGORY);
--Priority columns for deriving resolved_brand
CALL
  transient.ecomm_sproc_verify_presence_of_columns(TABLE_NAMES_TO_CHECK,
    PRIORITY_COLS_BRAND,
    BQ_PROJECT_NAME,
    BQ_TRANSIENT_DATASET_NAME,
    PRIORITY_COLS_BRAND);
--Priority columns for deriving resolved_product_name
CALL
  transient.ecomm_sproc_verify_presence_of_columns(TABLE_NAMES_TO_CHECK,
    PRIORITY_COLS_RESOLVED_PRD_NAME,
    BQ_PROJECT_NAME,
    BQ_TRANSIENT_DATASET_NAME,
    PRIORITY_COLS_RESOLVED_PRD_NAME);
--Priority columns for deriving manufacturer
CALL
  transient.ecomm_sproc_verify_presence_of_columns(TABLE_NAMES_TO_CHECK,
    PRIORITY_COLS_MANUFACTURER,
    BQ_PROJECT_NAME,
    BQ_TRANSIENT_DATASET_NAME,
    PRIORITY_COLS_MANUFACTURER);
-- Truncate derived xref info temp TABLE
EXECUTE IMMEDIATE
  CONCAT("""TRUNCATE TABLE """,ECOMM_DLF_TRANSIENT_DS,BQ_DERIVED_XREF_INFO_TABLENAME);
-- Get the dim_xref_natural_key from gmi_customer_metadata_reference
EXECUTE IMMEDIATE
  CONCAT("SELECT dim_xref_natural_key from ",ECOMM_DLF_TRANSIENT_DS,"gmi_customer_metadata_reference where feed_name = upper('",FEED_NAME,"')") INTO DIM_XREF_NATURAL_KEY;
-- This is the area to add customer specific logic if required. 2 variables wll be used to add the logic.
-- customer_specific_select -> add the select clause for a customer.
-- customer_specific_join -> add the join condition with proper aliases of the tables used in join conditions.
SET MANUFACTURER_COALESCE = CONCAT("""coalesce(CASE
        WHEN src.is_gmi_flag = 'Y' THEN 'General Mills'
    END
      , """,PRIORITY_COLS_MANUFACTURER,""",""",PRIORITY_COLS_BRAND,""",'')""");
SET MANUFACTURER_COMMON = CONCAT("""CASE
    WHEN UPPER(""",MANUFACTURER_COALESCE,""") LIKE ('%GENERAL MILL%') THEN 'General Mills'
    WHEN """,MANUFACTURER_COALESCE,""" = '' THEN 'Competitor'
  ELSE """,
  MANUFACTURER_COALESCE,"""
END
  AS manufacturer,""");
IF
  UPPER(customer_name) = "SHIPT" THEN
-- customer_account attribute logic.
SET
  CUSTOMER_SPECIFIC_SELECT=CONCAT("""
  CASE
    WHEN src.retailer IS NOT NULL THEN UPPER(CONCAT(src.customer_name,' - ',src.retailer))
  ELSE
  src.customer_name
END
  AS customer_account,""",MANUFACTURER_COMMON);

ELSEIF UPPER(customer_name) = "INSTACART" THEN
-- customer_account attribute logic.
SET
  CUSTOMER_SPECIFIC_SELECT=CONCAT("""
  CASE
    WHEN insta_club.club_account IS NOT NULL THEN UPPER(CONCAT('INSTACART',' - ',insta_club.club_account))
  ELSE
  'INSTACART'
END
  AS customer_account,""",MANUFACTURER_COMMON);
-- customer_account attribute logic.
SET
  CUSTOMER_SPECIFIC_JOIN=CONCAT("""
LEFT OUTER JOIN """,
  ECOMM_DLF_PROCESSED_DS,"""lkp_instacart_club_products AS insta_club
ON
  insta_club.ean_upc_cd = src.ean_upc_cd""");

ELSEIF UPPER(customer_name) = "AMAZON_COM"
  OR UPPER(customer_name) = "AMAZON_PANTRY" THEN
-- customer_account, manufacturer attributes logic.
SET
  CUSTOMER_SPECIFIC_SELECT=CONCAT("""
  src.customer_account AS customer_account,
  CASE
    WHEN UPPER(src.manufacturer) = '3P GMI SALES' THEN '3P GMI Sales'
    WHEN UPPER(""",MANUFACTURER_COALESCE,""") LIKE ('%GENERAL MILL%')
  AND src.is_3p = 'N' THEN 'General Mills'
    WHEN UPPER(""",MANUFACTURER_COALESCE,""") LIKE ('%GENERAL MILL%')
  AND src.is_3p = 'Y' THEN '3P GMI Sales - Brand'
    WHEN """,MANUFACTURER_COALESCE,""" = '' THEN 'Competitor'
  ELSE """,
  MANUFACTURER_COALESCE,"""
END
  AS manufacturer,""");
--for EUAU customers
ELSEIF UPPER(customer_name) IN UNNEST(EUAU_CUSTOMERS) THEN
-- Nielsen and product_dim columns different for COLES and WOOLWORTHS compared to NAR retailers.
SET NIELSEN_COLS = "src.nielsen_upc_derived_cd,src.nielsen_source_database_cd,src.nielsen_product_long_desc,src.nielsen_product_brand_derived_desc,src.nielsen_product_sub_brand_desc,src.nielsen_product_manufacturer_derived_desc,src.nielsen_product_category_derived_desc,src.nielsen_product_category_view_desc,src.nielsen_general_mills_product_fg,src.nielsen_product_segment_derived_desc,src.nielsen_product_sub_segment_derived_desc,src.nielsen_product_sector_desc,";
SET PRODUCT_DIM_COLS = "src.material_cd,src.material_short_desc,src.base_product_desc,src.gph_hier_top_cd,src.gph_hier_top_desc,src.gph_hier_family_cd,src.gph_hier_family_desc,src.gph_hier_category_cd,src.gph_hier_category_desc,src.gph_hier_flavor_format_cd,src.gph_hier_flavor_format_desc,src.gph_hier_package_size_cd,src.gph_hier_package_size_desc,src.ean_upc_cd,src.upc,src.old_system_material_nbr,src.bph4_hier_bph20_desc,src.bph4_hier_bph30_desc,src.bph4_hier_bph40_desc,src.bph4_hier_bph50_desc,src.bph4_hier_bph60_desc,src.bph4_hier_bph70_desc,src.material_number,src.ean_10,src.base_uom_to_eqc_fctr,src.is_gmi_flag,src.divested_fg";
--Set to bph4 for coles and woolworths.
SET BPH_PREFIX = "bph4";
-- customer_account, manufacturer attributes logic.
SET
  CUSTOMER_SPECIFIC_SELECT=CONCAT("""
  src.customer_account AS customer_account,""",MANUFACTURER_COMMON);

ELSE
-- customer_account, manufacturer attributes logic.
SET
  CUSTOMER_SPECIFIC_SELECT=CONCAT("""
  src.customer_account AS customer_account,""",MANUFACTURER_COMMON);
END IF
  ;
-- Generate a dynamic sql which will bring product dimension attributes, derive few attributes based on
-- Xrefs and dimension attributes.
SET
  SQL = CONCAT( """INSERT INTO """, ECOMM_DLF_TRANSIENT_DS,BQ_DERIVED_XREF_INFO_TABLENAME, """
  WITH
    all_xrefs AS (
    SELECT
      xrefs.* EXCEPT(""",DIM_XREF_NATURAL_KEY,""")
    FROM
      """,ECOMM_DLF_TRANSIENT_DS,BQ_CONSOLIDATE_XREF_TABLENAME,""" xrefs )
  SELECT
    src.source_product_hash, src.rctl_uuid, """,DIM_XREF_NATURAL_KEY,LKP_CUSTOMER_COLS,
  NIELSEN_COLS,
  PRODUCT_DIM_COLS,""",
  coalesce(""",PRIORITY_COLS_CATEGORY,""") AS resolved_category,
  coalesce(""",PRIORITY_COLS_BRAND,""") AS resolved_brand,
  coalesce(""",PRIORITY_COLS_RESOLVED_PRD_NAME,""") AS resolved_product_name,
  coalesce( xrefs.override_xref_brand, xrefs.brand_xref_brand ) AS xref_brand,
  coalesce( xrefs.override_xref_sub_brand, xrefs.brand_xref_sub_brand ) AS xref_sub_brand,
  LEAST( src.customer_share_flag,coalesce( xrefs.override_share_category_relevancy_flag,
    CAST(xrefs.cat_share_category_relevancy_flag AS string),
    'N' ) ) AS share_category_relevancy_flag,
  coalesce( xrefs.override_bph20_desc, src.""",BPH_PREFIX,"""_hier_bph20_desc ) AS bph20_desc,
  coalesce( xrefs.override_bph30_desc, src.""",BPH_PREFIX,"""_hier_bph30_desc ) AS bph30_desc,
  coalesce( xrefs.override_bph40_desc, src.""",BPH_PREFIX,"""_hier_bph40_desc ) AS bph40_desc,
  coalesce( xrefs.override_bph50_desc, src.""",BPH_PREFIX,"""_hier_bph50_desc ) AS bph50_desc,
  coalesce( xrefs.override_bph60_desc, src.""",BPH_PREFIX,"""_hier_bph60_desc ) AS bph60_desc,
  coalesce( xrefs.override_bph70_desc, src.""",BPH_PREFIX,"""_hier_bph70_desc ) AS bph70_desc,
  coalesce( xrefs.override_global_category, xrefs.cat_global_category ) AS global_category,
  coalesce( xrefs.override_global_sub_category, xrefs.cat_global_sub_category ) AS global_sub_category,
  xrefs.cat_global_category_parent AS global_category_parent,
   """,CUSTOMER_SPECIFIC_SELECT,"""
  CAST(""",JOB_RUN_ID,""" AS string) AS created_by,
  CURRENT_DATETIME AS created_datetime,
  CAST(""",JOB_RUN_ID,""" AS string) AS modified_by,
  CURRENT_DATETIME AS modified_datetime
  FROM
    """, ECOMM_DLF_TRANSIENT_DS,BQ_CONSOLIDATE_PRODUCT_TABLENAME,""" src
  LEFT OUTER JOIN
    all_xrefs xrefs
  ON
    (src.source_product_hash = xrefs.source_product_hash)
   """, CUSTOMER_SPECIFIC_JOIN);

Select SQL;

EXECUTE IMMEDIATE
  SQL;
EXCEPTION WHEN ERROR THEN
        EXECUTE IMMEDIATE CONCAT(
            """INSERT INTO processed.sproc_error_details (
		        SELECT
			        '""",FEED_NAME,"""' AS FEED_NAME,
                    split(split(@@error.formatted_stack_trace,'transient.')[OFFSET (1)],'[')[OFFSET(0)],
			        @@error.statement_text,
			        @@error.message,
			        current_timestamp()
	        );
	    """);

	    SELECT
	        ERROR (
	            CONCAT(
	            		@@error.message ,' ' ,
	            		@@error.statement_text, ' ' ,
	            		@@error.formatted_stack_trace ,' '
	            	)
	        );
END;