/*
Purpose of the stored proc: 
	    Load data into processed dataset
History of Changes:
	14/05 – first version
	05/10 - Updated composer related params and added sproc error mechanism
Author : 
	Pawan Rathod
*/

CREATE OR REPLACE PROCEDURE transient.ecomm_sproc_build_processed_table
(
	SRC_PROJECT string,
	INTERMEDIATE_DATASET string,
	DEST_DATASET string,
	SRC_TABLE string,
	DEST_TABLE string,
	ARCHIVE_TABLE string,
	ARCHIVE_FLAG string,
	FEED_NAME string
)
OPTIONS(
description = """

 How to call:

     CALL transient.ecomm_sproc_build_processed_table
	    (
	    	'ecomm-dlf-dev-01cd47', -- SRC_PROJECT
	    	'ecomm-dlf-dev-01cd47', -- INTERMEDIATE_DATASET
	    	'profitero_249', -- DEST_DATASET
	    	'transient', -- SRC_TABLE
	    	'processed', -- DEST_TABLE
	    	'brands', -- DEST_DATASET
	    	'profitero_249_brands', -- SRC_TABLE
	    	'profitero_249_brands', -- DEST_TABLE
	    	'profitero_249_brands', -- CUSTOMER_NAME
	    )

"""
)
BEGIN

-- declare variables

DECLARE JOB_RUN_ID DEFAULT 999999;
DECLARE BQ_PROJECT_NAME DEFAULT SRC_PROJECT;
DECLARE BQ_TRANSIENT_DATASET_NAME DEFAULT INTERMEDIATE_DATASET;
DECLARE BQ_PROCESSED_DATASET_NAME DEFAULT DEST_DATASET;
DECLARE BQ_SOURCE_TABLE DEFAULT SRC_TABLE;
DECLARE BQ_TARGET_TABLE DEFAULT DEST_TABLE;
DECLARE BQ_ARCHIVE_TABLE DEFAULT ARCHIVE_TABLE;


DECLARE REC_COUNT INT64;
DECLARE JOIN_CONDITION, EXCEPT_COLUMN_LIST STRING;

SET FEED_NAME = UPPER(FEED_NAME);

/* A few columns need not be fetched from Delta temp table, these will come in EXCEPT_COLUMN_LIST variable */
SET EXCEPT_COLUMN_LIST = 'file_dt, ingest_date , rctl_file_name, created_by , created_datetime , modified_by, modified_datetime'  ;
	
/* Generalising join condition:
	Fetching the Natural keys combination from Metadata Lookup table to create customer specific join condition statement,
	filtered on passed FEED_NAME */

Execute Immediate
concat("""WITH
  join_condn AS (
  SELECT
    element
  FROM
    UNNEST((
      SELECT
        SPLIT(vendor_file_natural_key,',') sk
      FROM
        `""",BQ_PROJECT_NAME,"""`.""",BQ_TRANSIENT_DATASET_NAME,""".gmi_customer_metadata_reference
      WHERE
        FEED_NAME ='""",FEED_NAME,"""')) AS element)
        select 
		rtrim(string_agg ('coalesce(cast(src.' || element || ' as string),"") = coalesce(cast(tgt.' || element || ' as string), "") and ',' '),' and ' ) 
		from join_condn
""") into JOIN_CONDITION;


--Check if Delta temp table has new records
Execute Immediate
concat("""select count(*) from 
 `""",BQ_PROJECT_NAME,"""`.""",BQ_TRANSIENT_DATASET_NAME,""".""",BQ_SOURCE_TABLE,""" src
join """,BQ_PROCESSED_DATASET_NAME,""".""",BQ_TARGET_TABLE, """ tgt
	on """,JOIN_CONDITION) into REC_COUNT;
	

 
	/* if matching records found  and Archive Flag is set to 'Y'
	then Archive the matching records 
		1.Copy the records to Archive table 
		2.Delete Records from Source fact table
	Else just Delete Records from Source Table, not Archive data. */

if REC_COUNT <> 0 then
	if upper(ARCHIVE_FLAG) = 'Y' then
		execute immediate
		concat("""Insert into `""",BQ_PROJECT_NAME,"""`.""",BQ_PROCESSED_DATASET_NAME,""".""",BQ_ARCHIVE_TABLE, """
		select tgt.* except(
			created_by 
			, created_datetime 
			, modified_by 
			, modified_datetime )
			,'""",JOB_RUN_ID,"""' as created_by
			, current_datetime as created_datetime
			,'""",JOB_RUN_ID,"""' as modified_by
			,current_datetime as modified_datetime 
			from `""",BQ_PROJECT_NAME,"""`.""",BQ_TRANSIENT_DATASET_NAME,""".""",BQ_SOURCE_TABLE,""" src
		join """,BQ_PROCESSED_DATASET_NAME,""".""",BQ_TARGET_TABLE,""" tgt
			on """,JOIN_CONDITION);
	end if;
	
--Delete already existing matching records from source table
Execute immediate
concat(""" delete from `""",BQ_PROJECT_NAME,"""`.""",BQ_PROCESSED_DATASET_NAME,""".""",BQ_TARGET_TABLE,"""  tgt
where exists
(
	Select src.*
	from `""",BQ_PROJECT_NAME,"""`.""",BQ_TRANSIENT_DATASET_NAME,""".""",BQ_SOURCE_TABLE,""" src
	where """,JOIN_CONDITION,"""
) 
""");
	 
end if;

execute immediate concat("""Insert into `""",BQ_PROJECT_NAME,"""`.""",BQ_PROCESSED_DATASET_NAME,""".""",BQ_TARGET_TABLE,"""
select 
	src.* except
	( """, 
        EXCEPT_COLUMN_LIST,
	 """ 
 	)
	,'""",JOB_RUN_ID,"""' as created_by
	,current_datetime as created_datetime
	,'""",JOB_RUN_ID,"""' as modified_by
	,current_datetime as modified_datetime
	from  `""",BQ_PROJECT_NAME,"""`.""",BQ_TRANSIENT_DATASET_NAME,""".""",BQ_SOURCE_TABLE,""" src""")   ;



EXCEPTION WHEN ERROR THEN
        EXECUTE IMMEDIATE CONCAT(
            """INSERT INTO processed.sproc_error_details (
		        SELECT
			        '""",FEED_NAME,"""' AS FEED_NAME,
                    split(split(@@error.formatted_stack_trace,'transient.')[OFFSET (1)],'[')[OFFSET(0)],
			        @@error.statement_text,
			        @@error.message,
			        current_timestamp()
	        );
	    """);

	    SELECT
	        ERROR (
	            CONCAT(
	            		@@error.message ,' ' ,
	            		@@error.statement_text, ' ' ,
	            		@@error.formatted_stack_trace ,' '
	            	)
	        );
 
End