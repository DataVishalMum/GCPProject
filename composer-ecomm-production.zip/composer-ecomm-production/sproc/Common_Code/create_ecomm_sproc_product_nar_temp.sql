  /* 
  Purpose OF the stored proc : 
	Enrich the source data with product columns
  History OF Changes : 
        03/24 first version
        04/05 changed to the source to UPC XREF
        04/06 Added 11 columns which will bepopulatd till processed-1 and dropped in processed-2
        07/07 - Enterprise dimension changes
        05/10 - Updated composer related params and added sproc error mechanism

  Author : 
		Pawan Rathod
  */
  
CREATE OR REPLACE PROCEDURE
  transient.ecomm_sproc_product_nar_temp(
    SRC_PROJECT STRING,
    DEST_DATASET STRING,
    XREF_DATASET STRING,
    SRC_LOOKUP_PROJECT STRING,
    SRC_LOOKUP_DATASET STRING,
    CUSTOMER_NAME STRING,
    DEST_TABLE STRING,
    FEED_NAME STRING
)
OPTIONS(
description = """

 How to call:

     CALL transient.ecomm_sproc_product_nar_temp (
        "ecomm-dlf-dev-01cd47", -- SRC_PROJECT
        "transient", -- DEST_DATASET
        "processed", -- XREF_DATASET
        "edw-qa-c89f9d", -- SRC_LOOKUP_PROJECT
        "enterprise", -- SRC_LOOKUP_DATASET
        "AMAZON_COM", -- CUSTOMER_NAME
        "amazon_com_product_temp", -- DEST_TABLE
        "AMAZON_COM" -- FEED_NAME
	)

"""
)
BEGIN

DECLARE JOB_RUN_ID DEFAULT 999999;
DECLARE BQ_PROJECT_NAME DEFAULT SRC_PROJECT;
DECLARE BQ_TRANSIENT_DATASET_NAME DEFAULT DEST_DATASET;
DECLARE BQ_PROCESSED_DATASET_NAME DEFAULT XREF_DATASET;
DECLARE BQ_EDW_PROJECT_NAME DEFAULT SRC_LOOKUP_PROJECT;
DECLARE BQ_ENTERPRISE_DATASET_NAME DEFAULT SRC_LOOKUP_DATASET;
DECLARE PRODUCT_TABLE_NAME DEFAULT DEST_TABLE;

DECLARE
  STR_TO_EXEC STRING;

SET CUSTOMER_NAME = UPPER(CUSTOMER_NAME);
SET FEED_NAME = UPPER(FEED_NAME);

  -- truncate data from the target table
EXECUTE IMMEDIATE
  CONCAT("""
  TRUNCATE TABLE
    `""",BQ_PROJECT_NAME,""".""",BQ_TRANSIENT_DATASET_NAME,""".""",PRODUCT_TABLE_NAME,"""`""");

-- Query to enrich product data. We are utilizing the UPC XREF dimension to get the target UPC in product table to map it to source UPC.
SET
  STR_TO_EXEC = CONCAT("""
  INSERT INTO
    `""",BQ_PROJECT_NAME,""".""",BQ_TRANSIENT_DATASET_NAME,""".""",PRODUCT_TABLE_NAME,"""` (upc,
      xref_upc_sk,
      ean_upc_cd,
      base_product_ean_upc_derived_cd,
      base_product_cd,
      base_product_desc,
      material_cd,
      material_short_desc,
      material_nbr,
      sls_hier_division_desc,
      sls_hier_category_desc,
      sls_hier_sub_category_desc,
      sls_hier_accrual_group_desc,
      sls_hier_sub_accrual_desc,
      sls_hier_ppg_desc,
      gph_hier_top_desc,
      gph_hier_family_desc,
      gph_hier_category_desc,
      gph_hier_flavor_format_desc,
      gph_hier_package_size_desc,
      base_uom_to_eqc_fctr,
      base_uom_to_ecv_fctr,
      all_cd,
      all_desc,
      sls_hier_sub_category_desc_ly,
      sls_hier_division_desc_ly,
      sls_hier_category_desc_ly,
      bph1_hier_bph20_desc,
      bph1_hier_bph30_desc,
      bph1_hier_bph40_desc,
      bph1_hier_bph50_desc,
      bph1_hier_bph60_desc,
      bph1_hier_bph70_desc,
      material_type_cd,
      sls_hier_division_cd,
      sls_hier_category_cd,
      sls_hier_sub_category_cd,
      sls_hier_accrual_group_cd,
      sls_hier_ppg_cd,
      gph_hier_top_cd,
      gph_hier_family_cd,
      gph_hier_category_cd,
      gph_hier_flavor_format_cd,
      gph_hier_package_size_cd,
      ean_upc_derived_cd,
      hier_cd,
      language_cd,
      version_cd,
      hier_level_cd,
      divested_fg,
      is_gmi_flag,
      created_by,
      created_datetime,
      modified_by,
      modified_datetime)
  WITH
    src_xref AS (
    SELECT
      xref_upc.customer_upc upc,
      xref_upc.target_upc,
      coalesce(xref_upc.xref_upc_sk,
        -1) xref_upc_sk
    FROM
      `""",BQ_PROJECT_NAME,""".""",BQ_PROCESSED_DATASET_NAME,""".dim_source_to_enterprise_upc_xref` xref_upc
	WHERE
	      xref_upc.customer_name = '""",CUSTOMER_NAME,"""'
      AND xref_upc.current_flg = 'Y'
      AND xref_upc.target_upc IS NOT NULL
      AND xref_upc.priority != -1
      AND xref_upc.xref_upc_sk <> -9999), src_prd AS (
    SELECT
      b.*
    FROM (
      SELECT
        a.*,
        ROW_NUMBER() OVER (PARTITION BY upc ORDER BY rnk) best
      FROM (
        SELECT
          src_xref.upc,
          src_xref.target_upc,
          src_xref.xref_upc_sk,
          prd.ean_upc_cd,
          prd.base_product_ean_upc_derived_cd,
          prd.base_product_cd,
          prd.base_product_desc,
          prd.material_cd,
          prd.material_short_desc,
          prd.material_nbr,
          prd.sls_hier_division_desc,
          prd.sls_hier_category_desc,
          prd.sls_hier_sub_category_desc,
          prd.sls_hier_accrual_group_desc,
          prd.sls_hier_sub_accrual_desc,
          prd.sls_hier_ppg_desc,
          prd.gph_hier_top_desc,
          prd.gph_hier_family_desc,
          prd.gph_hier_category_desc,
          prd.gph_hier_flavor_format_desc,
          prd.gph_hier_package_size_desc,
          CAST(prd.base_uom_to_eqc_fctr AS NUMERIC) as base_uom_to_eqc_fctr,
          CAST(prd.base_uom_to_ecv_fctr AS NUMERIC) as base_uom_to_ecv_fctr,
          prd.gph_hier_family_cd,
          prd.bph1_hier_bph20_desc,
          prd.bph1_hier_bph30_desc,
          prd.bph1_hier_bph40_desc,
          prd.bph1_hier_bph50_desc,
          prd.bph1_hier_bph60_desc,
          prd.bph1_hier_bph70_desc,
          prd.consumer_brand_desc,
          prd.material_type_cd,
          prd.sls_hier_division_cd,
          prd.sls_hier_category_cd,
          prd.sls_hier_sub_category_cd,
          prd.sls_hier_accrual_group_cd,
          prd.sls_hier_ppg_cd,
          prd.gph_hier_top_cd,
          prd.gph_hier_category_cd,
          prd.gph_hier_flavor_format_cd,
          prd.gph_hier_package_size_cd,
          prd.ean_upc_derived_cd,
          CASE
            WHEN ean_upc_cd IS NULL THEN 3
          ELSE
          1
        END
          AS rnk
        FROM
          src_xref
        LEFT OUTER JOIN
          `""",BQ_EDW_PROJECT_NAME,""".""",BQ_ENTERPRISE_DATASET_NAME,""".dim_product_active` prd
        ON
          prd.source_type_cd = 'NA'
          AND prd.ean_upc_cd = src_xref.target_upc
          AND prd.material_type_cd = 'CNPK'
          AND prd.language_cd = 'EN'
        UNION ALL
        SELECT
          src_xref.upc,
          src_xref.target_upc,
          src_xref.xref_upc_sk,
          prd.ean_upc_cd,
          prd.base_product_ean_upc_derived_cd,
          prd.base_product_cd,
          prd.base_product_desc,
          prd.material_cd,
          prd.material_short_desc,
          prd.material_nbr,
          prd.sls_hier_division_desc,
          prd.sls_hier_category_desc,
          prd.sls_hier_sub_category_desc,
          prd.sls_hier_accrual_group_desc,
          prd.sls_hier_sub_accrual_desc,
          prd.sls_hier_ppg_desc,
          prd.gph_hier_top_desc,
          prd.gph_hier_family_desc,
          prd.gph_hier_category_desc,
          prd.gph_hier_flavor_format_desc,
          prd.gph_hier_package_size_desc,
          CAST(prd.base_uom_to_eqc_fctr AS NUMERIC) as base_uom_to_eqc_fctr,
          CAST(prd.base_uom_to_ecv_fctr AS NUMERIC) as base_uom_to_ecv_fctr,
          prd.gph_hier_family_cd,
          prd.bph1_hier_bph20_desc,
          prd.bph1_hier_bph30_desc,
          prd.bph1_hier_bph40_desc,
          prd.bph1_hier_bph50_desc,
          prd.bph1_hier_bph60_desc,
          prd.bph1_hier_bph70_desc,
          prd.consumer_brand_desc,
          prd.material_type_cd,
          prd.sls_hier_division_cd,
          prd.sls_hier_category_cd,
          prd.sls_hier_sub_category_cd,
          prd.sls_hier_accrual_group_cd,
          prd.sls_hier_ppg_cd,
          prd.gph_hier_top_cd,
          prd.gph_hier_category_cd,
          prd.gph_hier_flavor_format_cd,
          prd.gph_hier_package_size_cd,
          prd.ean_upc_derived_cd,
          2 rnk
        FROM
          src_xref
        INNER JOIN
          `""",BQ_EDW_PROJECT_NAME,""".""",BQ_ENTERPRISE_DATASET_NAME,""".dim_product_active` prd
        ON
          prd.source_type_cd = 'NA'
          AND prd.base_product_ean_upc_derived_cd = src_xref.target_upc
          AND prd.material_type_cd = 'CNPK'
          AND prd.language_cd = 'EN')a ) b
    WHERE
      b.best = 1)
  SELECT
  p.upc,
  p.xref_upc_sk,
  p.ean_upc_cd,
  p.base_product_ean_upc_derived_cd,
  p.base_product_cd,
  p.base_product_desc,
  p.material_cd,
  p.material_short_desc,
  p.material_nbr,
  p.sls_hier_division_desc,
  p.sls_hier_category_desc,
  p.sls_hier_sub_category_desc,
  p.sls_hier_accrual_group_desc,
  p.sls_hier_sub_accrual_desc,
  p.sls_hier_ppg_desc,
  p.gph_hier_top_desc,
  p.gph_hier_family_desc,
  p.gph_hier_category_desc,
  p.gph_hier_flavor_format_desc,
  p.gph_hier_package_size_desc,
  CAST(p.base_uom_to_eqc_fctr AS NUMERIC) as base_uom_to_eqc_fctr,
  CAST(p.base_uom_to_ecv_fctr AS NUMERIC) as base_uom_to_ecv_fctr,
  v1.all_cd,
  v1.all_desc,
  v2.sls_hier_sub_category_desc_ly,
  v2.sls_hier_division_desc_ly,
  v2.sls_hier_category_desc_ly,
  p.bph1_hier_bph20_desc,
  p.bph1_hier_bph30_desc,
  p.bph1_hier_bph40_desc,
  p.bph1_hier_bph50_desc,
  p.bph1_hier_bph60_desc,
  p.bph1_hier_bph70_desc,
  p.material_type_cd,
  p.sls_hier_division_cd,
  p.sls_hier_category_cd,
  p.sls_hier_sub_category_cd,
  p.sls_hier_accrual_group_cd,
  p.sls_hier_ppg_cd,
  p.gph_hier_top_cd,
  p.gph_hier_family_cd,
  p.gph_hier_category_cd,
  p.gph_hier_flavor_format_cd,
  p.gph_hier_package_size_cd,
  p.ean_upc_derived_cd,
  COALESCE(v1.hier_cd,
    v2.hier_cd) AS hier_cd,
  COALESCE(v1.language_cd,
    v2.language_cd) AS language_cd,
  COALESCE(v1.version_cd,
    v2.version_cd) AS version_cd,
  COALESCE(v1.hier_level_cd,
    v2.hier_level_cd) AS hier_level_cd,
  CASE
    WHEN p.gph_hier_family_cd = '2200004' THEN 'Y'
  ELSE
  'N'
END
  AS divested_fg,
CASE
  WHEN p.base_product_cd IS NULL OR 
p.gph_hier_family_cd in ('2200004') OR 
p.gph_hier_family_cd in ('2281000') THEN ''
ELSE
'Y'
END
  AS is_gmi_flag,
  '""",JOB_RUN_ID,"""' created_by,
  current_datetime() created_datetime,
  '""",JOB_RUN_ID,"""' modified_by,
  current_datetime() modified_datetime
FROM
  src_prd p
  LEFT JOIN (
    SELECT
      all_cd,
      all_desc,
      base_product_cd,
      hier_cd,
      language_cd,
      version_cd,
      hier_level_cd
    FROM
       `""",BQ_EDW_PROJECT_NAME,""".""",BQ_ENTERPRISE_DATASET_NAME,""".dim_product_sls_hier_horiz_active`
    WHERE
      hier_level_cd = 'BASE'
      AND language_cd = 'EN'
      AND version_cd = 0)v1
  ON
    p.base_product_cd = v1.base_product_cd
  LEFT OUTER JOIN (
    SELECT
      sls_hier_sub_category_desc,
      hier_cd,
      language_cd,
      version_cd,
      hier_level_cd AS sls_hier_sub_category_desc_ly,
      sls_hier_division_desc AS sls_hier_division_desc_ly,
      sls_hier_category_desc AS sls_hier_category_desc_ly,
      base_product_cd,
      hier_level_cd
    FROM
      `""",BQ_EDW_PROJECT_NAME,""".""",BQ_ENTERPRISE_DATASET_NAME,""".dim_product_sls_hier_horiz_active`
    WHERE
      hier_level_cd = 'BASE'
      AND language_cd = 'EN'
      AND version_cd = 2)v2
  ON
    p.base_product_cd = v2.base_product_cd""");
EXECUTE IMMEDIATE
  STR_TO_EXEC;

EXCEPTION WHEN ERROR THEN
        EXECUTE IMMEDIATE CONCAT(
            """INSERT INTO processed.ecomm_admin_sproc_error_details (
		        SELECT
			        '""",FEED_NAME,"""' AS FEED_NAME,
                    split(split(@@error.formatted_stack_trace,'transient.')[OFFSET (1)],'[')[OFFSET(0)],
			        @@error.statement_text,
			        @@error.message,
			        current_timestamp()
	        );
	    """);

	    SELECT
	        ERROR (
	            CONCAT(
	            		@@error.message ,' ' ,
	            		@@error.statement_text, ' ' ,
	            		@@error.formatted_stack_trace ,' '
	            	)
	        );

END;