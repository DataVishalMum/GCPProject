/*
Purpose of the stored proc: 
	Consolidate attributes from Processed-0,XREF Derived attributes,Fiscal tables For EUAU Cutomers
History of Changes:
	04/05 – first version 
	04/14 - Created 2 seperate SPs & Changed SP name from 
			sp_customer_fact to sp_customer_fact_nar & sp_customer_fact_euau for repective customers
	04/26 - Removed ty_sales_value_usd & ty_sales_eqc_units calculation as this logic is getting handled in Processsd-2 proc
	05/07 - Removed join with currency exchange table as that is moved to process-2 step , dropped argument bq_raw_dataset_name
	05/20 - Added a new parameter 'FEED_NAME' in the call statement
	05/26 - Modified calculation logic for ty_sales_eqc_units
	06/07 - Check condition added to check column 'upc' coming from process-zero table
	07/07 - Enterprise dimension changes
	05/10 - Updated composer related params and added sproc error mechanism

Author : 
	Pawan Rathod

*/
CREATE OR REPLACE PROCEDURE transient.ecomm_sproc_customer_fact_euau
( 
	SRC_PROJECT STRING,
	SRC_LOOKUP_PROJECT STRING,
	SRC_DATASET STRING,
	SRC_LOOKUP_DATASET STRING,
	DEST_DATASET STRING,
	DEST_TABLE STRING,
	SRC_TABLE STRING,
	XREF_TABLE STRING,
	CUSTOMER_NAME STRING,
	FEED_NAME STRING
	
)
OPTIONS(
description = """

 How to call:

     CALL transient.ecomm_sproc_customer_fact_euau (
        "ecomm-dlf-dev-01cd47", -- SRC_PROJECT
        "edw-qa-c89f9d", -- SRC_LOOKUP_PROJECT
        "transient", -- SRC_DATASET
        "enterprise", -- SRC_LOOKUP_DATASET
        "processed", -- DEST_DATASET
        "coles_fact", -- DEST_TABLE
        "coles_processed_zero", -- SRC_TABLE
        "coles_derived_xref_info_temp", -- XREF_TABLE
        "COLES", -- CUSTOMER_NAME
        "COLES" -- FEED_NAME
      )
"""
)
BEGIN
-- declare variables

DECLARE JOB_RUN_ID DEFAULT 999999;
DECLARE BQ_PROJECT_NAME DEFAULT SRC_PROJECT;
DECLARE BQ_EDW_PROJECT_NAME DEFAULT SRC_LOOKUP_PROJECT;
DECLARE BQ_TRANSIENT_DATASET_NAME DEFAULT SRC_DATASET;
DECLARE BQ_ENTERPRISE_DATASET_NAME DEFAULT SRC_LOOKUP_DATASET;
DECLARE BQ_PROCESSED_DATASET_NAME DEFAULT DEST_DATASET;
DECLARE BQ_CUSTOMER_FACT_TABLE DEFAULT DEST_TABLE;
DECLARE BQ_PROCESSED_ZERO_TABLE DEFAULT SRC_TABLE;
DECLARE BQ_DERIVED_XREF_TABLE DEFAULT XREF_TABLE;

DECLARE 
	JOB_RUN_ID_STRING,
	NATURAL_KEYS,
	CHECK_UPC,
	FISCAL_DT,
	FISCAL_COLS,
	EXCEPT_COLUMN_LIST_1,
	EXCEPT_COLUMN_LIST_2 STRING; 

-- set variables
SET JOB_RUN_ID_STRING = cast(JOB_RUN_ID as STRING);

SET CUSTOMER_NAME = UPPER(CUSTOMER_NAME);

SET FEED_NAME = UPPER(FEED_NAME);



/* Conditional check for 'upc' column if present in processed-0 table or not (to avoid pulling duplicate columns from both the source tables */

EXECUTE IMMEDIATE
  CONCAT(
""" WITH
  dr AS (
  SELECT
    COUNT(*) cnt
  FROM
    """,BQ_TRANSIENT_DATASET_NAME,""".INFORMATION_SCHEMA.COLUMNS
  WHERE
    table_name = '""",BQ_PROCESSED_ZERO_TABLE,"""'
    AND column_name = 'upc')
SELECT
  CASE
    WHEN cnt <> 0 THEN 'upc,'
    else ''
END
FROM
  dr""") INTO CHECK_UPC;



/* A few columns need not be fetched from Source table, so that there are no duplicate columns fetched */
SET EXCEPT_COLUMN_LIST_1 = 'ty_sales_value,  ty_sales_units, source_product_hash, rctl_uuid, created_by, created_datetime, modified_by, modified_datetime'  ;
SET EXCEPT_COLUMN_LIST_2 = 'currency_code, currency_symbol, rctl_uuid, created_by, source_product_hash, created_datetime, modified_by, modified_datetime'  ;


/* Fetching the Natural Keys from gmi_customer_metadata_reference Table */
EXECUTE IMMEDIATE
  CONCAT(""" select  dim_xref_natural_key from `""",BQ_PROJECT_NAME,"""`.""",BQ_TRANSIENT_DATASET_NAME,""".gmi_customer_metadata_reference 
where FEED_NAME='""",FEED_NAME,"""' """) INTO NATURAL_KEYS;

-- Find the customer specific date column 
EXECUTE IMMEDIATE
  CONCAT("""
  SELECT
    vendor_file_fiscal_date
  FROM
    `""",BQ_PROJECT_NAME,"""`.""",BQ_TRANSIENT_DATASET_NAME,""".gmi_customer_metadata_reference
  WHERE
    FEED_NAME ='""",FEED_NAME,"""' """) INTO FISCAL_DT;

--Parameterising the Fiscal Table columns
SET FISCAL_COLS=
	CONCAT("""fiscal.fiscal_month_in_year_nbr, fiscal.fiscal_year_nbr, fiscal.fiscal_quarter_in_year_nbr, 
	fiscal.fiscal_week_in_year_nbr, fiscal.fiscal_month_in_year_short_desc
	,cast(fiscal.fiscal_week_begin_dt    as TIMESTAMP) fiscal_week_begin_dt
	,cast(fiscal.fiscal_week_end_dt      as TIMESTAMP) fiscal_week_end_dt
	,cast(fiscal.fiscal_month_begin_dt   as TIMESTAMP) fiscal_month_begin_dt
	,cast(fiscal.fiscal_month_end_dt     as TIMESTAMP) fiscal_month_end_dt
	,cast(fiscal.fiscal_quarter_begin_dt as TIMESTAMP) fiscal_quarter_begin_dt
	,cast(fiscal.fiscal_quarter_end_dt   as TIMESTAMP) fiscal_quarter_end_dt
	,cast(fiscal.fiscal_year_begin_dt    as TIMESTAMP) fiscal_year_begin_dt
	,cast(fiscal.fiscal_year_end_dt      as TIMESTAMP) fiscal_year_end_dt
	,fiscal.fiscal_year_short_desc, fiscal.fiscal_quarter_nbr 
	,fiscal.fiscal_year_week_nbr, fiscal.fiscal_year_month_nbr
	,fiscal.fiscal_day_in_week_nbr, fiscal.fiscal_month_week_qty 
	,cast(fiscal. fiscal_dt      as TIMESTAMP) fiscal_dt""") ;

/* Processed-1 Fact table is Truncate and Load */
EXECUTE IMMEDIATE
  CONCAT("""delete from `""",BQ_PROJECT_NAME,"""`.""",BQ_PROCESSED_DATASET_NAME,""".""",BQ_CUSTOMER_FACT_TABLE,""" where true""");

/* Consolidating all columns from Processed-0 ,Derived attributes, Fiscal Table into Processed-1 Fact */
EXECUTE IMMEDIATE
  CONCAT("""INSERT INTO
  `""",BQ_PROJECT_NAME,"""`.""",BQ_PROCESSED_DATASET_NAME,""".""",BQ_CUSTOMER_FACT_TABLE,"""
	 
	SELECT
	processed_zero.* EXCEPT ( """,CHECK_UPC,""" """,EXCEPT_COLUMN_LIST_1,""" )  ,	
	round(processed_zero.ty_sales_value,4)  AS ty_sales_value,
	coalesce(CAST(processed_zero.ty_sales_units as INT64),0) AS ty_sales_units,	
	NULL AS ty_sales_eqc_units,
	NULL AS  zone_hierarchy,
	derived_xref.currency_code,
	derived_xref.currency_symbol,
	'$' standard_currency_symbol,
	'USD' standard_currency_code,	
	derived_xref.* 
	EXCEPT ( """,NATURAL_KEYS,""",""",EXCEPT_COLUMN_LIST_2,"""),
	""",FISCAL_COLS,""",
	derived_xref.rctl_uuid,
	derived_xref.source_product_hash,
	'""",JOB_RUN_ID_STRING,"""' AS created_by,
	current_datetime AS created_datetime,
	'""",JOB_RUN_ID_STRING,"""' AS modified_by,
	current_datetime AS modified_datetime
	FROM
	`""",BQ_PROJECT_NAME,"""`.""",BQ_TRANSIENT_DATASET_NAME,""".""",BQ_DERIVED_XREF_TABLE,""" derived_xref
	JOIN
		`""",BQ_PROJECT_NAME,"""`.""",BQ_TRANSIENT_DATASET_NAME,""".""",BQ_PROCESSED_ZERO_TABLE,""" processed_zero
	ON
		processed_zero.source_product_hash= derived_xref.source_product_hash
	
	LEFT JOIN
		`""",BQ_EDW_PROJECT_NAME,"""`.""",BQ_ENTERPRISE_DATASET_NAME,""".dim_date fiscal
	ON
		fiscal.fiscal_year_variant_cd = '07'
		AND fiscal.language_cd ='EN'
		AND processed_zero.""",FISCAL_DT,"""= cast(fiscal_dt as timestamp)  
	
  """)
		;

EXCEPTION WHEN ERROR THEN
        EXECUTE IMMEDIATE CONCAT(
            """INSERT INTO processed.sproc_error_details (
		        SELECT
			        '""",FEED_NAME,"""' AS FEED_NAME,
                    split(split(@@error.formatted_stack_trace,'transient.')[OFFSET (1)],'[')[OFFSET(0)],
			        @@error.statement_text,
			        @@error.message,
			        current_timestamp()
	        );
	    """);

	    SELECT
	        ERROR (
	            CONCAT(
	            		@@error.message ,' ' ,
	            		@@error.statement_text, ' ' ,
	            		@@error.formatted_stack_trace ,' '
	            	)
	        );
 
End




