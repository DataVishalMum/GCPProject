  /* 
  Purpose OF the stored proc : 
		Consolidated Product Temp for EUAU 
  History OF Changes : 
		04/07 first version
        05/20 - Added feed Name parameter	
        06/07 - Added upc values from processed0 or product intl table
        05/10 - Updated composer related params and added sproc error mechanism
  Author : 
		Pawan Rathod

*/
	
CREATE OR REPLACE PROCEDURE
  transient.ecomm_sproc_consolidate_product_euau_temp (
    SRC_PROJECT STRING,
    SRC_DATASET STRING,
    SRC_LOOKUP_DATASET STRING,
    DEST_TABLE STRING,
    SRC_TABLE STRING,
    INTERMEDIATE_TABLE STRING,
    XREF_TABLE STRING,
    CUSTOMER_NAME STRING,
	FEED_NAME STRING
)
OPTIONS(
description = """

 How to call:

     CALL transient.ecomm_sproc_consolidate_product_euau_temp (
        'ecomm-dlf-dev-01cd47', -- SRC_PROJECT
        'transient', -- SRC_DATASET
        'processed', -- SRC_LOOKUP_DATASET
        'coles_consolidate_product_temp', -- DEST_TABLE
        'coles_processed_zero', -- SRC_TABLE
        'coles_product_temp', -- INTERMEDIATE_TABLE
        'coles_nielsen_product_temp', -- XREF_TABLE
        'COLES', -- CUSTOMER_NAME
	    'COLES' -- FEED_NAME
      )

"""
)
BEGIN

DECLARE JOB_RUN_ID DEFAULT 999999;
DECLARE BQ_PROJECT_NAME DEFAULT SRC_PROJECT;
DECLARE BQ_TRANSIENT_DATASET_NAME DEFAULT SRC_DATASET;
DECLARE BQ_PROCESSED_DATASET_NAME DEFAULT SRC_LOOKUP_DATASET;
DECLARE BQ_CONSOLIDATE_PRODUCT_TABLENAME DEFAULT DEST_TABLE;
DECLARE BQ_PROCESSED0_TEMP_TABLENAME DEFAULT SRC_TABLE;
DECLARE BQ_PRODUCT_TEMP_TABLENAME DEFAULT INTERMEDIATE_TABLE;
DECLARE BQ_NIELSEN_PRODUCT_TABLENAME DEFAULT XREF_TABLE;

DECLARE
  FISCAL_DT,UPC,UPC_EXCEPT STRING;

SET CUSTOMER_NAME = UPPER(CUSTOMER_NAME);

SET FEED_NAME = UPPER(FEED_NAME);

-- Find the customer specific date column 
EXECUTE IMMEDIATE
  CONCAT("""
  SELECT
    vendor_file_fiscal_date
  FROM
    `""",BQ_PROJECT_NAME,"""`.""",BQ_TRANSIENT_DATASET_NAME,""".gmi_customer_metadata_reference
  WHERE
    FEED_NAME =UPPER('""",FEED_NAME,"""') """) INTO FISCAL_DT;

EXECUTE IMMEDIATE
  CONCAT(""" WITH
  dr AS (
  SELECT
    COUNT(*) cnt
  FROM
    """,BQ_TRANSIENT_DATASET_NAME,""".INFORMATION_SCHEMA.COLUMNS
  WHERE
    table_name = '""",BQ_PROCESSED0_TEMP_TABLENAME,"""'
    AND column_name = 'upc')
SELECT
  CASE
    WHEN cnt = 0 THEN 'product.ean_upc_cd'
  ELSE
  'processed0.upc'
END
FROM
  dr""") INTO UPC;
-----Except condition to exclude upc column from source table if it exists  
IF UPC = 'processed0.upc' THEN EXECUTE IMMEDIATE CONCAT("""select 'EXCEPT(upc)'""") into UPC_EXCEPT ;
	ELSE EXECUTE IMMEDIATE CONCAT("""select ''""") into UPC_EXCEPT ;
END IF ;

-- Truncate Consolidate Product Temp TABLE
EXECUTE IMMEDIATE
  CONCAT("""TRUNCATE TABLE  `""",BQ_PROJECT_NAME,"""`.""",BQ_TRANSIENT_DATASET_NAME,""".""",BQ_CONSOLIDATE_PRODUCT_TABLENAME);
-- INSERT details INTO Customer specific Consolidate product temp TABLE
EXECUTE IMMEDIATE
  CONCAT( """INSERT INTO  `""",BQ_PROJECT_NAME,"""`.""",BQ_TRANSIENT_DATASET_NAME,""".""",BQ_CONSOLIDATE_PRODUCT_TABLENAME,""" (
    WITH
      processed0 AS (
      WITH
        dr AS (
        SELECT
          k.* EXCEPT( fact_sk,
            ty_sales_value,
            ty_sales_units,
            """,FISCAL_DT,""",
            created_by,
            created_datetime,
            modified_by,
            modified_datetime ),
          ROW_NUMBER() OVER(PARTITION BY k.source_product_hash ORDER BY """,FISCAL_DT,""" DESC) rnk
        FROM
          `""",BQ_PROJECT_NAME,"""`.""",BQ_TRANSIENT_DATASET_NAME,""".""",BQ_PROCESSED0_TEMP_TABLENAME,""" k )
      SELECT
        * EXCEPT(rnk)
      FROM
        DR
      WHERE
        RNK = 1 )
    SELECT
      processed0.* """,UPC_EXCEPT,""",
      customer.segment,
      customer.customer_share_flag,
      customer.report_fg,
      customer.customer_sales_flag,
      customer.country,
      customer.channel,
      customer.ad_security_role,
      customer.customer_desc,
      customer.customer_parent,
      customer.customer_account,
      customer.notes,
	  customer.currency_code,
	  customer.currency_symbol,
	  product.material_cd,
	  product.material_short_desc,
	  product.base_product_desc,
	  product.gph_hier_top_cd,
	  product.gph_hier_top_desc,
	  product.gph_hier_family_cd,
	  product.gph_hier_family_desc,
	  product.gph_hier_category_cd,
	  product.gph_hier_category_desc,
	  product.gph_hier_flavor_format_cd,
	  product.gph_hier_flavor_format_desc,
	  product.gph_hier_package_size_cd,
	  product.gph_hier_package_size_desc,
	  product.ean_upc_cd,
	  """,UPC,""" as upc,
	  product.old_system_material_nbr,
	  product.bph4_hier_bph20_desc,
	  product.bph4_hier_bph30_desc,
	  product.bph4_hier_bph40_desc,
	  product.bph4_hier_bph50_desc,
	  product.bph4_hier_bph60_desc,
	  product.bph4_hier_bph70_desc,
	  product.material_number,
	  product.ean_10,
	  product.is_gmi_flag,
	  product.divested_fg,
	  NULL as base_uom_to_eqc_fctr,
      nielsen.nielsen_upc_derived_cd,
      nielsen.nielsen_source_database_cd,
      nielsen.nielsen_product_long_desc,
      nielsen.nielsen_product_brand_derived_desc,
      nielsen.nielsen_product_sub_brand_desc,
      nielsen.nielsen_product_manufacturer_derived_desc,
      nielsen.nielsen_product_category_derived_desc,
      nielsen.nielsen_product_category_view_desc,
      nielsen.nielsen_general_mills_product_fg,
      nielsen.nielsen_product_segment_derived_desc,
      nielsen.nielsen_product_sub_segment_derived_desc,
      nielsen.nielsen_product_sector_desc,
      CAST(""",job_run_id,""" AS string) AS created_by,
      CURRENT_DATETIME AS created_datetime,
      CAST(""",job_run_id,""" AS string) AS modified_by,
      CURRENT_DATETIME AS modified_datetime
    FROM
      processed0
    LEFT JOIN
      `""",BQ_PROJECT_NAME,"""`.""",BQ_TRANSIENT_DATASET_NAME,""".""",BQ_PRODUCT_TEMP_TABLENAME,""" product
    ON
      processed0.source_item_code = product.source_item_code
    LEFT JOIN
      `""",BQ_PROJECT_NAME,"""`.""",BQ_PROCESSED_DATASET_NAME,""".lkp_customer customer
    ON
      processed0.CUSTOMER_NAME = customer.CUSTOMER_NAME
    LEFT JOIN
      `""",BQ_PROJECT_NAME,"""`.""",BQ_TRANSIENT_DATASET_NAME,""".""",BQ_NIELSEN_PRODUCT_TABLENAME,""" nielsen
    ON
      processed0.source_item_code = nielsen.source_item_code )""") ;

EXCEPTION WHEN ERROR THEN
        EXECUTE IMMEDIATE CONCAT(
            """INSERT INTO processed.sproc_error_details (
		        SELECT
			        '""",FEED_NAME,"""' AS FEED_NAME,
                    split(split(@@error.formatted_stack_trace,'transient.')[OFFSET (1)],'[')[OFFSET(0)],
			        @@error.statement_text,
			        @@error.message,
			        current_timestamp()
	        );
	    """);

	    SELECT
	        ERROR (
	            CONCAT(
	            		@@error.message ,' ' ,
	            		@@error.statement_text, ' ' ,
	            		@@error.formatted_stack_trace ,' '
	            	)
	        );

END