/*
Purpose OF the stored proc : 
  Enrich the source data with product columns
  History OF Changes : 
        04/07 first version
        04/14 - Updated the SP name from sp_product_int to sp_product_intl_temp
        05/06 - Removed the sub query to keep all join statements at one place.
        05/06 - Changed logic to remove duplicates
                - Before : Choose a random row if we have duplicates on source item code
                - After : Choose a row with non-null ean_upc_cd if there are duplicates on source item code
        05/11 - Removed the code for other customers except Coles and Woolsworth. Backup put at location - https://genmills.sharepoint.com/sites/DnASteeringTeam/Shared%20Documents/CAAP%20eComm%20Pod/BQ%20Code/create_sp_product_intl_temp_transient_bkp.sql
        07/07 - Enterprise dimension changes
        05/10 - Updated composer related params and added sproc error mechanism
        
  Author : 
		Pawan Rathod

*/

CREATE OR REPLACE PROCEDURE transient.ecomm_sproc_product_intl_temp (
  SRC_PROJECT STRING,
  DEST_DATASET STRING,
  SRC_DATASET STRING,
  SRC_LOOKUP_PROJECT STRING,
  SRC_LOOKUP_DATASET STRING,
  SRC_TABLE STRING,
  DEST_TABLE STRING,
  XREF_TABLE STRING,
  SRC_LOOKUP_TABLE STRING,
  CUSTOMER_NAME STRING,
  FEED_NAME STRING
)
OPTIONS(
description = """

 How to call:

     CALL transient.ecomm_sproc_product_intl_temp (
        "ecomm-dlf-dev-01cd47", -- SRC_PROJECT
        "transient", -- DEST_DATASET
        "processed", -- SRC_DATASET
        "edw-qa-c89f9d", -- SRC_LOOKUP_PROJECT
        "enterprise", -- SRC_LOOKUP_DATASET
        "coles_processed_zero", -- SRC_TABLE
        "coles_product_temp", -- DEST_TABLE
        "lkp_coles_mapping", -- XREF_TABLE
        "gmi_customer_metadata_reference", -- SRC_LOOKUP_TABLE
        "Coles", -- CUSTOMER_NAME
        "Coles" -- FEED_NAME
	)

"""
)
BEGIN

DECLARE JOB_RUN_ID DEFAULT 999999;
DECLARE BQ_PROJECT_NAME DEFAULT SRC_PROJECT;
DECLARE BQ_TRANSIENT_DATASET_NAME DEFAULT DEST_DATASET;
DECLARE BQ_PROCESSED_DATASET_NAME DEFAULT SRC_DATASET;
DECLARE BQ_EDW_PROJECT_NAME DEFAULT SRC_LOOKUP_PROJECT;
DECLARE BQ_ENTERPRISE_DATASET_NAME DEFAULT SRC_LOOKUP_DATASET;
DECLARE SOURCE_TABLE_NAME DEFAULT SRC_TABLE;
DECLARE TARGET_TABLE_NAME DEFAULT DEST_TABLE;
DECLARE CUSTOMER_SKU_TABLE DEFAULT XREF_TABLE;
DECLARE METADATA_LOOKUP_TABLE DEFAULT SRC_LOOKUP_TABLE;

DECLARE DATA_TO_ENRICH,SKU_COLUMN STRING;

SET CUSTOMER_NAME = UPPER(CUSTOMER_NAME);

SET FEED_NAME = UPPER(FEED_NAME);

-- Truncate the product temp table
EXECUTE IMMEDIATE CONCAT("""TRUNCATE TABLE
  `""",BQ_PROJECT_NAME,""".""",BQ_TRANSIENT_DATASET_NAME,""".""",TARGET_TABLE_NAME,"""`""");

-- Fetch the SKU column for the customer from the metadata table
EXECUTE IMMEDIATE CONCAT("""SELECT
  SKU_column
FROM
  `""",BQ_PROJECT_NAME,""".""",BQ_TRANSIENT_DATASET_NAME,""".""",METADATA_LOOKUP_TABLE,"""`
WHERE
  UPPER(customer_name) = UPPER('""",CUSTOMER_NAME,"""')""")
  INTO SKU_COLUMN;
/*
** Check if the customer SKU lookup table is present
** If the customer SKU lookup is present - Join the lookup table and product INTL table using material number and enrich the source using SKU column
** If the customer SKU lookup is not present - Enrich the source using the UPC column.
*/
IF CUSTOMER_SKU_TABLE != '' THEN
SET DATA_TO_ENRICH = CONCAT("""INSERT INTO
  `""",BQ_PROJECT_NAME,""".""",BQ_TRANSIENT_DATASET_NAME,""".""",TARGET_TABLE_NAME,"""`
    Select * EXCEPT(rn) from (
    SELECT
  cust.source_item_code,
  material_cd,
  material_short_desc,
  base_product_desc,
  gph_hier_top_cd,
  gph_hier_top_desc,
  gph_hier_family_cd,
  gph_hier_family_desc,
  gph_hier_category_cd,
  gph_hier_category_desc,
  gph_hier_flavor_format_cd,
  gph_hier_flavor_format_desc,
  gph_hier_package_size_cd,
  gph_hier_package_size_desc,
  ean_upc_cd,
  old_system_material_nbr,
  bph4_hier_bph20_desc,
  bph4_hier_bph30_desc,
  bph4_hier_bph40_desc,
  bph4_hier_bph50_desc,
  bph4_hier_bph60_desc,
  bph4_hier_bph70_desc,
  material_number,
  SUBSTRING(CAST(SAFE_CAST(p.ean_upc_cd AS INT64)AS STRING),
        0,
        10) AS ean_10,
  CASE WHEN material_cd is NOT NULL THEN 'Y'
  ELSE '' END AS is_gmi_flag,
  CASE
     WHEN gph_hier_family_cd = '2200004' THEN 'Y'
  ELSE
   'N'
  END
    AS divested_fg,
    ROW_NUMBER() OVER (PARTITION BY cust.source_item_code ORDER BY ean_upc_cd desc) rn,
  '""",job_run_id,"""' AS created_by,
  CURRENT_DATETIME() AS created_on,
  '""",job_run_id,"""' AS modified_by,
  CURRENT_DATETIME() AS modified_on
FROM (
  SELECT
    DISTINCT source_item_code
  FROM
    `""",BQ_PROJECT_NAME,""".""",BQ_TRANSIENT_DATASET_NAME,""".""",SOURCE_TABLE_NAME,"""`) cust
    LEFT JOIN 
    `""",BQ_PROJECT_NAME,""".""",BQ_PROCESSED_DATASET_NAME,""".""",CUSTOMER_SKU_TABLE,"""` s
    ON
  (CAST(SAFE_CAST(cust.source_item_code AS INT64) AS STRING) = CAST(SAFE_CAST(s.""",SKU_COLUMN,""" AS INT64) AS STRING))
  LEFT JOIN 
  `""",BQ_EDW_PROJECT_NAME,""".""",BQ_ENTERPRISE_DATASET_NAME,""".dim_product_active` p
  ON
     (CAST(SAFE_CAST(s.material_number AS INT64)AS STRING) = CAST(SAFE_CAST(p.old_system_material_nbr AS INT64)AS STRING)
      OR CAST(SAFE_CAST(s.material_number AS INT64)AS STRING) = CAST(SAFE_CAST(p.material_cd AS INT64)AS STRING))
    AND
      p.source_type_cd = 'INTL'
      AND p.language_cd = 'EN'
      AND gph_hier_top_cd IS NOT NULL
      AND gph_hier_category_desc NOT LIKE '%OUT OF SCOPE%'
      )
      where rn = 1""");
EXECUTE IMMEDIATE DATA_TO_ENRICH;
END IF;

EXCEPTION WHEN ERROR THEN
        EXECUTE IMMEDIATE CONCAT(
            """INSERT INTO processed.sproc_error_details (
		        SELECT
			        '""",FEED_NAME,"""' AS FEED_NAME,
                    split(split(@@error.formatted_stack_trace,'transient.')[OFFSET (1)],'[')[OFFSET(0)],
			        @@error.statement_text,
			        @@error.message,
			        current_timestamp()
	        );
	    """);

	    SELECT
	        ERROR (
	            CONCAT(
	            		@@error.message ,' ' ,
	            		@@error.statement_text, ' ' ,
	            		@@error.formatted_stack_trace ,' '
	            	)
	        );

END;