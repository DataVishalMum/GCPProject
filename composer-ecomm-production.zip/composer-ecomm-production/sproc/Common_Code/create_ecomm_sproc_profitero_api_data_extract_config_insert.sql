/*

Purpose of the stored proc: 
	Insert a new record for passed customer having latest status as 'complete'.
  This can be used when the source is a table instead of a file.

History of Changes:
	05/10 – first version
	05/10 - Updated composer related params and added sproc error mechanism
Author : 
	Pawan Rathod

*/

CREATE OR REPLACE PROCEDURE transient.ecomm_sproc_profitero_api_data_extract_config_insert
(
   DEST_PROJECT STRING,
   DEST_DATASET STRING,
   SRC_PROJECT STRING,
   SRC_DATASET STRING,
   SRC_TABLE STRING,
   COLUMN_NAME STRING,
   FEED_NAME STRING
)
OPTIONS(
description = """

 How to call:

     CALL transient.ecomm_sproc_profitero_api_data_extract_config_insert (
        "ecomm-dlf-dev-01cd47", -- DEST_PROJECT
        "transient", -- DEST_DATASET
        "ecomm-dlf-dev-01cd47", -- SRC_PROJECT
        "profitero_249", -- SRC_DATASET
        "brands", -- SRC_TABLE
        "updated_at", -- COLUMN_NAME
        "PROFITERO_249_BRANDS" -- FEED_NAME
	)

"""
)
BEGIN
-- declare variables

DECLARE JOB_RUN_ID DEFAULT 999999;
DECLARE BQ_PROJECT_NAME DEFAULT DEST_PROJECT;
DECLARE BQ_TRANSIENT_DATASET_NAME DEFAULT DEST_DATASET;
DECLARE SOURCE_PROJECT_NAME DEFAULT SRC_PROJECT;
DECLARE SOURCE_DATASET_NAME DEFAULT SRC_DATASET;
DECLARE BQ_TABLE_NAME DEFAULT SRC_TABLE;
DECLARE INGEST_DATE_COL DEFAULT COLUMN_NAME;

DECLARE
    STATUS,
    JOB_RUN_ID_STRING,
    INGEST_DATE_COL_TYPE STRING;
DECLARE
    END_DATETIME ,
    RAW_MAX_INGEST_DATE,
    MAX_MODIFIED_DATETIME TIMESTAMP;

-- set variables
SET JOB_RUN_ID_STRING = CAST(JOB_RUN_ID as STRING);

SET FEED_NAME = UPPER(FEED_NAME);

-- get the data type of the ingest_date_col
EXECUTE IMMEDIATE
  CONCAT("""SELECT data_type
  FROM `""",SOURCE_PROJECT_NAME,"""`.""",SOURCE_DATASET_NAME,""".INFORMATION_SCHEMA.COLUMNS
  WHERE table_name='""",BQ_TABLE_NAME,"""'AND column_name= '""",INGEST_DATE_COL,"""'""")
  INTO INGEST_DATE_COL_TYPE ;


-- get the max modified_datetime from data_extract_config for the incoiming table name.
EXECUTE IMMEDIATE
  CONCAT("""SELECT MAX(modified_datetime)
  FROM `""",BQ_PROJECT_NAME,"""`.""",BQ_TRANSIENT_DATASET_NAME,""".data_extract_config WHERE table_name=CONCAT('""",SOURCE_DATASET_NAME,"""','_','""",BQ_TABLE_NAME,"""')""")
  INTO MAX_MODIFIED_DATETIME ;


-- check the status on the record with max modified_datetime for the incoming table name.
EXECUTE IMMEDIATE
  CONCAT("""SELECT status  FROM `""",BQ_PROJECT_NAME,"""`.""",BQ_TRANSIENT_DATASET_NAME,""".data_extract_config
  WHERE table_name=CONCAT('""",SOURCE_DATASET_NAME,"""','_','""",BQ_TABLE_NAME,"""') AND modified_datetime ='""",MAX_MODIFIED_DATETIME,"""'""")
         INTO STATUS;

-- get the max ingest_date from the incoming raw table name.
-- convert ingest_date to timestamp if source ingest_date is an integer
-- This will be used to set the extract_end_datetime
IF
  INGEST_DATE_COL_TYPE= 'INT64' THEN
EXECUTE IMMEDIATE
  CONCAT("""SELECT MAX(TIMESTAMP_SECONDS(CAST(""",INGEST_DATE_COL,"""/1000 as INT64))) FROM `""",SOURCE_PROJECT_NAME,"""`.""",SOURCE_DATASET_NAME,""".""",BQ_TABLE_NAME ) INTO RAW_MAX_INGEST_DATE ;

ELSE
EXECUTE IMMEDIATE
  CONCAT("""SELECT TIMESTAMP(MAX(""",INGEST_DATE_COL,""")) FROM `""",SOURCE_PROJECT_NAME,"""`.""",SOURCE_DATASET_NAME,""".""",BQ_TABLE_NAME ) INTO RAW_MAX_INGEST_DATE ;
END if;

-- insert a new record only when the status of the record from the past run for this raw table
-- is set to "complete".  Raise an exception.
IF
  STATUS= 'complete' THEN
EXECUTE IMMEDIATE
  CONCAT( """SELECT extract_end_datetime FROM   `""",BQ_PROJECT_NAME,"""`.""",BQ_TRANSIENT_DATASET_NAME,""".data_extract_config
  WHERE   table_name=CONCAT('""",SOURCE_DATASET_NAME,"""','_','""",BQ_TABLE_NAME,"""') AND status='complete'   AND modified_datetime = '""",MAX_MODIFIED_DATETIME,"""'""") INTO END_DATETIME ;

EXECUTE IMMEDIATE
  CONCAT( """INSERT INTO `""",BQ_PROJECT_NAME,"""`.""",BQ_TRANSIENT_DATASET_NAME,""".data_extract_config
  (table_name, extract_start_datetime, extract_end_datetime, active_flag, status, created_by,created_datetime, modified_by, modified_datetime)
  VALUES(CONCAT('""",SOURCE_DATASET_NAME,"""','_','""",BQ_TABLE_NAME,"""'),'""",END_DATETIME,"""','""",RAW_MAX_INGEST_DATE,
   """','Y','running','""",JOB_RUN_ID_STRING, """',current_timestamp,'""",JOB_RUN_ID_STRING, """',current_timestamp)""");
else
 RAISE USING MESSAGE = CONCAT("""Did not find latest record for table: """,BQ_TABLE_NAME,""" with 'complete' status""");
END IF;

-- exception handling

EXCEPTION WHEN ERROR THEN
        EXECUTE IMMEDIATE CONCAT(
            """INSERT INTO processed.sproc_error_details (
		        SELECT
			        '""",FEED_NAME,"""' AS FEED_NAME,
                    split(split(@@error.formatted_stack_trace,'transient.')[OFFSET (1)],'[')[OFFSET(0)],
			        @@error.statement_text,
			        @@error.message,
			        current_timestamp()
	        );
	    """);

	    SELECT
	        ERROR (
	            CONCAT(
	            		@@error.message ,' ' ,
	            		@@error.statement_text, ' ' ,
	            		@@error.formatted_stack_trace ,' '
	            	)
	        );
END;
  
