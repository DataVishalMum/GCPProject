/*

Purpose of the stored proc: 
	Insert a new record for passed customer having latest status as 'complete'
History of Changes:
	03/10 – first version
	05/10 - Updated composer related params and added sproc error mechanism
Author : 
	Pawan Rathod

*/

CREATE OR REPLACE PROCEDURE transient.ecomm_sproc_data_extract_config_insert
(
   SRC_PROJECT STRING,
   SRC_DATASET STRING,
   INTERMEDIATE_DATASET STRING,
   SRC_TABLE STRING,
   FEED_NAME STRING
)
OPTIONS(
description = """

 How to call:

     CALL transient.ecomm_sproc_data_extract_config_insert(
        'ecomm-dlf-dev-01cd47', -- SRC_PROJECT
        'raw', -- SRC_DATASET
        'transient', -- INTERMEDIATE_DATASET
        'kroger_ship_sales', -- SRC_TABLE
        'kroger_ship' -- FEED_NAME
      )

"""
)
BEGIN
-- declare variables

DECLARE JOB_RUN_ID DEFAULT 999999;
DECLARE BQ_PROJECT_NAME DEFAULT SRC_PROJECT;
DECLARE BQ_RAW_DATASET_NAME DEFAULT SRC_DATASET;
DECLARE BQ_TRANSIENT_DATASET_NAME DEFAULT INTERMEDIATE_DATASET;
DECLARE BQ_TABLE_NAME DEFAULT SRC_TABLE;

DECLARE STATUS, JOB_RUN_ID_STRING STRING;
DECLARE END_DATETIME , RAW_MAX_INGEST_DATE, MAX_MODIFIED_DATETIME TIMESTAMP;

-- set variables
SET JOB_RUN_ID_STRING = cast(JOB_RUN_ID as STRING);

SET FEED_NAME = UPPER(FEED_NAME);


-- get the max modified_datetime from data_extract_config for the incoiming table name.
EXECUTE IMMEDIATE
  CONCAT("""SELECT MAX(modified_datetime) 
  FROM `""",BQ_PROJECT_NAME,"""`.""",BQ_TRANSIENT_DATASET_NAME,""".data_extract_config WHERE table_name='""",BQ_TABLE_NAME,"""'""")
  INTO MAX_MODIFIED_DATETIME ;


-- check the STATUS on the record with max modified_datetime for the incoming table name.
EXECUTE IMMEDIATE
  CONCAT("""SELECT STATUS  FROM `""",BQ_PROJECT_NAME,"""`.""",BQ_TRANSIENT_DATASET_NAME,""".data_extract_config
  WHERE table_name='""",BQ_TABLE_NAME, """' AND modified_datetime ='""",MAX_MODIFIED_DATETIME,"""'""")
         INTO STATUS;
		 
-- get the max ingest_date from the incoming raw table name.  
-- This will be used to set the extract_end_datetime

EXECUTE IMMEDIATE
  CONCAT("""SELECT MAX(ingest_date) FROM `""",BQ_PROJECT_NAME,"""`.""",BQ_RAW_DATASET_NAME,""".""",BQ_TABLE_NAME ) INTO RAW_MAX_INGEST_DATE ;

-- insert a new record only when the STATUS of the record from the past run for this raw table
-- is set to "complete".  Raise an exception.
IF
  STATUS= 'complete' THEN
EXECUTE IMMEDIATE
  CONCAT( """SELECT extract_end_datetime FROM   `""",BQ_PROJECT_NAME,"""`.""",BQ_TRANSIENT_DATASET_NAME,""".data_extract_config
  WHERE   table_name='""",BQ_TABLE_NAME, """' AND STATUS='complete'   AND modified_datetime = '""",MAX_MODIFIED_DATETIME,"""'""") INTO END_DATETIME ;

EXECUTE IMMEDIATE
  CONCAT( """INSERT INTO `""",BQ_PROJECT_NAME,"""`.""",BQ_TRANSIENT_DATASET_NAME,""".data_extract_config
  (table_name, extract_start_datetime, extract_end_datetime, active_flag, STATUS, created_by,created_datetime, modified_by, modified_datetime)
  VALUES('""",BQ_TABLE_NAME,"""','""",END_DATETIME,"""','""",RAW_MAX_INGEST_DATE,
   """','Y','running','""",JOB_RUN_ID_STRING, """',current_timestamp,'""",JOB_RUN_ID_STRING, """',current_timestamp)""");
else
 RAISE USING MESSAGE = CONCAT("""Did not find latest record for table: """,BQ_TABLE_NAME,""" with 'complete' STATUS""");
END IF;

-- exception handling

EXCEPTION WHEN ERROR THEN
        EXECUTE IMMEDIATE CONCAT(
            """INSERT INTO processed.sproc_error_details (
		        SELECT
			        '""",FEED_NAME,"""' AS FEED_NAME,
                    split(split(@@error.formatted_stack_trace,'transient.')[OFFSET (1)],'[')[OFFSET(0)],
			        @@error.statement_text,
			        @@error.message,
			        current_timestamp()
	        );
	    """);

	    SELECT
	        ERROR (
	            CONCAT(
	            		@@error.message ,' ' ,
	            		@@error.statement_text, ' ' ,
	            		@@error.formatted_stack_trace ,' '
	            	)
	        );

END
  
