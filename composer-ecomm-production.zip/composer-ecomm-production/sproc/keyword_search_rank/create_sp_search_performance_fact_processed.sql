  /*
Purpose of the stored proc: 
	- Incremental Load into fact table
	- Calculate Organic Rank,Customer weight, Click share for each keyword search 

History of Changes:
	22/07 – first version 
Author : 
	Swati Thakur
How to Call:
	CALL
	transient.sp_profitero_keyword_search_performance_fact
	(
		4208,
		'ecomm-dlf-dev-01cd47',
		'edw-prd-e567f9',
		'transient',
		'processed',
		'enterprise',
		'KEYWORD_SEARCH_RANK',
		'profitero_keyword_search_ranking_delta_temp'
	)
	
	*/
	

CREATE PROCEDURE IF NOT EXISTS
	  transient.sp_profitero_keyword_search_performance_fact 
	  ( job_run_id INT64,
		bq_project_name string,
		bq_edw_project_name string,
		bq_transient_dataset_name string,
		bq_processed_dataset_name string,
		bq_enterprise_dataset_name string,
		customer_name string,
		src_table_name string )
	BEGIN
	  -- declare variables
Declare sql,update_flags_sql STRING;
	SET
	  sql = CONCAT("""
	Merge into `""",bq_project_name,"""`.""",bq_processed_dataset_name,""".search_performance_fact tgt
		using(
	with srt_dt as -- Max search date, to be used for calculating the rest of the date ranges
	( Select max(search_date) as search_date
	from transient.profitero_keyword_search_ranking_delta_temp
	)
	,ty_date as -- Current year dates
	(select cur.fiscal_dt cur_fiscal_date,cur.fiscal_year_nbr,cur.fiscal_week_in_year_nbr,cur.fiscal_day_in_week_nbr,cur.fiscal_quarter_begin_dt,cur.fiscal_year_begin_dt,cur.fiscal_month_begin_dt,
	p13.fiscal_dt wk_13_ty_date,p26.fiscal_dt wk_26_ty_date,p52.fiscal_dt wk_52_ty_date
		from
		( -- get the current date , calculate the rolling 13,26 and 52 week. Join then with dim_date tables to get the dates (start of the week)
		select fd.fiscal_dt,(case when  fd.fiscal_week_in_year_nbr =53 then 52 else fd.fiscal_week_in_year_nbr end)fiscal_week_in_year_nbr,
		fd.fiscal_week_begin_dt,fd.fiscal_year_nbr,fd.fiscal_day_in_week_nbr,fd.fiscal_quarter_begin_dt,fd.fiscal_year_begin_dt,
		fd.fiscal_month_begin_dt
		,(case when (fd.fiscal_week_in_year_nbr-12) = 0 then -1 else (fd.fiscal_week_in_year_nbr-12) end) wk_13_wk_nbr
		,(case when (fd.fiscal_week_in_year_nbr-12) <= 0 then fd.fiscal_year_nbr-1 else fd.fiscal_year_nbr end) wk_13_yr_nbr
		,(case when (fd.fiscal_week_in_year_nbr-25) = 0 then -1 else (fd.fiscal_week_in_year_nbr-25) end) wk_26_wk_nbr
		,(case when (fd.fiscal_week_in_year_nbr-25) <= 0 then fd.fiscal_year_nbr-1 else fd.fiscal_year_nbr end) wk_26_yr_nbr
		,(case when (fd.fiscal_week_in_year_nbr-51) = 0 then -1 else (fd.fiscal_week_in_year_nbr-51) end) wk_52_wk_nbr
		,(case when (fd.fiscal_week_in_year_nbr-51)<= 0 then fd.fiscal_year_nbr-1 else fd.fiscal_year_nbr end) wk_52_yr_nbr
		from `""",bq_edw_project_name,"""`.""",bq_enterprise_dataset_name,""".dim_date fd inner join srt_dt
		on fd.fiscal_dt=srt_dt.search_date
		where fd.language_cd='EN' and fd.fiscal_year_variant_cd='07') cur
		inner join `""",bq_edw_project_name,"""`.""",bq_enterprise_dataset_name,""".dim_date p13
		on p13.language_cd='EN' and p13.fiscal_year_variant_cd='07' and p13.fiscal_year_nbr = cur.wk_13_yr_nbr
		and p13.fiscal_dt= p13.fiscal_week_begin_dt
		inner join `""",bq_edw_project_name,"""`.""",bq_enterprise_dataset_name,""".dim_date p26
		on p26.language_cd='EN' and p26.fiscal_year_variant_cd='07' and p26.fiscal_year_nbr = cur.wk_26_yr_nbr
		and p26.fiscal_dt= p26.fiscal_week_begin_dt
		inner join `""",bq_edw_project_name,"""`.""",bq_enterprise_dataset_name,""".dim_date p52
		on p52.language_cd='EN' and p52.fiscal_year_variant_cd='07' and p52.fiscal_year_nbr = cur.wk_52_yr_nbr
		and p52.fiscal_dt= p52.fiscal_week_begin_dt
		where p26.fiscal_week_in_year_nbr =(case when cur.wk_26_wk_nbr<0 then p26.fiscal_year_total_week_nbr else 0 end) +cur.wk_26_wk_nbr
		and p13.fiscal_week_in_year_nbr =(case when cur.wk_13_wk_nbr<0 then p13.fiscal_year_total_week_nbr else 0 end) +cur.wk_13_wk_nbr
		and p52.fiscal_week_in_year_nbr =(case when cur.wk_52_wk_nbr<0 then p52.fiscal_year_total_week_nbr else 0 end) +cur.wk_52_wk_nbr)
	,ly_date as -- Last Fiscal year dates
	(select cur_fiscal_date,cur.fiscal_dt ly_fiscal_date,cur.fiscal_week_begin_dt,cur.fiscal_quarter_begin_dt,cur.fiscal_year_begin_dt,cur.fiscal_month_begin_dt
	,p13.fiscal_dt wk_13_ly_date,p26.fiscal_dt wk_26_ly_date,p52.fiscal_dt wk_52_ly_date,cur.fiscal_year_nbr
	from
	(-- get the ly date and corresponding values and calculate the rolling 13,26 and 52 week. 
		--Join then with dim_date tables to get the dates (start of the week)
	select  t.cur_fiscal_date,fd.fiscal_dt,fd.fiscal_week_in_year_nbr,fd.fiscal_week_begin_dt,fd.fiscal_year_nbr,fd.fiscal_quarter_begin_dt,fd.fiscal_year_begin_dt,fd.fiscal_month_begin_dt
		,(case when (fd.fiscal_week_in_year_nbr-12) = 0 then -1 else (fd.fiscal_week_in_year_nbr-12) end) wk_13_wk_nbr
		,(case when (fd.fiscal_week_in_year_nbr-12) <= 0 then fd.fiscal_year_nbr-1 else fd.fiscal_year_nbr end) wk_13_yr_nbr
		,(case when (fd.fiscal_week_in_year_nbr-25) = 0 then -1 else (fd.fiscal_week_in_year_nbr-25) end) wk_26_wk_nbr
		,(case when (fd.fiscal_week_in_year_nbr-25) <= 0 then fd.fiscal_year_nbr-1 else fd.fiscal_year_nbr end) wk_26_yr_nbr
		,(case when (fd.fiscal_week_in_year_nbr-51) = 0 then -1 else (fd.fiscal_week_in_year_nbr-51) end) wk_52_wk_nbr
		,(case when (fd.fiscal_week_in_year_nbr-51)<= 0 then fd.fiscal_year_nbr-1 else fd.fiscal_year_nbr end) wk_52_yr_nbr
    from `""",bq_edw_project_name,"""`.""",bq_enterprise_dataset_name,""".dim_date fd inner join ty_date t
    on fd.fiscal_year_nbr=t.fiscal_year_nbr -1 and fd.fiscal_week_in_year_nbr = t.fiscal_week_in_year_nbr  and fd.fiscal_day_in_week_nbr = t.fiscal_day_in_week_nbr
    where fd.language_cd='EN' and fd.fiscal_year_variant_cd='07') cur
    inner join `""",bq_edw_project_name,"""`.""",bq_enterprise_dataset_name,""".dim_date p13
    on p13.language_cd='EN' and p13.fiscal_year_variant_cd='07' and p13.fiscal_year_nbr = cur.wk_13_yr_nbr
    and p13.fiscal_dt= p13.fiscal_week_begin_dt
    inner join `""",bq_edw_project_name,"""`.""",bq_enterprise_dataset_name,""".dim_date p26
    on p26.language_cd='EN' and p26.fiscal_year_variant_cd='07' and p26.fiscal_year_nbr = cur.wk_26_yr_nbr
    and p26.fiscal_dt= p26.fiscal_week_begin_dt
    inner join `""",bq_edw_project_name,"""`.""",bq_enterprise_dataset_name,""".dim_date p52
    on p52.language_cd='EN' and p52.fiscal_year_variant_cd='07' and p52.fiscal_year_nbr = cur.wk_52_yr_nbr
    and p52.fiscal_dt= p52.fiscal_week_begin_dt
    where p13.fiscal_week_in_year_nbr =(case when cur.wk_13_wk_nbr<0 then p13.fiscal_year_total_week_nbr else 0 end) +cur.wk_13_wk_nbr
    and p26.fiscal_week_in_year_nbr =(case when cur.wk_26_wk_nbr<0 then p26.fiscal_year_total_week_nbr else 0 end) +cur.wk_26_wk_nbr
    and p52.fiscal_week_in_year_nbr =(case when cur.wk_52_wk_nbr<0 then p52.fiscal_year_total_week_nbr else 0 end) +cur.wk_52_wk_nbr
    ),
    lly_date as -- last to last year dates
     (select cur_fiscal_date,cur.fiscal_dt ly_fiscal_date,cur.fiscal_week_begin_dt,cur.fiscal_quarter_begin_dt,cur.fiscal_year_begin_dt,cur.fiscal_month_begin_dt
   ,p13.fiscal_dt wk_13_ly_date,p26.fiscal_dt wk_26_ly_date,p52.fiscal_dt wk_52_ly_date,cur.fiscal_year_nbr
    from
    (-- get the ly date and corresponding values and calculate the rolling 13,26 and 52 week. Join then with dim_date tables to get the dates (start of the week)
    select  t.cur_fiscal_date,fd.fiscal_dt,fd.fiscal_week_in_year_nbr,fd.fiscal_week_begin_dt,fd.fiscal_year_nbr,fd.fiscal_quarter_begin_dt,fd.fiscal_year_begin_dt,fd.fiscal_month_begin_dt
		,(case when (fd.fiscal_week_in_year_nbr-12) = 0 then -1 else (fd.fiscal_week_in_year_nbr-12) end) wk_13_wk_nbr
		,(case when (fd.fiscal_week_in_year_nbr-12) <= 0 then fd.fiscal_year_nbr-1 else fd.fiscal_year_nbr end) wk_13_yr_nbr
		,(case when (fd.fiscal_week_in_year_nbr-25) = 0 then -1 else (fd.fiscal_week_in_year_nbr-25) end) wk_26_wk_nbr
		,(case when (fd.fiscal_week_in_year_nbr-25) <= 0 then fd.fiscal_year_nbr-1 else fd.fiscal_year_nbr end) wk_26_yr_nbr
		,(case when (fd.fiscal_week_in_year_nbr-51) = 0 then -1 else (fd.fiscal_week_in_year_nbr-51) end) wk_52_wk_nbr
		,(case when (fd.fiscal_week_in_year_nbr-51)<= 0 then fd.fiscal_year_nbr-1 else fd.fiscal_year_nbr end) wk_52_yr_nbr
    from `""",bq_edw_project_name,"""`.""",bq_enterprise_dataset_name,""".dim_date fd inner join ty_date t
    on fd.fiscal_year_nbr=t.fiscal_year_nbr -2 and fd.fiscal_week_in_year_nbr = t.fiscal_week_in_year_nbr  and fd.fiscal_day_in_week_nbr = t.fiscal_day_in_week_nbr
    where fd.language_cd='EN' and fd.fiscal_year_variant_cd='07') cur
    inner join `""",bq_edw_project_name,"""`.""",bq_enterprise_dataset_name,""".dim_date p13
    on p13.language_cd='EN' and p13.fiscal_year_variant_cd='07' and p13.fiscal_year_nbr = cur.wk_13_yr_nbr
    and p13.fiscal_dt= p13.fiscal_week_begin_dt
    inner join `""",bq_edw_project_name,"""`.""",bq_enterprise_dataset_name,""".dim_date p26
    on p26.language_cd='EN' and p26.fiscal_year_variant_cd='07' and p26.fiscal_year_nbr = cur.wk_26_yr_nbr
    and p26.fiscal_dt= p26.fiscal_week_begin_dt
    inner join `""",bq_edw_project_name,"""`.""",bq_enterprise_dataset_name,""".dim_date p52
    on p52.language_cd='EN' and p52.fiscal_year_variant_cd='07' and p52.fiscal_year_nbr = cur.wk_52_yr_nbr
    and p52.fiscal_dt= p52.fiscal_week_begin_dt
    where p13.fiscal_week_in_year_nbr =(case when cur.wk_13_wk_nbr<0 then p13.fiscal_year_total_week_nbr else 0 end) +cur.wk_13_wk_nbr
    and p26.fiscal_week_in_year_nbr =(case when cur.wk_26_wk_nbr<0 then p26.fiscal_year_total_week_nbr else 0 end) +cur.wk_26_wk_nbr
    and p52.fiscal_week_in_year_nbr =(case when cur.wk_52_wk_nbr<0 then p52.fiscal_year_total_week_nbr else 0 end) +cur.wk_52_wk_nbr
    )
	select * except(dedup) from (
    SELECT  
	
	-- Generating the hash key for input natural keys combination using FARM_FINGERPRINT function
	-- The output of this function for a particular input will never change
	-- Generated hash key is further used for joining with target table
	-- Using FARM_FINGERPRINT has resulted in improved performance
	
		FARM_FINGERPRINT( concat (pksr.search_date 					
			, COALESCE(pksr.retailer,'NULL') 		
			, COALESCE(pksr.upc,'NULL') 			
			, COALESCE(pksr.ean,'NULL') 			
			, COALESCE(pksr.rpc,'NULL') 			
			, COALESCE(cast(pksr.actual_rank as string) ,'NULL') 	
			, COALESCE(cast(pksr.page_placement as string) ,'NULL') 
			, COALESCE(exst.operating_unit,'NULL') 
			, COALESCE(pksr.keyword,'NULL') 	
			, COALESCE(exst.category,'NULL')))	  joinedkey_fingerprint,
		fd.date_sk,
		dim.material_sk,
		pksr.search_date,
        ty_date.cur_fiscal_date as max_date,			
        pksr.country AS source_country,
        'NA' as source_type_cd,
        pksr.retailer,
        lower(pksr.keyword) search_term ,
        pksr.keyword_type as search_term_type,
        pksr.upc,
        pksr.ean,
        pksr.rpc,
        pksr.product_model_no,
        pksr.product_title,
        pksr.page_placement,
        pksr.is_sponsored,
        pksr.number_of_images,
        pksr.is_keyword_title,
        pksr.star_rating,
        pksr.review_count,
        pksr.url,
        pksr.manufacturer,
        pksr.brand,
        pksr.sub_brand,
        pksr.account_category,
        pksr.account_category_2,
        pksr.account_category_3,
        pksr.account_category_4,
        pksr.account_category_5,
        pksr.account_category_6,
        pksr.product_title_clnsd,
        exsc.customer_parent as customer_parent,
        exsc.customer_account as customer_account,
        exsc.customer_sub_account as customer_sub_account,
        cast(exsc.customer_weight as FLOAT64) as customer_weight,
        fd.fiscal_month_in_year_short_desc,
        fd.fiscal_quarter_nbr ,
        fd.fiscal_month_in_year_nbr ,
        fd.fiscal_quarter_in_year_nbr ,
        extract(year from pksr.search_date) as calendar_year_nbr, -- Calendar year nbr
        fd.fiscal_year_nbr ,
        fd.fiscal_year_week_nbr ,
        concat(fd.fiscal_month_in_year_nbr,"-", fiscal_month_in_year_short_desc) as fiscal_month_number_short_desc,
		regexp_replace(substr( fd.fiscal_quarter_short_desc ,8,10)," ","") as fiscal_quarter_number_short_desc,
          concat(substr(fd.fiscal_year_short_desc,1,2),substr(fd.fiscal_year_short_desc,5,2)) as fiscal_year,
          concat(cast(fd.fiscal_year_nbr as STRING),
          LPAD(cast(fd.fiscal_month_in_year_nbr  as string),3,'0')) as fiscal_year_month_nbr,
        exst.operating_unit,
        exst.category,
        cast(exst.search_term_weight as FLOAT64) as search_term_weight,
        (case when pksr.is_sponsored='No' then cast(exsr.rank_weight as FLOAT64) else NULL end )as click_share,
        exst.keyword_type as keyword_type,
        exsb.override_brand,
        exsb.override_manufacturer,
        exsb.override_sub_brand,
        cast( exb.share_benchmark as FLOAT64) share_benchmark ,
        pksr.actual_rank,
        cast(( case when pksr.is_sponsored='No' then pksr.cal_org_rank else NULL end) as INT64) cal_org_rank,
        if(date(pksr.search_date) >=ty_date.fiscal_year_begin_dt,'Y','N') latest_year_ty_flg,
        if(date(pksr.search_date) >=ty_date.fiscal_quarter_begin_dt,'Y','N') fiscal_quarter_to_date_ty_flg,
        if(date(pksr.search_date) >=ty_date.fiscal_month_begin_dt,'Y','N') fiscal_month_to_date_ty_flg,
        if(date(pksr.search_date) >= ly_date.fiscal_year_begin_dt    and date(pksr.search_date)<= ly_date.ly_fiscal_date ,'Y','N') latest_year_ly_flg,
        if(date(pksr.search_date) >= ly_date.fiscal_quarter_begin_dt and date(pksr.search_date)<= ly_date.ly_fiscal_date,'Y','N') fiscal_quarter_to_date_ly_flg,
        if(date(pksr.search_date) >= ly_date.fiscal_month_begin_dt and date(pksr.search_date)<= ly_date.ly_fiscal_date,'Y','N') fiscal_month_to_date_ly_flg,
        if(date(pksr.search_date) >= ll.fiscal_year_begin_dt and date(pksr.search_date)<= ll.ly_fiscal_date ,'Y','N') latest_year_lly_flg,
        if(date(pksr.search_date) >= ll.fiscal_quarter_begin_dt and date(pksr.search_date)<= ll.ly_fiscal_date,'Y','N') fiscal_quarter_to_date_lly_flg,
        if(date(pksr.search_date) >= ll.fiscal_month_begin_dt and date(pksr.search_date)<= ll.ly_fiscal_date,'Y','N') fiscal_month_to_date_lly_flg,
        if(fd.fiscal_year_nbr = ly_date.fiscal_year_nbr,'Y','N') previous_year_ty_flg,
        if(fd.fiscal_year_nbr = ll.fiscal_year_nbr,'Y','N') previous_year_ly_flg,
        if(date(pksr.search_date) > ty_date.wk_13_ty_date ,'Y','N') latest_rolling_13_weeks_flg,
        if(date(pksr.search_date) > ty_date.wk_26_ty_date ,'Y','N') latest_rolling_26_weeks_flg,
        if(date(pksr.search_date) > ty_date.wk_52_ty_date ,'Y','N') latest_rolling_52_weeks_flg,
        if(date(pksr.search_date)  between ly_date.wk_13_ly_date and ly_date.ly_fiscal_date ,'Y','N') previous_rolling_13_weeks_flg,
        if(date(pksr.search_date)  between ly_date.wk_26_ly_date and ly_date.ly_fiscal_date ,'Y','N') previous_rolling_26_weeks_flg,
        if(date(pksr.search_date)  between ly_date.wk_52_ly_date and ly_date.ly_fiscal_date ,'Y','N') previous_rolling_52_weeks_flg,
        if(date(pksr.search_date)  between ll.wk_13_ly_date and ll.ly_fiscal_date ,'Y','N') previous_ly_rolling_13_weeks_flg,
        if(date(pksr.search_date)  between ll.wk_26_ly_date and ll.ly_fiscal_date ,'Y','N') previous_ly_rolling_26_weeks_flg,
        if(date(pksr.search_date)  between ll.wk_52_ly_date and ll.ly_fiscal_date ,'Y','N') previous_ly_rolling_52_weeks_flg,
		cast(ccw.customer_weight as FLOAT64) as current_customer_weight, 
		cast(csw.search_term_weight as FLOAT64) as current_search_term_weight, 
		exsc.segment,
		exsc.country,
		least(exst.report_fg, exsc.eport_fg) as report_flg,
		pksr.rctl_uuid,
		cast(4208 as string) created_by ,
		current_datetime created_datetime ,
		cast(4208 as string) modified_by ,
		current_datetime  modified_datetime,
			
		-- We are getting duplicates on the natural keys combination
		-- During a merge, if a row in the table to be updated joins with more than one row from the FROM clause, 
		-- then the query generates the following runtime error: UPDATE/MERGE must match at most one source row for each target row
	
        row_number() over (partition by 
			 pksr.search_date 					
			, COALESCE(pksr.retailer,'NULL') 		
			, COALESCE(pksr.upc,'NULL') 			
			, COALESCE(pksr.ean,'NULL') 			
			, COALESCE(pksr.rpc,'NULL') 			
			, pksr.actual_rank 	
			, pksr.page_placement 
			, COALESCE(exst.operating_unit,'NULL') 
			, COALESCE(pksr.keyword,'NULL') 	
			, COALESCE(exst.category,'NULL')) dedup
		from (SELECT  search_date
			,pksr.country
			,pksr.retailer
			,pksr.keyword
			,pksr.keyword_type
			,pksr.upc
			,pksr.ean
			,pksr.rpc
			,pksr.product_model_no
			,pksr.product_title
			,pksr.page_placement
			,pksr.is_sponsored
			,pksr.number_of_images
			,pksr.is_keyword_title
			,pksr.star_rating
			,pksr.review_count
			,pksr.url
			,pksr.manufacturer
			,pksr.brand
			,pksr.sub_brand
			,pksr.account_category
			,pksr.account_category_2
			,pksr.account_category_3
			,pksr.account_category_4
			,pksr.account_category_5
			,pksr.account_category_6
			,pksr.product_title_clnsd
			,pksr.actual_rank			
            ,rank() over (partition by pksr.search_date,pksr.keyword, pksr.retailer order by pksr.actual_rank) top_rank
            ,rank() over (partition by pksr.search_date,pksr.keyword, pksr.retailer,pksr.is_sponsored order by pksr.actual_rank) 
			cal_org_rank
			 ,rctl_uuid
			 
            FROM
            `""",bq_project_name,"""`.""",bq_transient_dataset_name,""".""",src_table_name,""" pksr
		) pksr
  INNER JOIN
  `""",bq_edw_project_name,"""`.""",bq_enterprise_dataset_name,""".dim_date fd
ON
  fd.fiscal_dt = pksr.search_date
  AND fd.language_cd='EN'
  AND fd.fiscal_year_variant_cd='07'
INNER JOIN
  `""",bq_project_name,"""`.""",bq_processed_dataset_name,""".lkp_search_regex_customer exsc
ON
  fd.fiscal_year_nbr = CAST(exsc.fiscal_year AS INT64)
  
 /* Fetching material_sk from dim_product_active Dimension */
 
LEFT JOIN (
  WITH
    src_xref AS (
    SELECT
      xref_upc.customer_upc upc,
      xref_upc.target_upc,
      coalesce(xref_upc.xref_upc_sk,
        -1) xref_upc_sk
    FROM
      `""",bq_project_name,"""`.""",bq_processed_dataset_name,""".dim_source_to_enterprise_upc_xref xref_upc
    WHERE
      xref_upc.customer_name = 'KEYWORD_SEARCH_RANK'
      AND xref_upc.current_flg = 'Y'
      AND xref_upc.target_upc IS NOT NULL
      AND xref_upc.priority != -1
      AND xref_upc.xref_upc_sk <> -9999),
    src_prd AS (
    SELECT
      b.*
    FROM (
      SELECT
        a.*,
        ROW_NUMBER() OVER (PARTITION BY upc ORDER BY rnk) best
      FROM (
        SELECT
          src_xref.upc,
          src_xref.target_upc,
          src_xref.xref_upc_sk,
          prd.material_sk,
          prd.base_product_cd,
          prd.ean_upc_cd,
          prd.ean_upc_derived_cd,
          CASE
            WHEN ean_upc_cd IS NULL THEN 3
          ELSE
          1
        END
          AS rnk
        FROM
          src_xref
        LEFT OUTER JOIN
          `""",bq_edw_project_name,""".""",bq_enterprise_dataset_name,""".dim_product_active` prd
        ON
          prd.source_type_cd = 'NA'
          AND prd.ean_upc_cd = src_xref.target_upc
          AND prd.material_type_cd = 'CNPK'
          AND prd.language_cd = 'EN'
        UNION ALL
        SELECT
          src_xref.upc,
          src_xref.target_upc,
          src_xref.xref_upc_sk,
          prd.material_sk,
          prd.base_product_cd,
          prd.ean_upc_cd,
          prd.ean_upc_derived_cd,
          2 rnk
        FROM
          src_xref
        INNER JOIN
          `""",bq_edw_project_name,""".""",bq_enterprise_dataset_name,""".dim_product_active` prd
        ON
          prd.source_type_cd = 'NA'
          AND prd.base_product_ean_upc_derived_cd = src_xref.target_upc
          AND prd.material_type_cd = 'CNPK'
          AND prd.language_cd = 'EN')a ) b
    WHERE
      b.best = 1)
  SELECT
    p.material_sk,
    p.upc
  FROM
    src_prd p) dim
ON
 coalesce(dim.upc,'NULL')= coalesce(pksr.upc,'NULL')
 /* Lookup Xref Joins */
LEFT JOIN
  `""",bq_project_name,"""`.""",bq_processed_dataset_name,""".lkp_search_rank exsr
ON
  LOWER(exsr.kywrd) = LOWER(pksr.keyword)
  AND fd.fiscal_year_nbr= CAST(exsr.fiscal_year AS INT64)
  AND CAST(exsr.org_rnk AS int64)=pksr.cal_org_rank
INNER JOIN
  `""",bq_project_name,"""`.""",bq_processed_dataset_name,""".lkp_search_term exst
ON
  LOWER(exst.kywrd) = LOWER(pksr.keyword)
  AND fd.fiscal_year_nbr= CAST(exst.fiscal_year AS INT64)
LEFT JOIN
  `""",bq_project_name,"""`.""",bq_processed_dataset_name,""".lkp_search_brand_override exsb
ON
  exsb.override_brand = pksr.brand
  AND exsb.prd_ttl = pksr.product_title
LEFT JOIN
  `""",bq_project_name,"""`.""",bq_processed_dataset_name,""".lkp_search_benchmarks exb
ON
  exb.customer_parent = exsc.customer_parent
  AND exb.global_category_parent = exst.category
  AND CAST(exb.fiscal_year AS int64) = fd.fiscal_year_nbr
  
CROSS JOIN  ty_date 
CROSS JOIN  ly_date 
CROSS JOIN lly_date ll

JOIN (
  SELECT
    DISTINCT customer_sub_account,
    customer_weight
  FROM
    `""",bq_project_name,"""`.""",bq_processed_dataset_name,""".lkp_search_regex_customer a
  INNER JOIN (
    SELECT
      MAX(fiscal_year) AS fiscal_year
    FROM
      `""",bq_project_name,"""`.""",bq_processed_dataset_name,""".lkp_search_regex_customer) b
  ON
    a.fiscal_year=b.fiscal_year) ccw
ON
  LOWER(ccw.customer_sub_account) = LOWER(exsc.customer_sub_account)
JOIN (
  SELECT
    DISTINCT kywrd,
    search_term_weight
  FROM
    `""",bq_project_name,"""`.""",bq_processed_dataset_name,""".lkp_search_term a
  INNER JOIN (
    SELECT
      MAX(fiscal_year) AS fiscal_year
    FROM
      `""",bq_project_name,"""`.""",bq_processed_dataset_name,""".lkp_search_term) b
  ON
    a.fiscal_year=b.fiscal_year) csw
ON
  LOWER(csw.kywrd) = LOWER(exst.kywrd)
WHERE
  pksr.top_rank <=40 --AND LOWER(TRIM(pksr.rtlr))
  --and regexp_contains (lower(trim(pksr.retailer)),exsc.regex_match)
and CASE
    WHEN exsc.regex_match LIKE '%[^<>]%'
    THEN REGEXP_CONTAINS(LOWER(TRIM(pksr.retailer)), split(exsc.regex_match,'[^<>]')[OFFSET (0)])
    AND NOT REGEXP_CONTAINS(LOWER(TRIM(pksr.retailer)), split(exsc.regex_match,'[^<>]')[OFFSET (1)])
    ELSE REGEXP_CONTAINS(LOWER(TRIM(pksr.retailer)), exsc.regex_match )
  END
 
) where dedup =1)src
on 
		src.joinedkey_fingerprint= tgt.joinedkey_fingerprint

-- Insert the incoming record when a new natural keys combination is found
-- Else Update the record

when not matched then insert row

when matched then update
set 
	tgt.date_sk	=	src.date_sk
	, tgt.material_sk	=	src.material_sk
	, tgt.max_date	=	src.max_date
	, tgt.source_country	=	src.source_country
	, tgt.source_type_cd	=	src.source_type_cd
	, tgt.search_term_type	=	src.search_term_type
	, tgt.ean	=	src.ean
	, tgt.product_model_no	=	src.product_model_no
	, tgt.product_title	=	src.product_title
	, tgt.is_sponsored	=	src.is_sponsored
	, tgt.number_of_images	=	src.number_of_images
	, tgt.is_keyword_title	=	src.is_keyword_title
	, tgt.star_rating	=	src.star_rating
	, tgt.review_count	=	src.review_count
	, tgt.url	=	src.url
	, tgt.manufacturer	=	src.manufacturer
	, tgt.brand	=	src.brand
	, tgt.sub_brand	=	src.sub_brand
	, tgt.acct_cat	=	src.account_category
	, tgt.acct_cat_2	=	src.account_category_2
	, tgt.acct_cat_3	=	src.account_category_3
	, tgt.acct_cat_4	=	src.account_category_4
	, tgt.acct_cat_5	=	src.account_category_5
	, tgt.acct_cat_6	=	src.account_category_6
	, tgt.product_title_clnsd	=	src.product_title_clnsd
	, tgt.customer_parent	=	src.customer_parent
	, tgt.customer_account	=	src.customer_account
	, tgt.customer_sub_account	=	src.customer_sub_account
	, tgt.customer_weight	=	src.customer_weight
	, tgt.fiscal_month_in_year_short_desc	=	src.fiscal_month_in_year_short_desc
	, tgt.fiscal_quarter_nbr	=	src.fiscal_quarter_nbr
	, tgt.fiscal_month_in_year_nbr	=	src.fiscal_month_in_year_nbr
	, tgt.fiscal_quarter_in_year_nbr	=	src.fiscal_quarter_in_year_nbr
	, tgt.calendar_year_nbr	=	src.calendar_year_nbr
	, tgt.fiscal_year_nbr	=	src.fiscal_year_nbr
	, tgt.fiscal_year_week_nbr	=	src.fiscal_year_week_nbr
	, tgt.fiscal_month_number_short_desc	=	src.fiscal_month_number_short_desc
	, tgt.fiscal_quarter_number_short_desc	=	src.fiscal_quarter_number_short_desc
	, tgt.fiscal_year	=	src.fiscal_year
	, tgt.fiscal_year_month_nbr	=	src.fiscal_year_month_nbr
	, tgt.category	=	src.category
	, tgt.search_term_weight	=	src.search_term_weight
	, tgt.click_share	=	src.click_share
	, tgt.keyword_type	=	src.keyword_type
	, tgt.override_manufacturer	=	src.override_manufacturer
	, tgt.override_brand	=	src.override_brand
	, tgt.override_sub_brand	=	src.override_sub_brand
	, tgt.share_benchmark	=	src.share_benchmark
	, tgt.organic_rank	=	src.cal_org_rank
	, tgt.latest_year_ty_flg	=	src.latest_year_ty_flg
	, tgt.fiscal_quarter_to_date_ty_flg	=	src.fiscal_quarter_to_date_ty_flg
	, tgt.fiscal_month_to_date_ty_flg	=	src.fiscal_month_to_date_ty_flg
	, tgt.latest_year_ly_flg	=	src.latest_year_ly_flg
	, tgt.fiscal_quarter_to_date_ly_flg	=	src.fiscal_quarter_to_date_ly_flg
	, tgt.fiscal_month_to_date_ly_flg	=	src.fiscal_month_to_date_ly_flg
	, tgt.latest_year_lly_flg	=	src.latest_year_lly_flg
	, tgt.fiscal_quarter_to_date_lly_flg	=	src.fiscal_quarter_to_date_lly_flg
	, tgt.fiscal_month_to_date_lly_flg	=	src.fiscal_month_to_date_lly_flg
	, tgt.previous_year_ty_flg	=	src.previous_year_ty_flg
	, tgt.previous_year_ly_flg	=	src.previous_year_ly_flg
	, tgt.latest_rolling_13_weeks_flg	=	src.latest_rolling_13_weeks_flg
	, tgt.latest_rolling_26_weeks_flg	=	src.latest_rolling_26_weeks_flg
	, tgt.latest_rolling_52_weeks_flg	=	src.latest_rolling_52_weeks_flg
	, tgt.previous_rolling_13_weeks_flg	=	src.previous_rolling_13_weeks_flg
	, tgt.previous_rolling_26_weeks_flg	=	src.previous_rolling_26_weeks_flg
	, tgt.previous_rolling_52_weeks_flg	=	src.previous_rolling_52_weeks_flg
	, tgt.previous_ly_rolling_13_weeks_flg	=	src.previous_ly_rolling_13_weeks_flg
	, tgt.previous_ly_rolling_26_weeks_flg	=	src.previous_ly_rolling_26_weeks_flg
	, tgt.previous_ly_rolling_52_weeks_flg	=	src.previous_ly_rolling_52_weeks_flg
	, tgt.current_customer_weight	=	src.current_customer_weight
	, tgt.current_search_term_weight	=	src.current_search_term_weight
	, tgt.segment	=	src.segment
	, tgt.country	=	src.country
	, tgt.report_flg	=	src.report_flg
	, tgt.rctl_uuid	=	src.rctl_uuid
	, tgt.created_by	=	src.created_by
	, tgt.modified_by	=	src.modified_by
	, tgt.modified_datetime	=	src.modified_datetime;


""");

EXECUTE IMMEDIATE sql;

SET
	  update_flags_sql = CONCAT("""
Merge into `""",bq_project_name,"""`.""",bq_processed_dataset_name,""".search_performance_fact tgt
USING
  (
  WITH
    srt_dt AS (
    SELECT
      MAX(search_date) AS search_date
    FROM
      `""",bq_project_name,"""`.""",bq_processed_dataset_name,""".search_performance_fact ),
    ty_date AS (
    SELECT
      cur.fiscal_dt cur_fiscal_date,
      cur.fiscal_year_nbr,
      cur.fiscal_week_in_year_nbr,
      cur.fiscal_day_in_week_nbr,
      cur.fiscal_quarter_begin_dt,
      cur.fiscal_year_begin_dt,
      cur.fiscal_month_begin_dt,
      p13.fiscal_dt wk_13_ty_date,
      p26.fiscal_dt wk_26_ty_date,
      p52.fiscal_dt wk_52_ty_date
    FROM (
      SELECT
        fd.fiscal_dt,
        (CASE
            WHEN fd.fiscal_week_in_year_nbr =53 THEN 52
          ELSE
          fd.fiscal_week_in_year_nbr
        END
          )fiscal_week_in_year_nbr,
        fd.fiscal_week_begin_dt,
        fd.fiscal_year_nbr,
        fd.fiscal_day_in_week_nbr,
        fd.fiscal_quarter_begin_dt,
        fd.fiscal_year_begin_dt,
        fd.fiscal_month_begin_dt,
        (CASE
            WHEN (fd.fiscal_week_in_year_nbr-12) = 0 THEN -1
          ELSE
          (fd.fiscal_week_in_year_nbr-12)
        END
          ) wk_13_wk_nbr,
        (CASE
            WHEN (fd.fiscal_week_in_year_nbr-12) <= 0 THEN fd.fiscal_year_nbr-1
          ELSE
          fd.fiscal_year_nbr
        END
          ) wk_13_yr_nbr,
        (CASE
            WHEN (fd.fiscal_week_in_year_nbr-25) = 0 THEN -1
          ELSE
          (fd.fiscal_week_in_year_nbr-25)
        END
          ) wk_26_wk_nbr,
        (CASE
            WHEN (fd.fiscal_week_in_year_nbr-25) <= 0 THEN fd.fiscal_year_nbr-1
          ELSE
          fd.fiscal_year_nbr
        END
          ) wk_26_yr_nbr,
        (CASE
            WHEN (fd.fiscal_week_in_year_nbr-51) = 0 THEN -1
          ELSE
          (fd.fiscal_week_in_year_nbr-51)
        END
          ) wk_52_wk_nbr,
        (CASE
            WHEN (fd.fiscal_week_in_year_nbr-51)<= 0 THEN fd.fiscal_year_nbr-1
          ELSE
          fd.fiscal_year_nbr
        END
          ) wk_52_yr_nbr
      FROM
        `""",bq_edw_project_name,"""`.""",bq_enterprise_dataset_name,""".dim_date fd
      INNER JOIN
        srt_dt
      ON
        fd.fiscal_dt=srt_dt.search_date
      WHERE
        fd.language_cd='EN'
        AND fd.fiscal_year_variant_cd='07') cur
    INNER JOIN
      `""",bq_edw_project_name,"""`.""",bq_enterprise_dataset_name,""".dim_date p13
    ON
      p13.language_cd='EN'
      AND p13.fiscal_year_variant_cd='07'
      AND p13.fiscal_year_nbr = cur.wk_13_yr_nbr
      AND p13.fiscal_dt= p13.fiscal_week_begin_dt
    INNER JOIN
      `""",bq_edw_project_name,"""`.""",bq_enterprise_dataset_name,""".dim_date p26
    ON
      p26.language_cd='EN'
      AND p26.fiscal_year_variant_cd='07'
      AND p26.fiscal_year_nbr = cur.wk_26_yr_nbr
      AND p26.fiscal_dt= p26.fiscal_week_begin_dt
    INNER JOIN
      `""",bq_edw_project_name,"""`.""",bq_enterprise_dataset_name,""".dim_date p52
    ON
      p52.language_cd='EN'
      AND p52.fiscal_year_variant_cd='07'
      AND p52.fiscal_year_nbr = cur.wk_52_yr_nbr
      AND p52.fiscal_dt= p52.fiscal_week_begin_dt
    WHERE
      p26.fiscal_week_in_year_nbr =(CASE
          WHEN cur.wk_26_wk_nbr<0 THEN p26.fiscal_year_total_week_nbr
        ELSE
        0
      END
        ) +cur.wk_26_wk_nbr
      AND p13.fiscal_week_in_year_nbr =(CASE
          WHEN cur.wk_13_wk_nbr<0 THEN p13.fiscal_year_total_week_nbr
        ELSE
        0
      END
        ) +cur.wk_13_wk_nbr
      AND p52.fiscal_week_in_year_nbr =(CASE
          WHEN cur.wk_52_wk_nbr<0 THEN p52.fiscal_year_total_week_nbr
        ELSE
        0
      END
        ) +cur.wk_52_wk_nbr),
    ly_date AS (
    SELECT
      cur_fiscal_date,
      cur.fiscal_dt ly_fiscal_date,
      cur.fiscal_week_begin_dt,
      cur.fiscal_quarter_begin_dt,
      cur.fiscal_year_begin_dt,
      cur.fiscal_month_begin_dt,
      p13.fiscal_dt wk_13_ly_date,
      p26.fiscal_dt wk_26_ly_date,
      p52.fiscal_dt wk_52_ly_date,
      cur.fiscal_year_nbr
    FROM (
      SELECT
        t.cur_fiscal_date,
        fd.fiscal_dt,
        fd.fiscal_week_in_year_nbr,
        fd.fiscal_week_begin_dt,
        fd.fiscal_year_nbr,
        fd.fiscal_quarter_begin_dt,
        fd.fiscal_year_begin_dt,
        fd.fiscal_month_begin_dt,
        (CASE
            WHEN (fd.fiscal_week_in_year_nbr-12) = 0 THEN -1
          ELSE
          (fd.fiscal_week_in_year_nbr-12)
        END
          ) wk_13_wk_nbr,
        (CASE
            WHEN (fd.fiscal_week_in_year_nbr-12) <= 0 THEN fd.fiscal_year_nbr-1
          ELSE
          fd.fiscal_year_nbr
        END
          ) wk_13_yr_nbr,
        (CASE
            WHEN (fd.fiscal_week_in_year_nbr-25) = 0 THEN -1
          ELSE
          (fd.fiscal_week_in_year_nbr-25)
        END
          ) wk_26_wk_nbr,
        (CASE
            WHEN (fd.fiscal_week_in_year_nbr-25) <= 0 THEN fd.fiscal_year_nbr-1
          ELSE
          fd.fiscal_year_nbr
        END
          ) wk_26_yr_nbr,
        (CASE
            WHEN (fd.fiscal_week_in_year_nbr-51) = 0 THEN -1
          ELSE
          (fd.fiscal_week_in_year_nbr-51)
        END
          ) wk_52_wk_nbr,
        (CASE
            WHEN (fd.fiscal_week_in_year_nbr-51)<= 0 THEN fd.fiscal_year_nbr-1
          ELSE
          fd.fiscal_year_nbr
        END
          ) wk_52_yr_nbr
      FROM
        `""",bq_edw_project_name,"""`.""",bq_enterprise_dataset_name,""".dim_date fd
      INNER JOIN
        ty_date t
      ON
        fd.fiscal_year_nbr=t.fiscal_year_nbr -1
        AND fd.fiscal_week_in_year_nbr = t.fiscal_week_in_year_nbr
        AND fd.fiscal_day_in_week_nbr = t.fiscal_day_in_week_nbr
      WHERE
        fd.language_cd='EN'
        AND fd.fiscal_year_variant_cd='07') cur
    INNER JOIN
      `""",bq_edw_project_name,"""`.""",bq_enterprise_dataset_name,""".dim_date p13
    ON
      p13.language_cd='EN'
      AND p13.fiscal_year_variant_cd='07'
      AND p13.fiscal_year_nbr = cur.wk_13_yr_nbr
      AND p13.fiscal_dt= p13.fiscal_week_begin_dt
    INNER JOIN
      `""",bq_edw_project_name,"""`.""",bq_enterprise_dataset_name,""".dim_date p26
    ON
      p26.language_cd='EN'
      AND p26.fiscal_year_variant_cd='07'
      AND p26.fiscal_year_nbr = cur.wk_26_yr_nbr
      AND p26.fiscal_dt= p26.fiscal_week_begin_dt
    INNER JOIN
      `""",bq_edw_project_name,"""`.""",bq_enterprise_dataset_name,""".dim_date p52
    ON
      p52.language_cd='EN'
      AND p52.fiscal_year_variant_cd='07'
      AND p52.fiscal_year_nbr = cur.wk_52_yr_nbr
      AND p52.fiscal_dt= p52.fiscal_week_begin_dt
    WHERE
      p13.fiscal_week_in_year_nbr =(CASE
          WHEN cur.wk_13_wk_nbr<0 THEN p13.fiscal_year_total_week_nbr
        ELSE
        0
      END
        ) +cur.wk_13_wk_nbr
      AND p26.fiscal_week_in_year_nbr =(CASE
          WHEN cur.wk_26_wk_nbr<0 THEN p26.fiscal_year_total_week_nbr
        ELSE
        0
      END
        ) +cur.wk_26_wk_nbr
      AND p52.fiscal_week_in_year_nbr =(CASE
          WHEN cur.wk_52_wk_nbr<0 THEN p52.fiscal_year_total_week_nbr
        ELSE
        0
      END
        ) +cur.wk_52_wk_nbr ),
    lly_date AS (
    SELECT
      cur_fiscal_date,
      cur.fiscal_dt ly_fiscal_date,
      cur.fiscal_week_begin_dt,
      cur.fiscal_quarter_begin_dt,
      cur.fiscal_year_begin_dt,
      cur.fiscal_month_begin_dt,
      p13.fiscal_dt wk_13_ly_date,
      p26.fiscal_dt wk_26_ly_date,
      p52.fiscal_dt wk_52_ly_date,
      cur.fiscal_year_nbr
    FROM (
      SELECT
        t.cur_fiscal_date,
        fd.fiscal_dt,
        fd.fiscal_week_in_year_nbr,
        fd.fiscal_week_begin_dt,
        fd.fiscal_year_nbr,
        fd.fiscal_quarter_begin_dt,
        fd.fiscal_year_begin_dt,
        fd.fiscal_month_begin_dt,
        (CASE
            WHEN (fd.fiscal_week_in_year_nbr-12) = 0 THEN -1
          ELSE
          (fd.fiscal_week_in_year_nbr-12)
        END
          ) wk_13_wk_nbr,
        (CASE
            WHEN (fd.fiscal_week_in_year_nbr-12) <= 0 THEN fd.fiscal_year_nbr-1
          ELSE
          fd.fiscal_year_nbr
        END
          ) wk_13_yr_nbr,
        (CASE
            WHEN (fd.fiscal_week_in_year_nbr-25) = 0 THEN -1
          ELSE
          (fd.fiscal_week_in_year_nbr-25)
        END
          ) wk_26_wk_nbr,
        (CASE
            WHEN (fd.fiscal_week_in_year_nbr-25) <= 0 THEN fd.fiscal_year_nbr-1
          ELSE
          fd.fiscal_year_nbr
        END
          ) wk_26_yr_nbr,
        (CASE
            WHEN (fd.fiscal_week_in_year_nbr-51) = 0 THEN -1
          ELSE
          (fd.fiscal_week_in_year_nbr-51)
        END
          ) wk_52_wk_nbr,
        (CASE
            WHEN (fd.fiscal_week_in_year_nbr-51)<= 0 THEN fd.fiscal_year_nbr-1
          ELSE
          fd.fiscal_year_nbr
        END
          ) wk_52_yr_nbr
      FROM
        `""",bq_edw_project_name,"""`.""",bq_enterprise_dataset_name,""".dim_date fd
      INNER JOIN
        ty_date t
      ON
        fd.fiscal_year_nbr=t.fiscal_year_nbr -2
        AND fd.fiscal_week_in_year_nbr = t.fiscal_week_in_year_nbr
        AND fd.fiscal_day_in_week_nbr = t.fiscal_day_in_week_nbr
      WHERE
        fd.language_cd='EN'
        AND fd.fiscal_year_variant_cd='07') cur
    INNER JOIN
      `""",bq_edw_project_name,"""`.""",bq_enterprise_dataset_name,""".dim_date p13
    ON
      p13.language_cd='EN'
      AND p13.fiscal_year_variant_cd='07'
      AND p13.fiscal_year_nbr = cur.wk_13_yr_nbr
      AND p13.fiscal_dt= p13.fiscal_week_begin_dt
    INNER JOIN
      `""",bq_edw_project_name,"""`.""",bq_enterprise_dataset_name,""".dim_date p26
    ON
      p26.language_cd='EN'
      AND p26.fiscal_year_variant_cd='07'
      AND p26.fiscal_year_nbr = cur.wk_26_yr_nbr
      AND p26.fiscal_dt= p26.fiscal_week_begin_dt
    INNER JOIN
      `""",bq_edw_project_name,"""`.""",bq_enterprise_dataset_name,""".dim_date p52
    ON
      p52.language_cd='EN'
      AND p52.fiscal_year_variant_cd='07'
      AND p52.fiscal_year_nbr = cur.wk_52_yr_nbr
      AND p52.fiscal_dt= p52.fiscal_week_begin_dt
    WHERE
      p13.fiscal_week_in_year_nbr =(CASE
          WHEN cur.wk_13_wk_nbr<0 THEN p13.fiscal_year_total_week_nbr
        ELSE
        0
      END
        ) +cur.wk_13_wk_nbr
      AND p26.fiscal_week_in_year_nbr =(CASE
          WHEN cur.wk_26_wk_nbr<0 THEN p26.fiscal_year_total_week_nbr
        ELSE
        0
      END
        ) +cur.wk_26_wk_nbr
      AND p52.fiscal_week_in_year_nbr =(CASE
          WHEN cur.wk_52_wk_nbr<0 THEN p52.fiscal_year_total_week_nbr
        ELSE
        0
      END
        ) +cur.wk_52_wk_nbr )
  SELECT
    joinedkey_fingerprint,
  IF
    (DATE(pksr.search_date) >=ty_date.fiscal_year_begin_dt,
      'Y',
      'N') latest_year_ty_flg,
  IF
    (DATE(pksr.search_date) >=ty_date.fiscal_quarter_begin_dt,
      'Y',
      'N') fiscal_quarter_to_date_ty_flg,
  IF
    (DATE(pksr.search_date) >=ty_date.fiscal_month_begin_dt,
      'Y',
      'N') fiscal_month_to_date_ty_flg,
  IF
    (DATE(pksr.search_date) >= ly_date.fiscal_year_begin_dt
      AND DATE(pksr.search_date)<= ly_date.ly_fiscal_date,
      'Y',
      'N') latest_year_ly_flg,
  IF
    (DATE(pksr.search_date) >= ly_date.fiscal_quarter_begin_dt
      AND DATE(pksr.search_date)<= ly_date.ly_fiscal_date,
      'Y',
      'N') fiscal_quarter_to_date_ly_flg,
  IF
    (DATE(pksr.search_date) >= ly_date.fiscal_month_begin_dt
      AND DATE(pksr.search_date)<= ly_date.ly_fiscal_date,
      'Y',
      'N') fiscal_month_to_date_ly_flg,
  IF
    (DATE(pksr.search_date) >= ll.fiscal_year_begin_dt
      AND DATE(pksr.search_date)<= ll.ly_fiscal_date,
      'Y',
      'N') latest_year_lly_flg,
  IF
    (DATE(pksr.search_date) >= ll.fiscal_quarter_begin_dt
      AND DATE(pksr.search_date)<= ll.ly_fiscal_date,
      'Y',
      'N') fiscal_quarter_to_date_lly_flg,
  IF
    (DATE(pksr.search_date) >= ll.fiscal_month_begin_dt
      AND DATE(pksr.search_date)<= ll.ly_fiscal_date,
      'Y',
      'N') fiscal_month_to_date_lly_flg,
  IF
    (pksr.fiscal_year_nbr = ly_date.fiscal_year_nbr,
      'Y',
      'N') previous_year_ty_flg,
  IF
    (pksr.fiscal_year_nbr = ll.fiscal_year_nbr,
      'Y',
      'N') previous_year_ly_flg,
  IF
    (DATE(pksr.search_date) > ty_date.wk_13_ty_date,
      'Y',
      'N') latest_rolling_13_weeks_flg,
  IF
    (DATE(pksr.search_date) > ty_date.wk_26_ty_date,
      'Y',
      'N') latest_rolling_26_weeks_flg,
  IF
    (DATE(pksr.search_date) > ty_date.wk_52_ty_date,
      'Y',
      'N') latest_rolling_52_weeks_flg,
  IF
    (DATE(pksr.search_date) BETWEEN ly_date.wk_13_ly_date
      AND ly_date.ly_fiscal_date,
      'Y',
      'N') previous_rolling_13_weeks_flg,
  IF
    (DATE(pksr.search_date) BETWEEN ly_date.wk_26_ly_date
      AND ly_date.ly_fiscal_date,
      'Y',
      'N') previous_rolling_26_weeks_flg,
  IF
    (DATE(pksr.search_date) BETWEEN ly_date.wk_52_ly_date
      AND ly_date.ly_fiscal_date,
      'Y',
      'N') previous_rolling_52_weeks_flg,
  IF
    (DATE(pksr.search_date) BETWEEN ll.wk_13_ly_date
      AND ll.ly_fiscal_date,
      'Y',
      'N') previous_ly_rolling_13_weeks_flg,
  IF
    (DATE(pksr.search_date) BETWEEN ll.wk_26_ly_date
      AND ll.ly_fiscal_date,
      'Y',
      'N') previous_ly_rolling_26_weeks_flg,
  IF
    (DATE(pksr.search_date) BETWEEN ll.wk_52_ly_date
      AND ll.ly_fiscal_date,
      'Y',
      'N') previous_ly_rolling_52_weeks_flg
  FROM
    `""",bq_project_name,"""`.""",bq_processed_dataset_name,""".search_performance_fact pksr
  CROSS JOIN
    ty_date
  CROSS JOIN
    ly_date
  CROSS JOIN
    lly_date ll
	WHERE EXTRACT(YEAR FROM pksr.search_date) >= ll.fiscal_year_nbr - 2)src
ON
  src.joinedkey_fingerprint= tgt.joinedkey_fingerprint
  WHEN MATCHED
  THEN
UPDATE
SET
  tgt.latest_year_ty_flg = src.latest_year_ty_flg,
  tgt.fiscal_quarter_to_date_ty_flg = src.fiscal_quarter_to_date_ty_flg,
  tgt.fiscal_month_to_date_ty_flg = src.fiscal_month_to_date_ty_flg,
  tgt.latest_year_ly_flg = src.latest_year_ly_flg,
  tgt.fiscal_quarter_to_date_ly_flg = src.fiscal_quarter_to_date_ly_flg,
  tgt.fiscal_month_to_date_ly_flg = src.fiscal_month_to_date_ly_flg,
  tgt.latest_year_lly_flg = src.latest_year_lly_flg,
  tgt.fiscal_quarter_to_date_lly_flg = src.fiscal_quarter_to_date_lly_flg,
  tgt.fiscal_month_to_date_lly_flg = src.fiscal_month_to_date_lly_flg,
  tgt.previous_year_ty_flg = src.previous_year_ty_flg,
  tgt.previous_year_ly_flg = src.previous_year_ly_flg,
  tgt.latest_rolling_13_weeks_flg = src.latest_rolling_13_weeks_flg,
  tgt.latest_rolling_26_weeks_flg = src.latest_rolling_26_weeks_flg,
  tgt.latest_rolling_52_weeks_flg = src.latest_rolling_52_weeks_flg,
  tgt.previous_rolling_13_weeks_flg = src.previous_rolling_13_weeks_flg,
  tgt.previous_rolling_26_weeks_flg = src.previous_rolling_26_weeks_flg,
  tgt.previous_rolling_52_weeks_flg = src.previous_rolling_52_weeks_flg,
  tgt.previous_ly_rolling_13_weeks_flg = src.previous_ly_rolling_13_weeks_flg,
  tgt.previous_ly_rolling_26_weeks_flg = src.previous_ly_rolling_26_weeks_flg,
  tgt.previous_ly_rolling_52_weeks_flg = src.previous_ly_rolling_52_weeks_flg;
  

""");

EXECUTE IMMEDIATE update_flags_sql;

	EXCEPTION WHEN ERROR THEN
		SELECT  
		ERROR (
			CONCAT(
					@@error.message ,' ' ,
					@@error.statement_text, ' ' ,
					@@error.formatted_stack_trace ,' '
				)
			)
		;

	END
 