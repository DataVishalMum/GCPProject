  /*
Purpose of the stored proc: 
	- Incremental Load into fact table

History of Changes:
	02/01 – first version
Author : 
	Pawan Rathod
How to Call:
	CALL
	transient.sp_profitero_keyword_search_product_level_fact
	(
		4208,
		'ecomm-dlf-dev-01cd47',
		'edw-prd-e567f9',
		'transient',
		'processed',
		'enterprise',
		'KEYWORD_SEARCH_RANK',
		'profitero_keyword_search_ranking_processed_zero'
	)
	
	*/
	

create procedure IF NOT EXISTS
	  transient.sp_profitero_keyword_search_product_level_fact
	  ( job_run_id INT64,
		bq_project_name string,
		bq_edw_project_name string,
		bq_transient_dataset_name string,
		bq_processed_dataset_name string,
		bq_enterprise_dataset_name string,
		customer_name string,
		src_table_name string )
BEGIN
	  -- declare variables
    DECLARE sql,update_flags_sql STRING;
    DECLARE
      month_begin_dt,
      max_end_date,
      prev_month_begin_dt,
      prev_month_end_dt,
      month_end_dt TIMESTAMP;
    DECLARE fiscal_year_nbr_val INT64;

    EXECUTE IMMEDIATE
      CONCAT("""
      SELECT
        CAST(DATE_TRUNC(CAST(MAX(DATE(search_date)) AS date), WEEK(MONDAY)) AS TIMESTAMP)
      FROM
        `""",bq_project_name,"""`.""",bq_transient_dataset_name,""".""",src_table_name) INTO max_end_date;

    EXECUTE IMMEDIATE
      CONCAT("""
      SELECT
        AS STRUCT CAST(MAX(fiscal_month_begin_dt) AS TIMESTAMP) AS month_begin_dt, CAST(MAX(fiscal_month_end_dt) AS TIMESTAMP) AS month_end_dt
      FROM
        `""",bq_edw_project_name,"""`.""",bq_enterprise_dataset_name,""".dim_date
      WHERE
        DATE_TRUNC(CAST(fiscal_month_end_dt AS date), WEEK(MONDAY)) <= CAST(@end_dt AS DATE)""") INTO month_begin_dt,
      month_end_dt
    USING
      max_end_date AS end_dt;

    EXECUTE IMMEDIATE
      CONCAT("""
      SELECT
        AS STRUCT CAST(MAX(fiscal_month_begin_dt) AS TIMESTAMP) AS month_begin_dt, CAST(MAX(fiscal_month_end_dt) AS TIMESTAMP) AS month_end_dt
      FROM
        `""",bq_edw_project_name,"""`.""",bq_enterprise_dataset_name,""".dim_date
      WHERE
        fiscal_month_end_dt <= CAST(@end_dt AS DATE)""") INTO prev_month_begin_dt,
      prev_month_end_dt
    USING
      month_begin_dt AS end_dt;

    EXECUTE IMMEDIATE
       CONCAT("""
       SELECT
            max(fiscal_year_nbr) as fiscal_year_nbr
       FROM  `""",bq_edw_project_name,""".enterprise.dim_date`
       WHERE
            current_date() = fiscal_dt
            AND language_cd='EN'
            AND fiscal_year_variant_cd = '07'
    """) INTO fiscal_year_nbr_val;

	EXECUTE IMMEDIATE
	 CONCAT("""
	   TRUNCATE TABLE `""",bq_project_name,"""`.""",bq_processed_dataset_name,""".profitero_keyword_search_product_level
	 """);

	EXECUTE IMMEDIATE
	 CONCAT("""
	INSERT INTO `""",bq_project_name,"""`.""",bq_processed_dataset_name,""".profitero_keyword_search_product_level
	(
        SELECT * EXCEPT (rn) FROM (
            SELECT *,row_number() over(PARTITION BY joinedkey_fingerprint order by search_date asc)  as rn
            FROM
            (
                SELECT
                    FARM_FINGERPRINT( concat (pksr.search_date
		        	, COALESCE(pksr.retailer,'NULL')
		        	, COALESCE(pksr.upc,'NULL')
		        	, COALESCE(pksr.ean,'NULL')
		        	, COALESCE(pksr.rpc,'NULL')
		        	, COALESCE(cast(pksr.actual_rank as string) ,'NULL')
		        	, COALESCE(cast(pksr.page_placement as string) ,'NULL')
		        	, COALESCE(lstn.operating_unit,'NULL')
		        	, COALESCE(pksr.keyword,'NULL')
		        	, COALESCE(lstn.category,'NULL'))) as joinedkey_fingerprint,
                     search_date,
                     lower(pksr.keyword) as search_term,
                     pksr.retailer,
                     exsc.customer_parent,
                     exsc.customer_account,
                     pksr.upc,
                     pksr.rpc,
                     pksr.ean,
                     pksr.product_title,
                     pksr.product_title_clnsd,
                     pksr.is_sponsored,
                     pksr.brand,
                     pksr.sub_brand,
                     pksr.manufacturer,
                     SAFE_CAST(pksr.actual_rank as INT64) as actual_rank,
                     (CASE
                         WHEN SAFE_CAST(pksr.actual_rank as INT64) <=5 THEN 0.5
                         WHEN SAFE_CAST(pksr.actual_rank as INT64) BETWEEN 6
                       AND 10 THEN 0.3
                         WHEN SAFE_CAST(pksr.actual_rank as INT64) BETWEEN 11 AND 15 THEN 0.15
                       ELSE
                       0.05
                     END
                       ) rnk_weightage,
                   	CAST(CAST(exsc.customer_weight AS numeric) AS FLOAT64) AS cust_weightage,
                    TRIM(lstn.keyword_type) as keyword_type,
                    TRIM(lstn.operating_unit) as ou,
                    TRIM(lstn.category) as category,
                    TRIM(exsc.location) as location,
                   	fd.fiscal_year_nbr as fiscal_year_nbr,
                   	fd.fiscal_month_in_year_nbr as fiscal_month_in_year_nbr,
                   	fd.fiscal_year_week_nbr as fiscal_year_week_nbr,
                   	fd.fiscal_year_month_nbr as fiscal_year_month_nbr,
                   	fd.fiscal_quarter_in_year_nbr as fiscal_quarter_in_year_nbr,
                   	fd.fiscal_month_in_year_short_desc as fiscal_month_in_year_short_desc,
                    CASE
                      WHEN (DATE(search_date) >= CAST(LEFT('""",month_begin_dt,"""',10) AS DATE)
                             AND DATE(search_date) <= CAST(LEFT('""",month_end_dt,"""',10) AS DATE))
                        THEN 'Y'
                      ELSE 'N'
                    END AS latest_completed_fiscal_month_fg,
                    CASE
                      WHEN (DATE(search_date) >= CAST(LEFT('""",prev_month_begin_dt,"""',10) AS DATE)
                             AND DATE(search_date) <= CAST(LEFT('""",prev_month_end_dt,"""',10) AS DATE))
                        THEN 'Y'
                      ELSE 'N'
                    END  AS previous_completed_fiscal_month_fg
                FROM
                  `""",bq_project_name,"""`.""",bq_transient_dataset_name,""".""",src_table_name,""" pksr
                INNER JOIN
                  `""",bq_edw_project_name,"""`.""",bq_enterprise_dataset_name,""".dim_date fd
                        ON
                          fd.fiscal_dt = DATE(search_date)
                          AND fd.language_cd='EN'
                          AND fd.fiscal_year_variant_cd='07'
                LEFT JOIN
                  `""",bq_project_name,"""`.""",bq_processed_dataset_name,""".lkp_new_search_regex_customer exsc
                        ON
                          CAST(exsc.fiscal_year AS INT64)=CAST(fd.fiscal_year_nbr AS INT64)
                             AND
                          (CASE
                               WHEN exsc.regex_match LIKE '%[^<>]%'
                                    THEN REGEXP_CONTAINS(LOWER(TRIM(pksr.retailer)), SPLIT(exsc.regex_match,'[^<>]')[ OFFSET (0)]) AND NOT REGEXP_CONTAINS(LOWER(TRIM(pksr.retailer)), SPLIT(exsc.regex_match,'[^<>]')[ OFFSET (1)])
                                ELSE REGEXP_CONTAINS(LOWER(TRIM(pksr.retailer)), exsc.regex_match )
                          END)
                INNER JOIN
                  `""",bq_project_name,"""`.""",bq_processed_dataset_name,""".lkp_new_search_term lstn
                        ON LOWER(pksr.keyword) = lower(lstn.search_term)
                WHERE
                  CAST(fd.fiscal_year_nbr as int64) BETWEEN CAST(""",fiscal_year_nbr_val,""" as int64)-2 AND CAST(""",fiscal_year_nbr_val,""" as int64)
                  AND SAFE_CAST(pksr.page_placement AS INT64) =1
                  AND SAFE_CAST(pksr.actual_rank AS INT64) <=20
                  AND COALESCE(TRIM(lstn.category),'')<>''
                  AND COALESCE(TRIM(exsc.customer_account),'')<>''
            )q
        )dedup where rn=1
    );
""");

EXCEPTION WHEN ERROR THEN
	SELECT
	ERROR (
		CONCAT(
				@@error.message ,' ' ,
				@@error.statement_text, ' ' ,
				@@error.formatted_stack_trace ,' '
			)
		)
	;

END
 