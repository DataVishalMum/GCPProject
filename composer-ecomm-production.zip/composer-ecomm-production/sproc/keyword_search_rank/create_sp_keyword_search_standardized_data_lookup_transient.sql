/*
Purpose of the stored proc: 
	This stored procedure processes the history data
	Map the source UPC to cleansed UPC
    Calculate the correct value of the UPC using harmonized UPC table
    Map source product title to cleansed product title
    Standardize product title and UPC, so that UPC and product title make a unique pair

History of Changes:
	08/13 – first version 
Author : 
	Swati Thakur

CALL transient.ecomm_sproc_keyword_search_standardized_data_lookup
(
	'ecomm-dlf-dev-01cd47',
	'transient',
	'shareddata-prd-cb5872',
	'sales_ecomm_global_sales_and_share',
	'shareddata-prd-cb5872',
	'shared_data_ecom',
	'profitero_keyword_search_ranking_raw_v'
)

*/
CREATE PROCEDURE IF NOT EXISTS transient.ecomm_sproc_keyword_search_standardized_data_lookup
(
	DEST_PROJECT STRING,
	DEST_DATASET STRING,
	SRC_PROJECT STRING,
    SRC_DATASET STRING,
    INTERMEDIATE_PROJECT STRING,
	INTERMEDIATE_DATASET STRING,
	SRC_TABLE STRING,
	FEED_NAME STRING
)
BEGIN

DECLARE SQL STRING;

DECLARE JOB_RUN_ID DEFAULT 999999;
DECLARE BQ_PROJECT_NAME DEFAULT DEST_PROJECT;
DECLARE BQ_TRANSIENT_DATASET_NAME DEFAULT DEST_DATASET;
DECLARE BQ_SRC_PROJECT_NAME DEFAULT SRC_PROJECT;
DECLARE BQ_ECOM_DATASET_NAME DEFAULT SRC_DATASET;
DECLARE BQ_EDW_PROJECT_NAME DEFAULT INTERMEDIATE_PROJECT;
DECLARE BQ_ENTERPRISE_DATASET_NAME DEFAULT INTERMEDIATE_DATASET;
DECLARE SRC_TABLE_NAME DEFAULT SRC_TABLE;

SET FEED_NAME = UPPER(FEED_NAME);

/*
Processes the source table data to 
Map the source UPC to cleansed UPC
Calculate the correct value of the UPC using harmonized UPC table 
Map source product title to cleansed product title
Standardize product title and UPC, so that UPC and product title make a unique pair
If the product title already exists, it updates it, otherwise inserts a new record.
*/

SET SQL =
CONCAT("""
MERGE INTO
  `""",BQ_PROJECT_NAME,""".""",BQ_TRANSIENT_DATASET_NAME,""".keyword_search_standardized_data_lookup` AS lkp_data
USING
  (
  WITH
    src_data AS (
    SELECT
      DISTINCT upc,
      product_title,
	  retailer,
      date     
    FROM
      `""",BQ_SRC_PROJECT_NAME,""".""",BQ_ECOM_DATASET_NAME,""".""",SRC_TABLE_NAME,"""`)
,

    cleansed_data AS (
    SELECT
      upc,
      product_title,
	  retailer,
      date,
      processed.checkingUpcEan(upc,10,14) cleansed_upc,
		processed.amazonProductTitle(product_title) cleansed_prod_title
    FROM
      src_data),

  -- Self tuning logic
  -- Fetches the latest UPC for a product title 

    upc_master AS (
    SELECT
      product_title,
      upc,
      ROW_NUMBER() OVER (PARTITION BY product_title ORDER BY date DESC) AS rnk
    FROM
      cleansed_data
    WHERE
      LENGTH(upc) >= 10
      AND product_title IS NOT NULL ),

    self_tuned AS (
    SELECT

    -- We fetch the latest UPC if exists, otherwise the cleansed source UPC.

      COALESCE(upc_master.upc, cleansed.upc) as upc_self_tuned, 
	  cleansed.*

    FROM
      cleansed_data cleansed
    LEFT OUTER JOIN
      upc_master upc_master
    ON
      cleansed.product_title = upc_master.product_title
      AND upc_master.rnk = 1)

  SELECT
    * EXCEPT(rnk)
  FROM (
    SELECT
      DISTINCT s.upc,
      s.cleansed_upc,
      coalesce(xref.upc, s.upc_self_tuned) as  calculated_upc,
      s.product_title,
      s.cleansed_prod_title cleansed_product_title,
	  s.retailer,
      ROW_NUMBER() OVER (PARTITION BY s.cleansed_upc, s.product_title ORDER BY s.date DESC) rnk
    FROM
      self_tuned s
    LEFT OUTER JOIN
      `""",BQ_EDW_PROJECT_NAME,""".""",BQ_ENTERPRISE_DATASET_NAME,""".ecom_data_harmonized_upc_xref` xref
    ON
      s.cleansed_prod_title = xref.product_title
   )
  WHERE
    rnk = 1
    AND coalesce(cleansed_upc,
      product_title,
      'null') <> 'null')delta_data
ON
  COALESCE(lkp_data.upc,
    'null') = COALESCE(delta_data.upc,
    'null')
  AND COALESCE(lkp_data.product_title,
    'null') = COALESCE(delta_data.product_title,
    'null')
  
  WHEN MATCHED THEN UPDATE SET lkp_data.upc = delta_data.upc,
   lkp_data.cleansed_upc = delta_data.cleansed_upc,
    lkp_data.calculated_upc = delta_data.calculated_upc,
	lkp_data.retailer = delta_data.retailer,
	 lkp_data.product_title = delta_data.product_title,
	  lkp_data.cleansed_product_title = delta_data.cleansed_product_title,
	    modified_by = '""",JOB_RUN_ID,"""',
		 modified_datetime = current_datetime()
  WHEN NOT MATCHED
  THEN
INSERT
  (upc,
    cleansed_upc,
    calculated_upc,
	retailer,
    product_title,
    cleansed_product_title,
    created_by,
    created_datetime,
    modified_by,
    modified_datetime)
VALUES
  (delta_data.upc,
  delta_data.cleansed_upc,
  delta_data.calculated_upc,
  delta_data.retailer,
  delta_data.product_title,
  delta_data.cleansed_product_title,
  '""",JOB_RUN_ID,"""',
  current_datetime(),
  '""",JOB_RUN_ID,"""',
  current_datetime())""");
EXECUTE IMMEDIATE SQL;

EXCEPTION WHEN ERROR THEN
        EXECUTE IMMEDIATE CONCAT(
            """INSERT INTO processed.sproc_error_details (
		        SELECT
			        '""",FEED_NAME,"""' AS FEED_NAME,
                    split(split(@@error.formatted_stack_trace,'transient.')[OFFSET (1)],'[')[OFFSET(0)],
			        @@error.statement_text,
			        @@error.message,
			        current_timestamp()
	        );
	    """);

	    SELECT
	        ERROR (
	            CONCAT(
	            		@@error.message ,' ' ,
	            		@@error.statement_text, ' ' ,
	            		@@error.formatted_stack_trace ,' '
	            	)
	        );

END;