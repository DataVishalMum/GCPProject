/*
Purpose of the stored proc: 
	Consolidate attributes from audit table and hash key generation
History of Changes:
	02/01 – first version
Author : 
	Pawan Rathod
How to Call:
	call transient.sp_search_processed_zero
	(	
		112,
		'ecomm-dlf-dev-01cd47',
		'transient',
		'profitero_keyword_search_ranking_delta_temp',
		'profitero_keyword_search_ranking_processed_zero',
		'profitero_keyword_search_ranking_processed_zero_archive',
		'PROFITERO',
		'PROFITERO_KEYWORD_RANKING'
	) 
*/

CREATE PROCEDURE IF NOT EXISTS transient.sp_search_processed_zero
(
	job_run_id INT64,
	bq_project_name string,
	bq_transient_dataset_name string,
	bq_delta_temp_table string,
	bq_processed_zero_table string,
	bq_archive_table string,
	customer_name string,
	feed_name string
)
BEGIN

-- declare variables
DECLARE extract_start_date,extract_end_date Timestamp;
DECLARE max_fact_sk,rec_count INT64;
DECLARE join_condition, original_file_name_column_verification,
		except_column_list , final_except_column_list,
        file_dt_column_verification,ingest_date_column_verification,rctl_file_name_column_verification  STRING;

/* A few columns need not be fetched from Delta temp table, these will come in except_column_list variable */
SET except_column_list = 'created_by , created_datetime , modified_by, modified_datetime'  ;

/* Check the presence of 'original_file_name,file_dt,ingest_date,rctl_file_name' columns in delta temp table before adding these to exception list
	file_dt,ingest_date and rctl_file_name are not present in the DA tables. */
EXECUTE IMMEDIATE
  CONCAT("""
  WITH
    dr AS (
    SELECT
      COUNT(*) cnt
    FROM
      """,bq_transient_dataset_name,""".INFORMATION_SCHEMA.COLUMNS
    WHERE
      table_name = '""",bq_delta_temp_table,"""'
      AND column_name = 'original_file_name')
  SELECT
    CASE
      WHEN cnt = 0 THEN ' '
    ELSE
    'original_file_name,'
  END
  FROM
    dr""") INTO original_file_name_column_verification;

EXECUTE IMMEDIATE
  CONCAT("""
  WITH
    dr AS (
    SELECT
      COUNT(*) cnt
    FROM
      """,bq_transient_dataset_name,""".INFORMATION_SCHEMA.COLUMNS
    WHERE
      table_name = '""",bq_delta_temp_table,"""'
      AND column_name = 'file_dt')
  SELECT
    CASE
      WHEN cnt = 0 THEN ' '
    ELSE
    'file_dt,'
  END
  FROM
    dr""") INTO file_dt_column_verification;

EXECUTE IMMEDIATE
  CONCAT("""
  WITH
    dr AS (
    SELECT
      COUNT(*) cnt
    FROM
      """,bq_transient_dataset_name,""".INFORMATION_SCHEMA.COLUMNS
    WHERE
      table_name = '""",bq_delta_temp_table,"""'
      AND column_name = 'ingest_date')
  SELECT
    CASE
      WHEN cnt = 0 THEN ' '
    ELSE
    'ingest_date,'
  END
  FROM
    dr""") INTO ingest_date_column_verification;

EXECUTE IMMEDIATE
  CONCAT("""
  WITH
    dr AS (
    SELECT
      COUNT(*) cnt
    FROM
      """,bq_transient_dataset_name,""".INFORMATION_SCHEMA.COLUMNS
    WHERE
      table_name = '""",bq_delta_temp_table,"""'
      AND column_name = 'rctl_file_name')
  SELECT
    CASE
      WHEN cnt = 0 THEN ' '
    ELSE
    'rctl_file_name,'
  END
  FROM
    dr""") INTO rctl_file_name_column_verification;

	-- concatenate all the columns to be added to exception list
SET final_except_column_list = CONCAT(original_file_name_column_verification,file_dt_column_verification,ingest_date_column_verification,rctl_file_name_column_verification,except_column_list);

--join condition
EXECUTE IMMEDIATE
  CONCAT ("""
  SELECT
    "COALESCE(CAST(delta_temp_tbl.search_date AS STRING), '') = COALESCE(CAST(processed_zero_tbl.search_date AS STRING), '') AND COALESCE(CAST(UPPER(delta_temp_tbl.file_name) AS STRING), '') = COALESCE(CAST(UPPER(processed_zero_tbl.file_name) AS STRING), '')"
    """) INTO join_condition;

--Check if Delta temp table has new records
Execute Immediate
concat("""with cte as (select distinct search_date,file_name FROM `""",bq_project_name,"""`.""",bq_transient_dataset_name,""".""",bq_processed_zero_table,""") select count(*) from
 `""",bq_project_name,"""`.""",bq_transient_dataset_name,""".""",bq_delta_temp_table,""" delta_temp_tbl inner join cte processed_zero_tbl	on """,join_condition) into rec_count;

---Fetch Maximum surrogate key from processed fact table
Execute Immediate
concat(""" select coalesce(max(fact_sk),0) from `""",bq_project_name,"""`.""",bq_transient_dataset_name,""".""",bq_processed_zero_table)
into max_fact_sk;

---Reinstatement Handling
---Delete all records from Processed zero for given search date & file_name in delta temp to handle deleted records in restatements or rolling weeks
---Archive the matching records for given search date & file_name 1. Copy the records to Archive table 2.Delete Records from processed fact table
if rec_count <> 0 then

EXECUTE IMMEDIATE
  CONCAT ("""Insert into `""",bq_project_name,"""`.""",bq_transient_dataset_name,""".""",bq_archive_table, """
        with cte as (
        select distinct
            search_date,
            file_name
        FROM
            `""",bq_project_name,"""`.""",bq_transient_dataset_name,""".""",bq_delta_temp_table,"""
        )
        select processed_zero_tbl.* except(
        	  created_by
        	, created_datetime
        	, modified_by
        	, modified_datetime )
        	,'""",job_run_id,"""' as created_by
        	, current_datetime as created_datetime
        	,'""",job_run_id,"""' as modified_by
        	,current_datetime as modified_datetime
        from `""",bq_project_name,"""`.""",bq_transient_dataset_name,""".""",bq_processed_zero_table,""" processed_zero_tbl
        inner join cte delta_temp_tbl on """,join_condition);

--Delete already existing report date from processed-0 fact table
execute immediate
concat(""" delete from `""",bq_project_name,"""`.""",bq_transient_dataset_name,""".""",bq_processed_zero_table,"""  processed_zero_tbl
where exists
(
	Select delta_temp_tbl.*
	from `""",bq_project_name,"""`.""",bq_transient_dataset_name,""".""",bq_delta_temp_table,""" delta_temp_tbl
	where  """,join_condition,"""
)
""");

end if;

execute immediate concat("""Insert into `""",bq_project_name,"""`.""",bq_transient_dataset_name,""".""",bq_processed_zero_table,""" 
select 
	(""",max_fact_sk,""" +(ROW_NUMBER() OVER())) as fact_sk	
	,delta_temp_tbl.* except
	( """, 
        final_except_column_list,
	 """ 
 	)
	,'""",job_run_id,"""' as created_by
	,current_datetime as created_datetime
	,'""",job_run_id,"""' as modified_by
	,current_datetime as modified_datetime
	from  `""",bq_project_name,"""`.""",bq_transient_dataset_name,""".""",bq_delta_temp_table,""" delta_temp_tbl""")   ;   



EXCEPTION WHEN ERROR THEN
    SELECT  
	ERROR (
		CONCAT(
    			@@error.message ,' ' ,
    			@@error.statement_text, ' ' ,
    			@@error.formatted_stack_trace ,' '
			)
		)
	;
 
End