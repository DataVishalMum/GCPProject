	  /*
	Purpose of the stored proc: 
		Delta Data extraction for 'profitero_keyword_search_ranking' 
	History of Changes:
		01/07 – first version
		15/02 - Added upc & ean original columns
	Author : 
		Pawan Rathod
	How to Call:
		CALL
		transient.sp_profitero_keyword_search_ranking_delta_temp
		(
			'ecomm-dlf-dev-01cd47',
			'edw-dev-c119a7',
			'transient',
			'enterprise',
			'transient',
			'profitero_keyword_search_api_raw_table',
			'profitero_keyword_search_ranking',
			'profitero_keyword_search_ranking'
		)
	*/
	
	CREATE PROCEDURE IF NOT EXISTS
	  transient.ecomm_sproc_profitero_keyword_search_ranking_delta_temp (
		SRC_PROJECT STRING,
		SRC_LOOKUP_PROJECT STRING,
		SRC_DATASET STRING,
		SRC_LOOKUP_DATASET STRING,
		DEST_DATASET STRING,
		INTERMEDIATE_DATASET STRING,
		SRC_TABLE STRING,
		CUSTOMER_NAME STRING,
		FEED_NAME STRING)
	OPTIONS(
	description = """
	                CALL
	                	transient.sp_profitero_keyword_search_ranking_delta_temp
	                	(
	                		'ecomm-dlf-dev-01cd47', -- SRC_PROJECT
	                		'edw-dev-c119a7', -- SRC_LOOKUP_PROJECT
	                		'transient', -- SRC_DATASET
	                		'enterprise', -- SRC_LOOKUP_DATASET
	                		'transient', -- DEST_DATASET
	                		'processed', -- INTERMEDIATE_DATASET
	                		'profitero_keyword_search_api_raw_table', -- SRC_TABLE
	                		'profitero_keyword_search_ranking', -- profitero_keyword_search_ranking
	                		'profitero_keyword_search_ranking' -- profitero_keyword_search_ranking
	                	)
	"""
	)
	BEGIN

	DECLARE JOB_RUN_ID DEFAULT 999999;
    DECLARE BQ_PROJECT_NAME DEFAULT SRC_PROJECT;
    DECLARE BQ_EDW_PROJECT_NAME DEFAULT SRC_LOOKUP_PROJECT;
    DECLARE BQ_RAW_DATASET_NAME DEFAULT SRC_DATASET;
    DECLARE BQ_ENTERPRISE_DATASET_NAME DEFAULT SRC_LOOKUP_DATASET;
    DECLARE BQ_TRANSIENT_DATASET_NAME DEFAULT DEST_DATASET;
    DECLARE BQ_PROCESSED_DATASET_NAME DEFAULT INTERMEDIATE_DATASET;
    DECLARE RAW_TABLE_NAME DEFAULT SRC_TABLE;


	  -- declare variables

	DECLARE
	  SQL STRING;


	SET CUSTOMER_NAME = UPPER(CUSTOMER_NAME);

    SET FEED_NAME = UPPER(FEED_NAME);

	EXECUTE IMMEDIATE
	  CONCAT("""TRUNCATE TABLE  `""",BQ_PROJECT_NAME,"""`.""",BQ_TRANSIENT_DATASET_NAME,""".""","""profitero_keyword_search_ranking_delta_temp""");
	  /*Insert Details for passed customer into 'profitero_keyword_search_ranking_delta_temp' table having ingest date greater than EXTRACT_START_DATE
	from data_extract_config table */
	SET
	  SQL = CONCAT("""insert into  `""",BQ_PROJECT_NAME,"""`.""",BQ_TRANSIENT_DATASET_NAME,""".""","""profitero_keyword_search_ranking_delta_temp
	( 
	with src_data as 
		(select  upc,product_title,date, src.* except(upc,product_title,date) from 
		 `""",BQ_PROJECT_NAME,"""`.""",BQ_RAW_DATASET_NAME,""".""",RAW_TABLE_NAME,""" src
		 ),
	
	dr as(
	SELECT
	 '""",CUSTOMER_NAME,"""' AS customer_name,
	 DATE(date) as search_date,
	 src.country ,
	 src.retailer,
	 lower(keyword) as keyword,
	 keyword_type,
	 amazon_search_frequency_rank,
	 lkp.calculated_upc as upc,
	 src.upc as upc_original,
	 CASE
	    WHEN length(src.ean) < 10 then null
	    WHEN length(src.ean) > 13 then LPAD(src.ean,15,'0')
	    ELSE src.ean
     END as ean,
	 src.ean as original_ean,
	 rpc as 	rpc,
	 product_model_number as product_model_no ,
	 src.product_title ,
	 SAFE_CAST(page_placement as int) as 	page_placement ,
	 SAFE_CAST(actual_rank as int) as 	actual_rank,
	 organic_rank,
	 sponsored_rank,
	 sponsored as 	is_sponsored,
	 _3ponly,
	 amazons_choice,
     amazon_best_seller,
     prime_pantry,
     amazon_subscribe_save,
     amazon_prime,
     amazon_addon_item,
     walmart_new,
     walmart_best_seller,
     walmart_2day_shipping,
     walmart_rollback,
     walmart_reduced_price,
     walmart_special_buy,
     walmart_clearance,
     only_at_walmart,
	 SAFE_CAST(number_of_images as int) as 	number_of_images,
	 is_keyword_title as is_keyword_title  ,
	 CAST(SAFE_CAST(star_rating as float64) as  int64) as 	star_rating,
	 SAFE_CAST(review_count as int) as 	review_count,
	 url ,
	 manufacturer ,
	 src.brand as 	brand,
	 sub_brand as 	sub_brand,
	 SAFE_CAST(profitero_id as STRING) as profitero_id,
	 account_category ,
	 account_category_2 ,
	 account_category_3 ,
	 account_category_4 ,
	 account_category_5 ,
	 account_category_6 ,
	 account_category_7,
	 lkp.cleansed_product_title as product_title_clnsd,
	 exsc.customer_parent,
	 SAFE_CAST(""",JOB_RUN_ID,""" AS string) AS created_by,
     current_datetime AS created_datetime,
     SAFE_CAST(""",JOB_RUN_ID,""" AS string) AS modified_by,
     current_datetime AS modified_datetime
	 
		-- the following ranking is done to avoid duplicates if multiple files
		-- are loaded in one run. The data is partitioned on the natural key 
		-- of the file. The data is then ordered descending on file_dt which is 
		-- the timestamp on the file.  Picking rank = 1 will result in the record 
		-- with latest file_dt being picked in case duplicate records
		-- exist in the raw table ***across different files***.
	 
	 , dense_rank() over (
								partition by  timestamp(date),src.retailer,actual_rank,page_placement,lower(keyword)
								order by 
									src.ingest_date desc
							) rnk_1
							
		
		-- the following ranking is done to avoid duplicates if the ****same file
		-- is loaded multiple times****. The data is partitioned on the natural key 
		-- of the file and the file_dt which is the timestamp on the file
		-- The data is then ordered descending on ingest_date which is the current timestamp
		-- coming from the ingestion framework.  Picking rank = 1 will result
		-- in the record with latest ingest_date being picked in case duplicate records
		-- exist in the raw table.  THIS SCENARIO WILL TYPICALLY NOT OCCUR.
		-- Please note the use of ROW_NUMBER function to pick one record.
		-- This function will be needed when the entire RAW table is read to reprocess history.
		
		, row_number() over (
								partition by  timestamp(date),src.retailer,actual_rank,page_placement,lower(keyword),
								src.ingest_date
								order by 
									 src.ingest_date desc
							) rnk_2
	 from src_data src 
	LEFT JOIN `""",BQ_PROJECT_NAME,""".""",BQ_TRANSIENT_DATASET_NAME,""".keyword_search_standardized_data_lookup` lkp
		on COALESCE(src.upc,'') = COALESCE(lkp.upc,'')
		AND COALESCE(src.product_title,'') = COALESCE(lkp.product_title,'')
	INNER JOIN `""",BQ_EDW_PROJECT_NAME,"""`.""",BQ_ENTERPRISE_DATASET_NAME,""".dim_date fd
                        ON
                          fd.fiscal_dt = DATE(date)
                          AND fd.language_cd='EN'
                          AND fd.fiscal_year_variant_cd='07'
    LEFT JOIN `""",BQ_PROJECT_NAME,"""`.""",BQ_PROCESSED_DATASET_NAME,""".lkp_new_search_regex_customer exsc
                        ON
                          CAST(exsc.fiscal_year AS INT64)=CAST(fd.fiscal_year_nbr AS INT64)
                             AND
                          (CASE
                               WHEN exsc.regex_match LIKE '%[^<>]%'
                                    THEN REGEXP_CONTAINS(LOWER(TRIM(src.retailer)), SPLIT(exsc.regex_match,'[^<>]')[ OFFSET (0)]) AND NOT REGEXP_CONTAINS(LOWER(TRIM(src.retailer)), SPLIT(exsc.regex_match,'[^<>]')[ OFFSET (1)])
                                ELSE REGEXP_CONTAINS(LOWER(TRIM(src.retailer)), exsc.regex_match )
                          END)
	 )
	 select
		search_date
		,country
		,customer_name
		,retailer
		,keyword
		,keyword_type
		,amazon_search_frequency_rank
		,upc
		,upc_original
		,ean
		,ean as original_ean
		,rpc
		,product_model_no
		,product_title
		,page_placement
		,actual_rank
		,organic_rank
        ,sponsored_rank
		,is_sponsored
		,_3ponly
		,amazons_choice
        ,amazon_best_seller
        ,prime_pantry
        ,amazon_subscribe_save
        ,amazon_prime
        ,amazon_addon_item
        ,walmart_new
        ,walmart_best_seller
        ,walmart_2day_shipping
        ,walmart_rollback
        ,walmart_reduced_price
        ,walmart_special_buy
        ,walmart_clearance
        ,only_at_walmart
		,number_of_images
		,is_keyword_title
		,star_rating
		,review_count
		,url
		,manufacturer
		,brand
		,sub_brand
		,profitero_id
		,account_category
		,account_category_2
		,account_category_3
		,account_category_4
		,account_category_5
		,account_category_6
		,account_category_7
		,product_title_clnsd
		,customer_parent
		,created_by
		,created_datetime
		,modified_by
		,modified_datetime

	 from dr
	 where 
			rnk_1 = 1 and rnk_2 = 1)
	""");

	EXECUTE IMMEDIATE SQL;

	EXCEPTION WHEN ERROR THEN
        EXECUTE IMMEDIATE CONCAT(
            """INSERT INTO processed.sproc_error_details (
		        SELECT
			        '""",FEED_NAME,"""' AS FEED_NAME,
                    split(split(@@error.formatted_stack_trace,'transient.')[OFFSET (1)],'[')[OFFSET(0)],
			        @@error.statement_text,
			        @@error.message,
			        current_timestamp()
	        );
	    """);

	    SELECT
	        ERROR (
	            CONCAT(
	            		@@error.message ,' ' ,
	            		@@error.statement_text, ' ' ,
	            		@@error.formatted_stack_trace ,' '
	            	)
	        );
    END  ;