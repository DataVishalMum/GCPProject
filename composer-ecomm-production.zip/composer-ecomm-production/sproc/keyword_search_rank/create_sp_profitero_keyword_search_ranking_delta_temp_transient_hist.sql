	  /*
	Purpose of the stored proc: 
		History Load for 'profitero_keyword_search_ranking' 
	History of Changes:
		23/07 – first version
		15/02 - Added upc & ean original columns
	Author : 
		Pawan Rathod
	How to Call:
		CALL
		transient.sp_profitero_keyword_search_ranking_delta_temp_hist
		(
			999999,
			'ecomm-dlf-dev-01cd47',
			'shareddata-prd-cb5872',
			'sales_ecomm_global_sales_and_share',
			'transient',			
			'KEYWORD_SEARCH_RANK',
			'profitero_keyword_search_ranking_raw_v',
			'profitero_keyword_search_ranking'
		)
	*/
	
	
	
	CREATE PROCEDURE IF NOT EXISTS
	  transient.ecomm_sproc_profitero_keyword_search_ranking_delta_temp_hist (
		DEST_PROJECT STRING,
		SRC_PROJECT STRING,
		SRC_DATASET STRING,
		DEST_DATASET STRING,
		SRC_TABLE STRING,
		CUSTOMER_NAME STRING,
		FEED_NAME STRING)
	BEGIN
	  -- declare variables

    DECLARE JOB_RUN_ID DEFAULT 999999;
    DECLARE BQ_PROJECT_NAME DEFAULT DEST_PROJECT;
    DECLARE BQ_EDW_PROJECT_NAME DEFAULT SRC_PROJECT;
    DECLARE BQ_ECOM_DATASET_NAME DEFAULT SRC_DATASET;
    DECLARE BQ_TRANSIENT_DATASET_NAME DEFAULT DEST_DATASET;
    DECLARE RAW_TABLE_NAME DEFAULT SRC_TABLE;

	DECLARE
	  SQL STRING;
	  -- Get Extract start datetime for incoming table from data_extract_config table

	SET CUSTOMER_NAME = UPPER(CUSTOMER_NAME);

    SET FEED_NAME = UPPER(FEED_NAME);

	EXECUTE IMMEDIATE
	  CONCAT("""TRUNCATE TABLE  `""",BQ_PROJECT_NAME,"""`.""",BQ_TRANSIENT_DATASET_NAME,""".""","""profitero_keyword_search_ranking_delta_temp""");
	  /*Insert Details for passed customer into 'profitero_keyword_search_ranking_delta_temp' table having ingest date greater than extract_start_date 
	from data_extract_config table */
	SET
	  SQL = CONCAT("""insert into  `""",BQ_PROJECT_NAME,"""`.""",BQ_TRANSIENT_DATASET_NAME,""".""","""profitero_keyword_search_ranking_delta_temp
	( 
	with src_data as 
		(select  upc,product_title,date, src.* except(upc,product_title,date) from 
		 `""",BQ_EDW_PROJECT_NAME,"""`.""",BQ_ECOM_DATASET_NAME,""".""",RAW_TABLE_NAME,""" src
		 
		 ),
	
	dr as(
	SELECT
	 '""",CUSTOMER_NAME,"""' AS customer_name,
	 DATE(TRIM(date)) as search_date,
	 country ,
	 src.retailer,
	 lower(keyword) as keyword,
	 keyword_type,
	 amazon_search_frequency_rank,
	 lkp.calculated_upc as upc,
	 src.upc as upc_original,
	 CASE
	    WHEN length(src.ean) < 10 then null
	    WHEN length(src.ean) > 13 then LPAD(src.ean,15,'0')
	    ELSE src.ean
     END as ean,
	 src.ean as original_ean,
	 rpc as 	rpc,
	 product_model_number as product_model_no ,
	 src.product_title ,
	 SAFE_CAST(page_placement as int) as 	page_placement ,
	 SAFE_CAST(actual_rank as int) as 	actual_rank,
	 organic_rank,
	 sponsored_rank,
	 sponsored as 	is_sponsored,
	 _3ponly,
	 amazons_choice,
     amazon_best_seller,
     prime_pantry,
     amazon_subscribe_save,
     amazon_prime,
     amazon_addon_item,
     walmart_new,
     walmart_best_seller,
     walmart_2day_shipping,
     walmart_rollback,
     walmart_reduced_price,
     walmart_special_buy,
     walmart_clearance,
     only_at_walmart,
	 SAFE_CAST(of_images as int) as 	number_of_images,
	 keyword_in_title as is_keyword_title ,
	 CAST(SAFE_CAST(star_rating as float64) as  int64) as 	star_rating,     
	 SAFE_CAST(review_count as int) as 	review_count,
	 url ,
	 manufacturer ,
	 src.brand as 	brand,
	 sub_brand as 	sub_brand,
	 profitero_id,
	 account_category ,
	 account_category_2 ,
	 account_category_3 ,
	 account_category_4 ,
	 account_category_5 ,
	 account_category_6 ,
	 account_category_7,
	 lkp.cleansed_product_title as product_title_clnsd,
    SAFE_CAST(""",JOB_RUN_ID,""" AS string) AS created_by,
    current_datetime AS created_datetime,
    SAFE_CAST(""",JOB_RUN_ID,""" AS string) AS modified_by,
    current_datetime AS modified_datetime
	
    -- the following ranking is done to avoid duplicates if there are duplicates
	-- for the same vendor file natural key in the raw table replicated from hadoop. 
	-- The data is partitioned on the natural key of the vendor file. 
	-- The data is then ordered descending on hadoop_update_ts which is 
	-- the create timestamp of the record in the raw table.  
	-- Picking rank = 1 will result in the record with latest create timestamp 
	-- to be selected in case duplicate records exist in the raw table 
	-- ***across different create timestamps***.
	
	
	 
	 , row_number() over (
								partition by  timestamp(trim(date)),src.retailer,actual_rank,page_placement,lower(keyword)
								order by 
									timestamp(hadoop_update_ts) desc
							) rnk_1
							
		
		
	 from src_data src 
	LEFT JOIN `""",BQ_PROJECT_NAME,""".""",BQ_TRANSIENT_DATASET_NAME,""".keyword_search_standardized_data_lookup` lkp
		on COALESCE(src.upc,'') = COALESCE(lkp.upc,'')
		AND COALESCE(src.product_title,'') = COALESCE(lkp.product_title,'')

	 
	 )
	 select
		search_date
		,country
		,customer_name
		,retailer
		,keyword
		,keyword_type
		,amazon_search_frequency_rank
		,upc
		,upc_original
		,ean
		,ean as original_ean
		,rpc
		,product_model_no
		,product_title
		,page_placement
		,actual_rank
		,organic_rank
        ,sponsored_rank
		,is_sponsored
		,_3ponly
		,amazons_choice
        ,amazon_best_seller
        ,prime_pantry
        ,amazon_subscribe_save
        ,amazon_prime
        ,amazon_addon_item
        ,walmart_new
        ,walmart_best_seller
        ,walmart_2day_shipping
        ,walmart_rollback
        ,walmart_reduced_price
        ,walmart_special_buy
        ,walmart_clearance
        ,only_at_walmart
		,number_of_images
		,is_keyword_title
		,star_rating
		,review_count
		,url
		,manufacturer
		,brand
		,sub_brand
		,profitero_id
		,account_category
		,account_category_2
		,account_category_3
		,account_category_4
		,account_category_5
		,account_category_6
		,account_category_7
		,product_title_clnsd
		,created_by
		,created_datetime
		,modified_by
		,modified_datetime
	 from dr
	 where 
			rnk_1 = 1 )
	""");

	EXECUTE IMMEDIATE SQL;

	EXCEPTION WHEN ERROR THEN
        EXECUTE IMMEDIATE CONCAT(
            """INSERT INTO processed.sproc_error_details (
		        SELECT
			        '""",FEED_NAME,"""' AS FEED_NAME,
                    split(split(@@error.formatted_stack_trace,'transient.')[OFFSET (1)],'[')[OFFSET(0)],
			        @@error.statement_text,
			        @@error.message,
			        current_timestamp()
	        );
	    """);

	    SELECT
	        ERROR (
	            CONCAT(
	            		@@error.message ,' ' ,
	            		@@error.statement_text, ' ' ,
	            		@@error.formatted_stack_trace ,' '
	            	)
	        );
    END  ;