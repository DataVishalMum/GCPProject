 /*
	Purpose of the stored proc:
		Load data from 'profiter_249 dataset'
	History of Changes:
		16/05 – first version
	Author :
		Pawan Rathod
	How to Call:
		CALL
		transient.ecomm_sproc_profitero_keyword_search_api_raw_table
		(
			"ecomm-dlf-dev-01cd47",
			"profitero_249",
			"transient",
			"profitero_keyword_search_api_raw_table",
			"profitero_keyword_search_ranking"
		)
		INSERT INTO transient.data_extract_config values ('profitero_keyword_search_api_raw_table', cast ('1800-01-01 00:00:00' as timestamp), cast ('2022-01-29 00:00:00' as timestamp), 'Y','complete','GMI',current_timestamp,'GMI',current_timestamp ) ;
		INSERT INTO transient.profitero_keyword_search_api_raw_table (date) VALUES (CAST('2022-01-29' AS DATE));
		INSERT INTO transient.gmi_customer_metadata_reference SELECT 'PROFITERO_KEYWORD_SEARCH_RANKING', 'PROFITERO_KEYWORD_SEARCH_RANKING', 'search_date,retailer,keyword,page_placement,actual_rank', 'search_date,retailer,keyword,page_placement,actual_rank', '', '', 'search_date', '', 'PROFITERO', '', '', '', 5, 'DAY';

*/

CREATE OR REPLACE PROCEDURE
  transient.ecomm_sproc_profitero_keyword_search_api_raw_table (
	SRC_PROJECT STRING,
	SRC_DATASET STRING,
	DEST_DATASET STRING,
	DEST_TABLE STRING,
	FEED_NAME STRING
	)
OPTIONS (
description = """
        CALL
		    transient.ecomm_sproc_keyword_search_api_raw_table
		(
			"ecomm-dlf-dev-01cd47", -- SRC_PROJECT
			"profitero_249", -- SRC_DATASET
			"transient", -- DEST_DATASET
			"profitero_keyword_search_api_raw_table", -- DEST_TABLE
			"profitero_keyword_search_ranking" -- FEED_NAME
		)
"""
)

BEGIN

--DECLARE MAX_DATE DATE DEFAULT "2022-01-29";
DECLARE PLK_CONDITION, CP_CONDITION STRING;
DECLARE EXTRACT_START_DATE TIMESTAMP;

SET FEED_NAME = UPPER(FEED_NAME);

-- Get Extract start & end datetime for incoming table from data_extract_config table
EXECUTE IMMEDIATE
  CONCAT("""
    SELECT MAX(extract_start_datetime)
    FROM `""",SRC_PROJECT,"""`.""",DEST_DATASET,""".data_extract_config
    WHERE table_name = '""",DEST_TABLE,"""'
  """) INTO EXTRACT_START_DATE;


SET PLK_CONDITION = (SELECT CONCAT("pl.date > DATE('",EXTRACT_START_DATE,"')"));

SET CP_CONDITION = (SELECT CONCAT("pah.date > DATE('",EXTRACT_START_DATE,"')"));

EXECUTE IMMEDIATE CONCAT(""" TRUNCATE TABLE  `""" ,SRC_PROJECT,"""`.""",DEST_DATASET,""".""",DEST_TABLE);

EXECUTE IMMEDIATE
CONCAT("""INSERT INTO `""" ,SRC_PROJECT,"""`.""",DEST_DATASET,""".""",DEST_TABLE,"""
(
with plk as (
            select pl.*, rn.type keyword_type, rn.name keyword,rn.retailer_id ret_id, rnp.*
              from """,SRC_DATASET,""".placement pl
              left join """,SRC_DATASET,""".rankings rn on rn.id = pl.ranking_id
              left join """,SRC_DATASET,""".ranking_products rnp on rnp.id = pl.ranking_product_id
          where """,PLK_CONDITION,"""
                AND rn.type != 'breadcrumb'
                AND pl.is_deleted = false
                AND rn.is_deleted = false
                AND rnp.is_deleted = false
          ),

cp as (select distinct plk.ranking_product_id as rid, pr.id, pah.customer_product_id as cid
              from plk
              left join """,SRC_DATASET,""".products pr on pr.ranking_product_id = plk.ranking_product_id
			  and pr.retailer_id = plk.ret_id
              right join """,SRC_DATASET,""".price_availability_history pah on pah.product_id = pr.id
          where """,CP_CONDITION,"""
                AND pr.id is not NULL
                AND pah.customer_product_id is not NULL
                AND pr.is_deleted = false
                AND pah.is_deleted = false
   ),
search_joined as (
select  plk.date,
        ret.country,
        ret.name as retailer,
        plk.keyword,
        plk.keyword_type,
        SAFE_CAST(plk.asfr AS STRING),
        plk.upc,
        plk.ean,
        plk.rpc,
        plk.model,
        plk.name,
        plk.page_placement,
        plk.actual_rank,
        SAFE_CAST(plk.organic_rank as STRING),
        SAFE_CAST(plk.sponsored_rank as STRING),
        SAFE_CAST(plk.sponsored as STRING),
        SAFE_CAST(plk.third_party_only as STRING),
        SAFE_CAST(plk.amazon_choice as STRING),
        SAFE_CAST(plk.amazon_bestseller as STRING),
        SAFE_CAST(plk.prime_pantry as STRING),
        SAFE_CAST(plk.amazon_subscribe_and_save as STRING),
        SAFE_CAST(plk.amazon_prime as STRING),
        SAFE_CAST(plk.amazon_addon_item as STRING),
        SAFE_CAST(plk.walmart_new as STRING),
        SAFE_CAST(plk.walmart_bestseller as STRING),
        SAFE_CAST(plk.walmart_2_day_shipping as STRING),
        SAFE_CAST(plk.walmart_rollback as STRING),
        SAFE_CAST(plk.walmart_reduced_price as STRING),
        SAFE_CAST(plk.walmart_special_buy as STRING),
        SAFE_CAST(plk.walmart_clearance as STRING),
        SAFE_CAST(plk.only_at_walmart as STRING),
        plk.number_of_images,
        SAFE_CAST(REGEXP_CONTAINS(plk.name, cast(plk.keyword as STRING)) AS STRING) AS keyword_in_title,
        SAFE_CAST(plk.star_rating AS INT64),
        SAFE_CAST(plk.review_count AS INT64),
        plk.url,
        b.owner as Manufacturer, b.brand as Brand, b.subbrand as Subbrand,
        plk.ranking_product_id as profitero_id,
        array ( select full_name
          from """,SRC_DATASET,""".categories_products t
            join """,SRC_DATASET,""".categories c on t.category_id = c.id
             where t.customer_product_id = cp.cid
         ) as `acc_categories`

from plk
  left join cp on plk.ranking_product_id = cp.rid
  join """,SRC_DATASET,""".retailers ret  on plk.retailer_id = ret.id
  join """,SRC_DATASET,""".brands b on b.id = plk.brand_id
)
select * EXCEPT(acc_categories),
acc_categories[SAFE_OFFSET(0)] account_category,
acc_categories[SAFE_OFFSET(1)] account_category_2,
acc_categories[SAFE_OFFSET(2)] account_category_3,
acc_categories[SAFE_OFFSET(3)] account_category_4,
acc_categories[SAFE_OFFSET(4)] account_category_5,
acc_categories[SAFE_OFFSET(5)] account_category_6,
acc_categories[SAFE_OFFSET(6)] account_category_7,
CAST(current_date() AS TIMESTAMP) as ingest_date
from search_joined
)""") ;

EXCEPTION WHEN ERROR THEN
    EXECUTE IMMEDIATE CONCAT(
        """INSERT INTO processed.sproc_error_details (
            SELECT
    	        '""",FEED_NAME,"""' AS FEED_NAME,
                split(split(@@error.formatted_stack_trace,'transient.')[OFFSET (1)],'[')[OFFSET(0)],
    	        @@error.statement_text,
    	        @@error.message,
    	        current_timestamp()
        );
    """);

    SELECT
        ERROR (
            CONCAT(
            		@@error.message ,' ' ,
            		@@error.statement_text, ' ' ,
            		@@error.formatted_stack_trace ,' '
            	)
        );
END ;