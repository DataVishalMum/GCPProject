/*
Purpose of the stored proc: 
	This stored procedure processes the history data
	Map the source UPC to cleansed UPC
    Calculate the correct value of the UPC using harmonized UPC table
    Map source product title to cleansed product title
    Standardize product title and UPC, so that UPC and product title make a unique pair

History of Changes:
	08/13 – first version 
Author : 
	Swati Thakur

CALL transient.sp_keyword_search_standardized_data_lookup
( 
	-99,
	'ecomm-dlf-dev-01cd47',
	'transient',
    'processed',
	'shareddata-prd-cb5872',
	'raw',
	'shared_data_ecom',
	'profitero_keyword_search_ranking'
)
*/
CREATE PROCEDURE IF NOT EXISTS transient.sp_keyword_search_standardized_data_lookup
( 
	job_run_id INT64,
	bq_project_name string,
	bq_transient_dataset_name string,
    bq_processed_dataset_name string,	
	bq_edw_project_name string,
	bq_raw_dataset_name string,
	bq_enterprise_dataset_name string,
	src_table_name string
)
BEGIN

DECLARE vendor,sql STRING;


/*
Processes the source table data to 
Map the source UPC to cleansed UPC
Calculate the correct value of the UPC using harmonized UPC table 
Map source product title to cleansed product title
Standardize product title and UPC, so that UPC and product title make a unique pair
If the product title already exists, it updates it, otherwise inserts a new record.
*/

SET sql =
CONCAT("""
MERGE INTO
  `""",bq_project_name,""".""",bq_transient_dataset_name,""".keyword_search_standardized_data_lookup` AS lkp_data
USING
  (
  WITH
    src_data AS (
    SELECT
      DISTINCT upc,
      product_title,
	  retailer,
      date     
    FROM
      `""",bq_project_name,""".""",bq_raw_dataset_name,""".""",src_table_name,"""`)
,

    cleansed_data AS (
    SELECT
      upc,
      product_title,
	  retailer,
      date,
      processed.checkingUpcEan(upc,10,14) cleansed_upc,
		processed.amazonProductTitle(product_title) cleansed_prod_title
    FROM
      src_data),

  -- Self tuning logic
  -- Fetches the latest UPC for a product title 

    upc_master AS (
    SELECT
      product_title,
      upc,
      ROW_NUMBER() OVER (PARTITION BY product_title ORDER BY date DESC) AS rnk
    FROM
      cleansed_data
    WHERE
      LENGTH(upc) >= 10
      AND product_title IS NOT NULL ),

    self_tuned AS (
    SELECT

    -- We fetch the latest UPC if exists, otherwise the cleansed source UPC.

      COALESCE(upc_master.upc, cleansed.upc) as upc_self_tuned, 
	  cleansed.*

    FROM
      cleansed_data cleansed
    LEFT OUTER JOIN
      upc_master upc_master
    ON
      cleansed.product_title = upc_master.product_title
      AND upc_master.rnk = 1)

  SELECT
    * EXCEPT(rnk)
  FROM (
    SELECT
      DISTINCT s.upc,
      s.cleansed_upc,
      coalesce(xref.upc, s.upc_self_tuned) as  calculated_upc,
      s.product_title,
      s.cleansed_prod_title cleansed_product_title,
	  s.retailer,
      ROW_NUMBER() OVER (PARTITION BY s.cleansed_upc, s.product_title ORDER BY s.date DESC) rnk
    FROM
      self_tuned s
    LEFT OUTER JOIN
      `""",bq_edw_project_name,""".""",bq_enterprise_dataset_name,""".ecom_data_harmonized_upc_xref` xref
    ON
      s.cleansed_prod_title = xref.product_title
   )
  WHERE
    rnk = 1
    AND coalesce(cleansed_upc,
      product_title,
      'null') <> 'null')delta_data
ON
  COALESCE(lkp_data.upc,
    'null') = COALESCE(delta_data.upc,
    'null')
  AND COALESCE(lkp_data.product_title,
    'null') = COALESCE(delta_data.product_title,
    'null')
  
  WHEN MATCHED THEN UPDATE SET lkp_data.upc = delta_data.upc,
   lkp_data.cleansed_upc = delta_data.cleansed_upc,
    lkp_data.calculated_upc = delta_data.calculated_upc,
	lkp_data.retailer = delta_data.retailer,
	 lkp_data.product_title = delta_data.product_title,
	  lkp_data.cleansed_product_title = delta_data.cleansed_product_title,
	    modified_by = '""",job_run_id,"""',
		 modified_datetime = current_datetime()
  WHEN NOT MATCHED
  THEN
INSERT
  (upc,
    cleansed_upc,
    calculated_upc,
	retailer,
    product_title,
    cleansed_product_title,
    created_by,
    created_datetime,
    modified_by,
    modified_datetime)
VALUES
  (delta_data.upc,
  delta_data.cleansed_upc,
  delta_data.calculated_upc,
  delta_data.retailer,
  delta_data.product_title,
  delta_data.cleansed_product_title,
  '""",job_run_id,"""',
  current_datetime(),
  '""",job_run_id,"""',
  current_datetime())""");
EXECUTE IMMEDIATE sql;
EXCEPTION WHEN ERROR THEN
    SELECT  
	ERROR (
		CONCAT(
    			@@error.message ,' ' ,
    			@@error.statement_text, ' ' ,
    			@@error.formatted_stack_trace ,' '
			)
		)
	;
END;