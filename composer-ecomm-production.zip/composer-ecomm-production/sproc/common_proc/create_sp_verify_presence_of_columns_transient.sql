/*
Purpose of the stored proc: 
	 This PROC will verify whether given columns are present in the given tables and if yes then return the columns list in the same order

Input : 
1. Table names in a string with comma delimiter.
2. Column names in a string with comma delimiter.
Output :
Column names in a string with comma delimiter.

History of Changes:
	04/07/2021 – first version 
Author : 
	Rakesh Reddy Kalluru 
*/
CREATE PROCEDURE IF NOT EXISTS transient.ecomm_sproc__verify_presence_of_columns(
table_names STRING,
column_names STRING,
bq_project_name STRING,
dataset_name STRING,
OUT result STRING)
BEGIN
  #DECLARE variables
DECLARE
  matched_columns,
  input_columns ARRAY<string>;
DECLARE
  table_names_quoted,
  column_names_quoted string;
DECLARE
  i INT64 DEFAULT 0;
SET
  result = '';

EXECUTE IMMEDIATE
  CONCAT("""select STRING_AGG(concat("'",col,"'")) from unnest(split('""",table_names,"""')) col""") INTO table_names_quoted;
EXECUTE IMMEDIATE
  CONCAT("""select STRING_AGG(concat("'",col,"'")) from unnest(split('""",column_names,"""')) col""") INTO column_names_quoted;

--Copy the matched columns of the given column_names list if they exist in the given table_names list with the help of INFORMATION_SCHEMA.
EXECUTE IMMEDIATE
  CONCAT("""SELECT ARRAY_AGG(distinct(trim(column_name))) from `""",bq_project_name,"`.",dataset_name,""".INFORMATION_SCHEMA.COLUMNS
  WHERE
    table_name IN (""",table_names_quoted,""")
    AND column_name IN (""",column_names_quoted,""")""") INTO matched_columns;
--Convert the given column_names to an array.
EXECUTE IMMEDIATE
  CONCAT("""select split('""",column_names,"""\',',')""") INTO input_columns;
--Arrange matched columns in the order of input_columns
LOOP
SET
  i = i+1 ;
IF
  i > ARRAY_LENGTH(input_columns) THEN
LEAVE
  ;
END IF
  ;
IF
  TRIM(input_columns[ORDINAL(i)]) IN UNNEST(matched_columns) THEN
SET
  result = CONCAT(result,",",input_columns[ORDINAL(i)]);
END IF
  ;
END LOOP
  ;
SET
  result = TRIM(result,',');
END;