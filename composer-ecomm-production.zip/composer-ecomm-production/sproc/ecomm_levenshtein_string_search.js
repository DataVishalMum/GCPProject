CREATE OR REPLACE FUNCTION `ecomm-dlf-dev-01cd47`.transient.ecomm_levenshtein_string_search(string_to_match string, available_values array<STRING>)
RETURNS ARRAY<STRUCT<deviation INT64,available_value STRING, percent_match FLOAT64, string_length INT64, value_length INT64>>
LANGUAGE js AS """
  result_set = [];
  for (let i = 0; i < available_values.length; i++) {
    let current_value = available_values[i];
    let current_value_length = current_value.length;
    let string_length = string_to_match.length;
    let deviation = fuzzball.distance(string_to_match,current_value);
    //let percent_match = deviation == 0 ? 0: Math.ceil(((current_value_length - deviation)/ current_value_length) * 100);
    let percent_match = Math.ceil((1 - deviation/Math.max(string_length, current_value_length))*100);
    result_set.push(
      {
        "deviation":deviation,
        "available_value":current_value,
        "percent_match":percent_match,
        "string_length":string_length,
        "value_length":current_value_length
      }
    )
  }
result_set.sort((a, b) => (a.deviation > b.deviation) ? 1 : -1)
return result_set;
"""
OPTIONS (library="gs://fh-bigquery/js/fuzzball.umd.min.js");


CREATE OR REPLACE FUNCTION `ecomm-dlf-dev-01cd47`.transient.ecomm_levenshtein_string_search_test(string_to_match string, available_values array<STRING>)
RETURNS ARRAY<STRUCT<deviation INT64,available_value STRING, percent_match FLOAT64>>
LANGUAGE js AS """
  result_set = [];
  for (let i = 0; i < available_values.length; i++) {
    let current_value = available_values[i];
    let deviation = fuzzball.distance(string_to_match,current_value);
    let percent_match = deviation == 0 ? 0: Math.ceil(((current_value.length - deviation)/ current_value.length) * 100);
    result_set.push({"deviation":deviation,"available_value":current_value,"percent_match":percent_match})
  }
result_set.sort((a, b) => (a.deviation > b.deviation) ? 1 : -1)
return result_set;
"""
OPTIONS (library="gs://fh-bigquery/js/fuzzball.umd.min.js");