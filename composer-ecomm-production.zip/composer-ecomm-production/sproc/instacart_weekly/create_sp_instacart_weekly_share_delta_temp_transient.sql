  /* Purpose OF the stored proc : Delta Temp Table
	History OF Changes : 28/10 first version
                       06/12: Changed UPC from NULL to ALL default value to identify that is is not coming from source.
	Author : Vijayandra Mahadik
	
CALL
  transient.sp_data_extract_config_insert(-99,
    'ecomm-dlf-dev-01cd47',
    'raw',
    'transient',
    'instacart_weekly_share');
CALL
  transient.sp_instacart_weekly_share_delta_temp(-99,
    'ecomm-dlf-dev-01cd47',
    'raw',
    'transient',
    'instacart_weekly_share',
	'processed',
    'lkp_instacart_weekly_mapping',
	'instacart_weekly_share_delta_temp',
	'instacart_weekly_processed_zero',
	'INSTACART');
CALL
  transient.sp_data_extract_config_update(-99,
    'ecomm-dlf-dev-01cd47',
    'transient',
    'instacart_weekly_share');

  */
CREATE PROCEDURE IF NOT EXISTS
  transient.sp_instacart_weekly_share_delta_temp ( job_run_id INT64,
    bq_project_name STRING,
    bq_raw_dataset_name STRING,
    bq_transient_dataset_name STRING,
    bq_raw_table_name STRING,
	bq_lkp_dataset_name STRING,
	bq_lkp_table_name STRING,
    bq_delta_temp_tablename STRING,
	bq_sales_processed_zero_table_name STRING,
    customer_name STRING)
BEGIN
  -- declare variables
DECLARE
  extract_start_date,
  extract_end_date Timestamp;
  -- Get Extract start datetime for incoming table from data_extract_config table
EXECUTE IMMEDIATE
  CONCAT("""select extract_start_datetime from `""",bq_project_name,"""`.""",bq_transient_dataset_name,""".""","""data_extract_config where table_name = '""",bq_raw_table_name,"""' and status = 'running'
and active_flag = 'Y'""") INTO extract_start_date;
  -- Get Extract end datetime for incoming table from data_extract_config table
EXECUTE IMMEDIATE
  CONCAT("""select extract_end_datetime from `""",bq_project_name,"""`.""",bq_transient_dataset_name,""".""", """data_extract_config where table_name = '""",bq_raw_table_name,"""' and status = 'running'  and active_flag = 'Y'""") INTO extract_end_date;
  -- Truncate Delta Temp Table
EXECUTE IMMEDIATE
  CONCAT("""TRUNCATE TABLE  `""",bq_project_name,"""`.""",bq_transient_dataset_name,""".""",bq_delta_temp_tablename);
  /*Insert Details for passed customer into 'instacart_weekly_share_delta_temp' table having ingest date greater than extract_start_date
from data_extract_config table */
EXECUTE IMMEDIATE
  CONCAT( """insert into  `""",bq_project_name,"""`.""",bq_transient_dataset_name,""".""",bq_delta_temp_tablename,"""
WITH
  share_data AS (
  SELECT
    * EXCEPT(rnk_1,
      rnk_2)
  FROM (
    SELECT
      A.*,
      '""",job_run_id,"""' AS created_by,
      current_datetime AS created_datetime,
      '""",job_run_id,"""' AS modified_by,
      current_datetime AS modified_datetime,
      DENSE_RANK() OVER (PARTITION BY report_date, department, super_category, category, sub_category ORDER BY PARSE_TIMESTAMP("%m-%d-%Y %H:%M:%S", file_dt) DESC ) rnk_1,
      ROW_NUMBER() OVER (PARTITION BY report_date, department, super_category, category, sub_category, PARSE_TIMESTAMP("%m-%d-%Y %H:%M:%S", file_dt)
      ORDER BY
        ingest_date DESC ) rnk_2
    FROM (
       SELECT
           'WEEK' AS grain,
           'UNKNOWN' AS retailer,
           '""",customer_name,"""' AS customer_name,
           -- report date formatting
           -- %F	The date in the format %Y-%m-%d. example 2021-01-20
           cast(parse_date ("%F", shr.report_date) as timestamp) AS report_date,
           shr.department,
           shr.super_category,
           shr.category,
           shr.sub_category,
           CONCAT(COALESCE(shr.department,''),
                  COALESCE(shr.super_category,''),
                  COALESCE(shr.category,''),
                  COALESCE(shr.sub_category,'')) AS shr_lookup_key,
     	   cat_map.lookup_key,
     	   cat_map.gmi_category,
           CAST(REGEXP_REPLACE(sub_category_sales, '$', '') AS FLOAT64) AS sub_category_sales,
           CAST(REGEXP_REPLACE(sub_category_sales_ya, '$', '') AS FLOAT64) AS sub_category_sales_ya,
           shr.original_file_name,
           shr.file_dt,
           shr.rctl_uuid,
           TIMESTAMP(shr.ingest_date) AS ingest_date,
           shr.rctl_file_name
       FROM
         `""" ,bq_project_name,"""`.""",bq_raw_dataset_name,""".""",bq_raw_table_name,""" shr
       LEFT JOIN
         `""" ,bq_project_name,"""`.""",bq_lkp_dataset_name,""".""",bq_lkp_table_name,""" cat_map
       ON cat_map.lookup_key = CONCAT(COALESCE(shr.department,''),
                                      COALESCE(shr.super_category,''),
     					             COALESCE(shr.category,''),
     					             COALESCE(shr.sub_category,''))
       WHERE
            shr.ingest_date > '""",extract_start_date,"""'
     	AND shr.ingest_date <= '""",extract_end_date,"""')A )a
    WHERE
      rnk_1 = 1
      AND rnk_2 = 1
  ),
  sales_data as (
  SELECT
    report_date,
    CONCAT(COALESCE(department,''),
           COALESCE(super_category,''),
           COALESCE(category,''),
           COALESCE(sub_category,'')) AS lookup_key,
    SUM(ty_sales_value) AS total_sales
  FROM  `""" ,bq_project_name,"""`.""",bq_transient_dataset_name,""".""",bq_sales_processed_zero_table_name,"""
  GROUP BY report_date, department, super_category, category, sub_category
  ),
  gm_products as (
    SELECT
       DISTINCT
       CONCAT(COALESCE(department,''),
              COALESCE(super_category,''),
              COALESCE(category,''),
              COALESCE(sub_category,'')) AS lookup_key
    FROM  `""" ,bq_project_name,"""`.""",bq_transient_dataset_name,""".""",bq_sales_processed_zero_table_name,"""
  )
  SELECT
   grain,
   retailer,
	 customer_name,
	 share_data.report_date,
	 share_data.department,
	 super_category,
	 category,
	 sub_category,
   'ALL' as upc,
   'ALL' as source_item_name,
	 share_data.lookup_key,
	 gmi_category,
   CASE WHEN gmi_category IS NULL AND gm_products.lookup_key IS NULL -- Competitor
        THEN 'Competitor'
        ELSE 'General Mills'
   END AS manufacturer_name,
   CASE WHEN gmi_category IS NOT NULL -- GMI product
        THEN COALESCE(sales_data.total_sales, 0)  -- GMI product
        ELSE CAST(sub_category_sales AS FLOAT64) - COALESCE(sales_data.total_sales, 0) -- Competitor product
   END AS ty_sales_value,
   0 as ty_sales_unit,
   sub_category_sales,
	 sub_category_sales_ya,
	 original_file_name,
	 file_dt,
	 rctl_uuid,
	 ingest_date,
	 rctl_file_name,
	 created_by,
	 created_datetime,
	 modified_by,
	 modified_datetime
  FROM share_data
  LEFT JOIN sales_data
    ON share_data.report_date = sales_data.report_date
    AND share_data.lookup_key = sales_data.lookup_key
  LEFT JOIN gm_products  -- If a category is found in Sales and is not present in lookup then manufacturer is General Mills
   -- lookup key from mapping table not considered as some of the GMI categories are to be skipped but the manufacturer should be marked as General Mills
   ON share_data.shr_lookup_key = gm_products.lookup_key
""") ;

EXCEPTION WHEN ERROR THEN
    SELECT  
	ERROR (
		CONCAT(
    			@@error.message ,' ' ,
    			@@error.statement_text, ' ' ,
    			@@error.formatted_stack_trace ,' '
			)
		)
	;

END;