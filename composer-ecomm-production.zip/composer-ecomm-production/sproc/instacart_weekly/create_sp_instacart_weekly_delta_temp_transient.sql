  /* Purpose OF the stored proc : Delta Temp Table
	History OF Changes : 06/10 first version
	Author : Shikha Soni
	
CALL
  transient.sp_data_extract_config_insert(-99,
    'ecomm-dlf-dev-01cd47',
    'raw',
    'transient',
    'instacart_weekly_sales');
CALL
  transient.sp_instacart_weekly_delta_temp(-99,
    'ecomm-dlf-dev-01cd47',
    'raw',
    'transient',
    'instacart_weekly_sales',
	'instacart_weekly_delta_temp',
	'INSTACART');
CALL
  transient.sp_data_extract_config_update(-99,
    'ecomm-dlf-dev-01cd47',
    'transient',
    'instacart_weekly_sales');

  */
CREATE PROCEDURE IF NOT EXISTS
  transient.sp_instacart_weekly_delta_temp ( job_run_id INT64,
    bq_project_name STRING,
    bq_raw_dataset_name STRING,
    bq_transient_dataset_name STRING,
    bq_raw_table_name STRING,
    bq_delta_temp_tablename STRING,
    customer_name STRING)
BEGIN
  -- declare variables
DECLARE
  extract_start_date,
  extract_end_date Timestamp;
  -- Get Extract start datetime for incoming table from data_extract_config table
EXECUTE IMMEDIATE
  CONCAT("""select extract_start_datetime from `""",bq_project_name,"""`.""",bq_transient_dataset_name,""".""","""data_extract_config where table_name = '""",bq_raw_table_name,"""' and status = 'running' 
and active_flag = 'Y'""") INTO extract_start_date;
  -- Get Extract end datetime for incoming table from data_extract_config table
EXECUTE IMMEDIATE
  CONCAT("""select extract_end_datetime from `""",bq_project_name,"""`.""",bq_transient_dataset_name,""".""", """data_extract_config where table_name = '""",bq_raw_table_name,"""' and status = 'running'  and active_flag = 'Y'""") INTO extract_end_date;
  -- Truncate Delta Temp Table
EXECUTE IMMEDIATE
  CONCAT("""TRUNCATE TABLE  `""",bq_project_name,"""`.""",bq_transient_dataset_name,""".""",bq_delta_temp_tablename); 
  /*Insert Details for passed customer into 'instacart_weekly_delta_temp' table having ingest date greater than extract_start_date
from data_extract_config table */
EXECUTE IMMEDIATE
  CONCAT( """insert into  `""",bq_project_name,"""`.""",bq_transient_dataset_name,""".""",bq_delta_temp_tablename,"""
( 
SELECT
  * EXCEPT(rnk_1,
    rnk_2)
FROM (
  SELECT
    A.*,
    '""",job_run_id,"""' AS created_by,
    current_datetime AS created_datetime,
    '""",job_run_id,"""' AS modified_by,
    current_datetime AS modified_datetime,
    DENSE_RANK() OVER (PARTITION BY report_date, upc ORDER BY PARSE_TIMESTAMP("%m-%d-%Y %H:%M:%S", file_dt) DESC ) rnk_1,
    ROW_NUMBER() OVER (PARTITION BY report_date, upc, PARSE_TIMESTAMP("%m-%d-%Y %H:%M:%S", file_dt)
    ORDER BY
      ingest_date DESC ) rnk_2
  FROM (
    SELECT
      'WEEK' AS grain,
      'UNKNOWN' AS retailer,
      '""",customer_name,"""' AS customer_name,
      -- report date formatting
      -- %F	The date in the format %Y-%m-%d. example 2021-01-20
      -- %m/%e/%Y date format example 4/27/2020
      coalesce(cast(safe.parse_date ("%F", report_date) as timestamp),
                cast(safe.parse_date ("%m/%e/%Y", report_date) as timestamp)
      ) as report_date,
      manufacturer_name,
      brand,
      department,
      super_category,
      category,
      sub_category,
      upc,
      'NULL' as source_item_name,
      CAST(REGEXP_REPLACE(sales_dollars, '$', '') AS FLOAT64) AS ty_sales_value,
      CAST(CAST(sales_units AS NUMERIC)AS INT64) AS ty_sales_units,
      deliveries_per_customer,
      units_per_customer,
      dollars_per_delivery,
      units_per_delivery,
      sales_ya,
      sales_growth_yoy,
      original_file_name,
      file_dt,
      rctl_uuid,
      TIMESTAMP(ingest_date) AS ingest_date,
      rctl_file_name
    FROM
      `""",bq_project_name,"""`.""",bq_raw_dataset_name,""".""",bq_raw_table_name,"""  r
      WHERE ingest_date > '""",extract_start_date,"""'
      AND ingest_date <= '""",extract_end_date,"""'  )A )a
WHERE
  rnk_1 = 1
  AND rnk_2 = 1
  
  )
""") ;
EXCEPTION WHEN ERROR THEN
    SELECT  
	ERROR (
		CONCAT(
    			@@error.message ,' ' ,
    			@@error.statement_text, ' ' ,
    			@@error.formatted_stack_trace ,' '
			)
		)
	;

END;