/*
Purpose of the stored proc:
	Delta Data extraction for 'cora_drive' customer
History of Changes:
	12/16 – first version
Author :
	Vishal Jadiya
How to Call:
		call transient.sp_cora_drive_delta_temp_hist
		(
		 99,
		'ecomm-dlf-dev-01cd47',
		'transient' ,
		'cora_drive_delta_temp',
		'edw-dev-c119a7',
		'syndicated_nielsen',
		'CORA_DRIVE'
		);

*/

CREATE PROCEDURE IF NOT EXISTS
  transient.sp_cora_drive_delta_temp_hist ( job_run_id int64,
    bq_project_name string,
    bq_transient_dataset_name string,
    bq_delta_temp_tablename string,
    bq_edw_project_name string,
    bq_edw_dataset_name string,
    customer_name string )

BEGIN

DECLARE fiscal_year_nbr_val INT64;

/* Delta Temp Table is Truncate & Load */

EXECUTE IMMEDIATE
CONCAT("""TRUNCATE TABLE  `""" ,bq_project_name,"""`.""",bq_transient_dataset_name,""".""",bq_delta_temp_tablename);

EXECUTE IMMEDIATE CONCAT(""" SELECT CASE  WHEN CURRENT_DATE() < DATE_TRUNC(PARSE_DATE('%F', CONCAT(CAST(EXTRACT(year FROM CURRENT_DATE()) AS string),'-06-01')), WEEK(MONDAY)) THEN CAST(EXTRACT(year FROM CURRENT_DATE()) AS int64)
           ELSE CAST(EXTRACT(year FROM CURRENT_DATE())+1 AS int64)  END as fiscal_year_nbr_val""") INTO fiscal_year_nbr_val;

/*EXECUTE IMMEDIATE CONCAT(""" SELECT  fiscal_year_nbr FROM  `""",bq_edw_project_name,""".enterprise.dim_date`
where current_date() = fiscal_dt AND language_cd='EN' AND fiscal_year_variant_cd = '07'""") INTO fiscal_year_nbr_val*/

/*Insert Details for passed customer into 'cora_drive_delta_temp' table having fiscal_week_begin_dt in current fiscal year */

EXECUTE IMMEDIATE
CONCAT("""insert into  `""" ,bq_project_name,"""`.""",bq_transient_dataset_name,""".""","""cora_drive_delta_temp
(
   WITH
     dr AS (
     SELECT
       'WEEK' AS grain,
       'CORA_DRIVE' AS retailer,
       '""",customer_name,"""' AS customer_name,
       prod.product_item_desc  source_item_code,
       prod.product_long_desc as source_item_name,
       prod.source_database_cd as source_category,
       prod.product_item_desc  as upc,
       SAFE_CAST(p.fiscal_week_begin_dt as timestamp) AS report_date,
       prod.agg_level_derived_desc,
	   f.any_promotion_volume_qty	as volume_promo,
	   f.any_promotion_unit_qty	as units_promo,
       f.any_promotion_value_amt	as sales_promo,
	   f.baseline_unit_qty	units_baseline,
	   f.baseline_volume_qty	volume_baseline,
       f.baseline_sales_value_amt	sales_baseline,
       m.country_cd	fr_country,
	   prod.country_hierarchy_level_2,
	   prod.country_hierarchy_level_3,
	   prod.country_hierarchy_level_4,
	   prod.general_mills_product_fg,
	   prod.product_long_desc as product_description,
       prod.product_segment_desc as fr_product_segment_desc,
	   prod.product_manufacturer_desc	as nielsen_product_manufacturer_derived_desc,
	   prod.product_brand_desc as nielsen_product_brand_derived_desc,
	   prod.product_sub_brand_desc	as sub_brand,
	   prod.product_std_promo_desc,
	   prod.product_weight_desc as  dim_nielsen_pos_fr_product,
	   prod.product_variety_desc,
	   prod.product_format_desc,
	   prod.product_number_of_actual_packs_desc,
	   prod.product_category_derived_desc as fr_product_category_derived_desc,
	   prod.product_segment_derived_desc,
	   prod.product_sub_segment_derived_desc as fr_product_sub_segment_derived_desc,
	   prod.product_manufacturer_derived_desc,
	   prod.product_brand_derived_desc,
	   prod.product_regional_mega_category_derived_desc,
	   prod.product_regional_category_derived_desc,
	   prod.product_regional_sector_desc,
	   prod.product_type_desc,
	   prod.product_sub_segment_desc,
	   prod.product_regional_mega_segment_desc,
	   prod.product_regional_segment_desc,
	   prod.product_regional_sub_segment_desc,
	   prod.product_regional_type_desc,
	   prod.product_pack_type_derived_desc,
	   prod.product_type_desc_legume,
	   prod.product_flavor_desc,
	   prod.product_number_in_multipack_desc,
	   prod.regional_hierarchy_level_0,
       prod.regional_hierarchy_level_1,
	   prod.regional_hierarchy_level_2,
	   prod.regional_hierarchy_level_3,
	   prod.regional_hierarchy_level_4,
	   coalesce(SAFE_CAST(f.sales_value_amt AS FLOAT64),0) AS ty_sales_value,
	   f.sales_unit_qty AS ty_sales_units,
	   f.sales_volume_qty	volume,
	   current_timestamp() ingest_date,
	   '""",job_run_id,"""' created_by,
       current_datetime created_datetime,
	   '""",job_run_id,"""' modified_by,
       current_datetime modified_datetime,

	   -- the following ranking is done to avoid duplicates if the ****same file
	   -- is loaded multiple times****. The data is partitioned on the natural key
	   -- of the file and the file_dt which is the timestamp on the file
	   -- The data is then ordered descending on ingest_date which is the current timestamp
	   -- coming from the ingestion framework.  Picking rank = 1 will result
	   -- in the record with latest ingest_date being picked in case duplicate records
	   -- exist in the raw table.  THIS SCENARIO WILL TYPICALLY NOT OCCUR.
	   -- Please note the use of ROW_NUMBER function to pick one record.
	   -- This function will be needed when the entire RAW table is read to reprocess history.


       ROW_NUMBER() OVER(PARTITION BY prod.product_item_desc, prod.product_long_desc, p.fiscal_week_begin_dt order by f.sales_value_amt desc) AS rnk_1
       FROM
         `""",bq_edw_project_name,""".""",bq_edw_dataset_name,""".dim_nielsen_pos_fr_period`  p
       INNER JOIN
         `""",bq_edw_project_name,""".""",bq_edw_dataset_name,""".nielsen_pos_fr_fact` f
		 ON p.period_tag_cd = f.period_tag_cd and p.source_database_cd=f.source_database_cd
       INNER JOIN
         `""",bq_edw_project_name,""".""",bq_edw_dataset_name,""".dim_nielsen_pos_fr_market` m
       ON m.market_tag_cd = f.market_tag_cd and m.source_database_cd=f.source_database_cd
       INNER JOIN
         `""",bq_edw_project_name,""".""",bq_edw_dataset_name,""".dim_nielsen_pos_fr_product` prod
       ON prod.product_tag_cd = f.product_tag_cd and prod.source_database_cd=f.source_database_cd
       WHERE UPPER(m.market_short_desc) = 'CORA DRIVE'  AND UPPER(prod.agg_level_derived_desc)='ITEM' AND (f.sales_value_amt IS NOT NULL OR f.sales_unit_qty IS NOT NULL))
     SELECT
     grain,
     retailer,
     customer_name,
     source_item_code,
     source_item_name,
     source_category,
     upc,
     report_date,
     agg_level_derived_desc,
     volume_promo,
     units_promo,
     sales_promo,
     units_baseline,
     volume_baseline,
     sales_baseline,
     fr_country,
     country_hierarchy_level_2,
     country_hierarchy_level_3,
     country_hierarchy_level_4,
     general_mills_product_fg,
     product_description,
     fr_product_segment_desc,
     nielsen_product_manufacturer_derived_desc,
     nielsen_product_brand_derived_desc,
     sub_brand,
     product_std_promo_desc,
     dim_nielsen_pos_fr_product,
     product_variety_desc,
     product_format_desc,
     product_number_of_actual_packs_desc,
     fr_product_category_derived_desc,
     product_segment_derived_desc,
     fr_product_sub_segment_derived_desc,
     product_manufacturer_derived_desc,
     product_brand_derived_desc,
     product_regional_mega_category_derived_desc,
     product_regional_category_derived_desc,
     product_regional_sector_desc,
     product_type_desc,
     product_sub_segment_desc,
     product_regional_mega_segment_desc,
     product_regional_segment_desc,
     product_regional_sub_segment_desc,
     product_regional_type_desc,
     product_pack_type_derived_desc,
     product_type_desc_legume,
     product_flavor_desc,
     product_number_in_multipack_desc,
     regional_hierarchy_level_0,
     regional_hierarchy_level_1,
     regional_hierarchy_level_2,
     regional_hierarchy_level_3,
     regional_hierarchy_level_4,
     volume,
     ty_sales_value,
     ty_sales_units,
     ingest_date,
     GENERATE_UUID() as rctl_uuid,
     created_by,
     created_datetime,
     modified_by,
     modified_datetime
   FROM
     dr
   WHERE
     rnk_1 = 1
)
""") ;

EXCEPTION WHEN ERROR THEN
    SELECT
	ERROR (
		CONCAT(
    			@@error.message ,' ' ,
    			@@error.statement_text, ' ' ,
    			@@error.formatted_stack_trace ,' '
			)
		)
	;

END;