/*

Purpose of the stored proc:
	Trigger DQ Checks based on Record Key

History of Changes:
	05/25 – first version

Author :
	Pawan Rathod

How to Call:

		CALL transient.sp_dq_checks_run
		(
		    "3128316538580414178,4809360811210864822",
		    'LOBLAWS'
		);

*/

CREATE OR REPLACE PROCEDURE transient.sp_dq_checks_run
(
	RECORD_KEY STRING,
	FEED_NAME STRING
)
BEGIN

DECLARE SQL, DQ_VALIDATION_RESULTS, RECORD_KEYS STRING;

SET FEED_NAME = UPPER(FEED_NAME);

SET RECORD_KEYS = (SELECT STRING_AGG(CONCAT("'",keys,"'")) FROM UNNEST(SPLIT(RECORD_KEY,",")) as keys);

FOR key in (SELECT keys FROM UNNEST(SPLIT(RECORD_KEY,",")) as keys)
DO
EXECUTE IMMEDIATE CONCAT ("""
    SELECT query
    FROM processed.data_quality_parameters
    WHERE record_key=""",key.keys)
INTO SQL;

EXECUTE IMMEDIATE SQL ;

END FOR;

EXECUTE IMMEDIATE CONCAT ("""
    SELECT
        IFNULL(STRING_AGG(record_key),'')
    FROM (
            SELECT
                ROW_NUMBER() OVER(partition by record_key order by execution_date desc) as rn,
                is_successful,
                record_key
            FROM processed.data_quality_validation_result
            WHERE record_key in (""",RECORD_KEYS,""")
            ) WHERE rn =1 and is_successful = False
""") INTO DQ_VALIDATION_RESULTS;

IF LENGTH(DQ_VALIDATION_RESULTS) > 0 THEN
SELECT
	        ERROR (CONCAT(" DQ CHECKS FAILED FOR RECORD KEY : '", DQ_VALIDATION_RESULTS, "'"));
END IF;

EXCEPTION WHEN ERROR THEN
        EXECUTE IMMEDIATE CONCAT(
            """INSERT INTO processed.sproc_error_details (
		        SELECT
			        '""",FEED_NAME,"""' AS FEED_NAME,
                    split(split(@@error.formatted_stack_trace,'transient.')[OFFSET (1)],'[')[OFFSET(0)],
			        @@error.statement_text,
			        @@error.message,
			        current_timestamp()
	        );
	    """);

	    SELECT
	        ERROR (
	            CONCAT(
	            		@@error.message ,' ' ,
	            		@@error.statement_text, ' ' ,
	            		@@error.formatted_stack_trace ,' '
	            	)
	        );

END;
