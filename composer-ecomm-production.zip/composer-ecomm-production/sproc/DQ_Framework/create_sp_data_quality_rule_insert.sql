/*

Purpose of the stored proc:
	Insert Data Quality Rules

History of Changes:
	05/25 – first version

Author :
	Pawan Rathod

How to Call:

		CALL
		    transient.sp_data_quality_rule_insert
		    (
		        1,
		        'duplicate_check',
		        """with query_to_run as (SELECT  COUNT(*) OVER(PARTITION BY ",dq_column,") as cnt, COUNT(*) OVER() as total_cnt FROM `",dq_project,"`.",dq_dataset,".",dq_table,")""",
		        "DQ_RULE_INSERT"
		    );

*/


CREATE OR REPLACE PROCEDURE transient.sp_data_quality_rule_insert
(
    RULE_ID INT64,
    RULE_NAME STRING,
    DQ_RULE_QUERY STRING,
    FEED_NAME STRING
)
BEGIN

DECLARE FORMATTED_QUERY_SKELETON, SQL, DQ_VALIDATION_TABLE STRING;
DECLARE RECORD_KEY ARRAY<INT64>;

SET FEED_NAME = UPPER(FEED_NAME);

SET DQ_VALIDATION_TABLE = "INSERT INTO processed.data_quality_validation_result ";

SET FORMATTED_QUERY_SKELETON = CONCAT(""" SELECT '",record_key,"' as record_key , current_timestamp() as execution_date, '",rule_name,"' as rule_name,'",customer_name,"' as customer_name, '",feed_name,"' as feed_name, failed_records as failed_record_counts, total_records as total_record_counts, '",threshold,"' as threshold, is_successful as is_successful  FROM ( SELECT IF(",threshold_is_percent,", IF((COALESCE((SUM(CASE WHEN cnt = 1 THEN 0 ELSE cnt END)) / MAX(total_cnt),0)*100) > ",threshold,",FALSE,TRUE), IF(COALESCE((SUM(CASE WHEN cnt = 1 THEN 0 ELSE cnt END))/ MAX(total_cnt),0) > ",threshold,",FALSE,TRUE)) as is_successful, SUM(CASE WHEN cnt = 1 THEN 0 ELSE cnt END) as failed_records, MAX(total_cnt) as total_records FROM query_to_run) """);

EXECUTE IMMEDIATE CONCAT("""
    MERGE INTO processed.data_quality_rules tgt
    using(
        SELECT
        rule_id,
        rule_name,
        original_query,
        CONCAT(\"""",DQ_VALIDATION_TABLE,"""\" , original_query,\"\"\"""",FORMATTED_QUERY_SKELETON,"""\"\"\") as formatted_query,
        current_timestamp() as  created_dt,
        'ECOMM' as created_by,
        current_timestamp() as  modified_dt,
        'ECOMM' as modified_by
        FROM (
            SELECT
            """,RULE_ID,""" as rule_id,
            '""",RULE_NAME,"""' as rule_name,
            CONCAT(\"\"\"""",DQ_RULE_QUERY,"""\"\"\") as original_query
        )
    )src
    on
    src.rule_id= tgt.rule_id
    when not matched then insert row
    when matched then update
    SET
    tgt.rule_id =  src.rule_id,
    tgt.rule_name = src.rule_name,
    tgt.original_query = src.original_query,
    tgt.formatted_query = src.formatted_query,
    tgt.modified_dt = src.modified_dt,
    tgt.modified_by = src.modified_by;
""");


EXECUTE IMMEDIATE CONCAT ("""
            SELECT ARRAY_AGG(record_key)
            FROM processed.data_quality_parameters
            WHERE rule_id = """,RULE_ID,""";""") INTO RECORD_KEY;

FOR key in (SELECT keys FROM UNNEST(RECORD_KEY) as keys)
DO
EXECUTE IMMEDIATE
  CONCAT("""
  SELECT
    REPLACE(CONCAT('SELECT CONCAT("',dqr.formatted_query,'")'),'",rule_name,"',dqr.rule_name),
    dqr.rule_name
  FROM
    processed.data_quality_rules dqr
  JOIN
    processed.data_quality_parameters dqp
  ON
    dqr.rule_id=dqp.rule_id
  WHERE
    dqp.record_key=""",key.keys ) INTO SQL, RULE_NAME;

EXECUTE IMMEDIATE CONCAT("""
UPDATE processed.data_quality_parameters
SET
query=(""",SQL,""" FROM processed.data_quality_parameters WHERE record_key=""",key.keys,""") ,
rule_name='""",RULE_NAME,"""',
modified_dt=current_timestamp()
WHERE record_key=""",key.keys);
END FOR;

EXCEPTION WHEN ERROR THEN
        EXECUTE IMMEDIATE CONCAT(
            """INSERT INTO processed.sproc_error_details (
		        SELECT
			        '""",FEED_NAME,"""' AS FEED_NAME,
                    split(split(@@error.formatted_stack_trace,'transient.')[OFFSET (1)],'[')[OFFSET(0)],
			        @@error.statement_text,
			        @@error.message,
			        current_timestamp()
	        );
	    """);

	    SELECT
	        ERROR (
	            CONCAT(
	            		@@error.message ,' ' ,
	            		@@error.statement_text, ' ' ,
	            		@@error.formatted_stack_trace ,' '
	            	)
	        );

END;