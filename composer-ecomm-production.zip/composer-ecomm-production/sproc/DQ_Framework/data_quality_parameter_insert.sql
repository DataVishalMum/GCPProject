-- ********************* DUPLICATE QUERY *********************

MERGE INTO `ecomm-dlf-dev-01cd47.processed.data_quality_parameters` tgt
using(
with cte as (
select
1 as rule_id,
"duplicate_check" as rule_name,
"LOBLAWS" as customer_name,
"LOBLAWS" as feed_name,
0 as threshold,
TRUE as threshold_is_percent,
'ecomm-dlf-dev-01cd47' as dq_project,
'transient' as dq_dataset,
'loblaws_delta_temp' as dq_table,
'article_number, upc,loblaws_week_start,store_banner' as dq_column,
'' as origin_project,
'' as origin_dataset,
'' as origin_table,
'' as origin_column,
'' as query,
)
select
ABS(FARM_FINGERPRINT(
	CONCAT(
		COALESCE(CAST(rule_id as STRING),''),
		COALESCE(CAST(customer_name as STRING),''),
		COALESCE(CAST(feed_name as STRING),''),
		COALESCE(CAST(threshold_is_percent as STRING),''),
		COALESCE(CAST(dq_project as STRING),''),
		COALESCE(CAST(dq_dataset as STRING),''),
		COALESCE(CAST(dq_table as STRING),''),
		COALESCE(CAST(dq_column as STRING),'')
	)
)) as record_key,
* ,
TRUE as is_active,
current_date as created_dt,
'ECOMM' as created_by,
current_date as modified_dt,
'ECOMM' as modified_by
from CTE
) src
on
src.record_key= tgt.record_key
when not matched then insert row
when matched then update
SET
tgt.threshold =  src.threshold,
tgt.threshold_is_percent = src.threshold_is_percent,
tgt.dq_project = src.dq_project,
tgt.dq_dataset = src.dq_dataset,
tgt.dq_table = src.dq_table,
tgt.dq_column = src.dq_column,
tgt.origin_project = src.origin_project,
tgt.origin_dataset = src.origin_dataset,
tgt.origin_table = src.origin_table,
tgt.origin_column = src.origin_column,
tgt.modified_dt = src.modified_dt,
tgt.modified_by = src.modified_by;

-- ********************* NULL QUERY *********************

MERGE INTO `ecomm-dlf-dev-01cd47.processed.data_quality_parameters` tgt
using(
with cte as (
select
2 as rule_id,
"null_check" as rule_name,
"LOBLAWS" as customer_name,
"LOBLAWS" as feed_name,
0 as threshold,
TRUE as threshold_is_percent,
'ecomm-dlf-dev-01cd47' as dq_project,
'transient' as dq_dataset,
'loblaws_delta_temp' as dq_table,
'upc' as dq_column,
'' as origin_project,
'' as origin_dataset,
'' as origin_table,
'' as origin_column,
'' as query,
)
select
ABS(FARM_FINGERPRINT(
	CONCAT(
		COALESCE(CAST(rule_id as STRING),''),
		COALESCE(CAST(customer_name as STRING),''),
		COALESCE(CAST(feed_name as STRING),''),
		COALESCE(CAST(threshold_is_percent as STRING),''),
		COALESCE(CAST(dq_project as STRING),''),
		COALESCE(CAST(dq_dataset as STRING),''),
		COALESCE(CAST(dq_table as STRING),''),
		COALESCE(CAST(dq_column as STRING),'')
	)
)) as record_key,
* ,
TRUE as is_active,
current_date as created_dt,
'ECOMM' as created_by,
current_date as modified_dt,
'ECOMM' as modified_by
from CTE
) src
on
src.record_key= tgt.record_key
when not matched then insert row
when matched then update
SET
tgt.threshold =  src.threshold,
tgt.threshold_is_percent = src.threshold_is_percent,
tgt.dq_project = src.dq_project,
tgt.dq_dataset = src.dq_dataset,
tgt.dq_table = src.dq_table,
tgt.dq_column = src.dq_column,
tgt.origin_project = src.origin_project,
tgt.origin_dataset = src.origin_dataset,
tgt.origin_table = src.origin_table,
tgt.origin_column = src.origin_column,
tgt.modified_dt = src.modified_dt,
tgt.modified_by = src.modified_by;

-- ********************* E Notation QUERY *********************


MERGE INTO `ecomm-dlf-dev-01cd47.processed.data_quality_parameters` tgt
using(
with cte as (
select
3 as rule_id,
"e_notation_check" as rule_name,
"LOBLAWS" as customer_name,
"LOBLAWS" as feed_name,
0 as threshold,
TRUE as threshold_is_percent,
'ecomm-dlf-dev-01cd47' as dq_project,
'transient' as dq_dataset,
'loblaws_delta_temp' as dq_table,
'upc' as dq_column,
'' as origin_project,
'' as origin_dataset,
'' as origin_table,
'' as origin_column,
'' as query,
)
select
ABS(FARM_FINGERPRINT(
	CONCAT(
		COALESCE(CAST(rule_id as STRING),''),
		COALESCE(CAST(customer_name as STRING),''),
		COALESCE(CAST(feed_name as STRING),''),
		COALESCE(CAST(threshold_is_percent as STRING),''),
		COALESCE(CAST(dq_project as STRING),''),
		COALESCE(CAST(dq_dataset as STRING),''),
		COALESCE(CAST(dq_table as STRING),''),
		COALESCE(CAST(dq_column as STRING),'')
	)
)) as record_key,
* ,
TRUE as is_active,
current_date as created_dt,
'ECOMM' as created_by,
current_date as modified_dt,
'ECOMM' as modified_by
from CTE
) src
on
src.record_key= tgt.record_key
when not matched then insert row
when matched then update
SET
tgt.threshold =  src.threshold,
tgt.threshold_is_percent = src.threshold_is_percent,
tgt.dq_project = src.dq_project,
tgt.dq_dataset = src.dq_dataset,
tgt.dq_table = src.dq_table,
tgt.dq_column = src.dq_column,
tgt.origin_project = src.origin_project,
tgt.origin_dataset = src.origin_dataset,
tgt.origin_table = src.origin_table,
tgt.origin_column = src.origin_column,
tgt.modified_dt = src.modified_dt,
tgt.modified_by = src.modified_by;