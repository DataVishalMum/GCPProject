CREATE OR REPLACE TABLE processed.data_quality_validation_result
(
record_key	STRING,
execution_date	TIMESTAMP,
rule_name	STRING,
customer_name	STRING,
feed_name	STRING,
failed_record_counts	INTEGER,
total_record_counts	INTEGER,
threshold	STRING,
is_successful	BOOLEAN
)
PARTITION BY DATE_TRUNC(execution_date, YEAR)
CLUSTER BY record_key, rule_name
OPTIONS(
  partition_expiration_days=1825.0,
  require_partition_filter=false,
  description="this table contains DQ validation results over a span of 5 yrs"
);