CREATE OR REPLACE TABLE
  processed.data_quality_parameters (
	record_key INT64,
    rule_id INT64,
    rule_name STRING, -- CASCADE FROM DQ RULE
    customer_name STRING,
    feed_name STRING,
    threshold FLOAT64,
    threshold_is_percent BOOLEAN,
	dq_project STRING, -- MANDATORY
	dq_dataset STRING, -- MANDATORY
	dq_table STRING, -- MANDATORY
	dq_column STRING, -- MANDATORY
	origin_project STRING,
	origin_dataset STRING,
	origin_table STRING,
	origin_column STRING,
	query STRING,
	is_active BOOLEAN,
    created_dt TIMESTAMP,
    created_by STRING,
    modified_dt TIMESTAMP,
    modified_by STRING );