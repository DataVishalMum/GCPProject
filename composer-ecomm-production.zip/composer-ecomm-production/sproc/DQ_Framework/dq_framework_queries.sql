CREATE OR REPLACE TABLE
  `ecomm-dlf-dev-01cd47`.processed.data_quality_parameters (
	record_key INT64,
    rule_id INT64,
    rule_name STRING, -- CASCADE FROM DQ RULE
    customer_name STRING,
    feed_name STRING,
    threshold FLOAT64,
    threshold_is_percent BOOLEAN,
	dq_project STRING, -- MANDATORY
	dq_dataset STRING, -- MANDATORY
	dq_table STRING, -- MANDATORY
	dq_column STRING, -- MANDATORY
	origin_project STRING,
	origin_dataset STRING,
	origin_table STRING,
	origin_column STRING,
	query STRING,
	is_active BOOLEAN,
    created_dt DATE,
    created_by STRING,
    modified_dt DATE,
    modified_by STRING );

--record_key -> rule_id,customer_name,feed_name,threshold_is_percent,dq_project,dq_dataset,dq_table, dq_column

MERGE INTO `ecomm-dlf-dev-01cd47.processed.data_quality_parameters` tgt
using(
with cte as (
select
1 as rule_id,
"duplicate_check" as rule_name,
"LOBLAWS" as customer_name,
"LOBLAWS" as feed_name,
0 as threshold,
TRUE as threshold_is_percent,
'ecomm-dlf-dev-01cd47' as dq_project,
'transient' as dq_dataset,
'loblaws_delta_temp' as dq_table,
'article_number, upc,loblaws_week_start,store_banner' as dq_column,
'' as origin_project,
'' as origin_dataset,
'' as origin_table,
'' as origin_column,
'' as query,
)
select
ABS(FARM_FINGERPRINT(
	CONCAT(
		COALESCE(CAST(rule_id as STRING),''),
		COALESCE(CAST(customer_name as STRING),''),
		COALESCE(CAST(feed_name as STRING),''),
		COALESCE(CAST(threshold_is_percent as STRING),''),
		COALESCE(CAST(dq_project as STRING),''),
		COALESCE(CAST(dq_dataset as STRING),''),
		COALESCE(CAST(dq_table as STRING),''),
		COALESCE(CAST(dq_column as STRING),'')
	)
)) as record_key,
* ,
TRUE as is_active,
current_date as created_dt,
'ECOMM' as created_by,
current_date as modified_dt,
'ECOMM' as modified_by
from CTE
) src
on
src.record_key= tgt.record_key
when not matched then insert row
when matched then update
SET
tgt.threshold =  src.threshold,
tgt.threshold_is_percent = src.threshold_is_percent,
tgt.dq_project = src.dq_project,
tgt.dq_dataset = src.dq_dataset,
tgt.dq_table = src.dq_table,
tgt.dq_column = src.dq_column,
tgt.origin_project = src.origin_project,
tgt.origin_dataset = src.origin_dataset,
tgt.origin_table = src.origin_table,
tgt.origin_column = src.origin_column,
tgt.modified_dt = src.modified_dt,
tgt.modified_by = src.modified_by;

CREATE OR REPLACE TABLE
  `ecomm-dlf-dev-01cd47.processed.data_quality_rules` (
	rule_id INT64,
	rule_name STRING,
	original_query STRING,
    formatted_query STRING,
    created_dt DATE,
    created_by STRING,
    modified_dt DATE,
    modified_by STRING );

TRUNCATE TABLE `ecomm-dlf-dev-01cd47.processed.data_quality_rules`;

MERGE INTO `ecomm-dlf-dev-01cd47.processed.data_quality_rules` tgt
using(
SELECT
rule_id,
rule_name,
original_query,
CONCAT(original_query,""" SELECT '",record_key,"' as record_key , current_timestamp() as execution_date, '",rule_name,"' as rule_name,'",customer_name,"' as customer_name, '",feed_name,"' as feed_name, failed_records as failed_record_counts, total_records as total_record_counts, '",threshold,"' as threshold, is_successful as is_successful  FROM ( SELECT IF(",threshold_is_percent,", IF((COALESCE((SUM(CASE WHEN cnt = 1 THEN 0 ELSE cnt END) - MAX(total_cnt))/ MAX(total_cnt),0)*100) > ",threshold,",FALSE,TRUE), IF(COALESCE((SUM(CASE WHEN cnt = 1 THEN 0 ELSE cnt END) - MAX(total_cnt))/ MAX(total_cnt),0) > ",threshold,",FALSE,TRUE)) as is_successful, SUM(CASE WHEN cnt = 1 THEN 0 ELSE cnt END) as failed_records, MAX(total_cnt) as total_records FROM query_to_run)""") as formatted_query,
current_date as created_dt,
'ECOMM' as created_by,
current_date as modified_dt,
'ECOMM' as modified_by
FROM (
select
1 as rule_id,
"duplicate_check" as rule_name,
CONCAT(""" with query_to_run as (SELECT  COUNT(*) OVER(PARTITION BY ",dq_column,") as cnt, COUNT(*) OVER() as total_cnt FROM `",dq_project,"`.",dq_dataset,".",dq_table,")""") as original_query
)
)src
on
src.rule_id= tgt.rule_id
when not matched then insert row
when matched then update
SET
tgt.rule_id =  src.rule_id,
tgt.rule_name = src.rule_name,
tgt.original_query = src.original_query,
tgt.formatted_query = src.formatted_query,
tgt.modified_dt = src.modified_dt,
tgt.modified_by = src.modified_by;



DECLARE query STRING;
DECLARE record_key INT64 DEFAULT 3013355766814044400;
EXECUTE IMMEDIATE CONCAT("""
  SELECT CONCAT('SELECT CONCAT("',dqr.formatted_query,'")')
FROM `ecomm-dlf-dev-01cd47.processed.data_quality_rules` dqr
JOIN `ecomm-dlf-dev-01cd47.processed.data_quality_parameters` dqp on dqr.rule_id=dqp.rule_id
where dqp.record_key=""",record_key
) INTO query;
EXECUTE IMMEDIATE CONCAT("""UPDATE `ecomm-dlf-dev-01cd47.processed.data_quality_parameters`
SET query=(""",query,""" FROM `ecomm-dlf-dev-01cd47.processed.data_quality_parameters` where record_key=""",record_key,""") where record_key=""",record_key)


####################### NULL QUERY

MERGE INTO `ecomm-dlf-dev-01cd47.processed.data_quality_rules` tgt
using(
SELECT
rule_id,
rule_name,
original_query,
CONCAT(original_query,""" SELECT '",record_key,"' as record_key , current_timestamp() as execution_date, '",rule_name,"' as rule_name,'",customer_name,"' as customer_name, '",feed_name,"' as feed_name, failed_records as failed_record_counts, total_records as total_record_counts, '",threshold,"' as threshold, is_successful as is_successful  FROM ( SELECT IF(",threshold_is_percent,", IF((COALESCE((SUM(CASE WHEN cnt = 1 THEN 0 ELSE cnt END) - MAX(total_cnt))/ MAX(total_cnt),0)*100) > ",threshold,",FALSE,TRUE), IF(COALESCE((SUM(CASE WHEN cnt = 1 THEN 0 ELSE cnt END) - MAX(total_cnt))/ MAX(total_cnt),0) > ",threshold,",FALSE,TRUE)) as is_successful, SUM(CASE WHEN cnt = 1 THEN 0 ELSE cnt END) as failed_records, MAX(total_cnt) as total_records FROM query_to_run)""") as formatted_query,
current_date as created_dt,
'ECOMM' as created_by,
current_date as modified_dt,
'ECOMM' as modified_by
FROM (
select
2 as rule_id,
"null_check" as rule_name,
CONCAT(""" with query_to_run as (SELECT  SUM(CASE WHEN ",dq_column," is null THEN 1 ELSE 0 END) as cnt, COUNT(*) as total_cnt FROM `",dq_project,"`.",dq_dataset,".",dq_table,")""") as original_query
)
)src
on
src.rule_id= tgt.rule_id
when not matched then insert row
when matched then update
SET
tgt.rule_id =  src.rule_id,
tgt.rule_name = src.rule_name,
tgt.original_query = src.original_query,
tgt.formatted_query = src.formatted_query,
tgt.modified_dt = src.modified_dt,
tgt.modified_by = src.modified_by;


MERGE INTO `ecomm-dlf-dev-01cd47.processed.data_quality_parameters` tgt
using(
with cte as (
select
2 as rule_id,
"null_check" as rule_name,
"LOBLAWS" as customer_name,
"LOBLAWS" as feed_name,
0 as threshold,
TRUE as threshold_is_percent,
'ecomm-dlf-dev-01cd47' as dq_project,
'transient' as dq_dataset,
'loblaws_delta_temp' as dq_table,
'upc' as dq_column,
'' as origin_project,
'' as origin_dataset,
'' as origin_table,
'' as origin_column,
'' as query,
)
select
ABS(FARM_FINGERPRINT(
	CONCAT(
		COALESCE(CAST(rule_id as STRING),''),
		COALESCE(CAST(customer_name as STRING),''),
		COALESCE(CAST(feed_name as STRING),''),
		COALESCE(CAST(threshold_is_percent as STRING),''),
		COALESCE(CAST(dq_project as STRING),''),
		COALESCE(CAST(dq_dataset as STRING),''),
		COALESCE(CAST(dq_table as STRING),''),
		COALESCE(CAST(dq_column as STRING),'')
	)
)) as record_key,
* ,
TRUE as is_active,
current_date as created_dt,
'ECOMM' as created_by,
current_date as modified_dt,
'ECOMM' as modified_by
from CTE
) src
on
src.record_key= tgt.record_key
when not matched then insert row
when matched then update
SET
tgt.threshold =  src.threshold,
tgt.threshold_is_percent = src.threshold_is_percent,
tgt.dq_project = src.dq_project,
tgt.dq_dataset = src.dq_dataset,
tgt.dq_table = src.dq_table,
tgt.dq_column = src.dq_column,
tgt.origin_project = src.origin_project,
tgt.origin_dataset = src.origin_dataset,
tgt.origin_table = src.origin_table,
tgt.origin_column = src.origin_column,
tgt.modified_dt = src.modified_dt,
tgt.modified_by = src.modified_by;

####################### E Notation QUERY

MERGE INTO `ecomm-dlf-dev-01cd47.processed.data_quality_rules` tgt
using(
SELECT
rule_id,
rule_name,
original_query,
CONCAT(original_query,""" SELECT '",record_key,"' as record_key , current_timestamp() as execution_date, '",rule_name,"' as rule_name,'",customer_name,"' as customer_name, '",feed_name,"' as feed_name, failed_records as failed_record_counts, total_records as total_record_counts, '",threshold,"' as threshold, is_successful as is_successful  FROM ( SELECT IF(",threshold_is_percent,", IF((COALESCE((SUM(CASE WHEN cnt = 1 THEN 0 ELSE cnt END) - MAX(total_cnt))/ MAX(total_cnt),0)*100) > ",threshold,",FALSE,TRUE), IF(COALESCE((SUM(CASE WHEN cnt = 1 THEN 0 ELSE cnt END) - MAX(total_cnt))/ MAX(total_cnt),0) > ",threshold,",FALSE,TRUE)) as is_successful, SUM(CASE WHEN cnt = 1 THEN 0 ELSE cnt END) as failed_records, MAX(total_cnt) as total_records FROM query_to_run)""") as formatted_query,
current_date as created_dt,
'ECOMM' as created_by,
current_date as modified_dt,
'ECOMM' as modified_by
FROM (
select
2 as rule_id,
"null_check" as rule_name,
CONCAT(""" with query_to_run as (SELECT  SUM(CASE WHEN ",dq_column," is null THEN 1 ELSE 0 END) as cnt, COUNT(*) as total_cnt FROM `",dq_project,"`.",dq_dataset,".",dq_table,")""") as original_query
)
)src
on
src.rule_id= tgt.rule_id
when not matched then insert row
when matched then update
SET
tgt.rule_id =  src.rule_id,
tgt.rule_name = src.rule_name,
tgt.original_query = src.original_query,
tgt.formatted_query = src.formatted_query,
tgt.modified_dt = src.modified_dt,
tgt.modified_by = src.modified_by;


MERGE INTO `ecomm-dlf-dev-01cd47.processed.data_quality_parameters` tgt
using(
with cte as (
select
2 as rule_id,
"null_check" as rule_name,
"LOBLAWS" as customer_name,
"LOBLAWS" as feed_name,
0 as threshold,
TRUE as threshold_is_percent,
'ecomm-dlf-dev-01cd47' as dq_project,
'transient' as dq_dataset,
'loblaws_delta_temp' as dq_table,
'upc' as dq_column,
'' as origin_project,
'' as origin_dataset,
'' as origin_table,
'' as origin_column,
'' as query,
)
select
ABS(FARM_FINGERPRINT(
	CONCAT(
		COALESCE(CAST(rule_id as STRING),''),
		COALESCE(CAST(customer_name as STRING),''),
		COALESCE(CAST(feed_name as STRING),''),
		COALESCE(CAST(threshold_is_percent as STRING),''),
		COALESCE(CAST(dq_project as STRING),''),
		COALESCE(CAST(dq_dataset as STRING),''),
		COALESCE(CAST(dq_table as STRING),''),
		COALESCE(CAST(dq_column as STRING),'')
	)
)) as record_key,
* ,
TRUE as is_active,
current_date as created_dt,
'ECOMM' as created_by,
current_date as modified_dt,
'ECOMM' as modified_by
from CTE
) src
on
src.record_key= tgt.record_key
when not matched then insert row
when matched then update
SET
tgt.threshold =  src.threshold,
tgt.threshold_is_percent = src.threshold_is_percent,
tgt.dq_project = src.dq_project,
tgt.dq_dataset = src.dq_dataset,
tgt.dq_table = src.dq_table,
tgt.dq_column = src.dq_column,
tgt.origin_project = src.origin_project,
tgt.origin_dataset = src.origin_dataset,
tgt.origin_table = src.origin_table,
tgt.origin_column = src.origin_column,
tgt.modified_dt = src.modified_dt,
tgt.modified_by = src.modified_by;