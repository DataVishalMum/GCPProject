/*

Purpose of the stored proc:
	Insert Data Quality Parameters Based on Data Quality Rules per retailers.

History of Changes:
	05/25 – first version

Author :
	Pawan Rathod

How to Call:

		CALL
		    transient.sp_data_quality_parameter_insert
		    (
		        1,
		        0,
		        TRUE,
		        'LOBLAWS',
		        'LOBLAWS',
		        'ecomm-dlf-dev-01cd47',
		        'transient',
		        'loblaws_delta_temp',
		        'article_number,upc,loblaws_week_start,store_banner',
		        '',
		        '',
		        '',
		        ''
		    );
*/

CREATE OR REPLACE PROCEDURE transient.sp_data_quality_parameter_insert
(
    RULE_ID INT64,
    THRESHOLD INT64,
    THRESHOLD_IS_PERCENT BOOLEAN,
    CUSTOMER_NAME STRING,
    FEED_NAME STRING,
    DEST_PROJECT STRING,
    DEST_DATASET STRING,
    DEST_TABLE STRING,
    DEST_COLUMN STRING,
    SRC_PROJECT STRING,
    SRC_DATASET STRING,
    SRC_TABLE STRING,
    SRC_COLUMN STRING
)
BEGIN

DECLARE SQL, RULE_NAME STRING;
DECLARE RECORD_KEY ARRAY<INT64>;

SET CUSTOMER_NAME = UPPER(CUSTOMER_NAME);
SET FEED_NAME = UPPER(FEED_NAME);

EXECUTE IMMEDIATE CONCAT("""
    MERGE INTO processed.data_quality_parameters tgt
    using(
    with cte as (
            select
            """,RULE_ID,""" as rule_id,
            '' as rule_name,
            '""",CUSTOMER_NAME,"""' as customer_name,
            '""",FEED_NAME,"""' as feed_name,
            """,THRESHOLD,""" as threshold,
            """,THRESHOLD_IS_PERCENT,""" as threshold_is_percent,
            '""",DEST_PROJECT,"""' as dq_project,
            '""",DEST_DATASET,"""' as dq_dataset,
            '""",DEST_TABLE,"""' as dq_table,
            '""",DEST_COLUMN,"""' as dq_column,
            '""",SRC_PROJECT,"""' as origin_project,
            '""",SRC_DATASET,"""' as origin_dataset,
            '""",SRC_TABLE,"""' as origin_table,
            '""",SRC_COLUMN,"""' as origin_column,
            '' as query
    )
    select
        ABS(FARM_FINGERPRINT(
        	CONCAT(
        		COALESCE(CAST(rule_id as STRING),''),
        		COALESCE(CAST(customer_name as STRING),''),
        		COALESCE(CAST(feed_name as STRING),''),
        		COALESCE(CAST(threshold_is_percent as STRING),''),
        		COALESCE(CAST(dq_project as STRING),''),
        		COALESCE(CAST(dq_dataset as STRING),''),
        		COALESCE(CAST(dq_table as STRING),''),
        		COALESCE(CAST(dq_column as STRING),'')
        	)
        )) as record_key,
        * ,
        TRUE as is_active,
        current_timestamp() as created_dt,
        'ECOMM' as created_by,
        current_timestamp() as modified_dt,
        'ECOMM' as modified_by
        from CTE
    ) src
    on
        src.record_key = tgt.record_key
    when not matched then insert row
    when matched then update
        SET
        tgt.rule_name = src.rule_name,
        tgt.threshold =  src.threshold,
        tgt.threshold_is_percent = src.threshold_is_percent,
        tgt.dq_project = src.dq_project,
        tgt.dq_dataset = src.dq_dataset,
        tgt.dq_table = src.dq_table,
        tgt.dq_column = src.dq_column,
        tgt.origin_project = src.origin_project,
        tgt.origin_dataset = src.origin_dataset,
        tgt.origin_table = src.origin_table,
        tgt.origin_column = src.origin_column,
        tgt.query = src.query,
        tgt.modified_dt = src.modified_dt,
        tgt.modified_by = src.modified_by;
""");


EXECUTE IMMEDIATE CONCAT ("""
            SELECT ARRAY_AGG(record_key)
            FROM processed.data_quality_parameters
            WHERE COALESCE(TRIM(query),'') = '';
""") INTO RECORD_KEY;

FOR key in (SELECT keys FROM UNNEST(RECORD_KEY) as keys)
DO
EXECUTE IMMEDIATE
  CONCAT("""
  SELECT
    REPLACE(CONCAT('SELECT CONCAT("',dqr.formatted_query,'")'),'",rule_name,"',dqr.rule_name), dqr.rule_name
  FROM
    processed.data_quality_rules dqr
  JOIN
    processed.data_quality_parameters dqp
  ON
    dqr.rule_id=dqp.rule_id
  WHERE
    dqp.record_key=""",key.keys ) INTO SQL, RULE_NAME;

EXECUTE IMMEDIATE CONCAT("""
UPDATE processed.data_quality_parameters
SET
query=(""",SQL,""" FROM processed.data_quality_parameters WHERE record_key=""",key.keys,""") ,
rule_name='""",RULE_NAME,"""'
WHERE record_key=""",key.keys);
END FOR;

EXCEPTION WHEN ERROR THEN
        EXECUTE IMMEDIATE CONCAT(
            """INSERT INTO processed.sproc_error_details (
		        SELECT
			        '""",FEED_NAME,"""' AS FEED_NAME,
                    split(split(@@error.formatted_stack_trace,'transient.')[OFFSET (1)],'[')[OFFSET(0)],
			        @@error.statement_text,
			        @@error.message,
			        current_timestamp()
	        );
	    """);

	    SELECT
	        ERROR (
	            CONCAT(
	            		@@error.message ,' ' ,
	            		@@error.statement_text, ' ' ,
	            		@@error.formatted_stack_trace ,' '
	            	)
	        );

END;