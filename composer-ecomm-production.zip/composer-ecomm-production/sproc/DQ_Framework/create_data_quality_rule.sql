CREATE OR REPLACE TABLE
  processed.data_quality_rules (
	rule_id INT64,
	rule_name STRING,
	original_query STRING,
    formatted_query STRING,
    created_dt TIMESTAMP,
    created_by STRING,
    modified_dt TIMESTAMP,
    modified_by STRING );