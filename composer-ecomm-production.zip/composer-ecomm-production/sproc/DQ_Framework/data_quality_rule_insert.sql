-- ********************* HOW TO RUN QUERY *********************

DECLARE SQL, RULE_NAME STRING;
DECLARE RECORD_KEY ARRAY<INT64>;

EXECUTE IMMEDIATE CONCAT (""" SELECT ARRAY_AGG(record_key) FROM processed.data_quality_parameters WHERE COALESCE(TRIM(query),'') = ''; """) INTO RECORD_KEY;

FOR key in (SELECT keys FROM UNNEST(RECORD_KEY) as keys)
DO
EXECUTE IMMEDIATE
  CONCAT("""
  SELECT
    CONCAT('SELECT CONCAT("',dqr.formatted_query,'")'), dqr.rule_name
  FROM
    `ecomm-dlf-dev-01cd47.processed.data_quality_rules` dqr
  JOIN
    `ecomm-dlf-dev-01cd47.processed.data_quality_parameters` dqp
  ON
    dqr.rule_id=dqp.rule_id
  WHERE
    dqp.record_key=""",key.keys ) INTO SQL, RULE_NAME;

EXECUTE IMMEDIATE CONCAT("""
UPDATE `ecomm-dlf-dev-01cd47.processed.data_quality_parameters`
SET
query=(""",SQL,""" FROM `ecomm-dlf-dev-01cd47.processed.data_quality_parameters` WHERE record_key=""",key.keys,""") ,
rule_name='""",RULE_NAME,"""'
WHERE record_key=""",key.keys);
END FOR;



-- ********************* DUPLICATE QUERY *********************

MERGE INTO `ecomm-dlf-dev-01cd47.processed.data_quality_rules` tgt
using(
SELECT
rule_id,
rule_name,
original_query,
CONCAT(original_query,""" SELECT '",record_key,"' as record_key , current_timestamp() as execution_date, '",rule_name,"' as rule_name,'",customer_name,"' as customer_name, '",feed_name,"' as feed_name, failed_records as failed_record_counts, total_records as total_record_counts, '",threshold,"' as threshold, is_successful as is_successful  FROM ( SELECT IF(",threshold_is_percent,", IF((COALESCE((SUM(CASE WHEN cnt = 1 THEN 0 ELSE cnt END) - MAX(total_cnt))/ MAX(total_cnt),0)*100) > ",threshold,",FALSE,TRUE), IF(COALESCE((SUM(CASE WHEN cnt = 1 THEN 0 ELSE cnt END) - MAX(total_cnt))/ MAX(total_cnt),0) > ",threshold,",FALSE,TRUE)) as is_successful, SUM(CASE WHEN cnt = 1 THEN 0 ELSE cnt END) as failed_records, MAX(total_cnt) as total_records FROM query_to_run)""") as formatted_query,
current_timestamp() as  created_dt,
'ECOMM' as created_by,
current_timestamp() as  modified_dt,
'ECOMM' as modified_by
FROM (
select
1 as rule_id,
"duplicate_check" as rule_name,
CONCAT(""" with query_to_run as (SELECT  COUNT(*) OVER(PARTITION BY ",dq_column,") as cnt, COUNT(*) OVER() as total_cnt FROM `",dq_project,"`.",dq_dataset,".",dq_table,")""") as original_query
)
)src
on
src.rule_id= tgt.rule_id
when not matched then insert row
when matched then update
SET
tgt.rule_id =  src.rule_id,
tgt.rule_name = src.rule_name,
tgt.original_query = src.original_query,
tgt.formatted_query = src.formatted_query,
tgt.modified_dt = src.modified_dt,
tgt.modified_by = src.modified_by;


-- ********************* NULL QUERY *********************

MERGE INTO `ecomm-dlf-dev-01cd47.processed.data_quality_rules` tgt
using(
SELECT
rule_id,
rule_name,
original_query,
CONCAT(original_query,""" SELECT '",record_key,"' as record_key , current_timestamp() as execution_date, '",rule_name,"' as rule_name,'",customer_name,"' as customer_name, '",feed_name,"' as feed_name, failed_records as failed_record_counts, total_records as total_record_counts, '",threshold,"' as threshold, is_successful as is_successful  FROM ( SELECT IF(",threshold_is_percent,", IF((COALESCE((SUM(CASE WHEN cnt = 1 THEN 0 ELSE cnt END) - MAX(total_cnt))/ MAX(total_cnt),0)*100) > ",threshold,",FALSE,TRUE), IF(COALESCE((SUM(CASE WHEN cnt = 1 THEN 0 ELSE cnt END) - MAX(total_cnt))/ MAX(total_cnt),0) > ",threshold,",FALSE,TRUE)) as is_successful, SUM(CASE WHEN cnt = 1 THEN 0 ELSE cnt END) as failed_records, MAX(total_cnt) as total_records FROM query_to_run)""") as formatted_query,
current_timestamp() as  created_dt,
'ECOMM' as created_by,
current_timestamp() as  modified_dt,
'ECOMM' as modified_by
FROM (
select
2 as rule_id,
"null_check" as rule_name,
CONCAT(""" with query_to_run as (SELECT  SUM(CASE WHEN ",dq_column," is null THEN 1 ELSE 0 END) as cnt, COUNT(*) as total_cnt FROM `",dq_project,"`.",dq_dataset,".",dq_table,")""") as original_query
)
)src
on
src.rule_id= tgt.rule_id
when not matched then insert row
when matched then update
SET
tgt.rule_id =  src.rule_id,
tgt.rule_name = src.rule_name,
tgt.original_query = src.original_query,
tgt.formatted_query = src.formatted_query,
tgt.modified_dt = src.modified_dt,
tgt.modified_by = src.modified_by;


####################### E Notation QUERY

MERGE INTO `ecomm-dlf-dev-01cd47.processed.data_quality_rules` tgt
using(
SELECT
rule_id,
rule_name,
original_query,
CONCAT(original_query,""" SELECT '",record_key,"' as record_key , current_timestamp() as execution_date, '",rule_name,"' as rule_name,'",customer_name,"' as customer_name, '",feed_name,"' as feed_name, failed_records as failed_record_counts, total_records as total_record_counts, '",threshold,"' as threshold, is_successful as is_successful  FROM ( SELECT IF(",threshold_is_percent,", IF((COALESCE((SUM(CASE WHEN cnt = 1 THEN 0 ELSE cnt END) - MAX(total_cnt))/ MAX(total_cnt),0)*100) > ",threshold,",FALSE,TRUE), IF(COALESCE((SUM(CASE WHEN cnt = 1 THEN 0 ELSE cnt END) - MAX(total_cnt))/ MAX(total_cnt),0) > ",threshold,",FALSE,TRUE)) as is_successful, SUM(CASE WHEN cnt = 1 THEN 0 ELSE cnt END) as failed_records, MAX(total_cnt) as total_records FROM query_to_run)""") as formatted_query,
current_timestamp() as  created_dt,
'ECOMM' as created_by,
current_timestamp() as  modified_dt,
'ECOMM' as modified_by
FROM (
select
3 as rule_id,
"e_notation_check" as rule_name,
CONCAT(""" with query_to_run as (SELECT  SUM(IF(REGEXP_CONTAINS(",dq_column,", r'E'),1,0)) as cnt, COUNT(*) as total_cnt FROM `",dq_project,"`.",dq_dataset,".",dq_table,")""") as original_query
)
)src
on
src.rule_id= tgt.rule_id
when not matched then insert row
when matched then update
SET
tgt.rule_id =  src.rule_id,
tgt.rule_name = src.rule_name,
tgt.original_query = src.original_query,
tgt.formatted_query = src.formatted_query,
tgt.modified_dt = src.modified_dt,
tgt.modified_by = src.modified_by;

