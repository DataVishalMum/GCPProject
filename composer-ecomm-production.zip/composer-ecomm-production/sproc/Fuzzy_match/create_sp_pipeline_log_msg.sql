CREATE OR REPLACE PROCEDURE transient.pipeline_log_msg_to_table(
	PIPELINE_LOG_MSG ARRAY<STRUCT<PIPELINE_LOGGING_TBL STRING,
                                  MESSAGE_OWNER STRING,
                                  CUSTOMER_PARENT STRING,
                                  INGESTION_PIPELINE_MSG STRING,
                                  MESSAGE_TEXT STRING,
                                  MESSAGE_VALUE INT64,
                                  MESSAGE_STATUS STRING,
                                  MESSAGE_GRAIN STRING,
                                  BATCH_NUMBER INT64>>
)
OPTIONS(
description= """ This procedure is used to log pipeline events in pipeline log table.

    How to call

    CALL transient.pipeline_log_msg_to_table([STRUCT('table_name' as PIPELINE_LOGGING_TBL,
                                                     'kroger' as MESSAGE_OWNER,
                                                     'kroger' as CUSTOMER_PARENT,
                                                     'Ingestion pipeline' as INGESTION_PIPELINE_MSG,
                                                     'Total records count' as MESSAGE_TEXT,
                                                     1000 as MESSAGE_VALUE,
                                                     'logging total records' as MESSAGE_STATUS,
                                                     'summary' as MESSAGE_GRAIN,
                                                     1 as BATCH_NUMBER)]

"""
)
BEGIN

FOR msg_value IN (SELECT msg FROM UNNEST(PIPELINE_LOG_MSG) as msg)
DO
    EXECUTE IMMEDIATE CONCAT("""
        INSERT INTO """,msg_value.msg.pipeline_logging_tbl,"""
        SELECT
            initcap('""",msg_value.msg.message_owner,"""') as message_owner,
    				initcap('""",msg_value.msg.customer_parent,"""') as customer_parent,
    				'""",msg_value.msg.ingestion_pipeline_msg,"""' as ingestion_pipeline_msg,
    				'""",msg_value.msg.message_text,"""' as message_text,
    				""",msg_value.msg.message_value,""" as message_value,
    				'""",msg_value.msg.message_status,"""' as message_status,
    				'""",msg_value.msg.message_grain,"""' as message_grain,
    				""",msg_value.msg.batch_number,""" as batch_number,
    				current_timestamp() as execution_ts
    """);
END FOR;
END;