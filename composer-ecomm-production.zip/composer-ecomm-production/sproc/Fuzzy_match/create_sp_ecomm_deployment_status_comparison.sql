DROP TABLE IF EXISTS `ecomm-dlf-dev-01cd47.processed.ecomm_pipeline_cost_summary`;
CREATE TABLE `ecomm-dlf-dev-01cd47.processed.ecomm_pipeline_cost_summary`
(
  record_key INT64,
  project_name STRING,
  creation_time TIMESTAMP,
  project_id STRING,
  user_email STRING,
  job_type STRING,
  statement_type STRING,
  start_time TIMESTAMP,
  end_time TIMESTAMP,
  query STRING,
  total_bytes_processed FLOAT64,
  cost_in_dollars FLOAT64,
  inserted_row_count INT64,
  deleted_row_count INT64,
  updated_row_count INT64,
  execution_dttm DATETIME,
  creation_date DATE
)
PARTITION BY DATE_TRUNC(creation_date, MONTH)
CLUSTER BY project_name,query,job_type,start_time
OPTIONS(
  friendly_name="Summary Table to analyze gcp cost.",
  description="This table is used for tracking gcp cost incurred by ecomm project.",
  labels=[("data_classification", "confidential_internal_2b"), ("rls", "rls-skip")]
);


CREATE OR REPLACE TABLE `ecomm-dlf-dev-01cd47.processed.ecomm_deployment_status`
(
  match_type STRING,
  specific_schema STRING,
  specific_name STRING,
  status STRING,
  execution_dttm DATETIME
)
OPTIONS(
  friendly_name="Summary Table to compare codes in gcp.",
  description="This table is used to compare sproc and ddl between dev, qa and prod env.",
  labels=[("data_classification", "confidential_internal_2b"), ("rls", "rls-skip")]
);


CREATE OR REPLACE PROCEDURE transient.sp_ecomm_gcp_cost_code_stats(
	FEED_NAME STRING
)
OPTIONS(
description= """ This procedure is used to populate gcp cost summary and deployment status table.

	How to Call:

			CALL transient.sp_ecomm_gcp_cost_code_stats(
				'gcp_cost_code_stats' -- FEED_NAME
			);

"""
)

BEGIN

DECLARE environment_details ARRAY<STRUCT<project_name STRING, environment_name STRING>>;

SET environment_details =  [STRUCT('ecomm-dlf-dev-01cd47','dlf-dev'),
                            STRUCT('ecomm-dlf-qa-ee8fb9','dlf-qa'),
                            STRUCT('ecomm-dlf-prd-634888','dlf-prod'),
                            STRUCT('ecomm-analytics-dev-0a9c44','analytics-dev'),
                            STRUCT('ecomm-analytics-prd-6238a8','analytics-prod')];
							
SET FEED_NAME = UPPER(FEED_NAME);

EXECUTE IMMEDIATE CONCAT("""TRUNCATE TABLE processed.ecomm_deployment_status """);

EXECUTE IMMEDIATE CONCAT("""
INSERT INTO processed.ecomm_deployment_status
with cte as (
select 
		'SPROC' as match_type,
		p.specific_schema,
		p.specific_name,
		CASE WHEN COALESCE(p.routine_definition,'p') <> COALESCE(q.routine_definition,'q') AND COALESCE(p.routine_definition,'p') <> COALESCE(d.routine_definition,'d') THEN 'Sprocs do not match in all 3 environments.'
			 WHEN COALESCE(p.routine_definition,'p') <> COALESCE(q.routine_definition,'q') AND COALESCE(p.routine_definition,'p') = COALESCE(d.routine_definition,'d') THEN 'Sprocs in Prod and Dev do not match QA.'
			 WHEN COALESCE(p.routine_definition,'p') = COALESCE(q.routine_definition,'q') AND COALESCE(p.routine_definition,'p') <> COALESCE(d.routine_definition,'d') THEN 'Sprocs in Prod and QA do not match Dev.'
			 WHEN COALESCE(q.routine_definition,'q') <> COALESCE(d.routine_definition,'d') THEN 'Sproc in QA do not match with Dev.'
			 WHEN COALESCE(p.routine_definition,'p') = COALESCE(q.routine_definition,'q') AND COALESCE(p.routine_definition,'p') = COALESCE(d.routine_definition,'d') THEN 'Sprocs match in all 3 environments.'
			 WHEN COALESCE(q.routine_definition,'q') = COALESCE(d.routine_definition,'d') THEN 'Sproc in QA match with Dev.'
			 ELSE ''
		END as status,
		current_datetime
FROM `ecomm-dlf-prd-634888`.transient.INFORMATION_SCHEMA.ROUTINES p
INNER JOIN `ecomm-dlf-qa-ee8fb9`.transient.INFORMATION_SCHEMA.ROUTINES q on p.specific_name = q.specific_name
INNER JOIN `ecomm-dlf-dev-01cd47`.transient.INFORMATION_SCHEMA.ROUTINES d on p.specific_name = d.specific_name)
select *
from cte
""");

EXECUTE IMMEDIATE CONCAT("""
INSERT INTO processed.ecomm_deployment_status
with cte as (
select 
		'TABLE' as match_type,
		p.table_schema,
		p.table_name,
		CASE WHEN COALESCE(REPLACE(p.ddl,CONCAT(p.table_catalog,'.'),''),'p') <> COALESCE(REPLACE(q.ddl,CONCAT(q.table_catalog,'.'),''),'q') AND COALESCE(REPLACE(p.ddl,CONCAT(p.table_catalog,'.'),''),'p') <> COALESCE(REPLACE(d.ddl,CONCAT(d.table_catalog,'.'),''),'d') THEN 'Tables do not match in all 3 environments.'
			 WHEN COALESCE(REPLACE(p.ddl,CONCAT(p.table_catalog,'.'),''),'p') <> COALESCE(REPLACE(q.ddl,CONCAT(q.table_catalog,'.'),''),'q') AND COALESCE(REPLACE(p.ddl,CONCAT(p.table_catalog,'.'),''),'p') = COALESCE(REPLACE(d.ddl,CONCAT(d.table_catalog,'.'),''),'d') THEN 'Tables in Prod and Dev do not match QA.'
			 WHEN COALESCE(REPLACE(p.ddl,CONCAT(p.table_catalog,'.'),''),'p') = COALESCE(REPLACE(q.ddl,CONCAT(q.table_catalog,'.'),''),'q') AND COALESCE(REPLACE(p.ddl,CONCAT(p.table_catalog,'.'),''),'p') <> COALESCE(REPLACE(d.ddl,CONCAT(d.table_catalog,'.'),''),'d') THEN 'Tables in Prod and QA do not match Dev.'
			 WHEN COALESCE(REPLACE(q.ddl,CONCAT(q.table_catalog,'.'),''),'q') <> COALESCE(REPLACE(d.ddl,CONCAT(d.table_catalog,'.'),''),'d') THEN 'Table in QA do not match with Dev'
			 WHEN COALESCE(REPLACE(p.ddl,CONCAT(p.table_catalog,'.'),''),'p') = COALESCE(REPLACE(q.ddl,CONCAT(q.table_catalog,'.'),''),'q') AND COALESCE(REPLACE(p.ddl,CONCAT(p.table_catalog,'.'),''),'p') = COALESCE(REPLACE(d.ddl,CONCAT(d.table_catalog,'.'),''),'d') THEN 'Tables match in all 3 environments.'
			 WHEN COALESCE(REPLACE(q.ddl,CONCAT(q.table_catalog,'.'),''),'q') = COALESCE(REPLACE(d.ddl,CONCAT(d.table_catalog,'.'),''),'d') THEN 'Table in QA match with Dev'
			 ELSE ''
		END as status,
		current_datetime
FROM `ecomm-dlf-prd-634888`.transient.INFORMATION_SCHEMA.TABLES p
INNER JOIN `ecomm-dlf-qa-ee8fb9`.transient.INFORMATION_SCHEMA.TABLES q on  p.table_schema = q.table_schema 
																	   AND p.table_name = q.table_name
INNER JOIN `ecomm-dlf-dev-01cd47`.transient.INFORMATION_SCHEMA.TABLES d on  p.table_schema = d.table_schema 
																	    AND p.table_name = d.table_name
)
select *
from cte
""");


FOR env IN (SELECT env_details FROM UNNEST(environment_details) as env_details)
DO
EXECUTE IMMEDIATE CONCAT("""MERGE INTO processed.ecomm_pipeline_cost_summary tgt
USING
(
SELECT
	ABS(FARM_FINGERPRINT(CONCAT(COALESCE(SAFE_CAST(creation_time AS STRING),' '),
								UPPER('""",env.env_details.environment_name,"""'),
								COALESCE(SAFE_CAST(creation_time AS STRING),' '),
								REPLACE(COALESCE(query,' '), '\\n', ' ')
								))) as record_key,
	UPPER('""",env.env_details.environment_name,"""') as project_name,
	creation_time,
	project_id,
	user_email,
	job_type,
	statement_type,
	start_time,
	end_time,
	REPLACE(query, '\\n', ' ') as query,
	ROUND((COALESCE(total_bytes_processed,0))/1e6,2) as total_bytes_processed,
	ROUND((COALESCE(total_bytes_billed,0))/1e12*5, 2) cost_in_dollars,
	COALESCE(dml_statistics.inserted_row_count,0) as inserted_row_count,
	COALESCE(dml_statistics.deleted_row_count,0) as deleted_row_count,
	COALESCE(dml_statistics.updated_row_count,0) as updated_row_count,
	current_datetime,
	DATE_TRUNC(DATE(creation_time), MONTH) as creation_date
FROM
`""",env.env_details.project_name,"""`.`region-us`.INFORMATION_SCHEMA.JOBS_BY_PROJECT
WHERE
creation_time BETWEEN TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL 2 DAY)
AND CURRENT_TIMESTAMP()
) src
on tgt.record_key=src.record_key
WHEN NOT MATCHED THEN INSERT ROW
""");

END FOR;

EXCEPTION WHEN ERROR THEN
        EXECUTE IMMEDIATE CONCAT(
            """INSERT INTO processed.sproc_error_details (
		        SELECT
			        '""",FEED_NAME,"""' AS FEED_NAME,
                    split(split(@@error.formatted_stack_trace,'transient.')[OFFSET (1)],'[')[OFFSET(0)],
			        @@error.statement_text,
			        @@error.message,
			        current_timestamp()
	        );
	    """);

	    SELECT
	        ERROR (
	            CONCAT(
	            		@@error.message ,' ' ,
	            		@@error.statement_text, ' ' ,
	            		@@error.formatted_stack_trace ,' '
	            	)
	        );

END
