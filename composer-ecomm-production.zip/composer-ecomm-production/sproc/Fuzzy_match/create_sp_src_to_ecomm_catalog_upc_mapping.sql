CREATE OR REPLACE PROCEDURE transient.sp_src_to_ecomm_catalog_upc_mapping_table(
    DEST_PROJECT STRING,
	FEED_NAME STRING,
	DATASET STRING,
	DELTA_TEMP_TABLE STRING,
	UPC_FIELD STRING,
	RPC_FIELD STRING,
	PRODUCT_TITLE_FIELD STRING,
	CUSTOMER_NAME_COLUMN STRING,
	CALCULATE_UPC_CHECK_DIGIT_FLG BOOLEAN,
	MATCH_THRESHOLD FLOAT64
)
OPTIONS(
description= """ This procedure is used to map source upc with product catalog upc.

	How to Call:

			CALL transient.sp_src_to_ecomm_catalog_upc_mapping_table(
				'ecomm-analytics-dev-0a9c44', -- DEST_PROJECT
				'target', -- FEED_NAME
                'transient', -- DATASET
                'target_delta_temp', -- DELTA_TEMP_TABLE
                'upc_cd', -- UPC_FIELD
                'rpc', -- RPC_FIELD
                'source_item_name', -- PRODUCT_TITLE_FIELD
                'customer_name', -- CUSTOMER_NAME_COLUMN,
                True, -- CALCULATE_UPC_CHECK_DIGIT_FLG
                0.8 -- MATCH_THRESHOLD
			);

"""
)
BEGIN

/* Declaring Pipeline variables. */

  DECLARE
		GMI_PRD_MAPPING_TBL,
		DT_PIPELINE_TBL,
		REFINED_DT_PIPELINE_TBL,
		GMI_PRD_TBL,
		PIPELINE_MASTER_DATA,
		LOG_TBL,
		FUZZY_TEMP_TBL,
		FUZZY_INPUT_TBL,
		SUMMARY_QUERY,
		RECORD_KEY,
		GMI_PRODUCTS_PREFIX_LIST,
		MATERIAL_TYPE_CDS,
		DELTA_TBL_COLUMN_LIST,
		PIPELINE_UPC,
		FUZZY_TEMP_TBL_SQL,
		EXPORT_CONFIG STRING;

DECLARE TOTAL_RECORD_CNT, UPC_CNT, RPC_CNT, PROD_TITLE_CNT, CHECK_FINI_UPC_CNT, BATCH_NUMBER INT64;

DECLARE TOTAL_FUZZY_FILTER_COMBINATIONS ARRAY<STRING>;

DECLARE PIPELINE_INGESTION_MSG      DEFAULT 'Ingestion pipeline';
DECLARE AVAILABLE_COMBINATIONS      DEFAULT '';
DECLARE BLUE_COMPANY_PREFIX_CD      DEFAULT '^8402431|^8596100';
DECLARE PIPELINE_FINAL_OUTPUT_TBL   DEFAULT 'ecomm_pipeline_src_to_catalog_upc_mapping_table';
DECLARE PET_EXCLUSIONS_STRING       DEFAULT '\\\\b';
DECLARE PIPELINE_LOGGING_TBL        DEFAULT 'ecomm_pipeline_log_msg';

DECLARE FUZZY_FILTER_COLUMN_LIST    DEFAULT ['expected_is_gmi_product','expected_is_gmi_data','expected_is_pet'];
DECLARE MATERIAL_TYPE_CD_LIST       DEFAULT ['CNPK', 'FINI'];
DECLARE PET_EXCLUSIONS_LIST         DEFAULT ['dog','puppy','cat','kitty','purina'];

DECLARE RUN_DATE                    DEFAULT current_timestamp;

DECLARE PIPELINE_LOG_MSG ARRAY<STRUCT<LOG_TBL STRING,
                                  MESSAGE_OWNER STRING,
                                  CUSTOMER_PARENT STRING,
                                  INGESTION_PIPELINE_MSG STRING,
                                  MESSAGE_TEXT STRING,
                                  MESSAGE_VALUE INT64,
                                  MESSAGE_STATUS STRING,
                                  MESSAGE_GRAIN STRING,
                                  BATCH_NUMBER INT64>>;

/* Initialize Variables. */

SET MATERIAL_TYPE_CDS           = (SELECT CONCAT("'",STRING_AGG(distinct material_type_cd, "','"),"'") FROM UNNEST(MATERIAL_TYPE_CD_LIST) as material_type_cd);
SET PET_EXCLUSIONS_STRING       = CONCAT(PET_EXCLUSIONS_STRING,ARRAY_TO_STRING(PET_EXCLUSIONS_LIST, "\\\\b|\\\\b"),"\\\\b");
SET REFINED_DT_PIPELINE_TBL     = CONCAT("_SESSION.",FEED_NAME, "_refined_delta_temp_product_mapping_pipeline");
SET DT_PIPELINE_TBL             = CONCAT("_SESSION.",FEED_NAME, "_delta_temp_product_mapping_pipeline");
SET GMI_PRD_MAPPING_TBL         = CONCAT("_SESSION.",FEED_NAME, "_customer_data_gmi_product_mapping");
SET PIPELINE_FINAL_OUTPUT_TBL   = CONCAT(LOWER(DATASET),".", LOWER(PIPELINE_FINAL_OUTPUT_TBL));
SET PIPELINE_MASTER_DATA        = CONCAT("_SESSION.",FEED_NAME, "_pipeline_master_products");
SET FUZZY_TEMP_TBL              = CONCAT("_SESSION.",FEED_NAME, "_fuzzy_match_table");
SET FUZZY_INPUT_TBL             = CONCAT("_SESSION.",FEED_NAME, "_fuzzy_input_table");
SET PIPELINE_LOGGING_TBL        = CONCAT("processed.",LOWER(PIPELINE_LOGGING_TBL));
SET LOG_TBL                     = CONCAT("_SESSION.",FEED_NAME, "_pipeline_info");
SET GMI_PRD_TBL                 = CONCAT("_SESSION.",FEED_NAME, "_gmi_products");
SET DELTA_TEMP_TABLE            = LOWER(DELTA_TEMP_TABLE);
SET FEED_NAME                   = LOWER(FEED_NAME);
SET RPC_FIELD                   = LOWER(RPC_FIELD);
SET DATASET                     = LOWER(DATASET);


/* Generating pipeline upc code. */
IF CALCULATE_UPC_CHECK_DIGIT_FLG THEN
  SET PIPELINE_UPC = CONCAT("SAFE_CAST(transient.generate_upc_check_digit(",UPC_FIELD,") as BIGINT)");
ELSE
  SET PIPELINE_UPC = CONCAT("SAFE_CAST(",UPC_FIELD," as BIGINT)");
END IF;


/* Computing latest batch_number for current feed. */
EXECUTE IMMEDIATE FORMAT("""
      SELECT COALESCE(MAX(batch_number),0) + 1
      FROM %s
      WHERE LOWER(message_owner) = '%s'
""",PIPELINE_LOGGING_TBL,FEED_NAME) INTO BATCH_NUMBER;


/* Create temp logging table which ensures consistency in logging table in case of failures. */
EXECUTE IMMEDIATE FORMAT("""
   CREATE TEMP TABLE `%s` (
        message_owner STRING,
		customer_parent STRING,
		message_type STRING,
		message_text STRING,
		message_value INT64,
		message_status STRING,
		message_grain STRING,
		batch_number INT64,
		execution_ts TIMESTAMP
	)
""", LOG_TBL);



/* Create pipeline master table which acts as a source for fuzzy match. */
EXECUTE IMMEDIATE CONCAT("""
    CREATE TEMP TABLE `""",PIPELINE_MASTER_DATA,"""` AS (
            SELECT *
            FROM
            (
                SELECT
                    DISTINCT
                            LOWER(x.customer_parent) as customer_parent,
                            x.material_cd,
                            x.material_type_cd,
                            x.ean_13_digit_retail_upc as suggested_upc,
                            LOWER(x.latest_customer_product_cd) as rpc,
                            x.parent_material_cd,
	        	            x.ean_upc_derived_cd,
	        	            ABS(FARM_FINGERPRINT(CONCAT(
                              COALESCE(SAFE_CAST(ean_upc_derived_cd AS STRING),''),
	        	              transient.remove_special_chars(x.material_short_desc)))
	        	            ) as derivedupc_gmititle_key, -- using this because pim_product_title may change by customer
                            transient.remove_special_chars(IFNULL(pim.consumer_product_name_txt , x.material_short_desc)) as pim_product_title,
	        	            x.material_short_desc,
	        	            x.current_flg,
	        	            x.upc_package_prefix_cd,
                            'GMI' as manufacturer,
                            TRUE as expected_is_gmi_product, -- need to check division if divestiture then false else true
                            FALSE as expected_is_pet,
                            TRUE as expected_is_gmi_data,
                            'GMI' as data_owner,
                            'ecomm_product_catalog' as data_source
                FROM processed.ecomm_product_catalog_v3 x
	            LEFT JOIN processed.fuzzy_match_pim_active_na pim
	        	on SAFE_CAST(pim.material_nbr AS STRING) = x.material_nbr
                WHERE UPPER(x.customer_parent) IN (SELECT DISTINCT UPPER(customer_parent) from processed.lkp_customer UNION ALL SELECT 'GMI')
                     AND x.material_type_cd IN (""",MATERIAL_TYPE_CDS,""")
                UNION DISTINCT
                SELECT
                        LOWER(x.platformname) AS customer_parent,
                        x.masterproductid AS gmi_material_cd,
                        'CNPK' AS material_type_cd,
                        transient.generate_upc_check_digit(nielsenupc) AS suggested_upc,
                        '' AS rpc,
                        '' AS parent_material_cd,
                        nielsenupc,
                        ABS(FARM_FINGERPRINT(CONCAT( COALESCE(SAFE_CAST(nielsenupc AS STRING),
                                ''), transient.remove_special_chars(x.skuname)))) AS derivedupc_gmititle_key,
                        transient.remove_special_chars(skuname) AS pim_product_title,
                        x.skuname,
                        TRUE AS current_flg,
                        '' AS upc_package_prefix_cd,
                        'GMI' as manufacturer,
                        TRUE as expected_is_gmi_product,
                        TRUE as expected_is_pet,
                        TRUE as expected_is_gmi_data,
                        'GMI' as data_owner,
                        'stonehenge_table' as data_source
                FROM
                    `ecomm-dlf-prd-634888.processed.lkp_stonehenge_product_master` x
                WHERE SAFE_CAST(upc as BIGINT) is not null
                UNION DISTINCT
                SELECT
                    DISTINCT
                            LOWER(x.gmi_manufacturer_desc) AS customer_parent,
                            x.material_cd AS gmi_material_cd,
                            'CNPK' AS material_type_cd,
                            ean_upc_derived_cd AS suggested_upc,
                            '' AS rpc,
                            '' AS parent_material_cd,
                            ean_upc_derived_cd,
                            ABS(FARM_FINGERPRINT(CONCAT( COALESCE(SAFE_CAST(ean_upc_derived_cd AS STRING),
                                    ''), transient.remove_special_chars(x.product_desc)))) AS derivedupc_gmititle_key,
                            transient.remove_special_chars(product_desc) AS pim_product_title,
                            x.product_desc,
                            TRUE AS current_flg,
                            '' AS upc_package_prefix_cd,
                            IF(lower(gmi_manufacturer_desc) = 'gmi', 'GMI', 'OTHER') as manufacturer,
                            IF(lower(gmi_manufacturer_desc) = 'gmi', True, False) as expected_is_gmi_product,
                            IF(lower(gmi_category_desc) = 'pet', TRUE, FALSE) as expected_is_pet,
                            FALSE as expected_is_gmi_data,
                            'NIELSEN' as data_owner,
                            'dim_nielsen_connect_pos_us_product' as data_source
                FROM
                    `edw-prd-e567f9.syndicated_nielsen.dim_nielsen_connect_pos_us_product` x
                WHERE lower(gmi_manufacturer_desc) != 'gmi'
            )
    )
""");


/* Computing all the possible combinations of available product types per data source. */
FOR cols in (SELECT col, ROW_NUMBER() over() as rn FROM UNNEST(FUZZY_FILTER_COLUMN_LIST) as col)
DO
    IF cols.rn != 1 THEN
        SET AVAILABLE_COMBINATIONS = CONCAT(AVAILABLE_COMBINATIONS,",' AND ");
    END IF;
    SET AVAILABLE_COMBINATIONS = CONCAT(AVAILABLE_COMBINATIONS,"pm",".",cols.col, " = ', UPPER(CAST(", cols.col," AS STRING))");
END FOR;

SET AVAILABLE_COMBINATIONS  = (SELECT CONCAT("SELECT DISTINCT CONCAT(' AND "
                                              ,AVAILABLE_COMBINATIONS,
                                              ",' AND LOWER(pm.data_source)=LOWER(\"',data_source,'\")') AS AVAILABLE_COMBINATIONS FROM ",
                                              PIPELINE_MASTER_DATA));

EXECUTE IMMEDIATE FORMAT("SELECT ARRAY_AGG(AVAILABLE_COMBINATIONS) FROM (%s)",AVAILABLE_COMBINATIONS) INTO TOTAL_FUZZY_FILTER_COMBINATIONS;


/* Listing out all the gmi upc prefix code. */
EXECUTE IMMEDIATE CONCAT("""
  	    SELECT CONCAT("(^",STRING_AGG(DISTINCT x.upc_package_prefix_cd, '|^'),"|""",BLUE_COMPANY_PREFIX_CD,""")") as regex_val
  	    FROM """,PIPELINE_MASTER_DATA,""" x
  	    WHERE x.manufacturer = 'GMI' and SAFE_CAST(x.upc_package_prefix_cd AS BIGINT) is not null
      """) INTO GMI_PRODUCTS_PREFIX_LIST;

/* Create temp GMI table. */
EXECUTE IMMEDIATE FORMAT("""
  CREATE TEMP TABLE `%s` AS (
    SELECT DISTINCT
      x.material_cd,
      x.material_type_cd,
      x.suggested_upc,
      x.parent_material_cd,
      x.pim_product_title,
      x.material_short_desc,
      x.ean_upc_derived_cd,
      x.derivedupc_gmititle_key,
      x.expected_is_pet,
      x.expected_is_gmi_product,
      x.expected_is_gmi_data,
      x.data_source
    FROM `%s` x
  )
""", GMI_PRD_TBL, PIPELINE_MASTER_DATA);

/* Create SQL strings to gather stats. Some tables don't have RPC columns and names may be different in others. */
EXECUTE IMMEDIATE FORMAT("""
  SELECT
    CASE WHEN IFNULL(COUNT(1),0) = 0 THEN
      "SUM(CASE WHEN COALESCE(TRIM(%s),'') <> '' THEN 1 ELSE 0 END) as upc_cnt, 0 as rpc_cnt, COUNT(*) as total_records"
    ELSE
      "SUM(CASE WHEN COALESCE(TRIM(%s),'') <> '' THEN 1 ELSE 0 END) as upc_cnt, SUM(CASE WHEN COALESCE(TRIM(%s),'') <> '' THEN 1 ELSE 0 END) as rpc_cnt, COUNT(*) as total_records"
    END
  FROM transient.INFORMATION_SCHEMA.COLUMNS
  WHERE table_name='%s' AND column_name = '%s'
""",UPC_FIELD,UPC_FIELD,RPC_FIELD, DELTA_TEMP_TABLE, RPC_FIELD) INTO SUMMARY_QUERY;


/* Add DATASET To table since we need it going forward. */
SET DELTA_TEMP_TABLE = CONCAT(DATASET,".",DELTA_TEMP_TABLE);


/* Gather initial stats from pipeline data using SQL strings created above. */
EXECUTE IMMEDIATE FORMAT("""
  SELECT
    total_records, upc_cnt, rpc_cnt
  FROM (SELECT %s FROM %s)
""", SUMMARY_QUERY, DELTA_TEMP_TABLE) INTO TOTAL_RECORD_CNT, UPC_CNT, RPC_CNT;


/* Create FINGERPRINT based on availability of RPC columns. */
IF RPC_CNT > 0 THEN

  SET RECORD_KEY = CONCAT("""
    ABS(FARM_FINGERPRINT(
      CONCAT(COALESCE(SAFE_CAST(""",UPC_FIELD,""" AS STRING),''),
      transient.remove_special_chars(""",PRODUCT_TITLE_FIELD,"""),
      COALESCE(SAFE_CAST(""",RPC_FIELD,""" AS STRING),''))))""");

  SET DELTA_TBL_COLUMN_LIST = CONCAT(""" delta.""",UPC_FIELD,""" , delta.""",RPC_FIELD,""" , delta.""",
                                     PRODUCT_TITLE_FIELD,""" , delta.""", CUSTOMER_NAME_COLUMN);
ELSE

  SET RECORD_KEY = CONCAT("""
    ABS(FARM_FINGERPRINT(CONCAT(
      COALESCE(SAFE_CAST(""",UPC_FIELD,""" AS STRING),''),
      transient.remove_special_chars(""",PRODUCT_TITLE_FIELD,"""))))""");

  SET DELTA_TBL_COLUMN_LIST = CONCAT(""" delta.""",UPC_FIELD,""" , delta.""",PRODUCT_TITLE_FIELD,""" , delta.""",
                                        CUSTOMER_NAME_COLUMN);
END IF;

/* If we have records then start processing. */
IF TOTAL_RECORD_CNT > 0 THEN

    /* Create needed Temp tables. */
    EXECUTE IMMEDIATE FORMAT("""
      CREATE TEMP TABLE `%s` AS
      (
        SELECT
          %s,
    	  0 as record_key,
    	  SAFE_CAST(0 as BIGINT) as pipeline_upc,
    	  '' as pipeline_customer_name,
    	  false as provided_is_gmi_product,
    	  '' as pim_product_title,
    	  '' as material_short_desc,
    	  '' as suggested_upc,
    	  '' as material_cd,
    	  '' as material_type_cd,
    	  0  as derivedupc_gmititle_key,
          '' as match_type,
          false as provided_is_pet,
          false as expected_is_gmi_product,
          false as expected_is_pet,
          '' as data_source
        FROM `%s` delta LIMIT 0
      )
    """, GMI_PRD_MAPPING_TBL, DELTA_TBL_COLUMN_LIST, DELTA_TEMP_TABLE);

	/* Replica of delta_temp table to save unnecessary processing of non-required columns and huge data*/
    EXECUTE IMMEDIATE FORMAT("""
      CREATE TEMP TABLE `%s` AS
      (
		  SELECT *
		  FROM
		  (
            SELECT DISTINCT
            %s,
            %s as record_key,
            %s as pipeline_upc,
            %s as pipeline_customer_name,
            REGEXP_CONTAINS(SAFE_CAST(IFNULL(%s,0) AS STRING), '%s') as provided_is_gmi_product
            FROM `%s` delta
	      )r
	      WHERE r.record_key NOT IN (SELECT DISTINCT record_key FROM %s WHERE UPPER(feed_name) = '%s' )
      )
    """, DT_PIPELINE_TBL,
         DELTA_TBL_COLUMN_LIST,
         RECORD_KEY,
         PIPELINE_UPC,
         CUSTOMER_NAME_COLUMN,
         PIPELINE_UPC,
         GMI_PRODUCTS_PREFIX_LIST,
         DELTA_TEMP_TABLE,
         PIPELINE_FINAL_OUTPUT_TBL,
         UPPER(FEED_NAME));

    /* Logging Total Records , Upc count & RPC counts into Logging Table. */

    EXECUTE IMMEDIATE CONCAT("""
          SELECT ARRAY_AGG(logging_msg)
          FROM
              (
                  SELECT STRUCT('""",LOG_TBL,"""' as log_tbl,
                                '""",FEED_NAME,"""' as message_owner,
                                '""",FEED_NAME,"""' as customer_parent,
                                '""",PIPELINE_INGESTION_MSG,"""' as ingestion_pipeline_msg,
                                'Total records received' as message_text,
                                """,TOTAL_RECORD_CNT,""" as message_value,
                                'pipeline initiated' as message_status,
                                'summary' as message_grain,
                                """,BATCH_NUMBER,""" as batch_number) as logging_msg
                  UNION ALL
                  SELECT STRUCT('""",LOG_TBL,"""' as log_tbl,
                                '""",FEED_NAME,"""' as message_owner,
                                '""",FEED_NAME,"""' as customer_parent,
                                '""",PIPELINE_INGESTION_MSG,"""' as ingestion_pipeline_msg,
                                'Total records with upc' as message_text,
                                """,UPC_CNT,""" as message_value,
                                'pipeline initiated' as message_status,
                                'summary' as message_grain,
                                """,BATCH_NUMBER,""" as batch_number)
                   UNION ALL
                  SELECT STRUCT('""",LOG_TBL,"""' as log_tbl,
                                '""",FEED_NAME,"""' as message_owner,
                                '""",FEED_NAME,"""' as customer_parent,
                                '""",PIPELINE_INGESTION_MSG,"""' as ingestion_pipeline_msg,
                                'Total records with rpc' as message_text,
                                """,RPC_CNT,""" as message_value,
                                'pipeline initiated' as message_status,
                                'summary' as message_grain,
                                """,BATCH_NUMBER,""" as batch_number)
              )
    """) INTO PIPELINE_LOG_MSG;

    CALL transient.pipeline_log_msg_to_table(PIPELINE_LOG_MSG);

    /* Start with UPC match if we have UPCs in the data. */
    IF UPC_CNT > 0 THEN

        /* We need to account for case upcs here so we cant insert this data just yet!. Need a break down of how many were CNPKs and how many were FINIs. */

        EXECUTE IMMEDIATE FORMAT("""
          INSERT INTO `%s`
            SELECT
              delta.*,
              gmi.pim_product_title,
              gmi.material_short_desc,
              gmi.suggested_upc,
              gmi.material_cd,
              gmi.material_type_cd,
              gmi.derivedupc_gmititle_key,
              IF(UPPER(material_type_cd)='CNPK','cnpk_upc','fini_upc') as match_type,
              REGEXP_CONTAINS(SAFE_CAST(IFNULL(delta.pipeline_upc,0) AS STRING), "(%s)") OR REGEXP_CONTAINS(IFNULL(LOWER(delta.%s),''), "(%s)") as provided_is_pet,
              gmi.expected_is_gmi_product,
              gmi.expected_is_pet,
              gmi.data_source
            FROM %s delta
            JOIN %s gmi ON delta.pipeline_upc = SAFE_CAST(gmi.suggested_upc as BIGINT)
          """, GMI_PRD_MAPPING_TBL,
               BLUE_COMPANY_PREFIX_CD,
               PRODUCT_TITLE_FIELD,
               PET_EXCLUSIONS_STRING,
               DT_PIPELINE_TBL,
               GMI_PRD_TBL
        );

        /* Log results from UPC match. */
        EXECUTE IMMEDIATE CONCAT("""
              SELECT
                  ARRAY_AGG
                          (
                             STRUCT
                                  (
                                      '""",LOG_TBL,"""' as log_tbl,
                                      '""",FEED_NAME,"""' as message_owner,
                                      COALESCE(pipeline_customer_name,'Unknown') as customer_parent,
                                      '""",PIPELINE_INGESTION_MSG,"""' as ingestion_pipeline_msg,
                                      'Total records with valid upc' as message_text,
                                      COALESCE(total_records,0) as message_value,
                                      'logged valid upc' as message_status,
                                      'detail' as message_grain,
                                      """,BATCH_NUMBER,""" as batch_number
                                  )
                          ),
                  COALESCE(SUM(total_records),0)
              FROM
                  (
                      SELECT
                        pipeline_customer_name, COUNT(*) as total_records
                      FROM `""",GMI_PRD_MAPPING_TBL,"""`
                      WHERE match_type='cnpk_upc'
                      GROUP BY pipeline_customer_name
                  )
        """) INTO PIPELINE_LOG_MSG, UPC_CNT;

        CALL transient.pipeline_log_msg_to_table(PIPELINE_LOG_MSG);

    ELSE
        EXECUTE IMMEDIATE CONCAT("""
            SELECT
                    [
                       STRUCT
                            (
                                '""",LOG_TBL,"""' as log_tbl,
                                '""",FEED_NAME,"""' as message_owner,
                                '""",FEED_NAME,"""' as customer_parent,
                                '""",PIPELINE_INGESTION_MSG,"""' as ingestion_pipeline_msg,
                                'Total records with valid upc' as message_text,
                                0 as message_value,
                                'skipped upc processing' as message_status,
                                'detail' as message_grain,
                                """,BATCH_NUMBER,""" as batch_number
                            )
                    ],
        """) INTO PIPELINE_LOG_MSG;

        CALL transient.pipeline_log_msg_to_table(PIPELINE_LOG_MSG);

    END IF;

    /* If we have RPCs then match using customer_name and rpc. */
    IF RPC_CNT > 0 THEN

        /* Matching rpc records with pipeline master table to fetch correct details. */
        EXECUTE IMMEDIATE FORMAT("""
            INSERT INTO `%s`
              WITH delta_cte AS (
                SELECT
                  delta.* ,
                  LOWER(%s) as normalised_customer_parent,
                  LOWER(`%s`) as normalised_rpc
                FROM `%s` delta
              )
              SELECT
                cte.* EXCEPT(normalised_customer_parent, normalised_rpc),
		    	gmi.pim_product_title,
		    	gmi.material_short_desc,
		    	gmi.suggested_upc,
		    	gmi.material_cd,
		    	gmi.material_type_cd,
		    	gmi.derivedupc_gmititle_key,
                'rpc' as match_type,
                REGEXP_CONTAINS(SAFE_CAST(IFNULL(cte.pipeline_upc,0) AS STRING), "(%s)") OR REGEXP_CONTAINS(IFNULL(LOWER(cte.%s),''), "(%s)") as provided_is_pet,
                gmi.expected_is_gmi_product,
                gmi.expected_is_pet,
                gmi.data_source
              FROM delta_cte cte
              JOIN `%s` gmi ON
              (
                cte.normalised_customer_parent = LOWER(gmi.customer_parent) AND cte.normalised_rpc = gmi.rpc
              )
		      WHERE gmi.material_type_cd='CNPK'
        """, GMI_PRD_MAPPING_TBL, CUSTOMER_NAME_COLUMN ,RPC_FIELD, DT_PIPELINE_TBL, BLUE_COMPANY_PREFIX_CD, PRODUCT_TITLE_FIELD, PET_EXCLUSIONS_STRING, PIPELINE_MASTER_DATA);

        /* Log results from customer_name and rpc match. */

        EXECUTE IMMEDIATE CONCAT("""
               SELECT
                   ARRAY_AGG
                           (
                              STRUCT
                                   (
                                       '""",LOG_TBL,"""' as log_tbl,
                                       '""",FEED_NAME,"""' as message_owner,
                                       COALESCE(pipeline_customer_name,'Unknown') as customer_parent,
                                       '""",PIPELINE_INGESTION_MSG,"""' as ingestion_pipeline_msg,
                                       'Total records with valid rpc' as message_text,
                                       COALESCE(total_records,0) as message_value,
                                       'logged valid rpc' as message_status,
                                       'detail' as message_grain,
                                       """,BATCH_NUMBER,""" as batch_number
                                   )
                           ),
                   COALESCE(SUM(total_records),0)
               FROM
                   (
                       SELECT
                         pipeline_customer_name, COUNT(*) as total_records
                       FROM `""",GMI_PRD_MAPPING_TBL,"""`
                       WHERE match_type='rpc'
                       GROUP BY pipeline_customer_name
                   )
        """) INTO PIPELINE_LOG_MSG, RPC_CNT;

        CALL transient.pipeline_log_msg_to_table(PIPELINE_LOG_MSG);
	ELSE
        EXECUTE IMMEDIATE CONCAT("""
            SELECT
                    [
                       STRUCT
                            (
                                '""",LOG_TBL,"""' as log_tbl,
                                '""",FEED_NAME,"""' as message_owner,
                                '""",FEED_NAME,"""' as customer_parent,
                                '""",PIPELINE_INGESTION_MSG,"""' as ingestion_pipeline_msg,
                                'Total records with valid rpc' as message_text,
                                0 as message_value,
                                'skipped rpc processing' as message_status,
                                'detail' as message_grain,
                                """,BATCH_NUMBER,""" as batch_number
                            )
                    ],
        """) INTO PIPELINE_LOG_MSG;

        CALL transient.pipeline_log_msg_to_table(PIPELINE_LOG_MSG);
    END IF;

    /* Re-create temp GMI table by removing duplicates. */

    EXECUTE IMMEDIATE CONCAT("""DROP TABLE IF EXISTS """,GMI_PRD_TBL);

    EXECUTE IMMEDIATE FORMAT("""
      CREATE TEMP TABLE `%s` AS (
        SELECT DISTINCT
          x.material_cd,
          x.material_type_cd,
          x.suggested_upc,
          x.parent_material_cd,
          x.pim_product_title,
          x.material_short_desc,
          x.ean_upc_derived_cd,
          x.derivedupc_gmititle_key,
          x.expected_is_pet,
          x.expected_is_gmi_product,
          x.expected_is_gmi_data,
          x.data_source
        FROM `%s` x
              /* distinct based on upc as same upc can have different title. */
        QUALIFY  1 = ROW_NUMBER() over(partition by manufacturer, material_cd, suggested_upc order by current_flg desc)
              /* distinct based on title as same title can have different upc. */
            AND  1 = ROW_NUMBER() over(partition by manufacturer, material_cd, pim_product_title order by current_flg desc)
      )
    """, GMI_PRD_TBL, PIPELINE_MASTER_DATA);

     /* JOIN WITH OVERRIDES UPC */

	EXECUTE IMMEDIATE FORMAT("""
        INSERT INTO `%s`
          SELECT
            delta.*,
			gmi.pim_product_title,
			gmi.material_short_desc,
			gmi.suggested_upc,
			gmi.material_cd,
			gmi.material_type_cd,
			gmi.derivedupc_gmititle_key,
            'override_upc' as match_type,
            REGEXP_CONTAINS(SAFE_CAST(IFNULL(delta.pipeline_upc,0) AS STRING), "(%s)") OR REGEXP_CONTAINS(IFNULL(LOWER(delta.%s),''), "(%s)") as provided_is_pet,
            gmi.expected_is_gmi_product,
            gmi.expected_is_pet,
            gmi.data_source
          FROM %s delta
		  JOIN processed.override_upc ou on
		                    delta.%s = ou.original_upc
		                and lower(ou.feed_name) = '%s'
          JOIN %s gmi ON SAFE_CAST(ou.updated_upc as BIGINT) = SAFE_CAST(gmi.suggested_upc as BIGINT)
		  WHERE delta.record_key NOT IN (SELECT distinct record_key from %s)
      """, GMI_PRD_MAPPING_TBL,
           BLUE_COMPANY_PREFIX_CD,
           PRODUCT_TITLE_FIELD,
           PET_EXCLUSIONS_STRING,
           DT_PIPELINE_TBL,
           UPC_FIELD,
           LOWER(FEED_NAME),
           GMI_PRD_TBL,
           GMI_PRD_MAPPING_TBL);


	/* Identifying records count whose parent_material_cd don't have material_type_cd as cnpk. */
    EXECUTE IMMEDIATE FORMAT(
            """
                SELECT IFNULL(COUNT(*),0)
                FROM %s
                WHERE material_type_cd = 'FINI'
            """,GMI_PRD_MAPPING_TBL
    ) INTO CHECK_FINI_UPC_CNT;

	IF CHECK_FINI_UPC_CNT > 0 THEN

	    /* Mapping FINI upc to CNPK upc. */

        EXECUTE IMMEDIATE FORMAT("""
		    INSERT INTO `%s`
		    	WITH
		    		CTE AS (
		    		SELECT
		    			gmi.*
		    		FROM
		    			%s gmi
		    		WHERE
		    			material_type_cd = 'FINI'),
		    		CTE1 AS (
		    		SELECT
		    			*
		    		FROM
		    			UNNEST(transient.convert_fini_to_cnpk((
		    				SELECT
		    				ARRAY_AGG(DISTINCT cte.material_cd)
		    				FROM
		    				cte))) )
		    	SELECT
		    	    cte.* EXCEPT (match_type, provided_is_pet, expected_is_gmi_product, expected_is_pet, suggested_upc,material_cd,material_type_cd, derivedupc_gmititle_key, data_source),
		    	    cte1.suggested_upc,
		    	    cte1.material_cd,
		    	    cte1.material_type_cd,
		    	    cte.derivedupc_gmititle_key,
		    	    IF(cte1.is_cnpk_upc_found,'fini_to_cnpk_upc','cnpk_upc_not_found') AS match_type,
		    	    cte.provided_is_pet,
		    	    cte.expected_is_gmi_product,
		    	    cte.expected_is_pet,
		    	    cte.data_source
		    	FROM cte
		    	JOIN cte1
		    	    ON 	cte.material_cd = cte1.parent_material_cd
		""", GMI_PRD_MAPPING_TBL, GMI_PRD_MAPPING_TBL);
    END IF;


    /* Refining pipeline delta_temp table to get only those records which are not matched using upc and rpc. */

    EXECUTE IMMEDIATE FORMAT("""
            CREATE TEMP TABLE %s
               AS (
                      SELECT DISTINCT
	                         delta_cte.%s as provided_upc,
	                         LOWER(delta_cte.%s) as provided_title,
	                         REGEXP_CONTAINS(SAFE_CAST(IFNULL(%s,0) AS STRING), '%s') as provided_is_gmi_product,
	                         REGEXP_CONTAINS(SAFE_CAST(IFNULL(delta_cte.pipeline_upc,0) AS STRING), "(%s)") OR REGEXP_CONTAINS(IFNULL(LOWER(delta_cte.%s),''), "(%s)") as provided_is_pet,
	                         delta_cte.record_key
	                  FROM %s delta_cte
	                  WHERE record_key NOT IN (SELECT DISTINCT record_key FROM %s)
	                  QUALIFY 1 = ROW_NUMBER() OVER(PARTITION BY LOWER(delta_cte.%s))
	            )
    """,
        REFINED_DT_PIPELINE_TBL,
        UPC_FIELD,
        PRODUCT_TITLE_FIELD,
        PIPELINE_UPC,
        GMI_PRODUCTS_PREFIX_LIST,
        BLUE_COMPANY_PREFIX_CD,
        PRODUCT_TITLE_FIELD,
        PET_EXCLUSIONS_STRING,
	    DT_PIPELINE_TBL,
	    GMI_PRD_MAPPING_TBL,
	    PRODUCT_TITLE_FIELD
    );

    /* Processing all the remaining records for fuzzy match. */

    FOR filters IN (SELECT filter_val,
                           ROW_NUMBER() over() as rn_1
                           FROM UNNEST(TOTAL_FUZZY_FILTER_COMBINATIONS) as filter_val)
    DO
        IF filters.rn_1 = 1 THEN
            SET FUZZY_TEMP_TBL_SQL =  CONCAT("CREATE TEMP TABLE ",FUZZY_TEMP_TBL," AS ");
        ELSE
            SET FUZZY_TEMP_TBL_SQL = CONCAT("INSERT INTO ",FUZZY_TEMP_TBL," ");
        END IF;

        EXECUTE IMMEDIATE FORMAT("""
            CREATE TEMP TABLE %s AS (
                WITH pc as (
                    SELECT *
                    FROM %s pm
                    WHERE
                            pm.material_type_cd='CNPK'
                            %s
                )
                SELECT DISTINCT
                delta_temp.provided_upc,
                delta_temp.provided_title,
                delta_temp.record_key,
                delta_temp.provided_is_gmi_product,
                delta_temp.provided_is_pet,
                pc.expected_is_pet,
                pc.expected_is_gmi_product,
                pc.suggested_upc,
                pc.pim_product_title,
                pc.material_short_desc,
                pc.material_cd,
                pc.material_type_cd,
                pc.derivedupc_gmititle_key,
                pc.data_source
                FROM %s delta_temp
                JOIN pc on soundex(delta_temp.provided_title) = soundex(pc.pim_product_title)
                        and pc.expected_is_pet = delta_temp.provided_is_pet
            )
        """,
            FUZZY_INPUT_TBL,
            GMI_PRD_TBL,
            filters.filter_val,
            REFINED_DT_PIPELINE_TBL
        );

        EXECUTE IMMEDIATE FORMAT("""
            %s
            (
                WITH fuzzy_match_output AS (
                	SELECT *
                	FROM
                	    (
                			SELECT
                				provided_title,
                				provided_upc,
                				suggested_upc,
                				record_key,
                				pim_product_title,
                				material_short_desc,
                				material_cd,
                				material_type_cd,
                				derivedupc_gmititle_key,
                				provided_is_pet,
                				provided_is_gmi_product,
                				expected_is_pet,
                				expected_is_gmi_product,
                				data_source,
                				SAFE_CAST(material_type_cd != 'CNPK' AS INT64) AS material_type_rank,
                				`processed.fuzzy_matching_levenshtein_distance`(provided_title, pim_product_title) levenshtein_distance, -- lower means both strings are similar
                				ROUND(`processed.fuzzy_matching_levenshtein_ratio`(provided_title, pim_product_title),2) levenshtein_ratio,-- high ratio shows similarity
                				ROUND(`processed.fuzzy_matching_token_sort_ratio`(provided_title, pim_product_title),2) tokenize_sort_ratio, -- high ratio shows similarity
                				ROUND(`processed.fuzzy_matching_token_set_ratio`(provided_title, pim_product_title),2) tokenize_set_ratio,-- high ratio shows similarity
                			FROM %s
                		)q WHERE tokenize_sort_ratio > %f
                		   QUALIFY 1 = RANK() OVER(PARTITION BY provided_title ORDER BY levenshtein_distance ASC,
                		                                                tokenize_sort_ratio DESC,
                	                                                    tokenize_set_ratio DESC,
                	                                                    material_type_rank ASC,
                	                                                    material_cd DESC)
                )
                SELECT
                		derivedupc_gmititle_key,
                		record_key,
                		material_cd,
                		material_type_cd,
                		suggested_upc,
                		pim_product_title,
                		material_short_desc,
                		ARRAY_AGG(
                		            STRUCT(
                		                    '%s' as feed_name,
                		                    provided_title,
                		                    provided_upc,
                		                    levenshtein_distance as string_variance,
                		                    tokenize_sort_ratio as match_score,
                		                    'product_title' as match_type,
                		                    provided_is_gmi_product,
                		                    provided_is_pet,
                		                    expected_is_gmi_product,
                		                    expected_is_pet,
                		                    data_source
                		            )
                		) as source_record
                FROM fuzzy_match_output
                GROUP BY
                		derivedupc_gmititle_key,
                		record_key,
                		material_cd,
                		material_type_cd,
                		suggested_upc,
                		pim_product_title,
                		material_short_desc
            )
            """, FUZZY_TEMP_TBL_SQL,
                 FUZZY_INPUT_TBL,
                 MATCH_THRESHOLD,
                 INITCAP(FEED_NAME)
        );

        EXECUTE IMMEDIATE FORMAT("""DROP TABLE IF EXISTS %s""",FUZZY_INPUT_TBL);

    END FOR;

	/* Merging results of upc match, rpc match & fuzzy match into fuzzy output table. */
	EXECUTE IMMEDIATE CONCAT("""
		MERGE INTO """,PIPELINE_FINAL_OUTPUT_TBL,""" tgt
		USING
		(
			SELECT *
			FROM
			(
					SELECT
						derivedupc_gmititle_key,
						record_key,
						material_cd,
						material_type_cd,
						suggested_upc,
						pim_product_title,
						material_short_desc,
						src_record.feed_name,
						src_record.provided_title,
						src_record.provided_upc,
						src_record.string_variance,
						src_record.match_score,
						src_record.match_type,
						src_record.provided_is_gmi_product,
						src_record.provided_is_pet,
						src_record.expected_is_gmi_product,
						src_record.expected_is_pet,
						src_record.data_source,
						DATE('""",RUN_DATE,"""') as run_date
					FROM """,FUZZY_TEMP_TBL,""" ,
					UNNEST(source_record) as src_record
					UNION ALL
					SELECT
						derivedupc_gmititle_key,
						record_key,
						material_cd,
						material_type_cd,
						suggested_upc,
						pim_product_title,
						material_short_desc,
						'""",INITCAP(FEED_NAME),"""' as feed_name,
						lower(""",PRODUCT_TITLE_FIELD,""") as provided_title,
						""",UPC_FIELD,""" as provided_upc,
						0 as string_variance,
						0 as match_score,
						match_type,
						provided_is_gmi_product,
						provided_is_pet,
						expected_is_gmi_product,
						expected_is_pet,
						data_source,
						DATE('""",RUN_DATE,"""') as run_date
					FROM """,GMI_PRD_MAPPING_TBL,"""
		    ) QUALIFY  1 = ROW_NUMBER() OVER (PARTITION BY record_key ORDER by match_score DESC)
		) src
		ON
		        src.record_key              = tgt.record_key
		    AND src.provided_upc            = tgt.provided_upc
		    AND src.provided_title          = tgt.provided_title
		    AND src.feed_name               = tgt.feed_name
		WHEN NOT MATCHED THEN INSERT ROW
		WHEN MATCHED THEN UPDATE
			SET
				tgt.record_key = src.record_key,
				tgt.material_cd = src.material_cd,
				tgt.material_type_cd = src.material_type_cd,
				tgt.suggested_upc = src.suggested_upc,
				tgt.pim_product_title = src.pim_product_title,
				tgt.material_short_desc = src.material_short_desc,
				tgt.feed_name = src.feed_name,
				tgt.provided_title = src.provided_title,
				tgt.provided_upc = src.provided_upc,
				tgt.string_variance = src.string_variance,
				tgt.match_score = src.match_score,
				tgt.provided_is_gmi_product = src.provided_is_gmi_product,
				tgt.match_type = src.match_type,
				tgt.provided_is_pet = src.provided_is_pet,
				tgt.expected_is_gmi_product = src.expected_is_gmi_product,
				tgt.expected_is_pet = src.expected_is_pet,
				tgt.data_source = src.data_source,
				tgt.run_date = src.run_date
	""");

	/* Product Enrichment */

	/* Nielsen Enrichment */

	/* Logging total records processed for fuzzy title match. */
    EXECUTE IMMEDIATE CONCAT("""
            WITH CTE AS (
                SELECT src.provided_upc
                FROM `""",FUZZY_TEMP_TBL,"""` fuzzy,
                UNNEST(source_record) as src
            ),
            CTE1 AS (
                SELECT delta.pipeline_customer_name as pipeline_customer_name, COUNT(*) as total_records
                FROM cte
                JOIN `""",DT_PIPELINE_TBL,"""` delta on SAFE_CAST(cte.provided_upc AS BIGINT) = SAFE_CAST(delta.""",UPC_FIELD,""" AS BIGINT)
                GROUP BY delta.pipeline_customer_name
            )
            SELECT
                ARRAY_AGG
                        (
                           STRUCT
                                (
                                    '""",LOG_TBL,"""' as log_tbl,
                                    '""",FEED_NAME,"""' as message_owner,
                                    COALESCE(pipeline_customer_name,'Unknown') as customer_parent,
                                    '""",PIPELINE_INGESTION_MSG,"""' as ingestion_pipeline_msg,
                                    'Total records above title search threshold of """,MATCH_THRESHOLD,"""' as message_text,
                                    COALESCE(total_records,0) as message_value,
                                    'product title match completed' as message_status,
                                    'detail' as message_grain,
                                    """,BATCH_NUMBER,""" as batch_number
                                )
                        ),
                COALESCE(SUM(total_records),0)
            FROM CTE1
    """) INTO PIPELINE_LOG_MSG, PROD_TITLE_CNT;

    CALL transient.pipeline_log_msg_to_table(PIPELINE_LOG_MSG);

    /* Logging total records processed based on categories of products. */
    EXECUTE IMMEDIATE CONCAT("""
         SELECT
                ARRAY_AGG
                        (
                           STRUCT
                                (
                                    '""",LOG_TBL,"""' as log_tbl,
                                    '""",FEED_NAME,"""' as message_owner,
                                    '""",FEED_NAME,"""' as customer_parent,
                                    '""",PIPELINE_INGESTION_MSG,"""' as ingestion_pipeline_msg,
                                    COALESCE(product_type,'') as message_text,
                                    COALESCE(total_records,0) as message_value,
                                    'processed product types' as message_status,
                                    'detail' as message_grain,
                                    """,BATCH_NUMBER,""" as batch_number
                                )
                        )
         FROM
         (
             SELECT
                    product_type, count(*) total_records
             FROM
             (
                 SELECT CASE
                            WHEN expected_is_pet = FALSE AND expected_is_gmi_product = FALSE THEN 'Non GMI & Non Pet Products'
                            WHEN expected_is_pet = TRUE  AND expected_is_gmi_product = FALSE THEN 'Non GMI Pet Products'
                            WHEN expected_is_pet = FALSE AND expected_is_gmi_product = TRUE  THEN 'GMI Non Pet Products'
                            WHEN expected_is_pet = TRUE  AND expected_is_gmi_product = TRUE  THEN 'GMI Pet Products'
                            ELSE ''
                       END as product_type, record_key
                 FROM """,PIPELINE_FINAL_OUTPUT_TBL,"""
                 WHERE feed_name = '""",INITCAP(FEED_NAME),"""' AND DATE(run_date) = DATE('""",RUN_DATE,"""')
             ) group by product_type
         )
    """) INTO PIPELINE_LOG_MSG;

    CALL transient.pipeline_log_msg_to_table(PIPELINE_LOG_MSG);

    CALL transient.pipeline_log_msg_to_table(
                                               [STRUCT
                                                    (
                                                      LOG_TBL,
                                                      FEED_NAME,
                                                      FEED_NAME,
                                                      'Ingestion pipeline',
                                                      'Total records updated from pipeline',
                                                      (UPC_CNT + RPC_CNT + PROD_TITLE_CNT),
                                                      'pipeline completed',
                                                      'summary',
                                                      BATCH_NUMBER
                                                    )
                                               ]
                                            );

    /* Inserting all the logs into final logging table. */
	EXECUTE IMMEDIATE FORMAT ( """
		INSERT INTO %s
			SELECT *
			FROM %s
		""",PIPELINE_LOGGING_TBL, LOG_TBL);

    /* Merging all the unmatch data into override upc table for business to update the same. */

	EXECUTE IMMEDIATE FORMAT("""
        MERGE INTO processed.override_upc tgt
        USING (
          SELECT ABS(FARM_FINGERPRINT(CONCAT(feed_name,
                                             customer_parent,
                                             SAFE_CAST(original_upc AS STRING),
                                             SAFE_CAST(provided_title AS STRING)
                                             )
                                       )
                     ) as record_key,
                 *
          FROM
            (
               SELECT
                   DISTINCT
                      '%s' as feed_name,
                      COALESCE(pipeline_customer_name,'Unknown') as customer_parent,
                      delta.%s as original_upc,
		  	          '' as updated_upc,
		  	          delta.%s as provided_title,
		  	          '999999' as created_by,
		  	          SAFE_CAST(current_datetime() as timestamp) as created_timestamp,
		  	          '999999' as created_by,
		  	          SAFE_CAST(current_datetime() as timestamp) as modified_timestamp
               FROM %s delta
		       WHERE
		           (
		                     delta.pipeline_upc NOT IN (SELECT DISTINCT SAFE_CAST(suggested_upc as BIGINT) FROM %s)
		  	           OR  delta.pipeline_upc NOT IN (SELECT DISTINCT SAFE_CAST(provided_upc AS BIGINT) FROM %s)
		  	           OR  delta.%s NOT IN (SELECT DISTINCT provided_upc FROM %s)
		  	           OR  delta.%s NOT IN (SELECT DISTINCT provided_title FROM %s)
		  	       )
		  	       AND length(transient.remove_special_chars(CAST(delta.pipeline_upc AS STRING))) > 0
		    )
		    QUALIFY 1 = ROW_NUMBER() OVER(PARTITION BY original_upc , provided_title)
		) src
		ON      (src.original_upc = tgt.original_upc OR src.provided_title = tgt.provided_title)
		    AND src.feed_name = tgt.feed_name AND src.customer_parent = tgt.customer_parent
		WHEN MATCHED THEN DELETE
		WHEN NOT MATCHED THEN INSERT ROW
      """, INITCAP(FEED_NAME),
           UPC_FIELD,
           PRODUCT_TITLE_FIELD,
           DT_PIPELINE_TBL,
           PIPELINE_FINAL_OUTPUT_TBL,
           PIPELINE_FINAL_OUTPUT_TBL,
           UPC_FIELD,
           PIPELINE_FINAL_OUTPUT_TBL,
           PRODUCT_TITLE_FIELD,
           PIPELINE_FINAL_OUTPUT_TBL);


    SET EXPORT_CONFIG = (
           SELECT transient.bq_export_to_gcs (
                CONCAT('output_',LOWER(DEST_PROJECT),'/override_upc_pipeline_data/'),
                LOWER(FULL_LOAD),
                'csv',
                ',',
                true,
                true
           )
    );

    EXECUTE IMMEDIATE CONCAT(EXPORT_CONFIG,"""
                               SELECT
                                      CONCAT('"',SAFE_CAST(x.record_key AS STRING),'"') as record_key,
                                      CONCAT('"',SAFE_CAST(initcap(x.feed_name) AS STRING),'"') as feed_name,
                                      CONCAT('"',SAFE_CAST(initcap(x.customer_parent) AS STRING),'"') as customer_parent,
                                      CONCAT('"',SAFE_CAST(x.original_upc AS STRING),'"') as original_upc,
                                      CONCAT('"',SAFE_CAST(x.updated_upc AS STRING),'"') as updated_upc,
                                      CONCAT('"',SAFE_CAST(initcap(x.provided_title) AS STRING),'"') as provided_title,
                                      CONCAT('"',SAFE_CAST(x.created_timestamp AS STRING),'"') as created_timestamp,
                                      CONCAT('"',SAFE_CAST(x.modified_timestamp AS STRING),'"') as modified_timestamp,
                                      CONCAT('"',SAFE_CAST(UPPER(x.modified_by) AS STRING),'"') as modified_by
                               FROM processed.override_upc x
                               WHERE  LOWER(x.feed_name) = '""",LOWER(FEED_NAME),"""'"""
                           );

    /* Dropping all the temp table to clean up memory and avoid cost */
    FOR tables in (SELECT table_name FROM UNNEST([REFINED_DT_PIPELINE_TBL,
                                                  PIPELINE_MASTER_DATA,
                                                  GMI_PRD_MAPPING_TBL,
                                                  FUZZY_INPUT_TBL,
                                                  DT_PIPELINE_TBL,
                                                  FUZZY_TEMP_TBL,
                                                  GMI_PRD_TBL,
                                                  LOG_TBL
                                                  ]) as table_name)
    DO
         EXECUTE IMMEDIATE FORMAT(""" DROP TABLE IF EXISTS %s  """, tables.table_name);
    END FOR;


  ELSE
    /* We got no data to process so log it. */
      CALL transient.pipeline_log_msg_to_table([STRUCT(
				PIPELINE_LOGGING_TBL,
				FEED_NAME,
				FEED_NAME,
				'Ingestion pipeline',
				'No records found to process in source table',
				0,
				'pipeline completed',
				'summary',
				BATCH_NUMBER)]);
  END IF;
END;