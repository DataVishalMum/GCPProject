CREATE TABLE IF NOT EXISTS transient.ecomm_pipeline_src_to_catalog_upc_mapping_table
(
derivedupc_gmititle_key	INT64,
record_key INT64,
material_cd	STRING,
material_type_cd	STRING,
suggested_upc	STRING,
pim_product_title	STRING,
material_short_desc	STRING,
feed_name	STRING,
provided_title	STRING,
provided_upc	STRING,
string_variance	INT64,
match_score	FLOAT64,
match_type STRING,
provided_is_gmi_product	BOOLEAN,
provided_is_pet BOOLEAN,
expected_is_gmi_product	BOOLEAN,
expected_is_pet BOOLEAN,
data_source STRING,
run_date DATE
)
PARTITION BY run_date
CLUSTER BY derivedupc_gmititle_key, material_cd, suggested_upc, pim_product_title
OPTIONS(
  friendly_name="Src to eComm Catalog upc Mapping table",
  description="Table used for mapping source upc with ecomm product catalog data on upc ,rpc and fuzzy matching using product title",
  labels=[("data_classification", "confidential_internal_2b"), ("rls", "rls-skip")]
);