CREATE TABLE IF NOT EXISTS processed.ecomm_pipeline_log_msg (
message_owner STRING,
customer_parent STRING,
message_type STRING,
message_text STRING,
message_value INT64,
message_status STRING,
message_grain STRING,
batch_number INT64,
execution_ts TIMESTAMP
)
PARTITION BY TIMESTAMP_TRUNC(execution_ts, MONTH)
CLUSTER BY message_owner,customer_parent,message_status,batch_number
OPTIONS(
  friendly_name="Logging pipeline events into log table.",
  description="This table is used for tracking pipeline events.",
  labels=[("data_classification", "confidential_internal_2b"), ("rls", "rls-skip")]
);