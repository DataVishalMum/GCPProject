CREATE OR REPLACE FUNCTION transient.generate_upc_check_digit(ORIGINAL_UPC STRING)
AS ((
WITH NEEDS_CTE AS (
          SELECT CASE
                    WHEN LENGTH(COALESCE(ORIGINAL_UPC,'')) > 12 THEN False
                    ELSE True
          END AS upc_status,
          CASE
              WHEN LENGTH(COALESCE(ORIGINAL_UPC,'')) < 12 THEN LPAD(ORIGINAL_UPC, 12,'0')
              ELSE ORIGINAL_UPC
          END AS original_upc
),
CALCULATE_CHECK_DIGIT AS (
      SELECT
            MOD(
                    ((SUM(CASE WHEN MOD(rn,2) = 0 THEN CAST(upc as INT) ELSE 0 END)*3) +
                      SUM(CASE WHEN MOD(rn,2) != 0 THEN CAST(upc as INT) ELSE 0 END))
                  ,10) computed_digit
        FROM (
            SELECT
                  upc,
                  row_number() over() as rn
            FROM UNNEST((SELECT SPLIT(original_upc,'') FROM NEEDS_CTE WHERE upc_status=TRUE)) as upc
        )
    )
    SELECT IF(upc_status = FALSE,original_upc, CONCAT(original_upc, IF(computed_digit !=0, 10-computed_digit, 0)))
    FROM NEEDS_CTE, CALCULATE_CHECK_DIGIT
  ))
OPTIONS(
description= """ This function is used to generate check digit for a 12-Digit upc.

        How to run:

        select transient.generate_upc_check_digit('000834680423');
 """);