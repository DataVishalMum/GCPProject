/*

TODO:

1. Create Log table called ecomm_deleted_database_objects_log. Fields {project_name,dataset,table_name,deleted_date}.
2. Entires to be deleted should be logged in ecomm_deleted_database_objects_log before deleting.
3. ecomm_deleted_database_objects_log will be partition on deleted_date with an expiration of 30 days.
4. Create array of projects and loop through each project in dlf & analytics.

*/

CREATE OR REPLACE PROCEDURE transient.ecomm_database_objects_cleanup(
    FEED_NAME STRING
)
OPTIONS(
description= """ This procedure is used to drop all the unused tables & routines from DEV & QA which are not modified for last 90 days (30 days for objects in QA when Dev is skipped). All the deleted objects are stored in log table for 60 days.

    How to call

    CALL transient.ecomm_database_objects_cleanup("ecomm_database_objects_cleanup");

"""
)
BEGIN

DECLARE DATASETS DEFAULT ['raw','transient','processed']; -- Declaring all the datasets which will be scanned.
DECLARE DEV_TABLE_LIST, QA_TABLE_LIST ARRAY<STRING>;
DECLARE DROP_DATA ARRAY<STRING> DEFAULT [];
DECLARE TTL DEFAULT 90;


SET FEED_NAME = UPPER(FEED_NAME);

-- Looping through each dataset provided in variable.

FOR schema IN (SELECT LOWER(dataset) as dataset FROM UNNEST(DATASETS) as dataset)
DO
    -- Getting list of tables from DEV and QA which are required to dropped.

    EXECUTE IMMEDIATE CONCAT("""
        WITH cte as
        (
            SELECT
                dev.project_id as dev_project_id,
                qa.project_id as qa_project_id,
                prd.project_id as prd_project_id,
                dev.table_id as dev_table,
                qa.table_id as qa_table,
                prd.table_id as prd_table,
                CASE
                    WHEN ((qa.table_id is null and prd.table_id is null) and dev.table_id is not null)
                    AND (TIMESTAMP_DIFF(current_timestamp(),TIMESTAMP_MILLIS(dev.last_modified_time), DAY) > """,TTL,""")
                        THEN True
                    WHEN (qa.table_id is null and dev.table_id is not null)
                    AND (TIMESTAMP_DIFF(current_timestamp(),TIMESTAMP_MILLIS(dev.last_modified_time), DAY) > """,TTL,""")
                        THEN True
                    WHEN (dev.table_id is null and qa.table_id is not null)
                    AND (TIMESTAMP_DIFF(current_timestamp(),TIMESTAMP_MILLIS(qa.creation_time), DAY) > 30)
                        THEN True
                    ELSE false
                END AS is_delete
            FROM `ecomm-dlf-dev-01cd47`.""",schema.dataset,""".__TABLES__ dev
            FULL OUTER JOIN `ecomm-dlf-qa-ee8fb9`.""",schema.dataset,""".__TABLES__ qa      on dev.table_id = qa.table_id
            FULL OUTER JOIN `ecomm-dlf-prd-634888`.""",schema.dataset,""".__TABLES__ prd    on dev.table_id = prd.table_id
        )
        SELECT
            ARRAY_AGG(CONCAT('DROP TABLE IF EXISTS `',cte.dev_project_id,'`.','""",schema.dataset,"""','.',cte.dev_table,';') IGNORE NULLS) as dev_table,
            ARRAY_AGG(CONCAT('DROP TABLE IF EXISTS `',cte.qa_project_id,'`.','""",schema.dataset,"""','.',cte.qa_table,';') IGNORE NULLS) as qa_table
        FROM cte
        WHERE is_delete = True
    """) INTO DEV_TABLE_LIST, QA_TABLE_LIST;

    -- Appending list of tables from both environment to DROP_DATA variable.

    SET DROP_DATA = (SELECT ARRAY_CONCAT(DROP_DATA,DEV_TABLE_LIST, QA_TABLE_LIST));

    -- Getting list of procedure from DEV and QA which are required to dropped.

    EXECUTE IMMEDIATE CONCAT("""
        WITH cte as
        (
            SELECT
                dev.specific_catalog as dev_project_id,
                qa.specific_catalog as qa_project_id,
                prd.specific_catalog as prd_project_id,
                dev.specific_name as dev_table,
                qa.specific_name as qa_table,
                prd.specific_name as prd_table,
                CASE
                    WHEN ((qa.specific_name is null and prd.specific_name is null) and dev.specific_name is not null)
                    AND (TIMESTAMP_DIFF(current_timestamp(),dev.last_altered, DAY) > """,TTL,""")
                        THEN True
                    WHEN (qa.specific_name is null and dev.specific_name is not null)
                    AND (TIMESTAMP_DIFF(current_timestamp(),dev.last_altered, DAY) > """,TTL,""")
                        THEN True
                    WHEN (dev.specific_name is null and qa.specific_name is not null)
                    AND (TIMESTAMP_DIFF(current_timestamp(),qa.created, DAY) > 30)
                        THEN True
                    ELSE false
                END AS is_delete
            FROM `ecomm-dlf-dev-01cd47`.""",schema.dataset,""".INFORMATION_SCHEMA.ROUTINES dev
            FULL OUTER JOIN `ecomm-dlf-qa-ee8fb9`.""",schema.dataset,""".INFORMATION_SCHEMA.ROUTINES qa     on dev.specific_name = qa.specific_name
            FULL OUTER JOIN `ecomm-dlf-prd-634888`.""",schema.dataset,""".INFORMATION_SCHEMA.ROUTINES prd   on dev.specific_name = prd.specific_name
        )
        SELECT
            ARRAY_AGG(CONCAT('DROP PROCEDURE IF EXISTS `',cte.dev_project_id,'`.','""",schema.dataset,"""','.',cte.dev_table,';') IGNORE NULLS) as dev_table,
            ARRAY_AGG(CONCAT('DROP PROCEDURE IF EXISTS `',cte.qa_project_id,'`.','""",schema.dataset,"""','.',cte.qa_table,';') IGNORE NULLS) as qa_table
        FROM cte
        WHERE is_delete = True
    """) INTO DEV_TABLE_LIST, QA_TABLE_LIST;

    -- Appending list of procedures from both environment to DROP_DATA variable.

    SET DROP_DATA = (SELECT ARRAY_CONCAT(DROP_DATA,DEV_TABLE_LIST, QA_TABLE_LIST));

END FOR;

 -- Dropping all the unused tables and procedures
SELECT * FROM UNNEST(DROP_DATA);

EXCEPTION WHEN ERROR THEN
        EXECUTE IMMEDIATE CONCAT(
            """INSERT INTO processed.sproc_error_details (
		        SELECT
			        '""",FEED_NAME,"""' AS FEED_NAME,
			                            split(split(@@error.formatted_stack_trace,'transient.')[OFFSET (1)],'[')[OFFSET(0)],
			        @@error.statement_text,
			        @@error.message,
			        current_timestamp()
	        );
	    """);

	    SELECT
	        ERROR (
	            CONCAT(
	            		@@error.message ,' ' ,
	            		@@error.statement_text, ' ' ,
	            		@@error.formatted_stack_trace ,' '
	            	)
	        );

END