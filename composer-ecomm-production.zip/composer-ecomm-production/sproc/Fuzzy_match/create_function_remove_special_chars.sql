CREATE FUNCTION IF NOT EXISTS transient.remove_special_chars(original_string STRING)
AS (COALESCE(TRIM(SAFE_CAST(regexp_replace(lower(original_string),r'[^\w\s]','') AS STRING)),''))
OPTIONS(
description= """ This function is used to remove any special charaters from the string.

        How to run:

        select transient.remove_special_chars('H@ell@o World!');
 """);