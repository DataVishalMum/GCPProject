CREATE OR REPLACE FUNCTION transient.convert_fini_to_cnpk(PROVIDED_FINI_MATERIAL_CODES ARRAY<STRING>)
AS ((
	WITH CNPKS AS (
		SELECT material_cd, x.ean_13_digit_retail_upc as ecomm_upc, material_type_cd , parent_material_cd
		FROM processed.ecomm_product_catalog_v3 x
		WHERE x.parent_material_cd IN (SELECT parent_material_code FROM UNNEST(PROVIDED_FINI_MATERIAL_CODES) as parent_material_code)
		AND x.material_type_cd = 'CNPK'
	)
	SELECT ARRAY_AGG(STRUCT(material_cd, ecomm_upc, material_type_cd, parent_material_cd,is_cnpk_upc_found))
	FROM
	(
		SELECT DISTINCT material_cd, ecomm_upc, material_type_cd, parent_material_cd,True as is_cnpk_upc_found
		FROM CNPKS
		UNION DISTINCT
		SELECT DISTINCT material_cd, ean_13_digit_retail_upc ecomm_upc, material_type_cd, parent_material_cd,false
		FROM processed.ecomm_product_catalog_v3 x
		WHERE x.parent_material_cd IN (SELECT parent_material_code FROM UNNEST(PROVIDED_FINI_MATERIAL_CODES) as parent_material_code)
		AND x.material_type_cd = 'FINI'
		AND x.parent_material_cd NOT IN (SELECT DISTINCT parent_material_cd FROM CNPKS)
	)
  ))
OPTIONS(
description= """ This function is used to map FINI upc with CNPK upc using parent_material_cd from ecomm_product_catalog table.

        How to run:

        select transient.convert_fini_to_cnpk(['000000000003063000',
                                               '000000000314057000',
                                               '000000000360677000',
                                               '000000000028988000',
                                               '000000000013505000',
                                               '000000000112023000',
                                               '000000000040936000']);
 """);