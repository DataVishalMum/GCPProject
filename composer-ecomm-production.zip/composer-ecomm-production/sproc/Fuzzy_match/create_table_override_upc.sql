CREATE TABLE IF NOT EXISTS processed.override_upc (
record_key INT64,
feed_name STRING,
customer_parent STRING,
original_upc STRING,
updated_upc STRING,
provided_title STRING,
created_by STRING,
created_timestamp TIMESTAMP,
modified_by STRING,
modified_timestamp TIMESTAMP
)
OPTIONS(
  friendly_name="Logging all the invalid upc for which there was no match found.",
  description="This table is used for tracking all the invalid upc.",
  labels=[("data_classification", "confidential_internal_2b"), ("rls", "rls-skip")]
);