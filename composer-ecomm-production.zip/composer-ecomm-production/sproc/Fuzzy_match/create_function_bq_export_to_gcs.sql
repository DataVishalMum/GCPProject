CREATE OR REPLACE FUNCTION transient.bq_export_to_gcs(
														BUCKET_PATH STRING,
														FILE_NAME STRING,
														EXTRACT_FORMAT STRING,
														FIELD_DELIMITER STRING,
														OVERWRITE BOOLEAN,
														HEADER BOOLEAN
													 )
AS ((
SELECT
CASE
      WHEN LOWER(EXTRACT_FORMAT) = 'csv'
            THEN CONCAT(""" EXPORT DATA OPTIONS (uri= 'gs://""", LOWER(BUCKET_PATH), LOWER(FILE_NAME), """_*.""",
                            LOWER(EXTRACT_FORMAT),"""',format='""",UPPER(EXTRACT_FORMAT),"""',overwrite=""",OVERWRITE,
                            """,header=""",HEADER,""",field_delimiter='""",FIELD_DELIMITER,"""') AS """)
       WHEN LOWER(EXTRACT_FORMAT) = 'json'
            THEN CONCAT(""" EXPORT DATA OPTIONS (uri= 'gs://""", LOWER(BUCKET_PATH), LOWER(FILE_NAME), """_*.""",
                            LOWER(EXTRACT_FORMAT),"""',format='""",UPPER(EXTRACT_FORMAT),"""',overwrite=""",
                            OVERWRITE,""") AS """)
ELSE ''
END
))
OPTIONS(
description= """ This function is used to extract data from bigquery table to gcs bucket.

        How to Use:
        DECLARE EXPORT_CONFIG STRING;

        SET EXPORT_CONFIG = (
           select transient.bq_export_to_gcs (
                'landing_ecomm-dlf-dev-01cd47/test_function_data/', -- BUCKET_NAME (REQUIRED {must end with / })
                'lkp_customer', -- FILE_NAME (REQUIRED)
                'json', -- EXTRACT_FORMAT (REQUIRED)
                ';', -- FIELD_DELIMITER (REQUIRED {ONLY USED WHEN EXPORTED AS CSV})
                true, -- OVERWRITE (REQUIRED {ONLY USED WHEN EXPORTED AS CSV})
                true -- HEADER (REQUIRED {ONLY USED WHEN EXPORTED AS CSV})
           )
        );

        EXECUTE IMMEDIATE CONCAT(EXPORT_CONFIG," select * from processed.lkp_customer x ");

""");