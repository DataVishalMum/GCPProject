/*
Purpose of the stored proc: 
	Delta Data extraction for 'amazon_prime_now' customer
History of Changes:
	04/19 – first version
  07/20 - Added underscores to the raw table column names 
Author : 
	Vijayandra Mahadik
How to Call:
		call transient.sp_amazon_prime_now_delta_temp
		(
		 99,
		'ecomm-dlf-dev-01cd47',
		'raw',
		'transient' ,
		'amazon_prime_now_sales',
		'processed',
		'lkp_amazon_catalog_mapping',
		'amazon_prime_now_delta_temp',
		'AMAZON_PRIME_NOW'
		);

*/

CREATE PROCEDURE IF NOT EXISTS
  transient.sp_amazon_prime_now_delta_temp ( job_run_id int64,
    bq_project_name string,
    bq_raw_dataset_name string,
    bq_transient_dataset_name string,
    bq_raw_table_name string,
    bq_lkp_dataset_name string,
    bq_lkp_table_name string,
    bq_delta_temp_tablename string,
    customer_name string )
BEGIN

-- declare variables
DECLARE 
	 extract_start_date
	,extract_end_date Timestamp;

/* Get Extract start datetime for incoming table from data_extract_config table */
EXECUTE IMMEDIATE
  CONCAT("""select extract_start_datetime from `""",bq_project_name,"""`.""",bq_transient_dataset_name,""".""","""data_extract_config
where table_name = '""",bq_raw_table_name,"""' and status = 'running'
and active_flag = 'Y'""") INTO extract_start_date;

/* Get Extract end datetime for incoming table from data_extract_config table */
EXECUTE IMMEDIATE
  CONCAT("""select extract_end_datetime from `""",bq_project_name,"""`.""",bq_transient_dataset_name,""".""", """data_extract_config 
  where table_name = '""",bq_raw_table_name,"""' and status = 'running'  and active_flag = 'Y'""") INTO extract_end_date;

/* Delta Temp Table is Truncate & Load */
EXECUTE IMMEDIATE
CONCAT("""TRUNCATE TABLE  `""" ,bq_project_name,"""`.""",bq_transient_dataset_name,""".""",bq_delta_temp_tablename);

	/*Insert Details for passed customer into 'amazon_prime_now_delta_temp' table having ingest date greater than extract_start_date
from data_extract_config table */
EXECUTE IMMEDIATE
CONCAT("""insert into  `""" ,bq_project_name,"""`.""",bq_transient_dataset_name,""".""",bq_delta_temp_tablename,
"""
(
   WITH
     dr AS (
     SELECT
       'WEEK' AS grain,
       'AMAZON PRIME NOW' AS retailer,
       '""",customer_name,"""' AS customer_name,
       amzn_sales.asin AS source_item_code,
       upc_map.pkg_upc AS upc,
       --the file contains the date in the form Viewing=[11/24/19 - 11/30/19]
       --this code extracts the second date and converts it to timestamp (2019-11-30 00:00:00)
       CAST(PARSE_DATE('%m/%d/%y',
           TRIM(SPLIT(amzn_sales.report_date,"-")[OFFSET(1)],"]")
           ) AS TIMESTAMP) AS report_date,
       amzn_sales.product_title AS source_item_name,
       -- Remove dollar sign ($) or comma(,) from revenue.
       -- $ is special character hence needs escape char '\\'. '|' for OR logic
       -- Due to CONCAT '\\' becomes '\' which gives error hence use '\\\\'
       coalesce(SAFE_CAST(REGEXP_REPLACE(amzn_sales.ordered_revenue, "\\\\$|,", "") AS FLOAT64),
         0) AS ty_sales_value,
       coalesce(SAFE_CAST(REGEXP_REPLACE(amzn_sales.ordered_units, ",", "") AS INT64),
         0) AS ty_sales_units,
       SAFE_CAST((coalesce(SAFE_CAST(REGEXP_REPLACE(amzn_sales.ordered_units, ",", "") AS INT64),
             0) * coalesce(SAFE_CAST(upc_map.eaches_in_title AS INT64),
             1)) AS INT64) AS adjusted_units,
       coalesce(SAFE_CAST(REGEXP_REPLACE(amzn_sales.avg_sales_price, "\\\\$", "") AS FLOAT64),
         0) AS avg_sales_price,
       amzn_sales.original_file_name,
       amzn_sales.file_dt,
       amzn_sales.rctl_uuid,
       TIMESTAMP(amzn_sales.ingest_date) ingest_date,
       amzn_sales.rctl_file_name,
       '""",job_run_id,"""' created_by,
       current_datetime created_datetime,
       '""",job_run_id,"""' modified_by,
       current_datetime modified_datetime,

	   -- the following ranking is done to avoid duplicates if multiple files
	   -- are loaded in one run. The data is partitioned on the natural key
	   -- of the file. The data is then ordered descending on file_dt which is
	   -- the timestamp on the file.  Picking rank = 1 will result in the record
	   -- with latest file_dt being picked in case duplicate records
	   -- exist in the raw table ***across different files***.

       DENSE_RANK() OVER (PARTITION BY amzn_sales.asin,
                                       CAST(PARSE_DATE('%m/%d/%y',
                                            TRIM(SPLIT(amzn_sales.report_date,"-")[OFFSET(1)],"]")
                                            ) AS TIMESTAMP)
                          ORDER BY PARSE_TIMESTAMP("%m-%d-%Y %H:%M:%S", amzn_sales.file_dt) DESC
                          ) AS rnk_1,

	   -- the following ranking is done to avoid duplicates if the ****same file
	   -- is loaded multiple times****. The data is partitioned on the natural key
	   -- of the file and the file_dt which is the timestamp on the file
	   -- The data is then ordered descending on ingest_date which is the current timestamp
	   -- coming from the ingestion framework.  Picking rank = 1 will result
	   -- in the record with latest ingest_date being picked in case duplicate records
	   -- exist in the raw table.  THIS SCENARIO WILL TYPICALLY NOT OCCUR.
	   -- Please note the use of ROW_NUMBER function to pick one record.
	   -- This function will be needed when the entire RAW table is read to reprocess history.

       ROW_NUMBER() OVER (PARTITION BY amzn_sales.asin,
                                       CAST(PARSE_DATE('%m/%d/%y',
                                            TRIM(SPLIT(amzn_sales.report_date,"-")[OFFSET(1)],"]")
                                            ) AS TIMESTAMP),
                                       PARSE_TIMESTAMP("%m-%d-%Y %H:%M:%S", amzn_sales.file_dt)
                          ORDER BY amzn_sales.ingest_date DESC
                          ) rnk_2

       FROM
         `""" ,bq_project_name,"""`.""",bq_raw_dataset_name,""".""",bq_raw_table_name,""" amzn_sales
       LEFT JOIN
       --left join will expose holes in our upc mappings
         `""" ,bq_project_name,"""`.""",bq_lkp_dataset_name,""".""",bq_lkp_table_name,""" upc_map
       ON
             upc_map.asin = amzn_sales.asin
         and upc_map.vendor = 'GENXD'
       WHERE
             amzn_sales.ingest_date > '""",extract_start_date,"""'
	     AND amzn_sales.ingest_date <= '""",extract_end_date,"""')
   SELECT
     grain,
     retailer,
     customer_name,
     source_item_code,
     upc,
     report_date,
     source_item_name,
     ty_sales_value,
     ty_sales_units,
     adjusted_units,
     avg_sales_price,
     original_file_name,
     file_dt,
     ingest_date,
     rctl_file_name,
     rctl_uuid,
     created_by,
     created_datetime,
     modified_by,
     modified_datetime
   FROM
     dr
   WHERE
     rnk_1 = 1
     AND rnk_2 = 1
 )
""") ;

EXCEPTION WHEN ERROR THEN
    SELECT  
	ERROR (
		CONCAT(
    			@@error.message ,' ' ,
    			@@error.statement_text, ' ' ,
    			@@error.formatted_stack_trace ,' '
			)
		)
	;

END

