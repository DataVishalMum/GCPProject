 /* Purpose OF the stored proc : History Load
	
	Author : Vishal Jadiya 
	
CALL
  transient.sp_costco_canada_delta_temp_hist(-99,
    'ecomm-dlf-dev-01cd47',
	'shareddata-prd-cb5872',
    'sales_ecomm_global_sales_and_share',
    'transient',
    'ecom_costco_canada_sales_raw_v',
	'processed',
    'lkp_costco_mapping',
	'costco_canada_delta_temp',
	'COSTCO_CANADA');

  */
CREATE PROCEDURE IF NOT EXISTS
  transient.sp_costco_canada_delta_temp_hist ( job_run_id INT64,
    bq_project_name STRING,
	bq_source_project_name string,
    bq_source_dataset_name STRING,
    bq_transient_dataset_name STRING,
    bq_raw_table_name STRING,
	bq_lkp_dataset_name STRING,
	bq_lkp_table_name STRING,
	bq_delta_temp_tablename STRING,
	customer_name STRING)
BEGIN

-- Truncate Delta Temp Table
EXECUTE IMMEDIATE
CONCAT("""TRUNCATE TABLE  `""" ,bq_project_name,"""`.""",bq_transient_dataset_name,""".""",bq_delta_temp_tablename);

-- Insert History records into delta temp table
EXECUTE IMMEDIATE
CONCAT("""insert into  `""" ,bq_project_name,"""`.""",bq_transient_dataset_name,""".""",bq_delta_temp_tablename,"""  
( 
WITH
  raw_data AS (
  SELECT
    'WEEK' AS grain,
    'costco_canada' AS retailer,
    '""",customer_name,"""' AS customer_name,
    venue,
    upc_map.upc AS upc,
	  upc_map.upc AS item,
	  substr(costco_sales.item, 16,37) AS item_description,
    upc_map.upc AS source_item_code,
    substr(costco_sales.item, 16,37) AS source_item_name,
    'History load'  as original_file_name,
    cast(PARSE_DATE("%m-%d-%Y",SPLIT(costco_sales.week_end_date," ")[OFFSET(3)]) as timestamp)AS week_end_date,
	  coalesce(safe_cast (costco_sales.dollar_sales AS FLOAT64),
    0) AS ty_sales_value,
	  coalesce(SAFE_CAST(costco_sales.unit_sales AS INT64),
    0) AS ty_sales_units,
'01/01/0001' file_dt,
	GENERATE_UUID() rctl_uuid,
	current_timestamp ingest_date,
	'History load' rctl_file_name,
	hadoop_update_ts,
    CAST(""",job_run_id,""" AS string) AS created_by,
    current_datetime AS created_datetime,
    CAST(""",job_run_id,""" AS string) AS modified_by,
    current_datetime AS modified_datetime
  FROM
    `""" ,bq_source_project_name,"""`.""",bq_source_dataset_name,""".""",bq_raw_table_name,""" costco_sales
  LEFT OUTER JOIN
    `""" ,bq_project_name,"""`.""",bq_lkp_dataset_name,""".""",bq_lkp_table_name,""" upc_map
  ON
  costco_sales.item = upc_map.item
 
    )
SELECT
  * EXCEPT(rnk_1)
FROM (
  SELECT
    grain,
    retailer,
    customer_name,
	venue,
  upc,
	item,
	item_description,
    source_item_code,
	  source_item_name,
    original_file_name,
    week_end_date,
    ty_sales_value,
    ty_sales_units,
    '01/01/0001' file_dt,
	GENERATE_UUID() rctl_uuid,
	current_timestamp ingest_date,
	'History load' rctl_file_name,
	SAFE_CAST(""",job_run_id,""" AS string) AS created_by,
	current_datetime AS created_datetime,
	SAFE_CAST(""",job_run_id,""" AS string) AS modified_by,
	current_datetime AS modified_datetime,
		ROW_NUMBER() OVER (PARTITION BY source_item_code, week_end_date ORDER BY hadoop_update_ts DESC) AS rnk_1
  FROM
    raw_data k
  )A
WHERE
  rnk_1 = 1)
""") ;

EXCEPTION WHEN ERROR THEN
    SELECT  
	ERROR (
		CONCAT(
    			@@error.message ,' ' ,
    			@@error.statement_text, ' ' ,
    			@@error.formatted_stack_trace ,' '
			)
		)
	;

END;