 /* Purpose OF the stored proc : Delta Temp Table
	History OF Changes : 06/17 first version 
	Author : Vishal Jadiya
	
CALL
  transient.sp_data_extract_config_insert(-99,
    'ecomm-dlf-dev-01cd47',
    'raw',
    'transient',
    'costco_canada_sales');
CALL
  transient.sp_costco_canada_delta_temp(-99,
    'ecomm-dlf-dev-01cd47',
    'raw',
    'transient',
    'costco_canada_sales',
	'processed',
    'lkp_costco_mapping',
	'costco_canada_delta_temp',
	'COSTCO_CANADA');
CALL
  transient.sp_data_extract_config_update(-99,
    'ecomm-dlf-dev-01cd47',
    'transient',
    'costco_canada_sales');

  */
CREATE PROCEDURE IF NOT EXISTS
  transient.sp_costco_canada_delta_temp ( job_run_id INT64,
    bq_project_name STRING,
    bq_raw_dataset_name STRING,
    bq_transient_dataset_name STRING,
    bq_raw_table_name STRING,
	bq_lkp_dataset_name STRING,
	bq_lkp_table_name STRING,
	bq_delta_temp_tablename STRING,
	customer_name STRING)
BEGIN
-- declare variables
DECLARE extract_start_date,extract_end_date Timestamp;

-- Get Extract start datetime for incoming table from data_extract_config table
EXECUTE IMMEDIATE CONCAT("""select extract_start_datetime from `""",bq_project_name,"""`.""",bq_transient_dataset_name,""".""","""data_extract_config where table_name = '""",bq_raw_table_name,"""' and status = 'running' 
and active_flag = 'Y'""") into extract_start_date;

-- Get Extract end datetime for incoming table from data_extract_config table
EXECUTE IMMEDIATE CONCAT("""select extract_end_datetime from `""",bq_project_name,"""`.""",bq_transient_dataset_name,""".""",
"""data_extract_config where table_name = '""",bq_raw_table_name,"""' and status = 'running'  and active_flag = 'Y'""") into extract_end_date;

-- Truncate Delta Temp Table
EXECUTE IMMEDIATE
CONCAT("""TRUNCATE TABLE  `""" ,bq_project_name,"""`.""",bq_transient_dataset_name,""".""",bq_delta_temp_tablename);

/*Insert Details for passed customer into 'costco_canada_delta_temp' table having ingest date greater than extract_start_date 
from data_extract_config table */
EXECUTE IMMEDIATE
CONCAT("""insert into  `""" ,bq_project_name,"""`.""",bq_transient_dataset_name,""".""",bq_delta_temp_tablename,"""  
( 
WITH
  raw_data AS (
  SELECT
    'WEEK' AS grain,
    'costco_canada' AS retailer,
    '""",customer_name,"""' AS customer_name,
    venue,
    upc_map.upc AS upc,
	  upc_map.upc AS item,
	  substr(costco_sales.item, 16,37) AS item_description,
    upc_map.upc AS source_item_code,
    substr(costco_sales.item, 16,37) AS source_item_name,
    costco_sales.original_file_name,
    cast(PARSE_DATE("%m-%d-%Y",SPLIT(costco_sales.week_end_date," ")[OFFSET(3)]) as timestamp)AS week_end_date,
	  coalesce(safe_cast (costco_sales.dollar_sales AS FLOAT64),
    0) AS ty_sales_value,
	  coalesce(SAFE_CAST(costco_sales.unit_sales AS INT64),
    0) AS ty_sales_units,
    costco_sales.file_dt,
    costco_sales.rctl_uuid,
    costco_sales.ingest_date,
    costco_sales.rctl_file_name,
    CAST(""",job_run_id,""" AS string) AS created_by,
    current_datetime AS created_datetime,
    CAST(""",job_run_id,""" AS string) AS modified_by,
    current_datetime AS modified_datetime
  FROM
    `""" ,bq_project_name,"""`.""",bq_raw_dataset_name,""".""",bq_raw_table_name,""" costco_sales
  LEFT OUTER JOIN
    `""" ,bq_project_name,"""`.""",bq_lkp_dataset_name,""".""",bq_lkp_table_name,""" upc_map
  ON
  costco_sales.item = upc_map.item
  WHERE
    costco_sales.ingest_date > '""",extract_start_date,"""' 
	AND costco_sales.ingest_date <= '""",extract_end_date,"""' 
    )
SELECT
  * EXCEPT(rnk_1 , rnk_2)
FROM (
  SELECT
    grain,
    retailer,
    customer_name,
	venue,
  upc,
	item,
	item_description,
    source_item_code,
	  source_item_name,
    original_file_name,
    week_end_date,
    ty_sales_value,
    ty_sales_units,
    file_dt ,
    rctl_uuid ,
    ingest_date ,
    rctl_file_name ,
    created_by ,
    created_datetime ,
    modified_by ,
    modified_datetime ,
	-- the following ranking is done to avoid duplicates if multiple files
	-- are loaded in one run. The data is partitioned on the natural key 
	-- of the file. The data is then ordered descending on file_dt which is 
	-- the timestamp on the file.  Picking rank = 1 will result in the record 
	-- with latest file_dt being picked in case duplicate records
	-- exist in the raw table ***across different files***.
    DENSE_RANK() OVER (PARTITION BY source_item_code, week_end_date ORDER BY PARSE_timestamp("%m-%d-%Y %H:%M:%S", file_dt) DESC) AS rnk_1,
	
	-- the following ranking is done to avoid duplicates if the ****same file
	-- is loaded multiple times****. The data is partitioned on the natural key 
	-- of the file and the file_dt which is the timestamp on the file
	-- The data is then ordered descending on ingest_date which is the current timestamp
	-- coming from the ingestion framework.  Picking rank = 1 will result
	-- in the record with latest ingest_date being picked in case duplicate records
	-- exist in the raw table.  THIS SCENARIO WILL TYPICALLY NOT OCCUR.
	-- Please note the use of ROW_NUMBER function to pick one record.
	ROW_NUMBER() OVER (PARTITION BY source_item_code, week_end_date,PARSE_timestamp("%m-%d-%Y %H:%M:%S", file_dt) ORDER BY ingest_date DESC) AS rnk_2
  FROM
    raw_data k
  )A
WHERE
  rnk_1 = 1  and rnk_2 = 1)
""") ;

EXCEPTION WHEN ERROR THEN
    SELECT  
	ERROR (
		CONCAT(
    			@@error.message ,' ' ,
    			@@error.statement_text, ' ' ,
    			@@error.formatted_stack_trace ,' '
			)
		)
	;

END;