/*
Purpose of the stored proc: 
	Delta Data extraction for 'Publix Instacart' 
History of Changes:
	06/17 – first version 
Author : 
	Navdisha Singla
How to Call:
	CALL transient.sp_publix_instacart_delta_temp
    (-99,
    'ecomm-dlf-dev-01cd47',
    'transient',
    'shareddata-prd-cb5872',
    'shared_data_srm',
    'edw-dev-c119a7',
    'enterprise',
    'publix_instacart_delta_temp'
    )	

*/
CREATE PROCEDURE IF NOT EXISTS transient.sp_publix_instacart_delta_temp
( 
	job_run_id INT64,
	bq_project_name string,
	bq_transient_dataset_name string,	
  bq_shared_project_name string,  
  bq_srm_dataset_name string, 
  bq_edw_project_name string,
  bq_enterprise_dataset string,
  target_table_name string
)
BEGIN
DECLARE 
extract_start_date
	,extract_end_date Timestamp;

EXECUTE IMMEDIATE CONCAT("""TRUNCATE TABLE `""",bq_project_name,""".""",bq_transient_dataset_name,""".""",target_table_name,"""`""");

/* Get Extract start datetime for incoming table from data_extract_config table */
-- We are treating 'datasembly_store_price' as the driving table.
-- So, we are fetching the delta data from 'datasembly_store_price' only.

EXECUTE IMMEDIATE
  CONCAT("""select extract_start_datetime from `""",bq_project_name,"""`.""",bq_transient_dataset_name,""".""","""data_extract_config
where table_name = 'publix_instacart_datasembly_store_price' and status = 'running' 
and active_flag = 'Y'""") INTO extract_start_date;

/* Get Extract end datetime for incoming table from data_extract_config table */
EXECUTE IMMEDIATE
  CONCAT("""select extract_end_datetime from `""",bq_project_name,"""`.""",bq_transient_dataset_name,""".""", """data_extract_config 
  where table_name = 'publix_instacart_datasembly_store_price' and status = 'running'  and active_flag = 'Y'""") INTO extract_end_date;

EXECUTE IMMEDIATE 
    CONCAT(
        """
        INSERT INTO `""",bq_project_name,""".""",bq_transient_dataset_name,""".""",target_table_name,"""`
  WITH
  datasembly_store AS (
  SELECT
  chain_nm,
    banner_nm,
    store_number,
    state_cd,
    city_nm,
    address_desc,
    postal_cd,
    store_id,
    banner_id,

    -- As per the analysis,'store_number, state_cd, city_nm' serves as the natural key for the selected columns.
    -- Applying a row_num function on these keys help remove any duplicate from the source data
    -- We are then ordering it using runid (which serves as the load timestamp of the source), store_id and banner_id
    -- store_id and banner_id are used for order because we observed NULLs in store_id and banner_id
    -- We are avoiding NULLs in store_id and banner_id because these are used to join the tables.

    ROW_NUMBER() OVER (PARTITION BY store_number, state_cd, city_nm ORDER BY TIMESTAMP_SECONDS(CAST(runid/1000 AS INT64)) DESC,
      store_id DESC,
      banner_id DESC) rnk_data_store
  FROM
    `""",bq_shared_project_name,""".""",bq_srm_dataset_name,""".datasembly_store`
  WHERE
    chain_nm = 'Publix'
  ),
  datasembly_store_price AS (
  SELECT
    report_date,
    sku,
    host,
    in_stock,
    source_file_name_dt,
    store_id,
    banner_id,

    -- As per the analysis,'sku, report_date, source_file_name_dt' serves as the natural key for the selected columns.
    -- Applying a row_num function on these keys help remove any duplicate from the source data
    -- We are then ordering it using runid (which serves as the load timestamp of the source),in_stock, store_id and banner_id
    -- We are using 'in_stock' column in the order clause because we prefer in_stock values 'true' in case of duplicates.
    -- store_id and banner_id are used for order because we observed NULLs in store_id and banner_id
    -- We are avoiding NULLs in store_id and banner_id because these are used to join the tables.

    ROW_NUMBER() OVER (PARTITION BY sku, report_date, source_file_name_dt ORDER BY TIMESTAMP_SECONDS(CAST(runid/1000 AS INT64)) DESC,
      in_stock DESC,
      store_id DESC,
      banner_id DESC) rnk_data_store_price
  FROM
    `""",bq_project_name,""".""",bq_transient_dataset_name,""".publix_instacart_datasembly_store_price`
  WHERE
    TIMESTAMP_SECONDS(CAST(runid/1000 as INT64)) > '""",extract_start_date,"""'
    and TIMESTAMP_SECONDS(CAST(runid/1000 as INT64)) <= '""",extract_end_date,"""'
  ),

  -- We have removed 'original_store_number,country_cd,store_operational_fg,channel_pickup,channel_local_delivery,channel_in_store,
  -- channel_method_desc,description,size_text,brand' columns which are present in Hadoop as per the suggestion by Kaia. 
  -- These columns are only description columns and are not used in future queries and reporting.
  -- 'datasembly_products' table is removed as a source because all the columns fetched from it are removed.

  raw_data AS (
  SELECT

  -- Keeping customer_name as the 'chain_nm' similar to publix com. 
  -- This is done so that the join condition for in-store and online customers on 'unique_composite_key' (in the joined query) does not fail

    UPPER(ds.chain_nm) customer_name,
    ds.banner_nm banner,
    ds.store_number store_number,
    ds.state_cd store_state,
    INITCAP(ds.city_nm) store_city,
    ds.address_desc store_street_address,
    ds.postal_cd store_zipcode,

    -- The below logic helps to bring report_date to a single week 

    CASE
      WHEN PARSE_DATE('%Y-%m-%d', dsp.report_date)<=DATE_ADD(PARSE_DATE('%Y-%m-%d', dsp.source_file_name_dt),INTERVAL 6 DAY) THEN DATE_ADD(PARSE_DATE('%Y-%m-%d', dsp.report_date), INTERVAL 1 DAY)
    ELSE
    PARSE_DATE('%Y-%m-%d',
      dsp.report_date)
  END
    AS report_date,
    dsp.sku,
    dsp.host,

    -- 'in_stock' is renamed as 'stock_flg' as per the naming standards
    -- The datatype of 'in_stock' is also changed to BOOLEAN because of greater performance
    -- The source values of 'in_stock' field are either 'true' or 'false'

    CASE WHEN dsp.in_stock = 'true' THEN TRUE
    WHEN dsp.in_stock = 'false' THEN FALSE
    END AS stock_flg,
    dsp.source_file_name_dt
  FROM
    datasembly_store ds
  JOIN
    datasembly_store_price dsp
  ON
    ds.store_id = dsp.store_id
    AND ds.banner_id = dsp.banner_id
  WHERE
    rnk_data_store = 1
    AND rnk_data_store_price = 1 
    ),
  fiscal_data AS (
  SELECT
    fch.date_sk,
    w.* EXCEPT(report_date,
      source_file_name_dt),
    fch.fiscal_month_in_year_nbr,
    fch.fiscal_year_nbr,
    fch.fiscal_quarter_in_year_nbr,
    fch.fiscal_week_in_year_nbr,
    fch.fiscal_month_in_year_short_desc,
    fch.fiscal_week_begin_dt,
    fch.fiscal_week_end_dt,
    fch.fiscal_month_begin_dt,
    fch.fiscal_month_end_dt,
    fch.fiscal_quarter_begin_dt,
    fch.fiscal_quarter_end_dt,
    fch.fiscal_year_begin_dt,
    fch.fiscal_year_end_dt,
    fch.fiscal_year_short_desc,
    fch.fiscal_quarter_nbr,
    fch.fiscal_year_month_nbr,
    fch.fiscal_year_week_nbr,
    fch.calendar_year_nbr
  FROM
    raw_data w
  LEFT JOIN
    `""",bq_edw_project_name,""".""",bq_enterprise_dataset,""".dim_date` fch
  ON
    w.report_date= fch.fiscal_dt
  WHERE
    fch.language_cd='EN'
    AND fch.fiscal_year_variant_cd='07')

  -- In the below query, we are fetching the upc from Instacart sales as we do not have UPC in publix instacart for further processing
  -- We use SKU column in Publix Instacart to fetch UPC from Instacart Sales.

SELECT
  * except(rnk)
  ,CAST(""",job_run_id,""" AS string) AS created_by
  ,current_datetime AS created_datetime
  ,CAST(""",job_run_id,""" AS string) AS modified_by
  ,current_datetime AS modified_datetime
FROM (
  SELECT
  src.date_sk,
    hier.upc,
    src.* except (date_sk),
    ROW_NUMBER() OVER (PARTITION BY src.store_number, src.sku, src.fiscal_week_begin_dt,hier.upc ORDER BY src.stock_flg DESC ) AS rnk
  FROM
    fiscal_data src
  LEFT JOIN (
    SELECT
      DISTINCT upc,
      source_item_code
    FROM (
      SELECT
        DISTINCT upc,
        source_item_code,
        ROW_NUMBER() OVER (PARTITION BY source_item_code ORDER BY report_date DESC, created_datetime DESC) rnk_hier
      FROM
        `""",bq_project_name,""".""",bq_transient_dataset_name,""".instacart_processed_zero`)
    WHERE
      rnk_hier = 1) hier
  ON
    src.sku = hier.source_item_code)    
  WHERE
    rnk = 1 
        """
    );
END;