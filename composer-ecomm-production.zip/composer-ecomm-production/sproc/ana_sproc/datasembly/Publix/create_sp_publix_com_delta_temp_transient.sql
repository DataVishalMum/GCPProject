/*
Purpose of the stored proc: 
	Delta Data extraction for 'Publix Instacart' 
History of Changes:
	06/17 – first version 
Author : 
	Navdisha Singla
How to Call:
	CALL transient.sp_publix_com_delta_temp
    (-99,
    'ecomm-dlf-dev-01cd47',
    'transient',
    'processed',
    'shareddata-prd-cb5872',
    'shared_data_srm',
    'edw-dev-c119a7',
    'enterprise',
    'publix_com_delta_temp'
    )	

*/
CREATE PROCEDURE IF NOT EXISTS transient.sp_publix_com_delta_temp
( 
	job_run_id INT64,
	bq_project_name string,
	bq_transient_dataset_name string,	
  bq_processed_dataset_name string,
  bq_shared_project_name string,
  bq_srm_dataset_name string, 
  bq_edw_project_name string,
  bq_enterprise_dataset string,
  target_table_name string
)
BEGIN
DECLARE 
extract_start_date
	,extract_end_date Timestamp;

EXECUTE IMMEDIATE CONCAT("""TRUNCATE TABLE `""",bq_project_name,""".""",bq_transient_dataset_name,""".""",target_table_name,"""`""");

/* Get Extract start datetime for incoming table from data_extract_config table */
EXECUTE IMMEDIATE
  CONCAT("""select extract_start_datetime from `""",bq_project_name,"""`.""",bq_transient_dataset_name,""".""","""data_extract_config
where table_name = 'datasembly_products' and status = 'running' 
and active_flag = 'Y'""") INTO extract_start_date;

/* Get Extract end datetime for incoming table from data_extract_config table */
EXECUTE IMMEDIATE
  CONCAT("""select extract_end_datetime from `""",bq_project_name,"""`.""",bq_transient_dataset_name,""".""", """data_extract_config 
  where table_name = 'datasembly_products' and status = 'running'  and active_flag = 'Y'""") INTO extract_end_date;

EXECUTE IMMEDIATE 
    CONCAT(
        """
        INSERT INTO `""",bq_project_name,""".""",bq_transient_dataset_name,""".""",target_table_name,"""`
  WITH
  datasembly_store AS (
  SELECT
    chain_nm customer_name,
    banner_nm,
    store_number,
    state_cd,
    city_nm,
    address_desc,
    postal_cd,
    banner_id,

    -- As per the analysis,'store_number, state_cd, city_nm' serves as the natural key for the selected columns.
    -- Applying a row_num function on these keys help remove any duplicate from the source data
    -- We are then ordering it using runid (which serves as the load timestamp of the source) and banner_id
    -- banner_id is used for order because we observed NULLs in banner_id column
    -- We are avoiding NULLs in banner_id because these are used to join the tables.

    ROW_NUMBER() OVER (PARTITION BY store_number, state_cd, city_nm ORDER BY TIMESTAMP_SECONDS(CAST(runid/1000 AS INT64)) DESC,
      banner_id DESC) rnk_data_store
  FROM
    `""",bq_shared_project_name,""".""",bq_srm_dataset_name,""".datasembly_store`
  WHERE
    chain_nm = 'Publix'
  ),
  datasembly_products AS (
  SELECT
    sku,
    host,
    CAST(source_file_name_dt AS DATE) source_file_name_dt,
    banner_id,

    -- As per the analysis,'sku, source_file_name_dt' serves as the natural key for the selected columns.
    -- Applying a row_num function on these keys help remove any duplicate from the source data
    -- We are then ordering it using runid (which serves as the load timestamp of the source) and banner_id
    -- banner_id is used for order because we observed NULLs in banner_id column
    -- We are avoiding NULLs in banner_id because these are used to join the tables.

    ROW_NUMBER() OVER (PARTITION BY sku, CAST(source_file_name_dt AS DATE) ORDER BY TIMESTAMP_SECONDS(CAST(runid/1000 AS INT64)) DESC,
      banner_id DESC) rnk_data_store_price
  FROM
    `""",bq_shared_project_name,""".""",bq_srm_dataset_name,""".datasembly_products`
  WHERE
    host = 'services.publix.com'
    AND TIMESTAMP_SECONDS(CAST(runid/1000 as INT64)) > '""",extract_start_date,"""'
    and TIMESTAMP_SECONDS(CAST(runid/1000 as INT64)) <= '""",extract_end_date,"""'
  ),

  -- We have removed 'country_cd,store_operational_fg,channel_pickup,channel_local_delivery,channel_in_store,
  -- channel_method_desc,description,size_text,brand' columns which are present in Hadoop as per the suggestion by Kaia. 
  -- These columns are only description columns and are not used in future queries and reporting.

  raw_data AS (
  SELECT
    UPPER(ds.customer_name) customer_name,
    ds.banner_nm banner,
    ds.store_number store_number,
    ds.state_cd store_state,
    INITCAP(ds.city_nm) store_city,
    ds.address_desc store_street_address,
    ds.postal_cd store_zipcode,
    dp.sku,
    dp.host,
    dp.source_file_name_dt
  FROM
    datasembly_store ds
  JOIN
    datasembly_products dp
  ON
  ds.banner_id = dp.banner_id
  WHERE
    rnk_data_store = 1
    AND rnk_data_store_price = 1 
    )
    select * except (rnk)
    ,CAST(""",job_run_id,""" AS string) AS created_by
    ,current_datetime AS created_datetime
    ,CAST(""",job_run_id,""" AS string) AS modified_by
    ,current_datetime AS modified_datetime
    FROM
    (
  SELECT
    fch.date_sk,

  -- renaming 'case_upc' to 'upc'. This is done done so that we need not make any changes to UPC XREF and joined query

    pc.case_upc upc,
    w.*,

    -- Since, publix_com is added as an in-store table input to the joined query, 
    -- We are adding NULL authorization_flg and division columns which are used in the joined query 
    -- The authorization_flg and division are NULL in Hadoop as well for Publix

    CAST(NULL AS BOOLEAN) authorization_flg,
    CAST(NULL AS STRING) division,      
    fch.fiscal_month_in_year_nbr,
    fch.fiscal_year_nbr,
    fch.fiscal_quarter_in_year_nbr,
    fch.fiscal_week_in_year_nbr,
    fch.fiscal_month_in_year_short_desc,
    fch.fiscal_week_begin_dt,
    fch.fiscal_week_end_dt,
    fch.fiscal_month_begin_dt,
    fch.fiscal_month_end_dt,
    fch.fiscal_quarter_begin_dt,
    fch.fiscal_quarter_end_dt,
    fch.fiscal_year_begin_dt,
    fch.fiscal_year_end_dt,
    fch.fiscal_year_short_desc,
    fch.fiscal_quarter_nbr,
    fch.fiscal_year_month_nbr,
    fch.fiscal_year_week_nbr,
    fch.calendar_year_nbr,

    -- Removing duplicates on the natural key - store_number, upc and fiscal week
    -- We observed duplicates on the SKU column when the upc is NULL

    ROW_NUMBER() OVER (PARTITION BY w.store_number,pc.case_upc,fch.fiscal_week_begin_dt ORDER BY w.source_file_name_dt desc) rnk
    FROM
    raw_data w
  LEFT JOIN
    `""",bq_edw_project_name,""".""",bq_enterprise_dataset,""".dim_date` fch
  ON
    date_add(w.source_file_name_dt, INTERVAL 1 DAY) = fch.fiscal_dt
    LEFT JOIN `""",bq_project_name,"""`.""",bq_processed_dataset_name,""".lkp_publix_catalog pc
    on pc.store_product_code = w.sku
    WHERE fch.language_cd='EN'
    AND fch.fiscal_year_variant_cd='07')
    WHERE rnk = 1
        """
    );
END;