/*
Purpose of the stored proc:
	Delta Data extraction for Datasembly customers
History of Changes:
	06/02/2021 – first version
	10/27/2021 - update filter in raw_weekly section to support addition of Instacart data
	03/10/2022 - remove host URL filter from Walmart section
	03/15/2022 - remove unneeded fiscal attributes
    02/08/2022 - (Shubham Saxena)
    - removed join logic and pointed select statement to reference newly created materialized views
    - added in duplicate remover to manage the sku column in datasembly'
Author :
	Kaia Arthur
*/

CREATE OR REPLACE PROCEDURE transient.ecomm_sproc_ana_datasembly_delta_temp
(
	DEST_PROJECT STRING,
	DEST_DATASET STRING,
	CUSTOMER_NAME STRING,
	DEST_TABLE STRING,
    SRC_TABLE STRING,
    FEED_NAME STRING
)
OPTIONS(
description = """

How to Call:
		call transient.ecomm_sproc_ana_datasembly_delta_temp
		(
		'ecomm-dlf-dev-01cd47', --DEST_PROJECT
		'transient' , --DEST_DATASET
		'KROGER', --CUSTOMER_NAME
		'kroger_datasembly_delta_temp', --DEST_TABLE
        'kroger_datasembly_store_price' --SRC_TABLE
        'KROGER' --FEED_NAME
		)

"""
)

BEGIN
-- declare variables
DECLARE BQ_PROJECT_NAME DEFAULT DEST_PROJECT;
DECLARE BQ_TRANSIENT_DATASET_NAME DEFAULT DEST_DATASET;
DECLARE BQ_TRANSIENT_TABLE_NAME DEFAULT DEST_TABLE;
DECLARE BQ_SOURCE_TABLE_NAME DEFAULT SRC_TABLE;
DECLARE
	 EXTRACT_START_DATE
	,EXTRACT_END_DATE Timestamp;

SET CUSTOMER_NAME = UPPER(CUSTOMER_NAME);
SET FEED_NAME = UPPER(FEED_NAME);

/* Get Extract start datetime for incoming table from data_extract_config table */
EXECUTE IMMEDIATE
  CONCAT("""select extract_start_datetime from `""",BQ_PROJECT_NAME,"""`.""",BQ_TRANSIENT_DATASET_NAME,""".""","""data_extract_config
where table_name = '""",BQ_SOURCE_TABLE_NAME,"""_mv""","""' and status = 'running'
and active_flag = 'Y'""") INTO EXTRACT_START_DATE;

/* Get Extract end datetime for incoming table from data_extract_config table */
EXECUTE IMMEDIATE
  CONCAT("""SELECT extract_end_datetime from `""",BQ_PROJECT_NAME,"""`.""",BQ_TRANSIENT_DATASET_NAME,""".""", """data_extract_config
  where table_name = '""",BQ_SOURCE_TABLE_NAME,"""_mv""","""' and status = 'running'  and active_flag = 'Y'""") INTO EXTRACT_END_DATE;

/* Delta Temp Table is Truncate & Load */
EXECUTE IMMEDIATE
CONCAT("""TRUNCATE TABLE  `""" ,BQ_PROJECT_NAME,"""`.""",BQ_TRANSIENT_DATASET_NAME,""".""",BQ_TRANSIENT_TABLE_NAME);

EXECUTE IMMEDIATE
CONCAT(
"""INSERT INTO  `""" ,BQ_PROJECT_NAME,"""`.""",BQ_TRANSIENT_DATASET_NAME,""".""",BQ_TRANSIENT_TABLE_NAME,"""
 (

  WITH

  ORIGINAL AS(

  SELECT DISTINCT
    date_sk,
    customer_name,
    banner,
    store_number,
    store_state,
    store_city,
    store_street_address,
    store_zipcode,
    upc,
    host,
    stock_flg,
    SAFE_CAST(source_file_name_dt AS STRING) AS source_file_name_dt,
    fiscal_month_in_year_nbr,
    fiscal_year_nbr,
    fiscal_week_in_year_nbr,
    fiscal_week_begin_dt,
    fiscal_year_month_nbr,
    fiscal_year_week_nbr,
    SAFE_CAST(file_dt AS STRING) AS file_dt,
    ingest_date,
    rctl_file_name,
    SAFE_CAST(created_by AS STRING) AS created_by,
    created_datetime,
    SAFE_CAST(modified_by AS STRING) AS modified_by,
    modified_datetime,
    ROW_NUMBER() OVER (PARTITION BY customer_name, fiscal_week_begin_dt, host, store_number, upc ORDER BY stock_flg DESC) AS rowNum
  FROM
    `""" ,BQ_PROJECT_NAME,"""`.""",BQ_TRANSIENT_DATASET_NAME,""".""",BQ_SOURCE_TABLE_NAME,"""_mv""","""
    WHERE 1=1
    AND ingest_date >  '""",EXTRACT_START_DATE,"""'
    AND ingest_date <= '""",EXTRACT_END_DATE,"""' )

  SELECT * EXCEPT(rowNum) FROM ORIGINAL WHERE rowNum =1)

""") ;

EXCEPTION WHEN ERROR THEN
        EXECUTE IMMEDIATE CONCAT(
            """INSERT INTO processed.ecomm_admin_sproc_error_details (
		        SELECT
			        '""",FEED_NAME,"""' AS FEED_NAME,
                    split(split(@@error.formatted_stack_trace,'transient.')[OFFSET (1)],'[')[OFFSET(0)],
			        @@error.statement_text,
			        @@error.message,
			        current_timestamp()
	        );
	    """);

	    SELECT
	        ERROR (
	            CONCAT(
	            		@@error.message ,' ' ,
	            		@@error.statement_text, ' ' ,
	            		@@error.formatted_stack_trace ,' '
	            	)
	        );
END;