/*
Purpose of the stored proc:
	/*
    Loads tables from delta_temp and joins on dim_product to get product dimensions, will load into processed one sp

History of Changes:
	05/16/22 – first version
Author :
	Shubham Saxena
*/

CREATE OR REPLACE PROCEDURE transient.ecomm_sproc_ana_dist_planner_temp
(
    DEST_PROJECT STRING,
    SRC_TABLE STRING,
    INTERMEDIATE_PROJECT STRING,
    INTERMEDIATE_DATASET STRING,
    INTERMEDIATE_TABLE STRING,
    DEST_DATASET STRING,
    DEST_TABLE STRING,
    FEED_NAME STRING
)
OPTIONS(
description = """

How to Call:
		call transient.ecomm_sproc_ana_dist_planner_temp
		(
        'ecomm-dlf-dev-01cd47',  --DEST_PROJECT
        'publix_instacart_dist_planner_delta_temp', --SRC_TABLE
        'edw-prd-e567f9',    --INTERMEDIATE_PROJECT
        'enterprise',        --INTERMEDIATE_DATASET
        'dim_product_active',--INTERMEDIATE_TABLE
        'transient',         --DEST_DATASET
        'publix_instacart_dist_planner_temp', --DEST_TABLE
        'publix'                              --FEED_NAME
		)
"""
)

BEGIN
DECLARE JOB_RUN_ID DEFAULT 999999;
DECLARE BQ_PROJECT_NAME DEFAULT DEST_PROJECT;
DECLARE BQ_SOURCE_TABLE_NAME DEFAULT SRC_TABLE;
DECLARE BQ_EDW_PROJECT_NAME DEFAULT INTERMEDIATE_PROJECT;
DECLARE BQ_ENTERPRISE_DATASET_NAME DEFAULT INTERMEDIATE_DATASET;
DECLARE BQ_INTER_TABLE_NAME DEFAULT INTERMEDIATE_TABLE;
DECLARE BQ_TRANSIENT_DATASET_NAME DEFAULT DEST_DATASET;
DECLARE BQ_TARGET_TABLE_NAME DEFAULT DEST_TABLE;
SET FEED_NAME = UPPER(FEED_NAME);

EXECUTE IMMEDIATE CONCAT("""TRUNCATE TABLE `""",BQ_PROJECT_NAME,""".""",BQ_TRANSIENT_DATASET_NAME,""".""",BQ_TARGET_TABLE_NAME,"""`""");

EXECUTE IMMEDIATE
  CONCAT( """INSERT INTO  `""",BQ_PROJECT_NAME,"""`.""",BQ_TRANSIENT_DATASET_NAME,""".""",BQ_TARGET_TABLE_NAME,""" (
    select
        prd.ean_upc_cd gmi_upc
        , prd.ean_upc_cd gmi_upc_desc
        , src.cm_tdp_reach
        , 'PUBLIX' as customer_name
        , prd.gmi_division_cd division
        , prd.gmi_division_desc division_desc
        , 'PUBLIX' as banner
        , NULL authorization_flg
        , 'USD' currency_cd
        , 0 average_inventory_on_hand_units
        , prd.base_product_cd base_product_cd
        , prd.base_product_desc base_product_desc
        , prd.material_cd material_cd
        , prd.material_short_desc material_short_desc
        , prd.material_nbr material_nbr
        , prd.ean_upc_cd ean_upc_cd
        , prd.sls_hier_division_desc sls_hier_division_desc
        , prd.sls_hier_category_desc sls_hier_category_desc
        , prd.sls_hier_sub_category_desc sls_hier_sub_category_desc
        , prd.sls_hier_ppg_desc sls_hier_ppg_desc
        , CAST(""",JOB_RUN_ID,""" AS STRING) created_by
        , current_datetime created_datetime
        , CAST(""",JOB_RUN_ID,""" AS STRING) modified_by
        , current_datetime modified_datetime
    from `""",BQ_PROJECT_NAME,""".""",BQ_TRANSIENT_DATASET_NAME,""".""",BQ_SOURCE_TABLE_NAME,"""` src
    left join `""",BQ_EDW_PROJECT_NAME,""".""",BQ_ENTERPRISE_DATASET_NAME,""".""",BQ_INTER_TABLE_NAME,"""` prd
        on src.material_cd = prd.material_cd
        and language_cd = 'EN'
        and source_type_cd = 'NA'
        and material_type_cd in ('CNPK', 'FINI')
    where src.cm_tdp_reach >= 80.0
)
""");


EXCEPTION WHEN ERROR THEN
        EXECUTE IMMEDIATE CONCAT(
            """INSERT INTO processed.ecomm_admin_sproc_error_details (
		        SELECT
			        '""",FEED_NAME,"""' AS FEED_NAME,
                    split(split(@@error.formatted_stack_trace,'transient.')[OFFSET (1)],'[')[OFFSET(0)],
			        @@error.statement_text,
			        @@error.message,
			        current_timestamp()
	        );
	    """);

	    SELECT
	        ERROR (
	            CONCAT(
	            		@@error.message ,' ' ,
	            		@@error.statement_text, ' ' ,
	            		@@error.formatted_stack_trace ,' '
	            	)
	        );

END;