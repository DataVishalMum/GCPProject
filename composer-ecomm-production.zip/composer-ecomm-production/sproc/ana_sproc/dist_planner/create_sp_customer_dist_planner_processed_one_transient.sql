/*
Purpose of the stored proc:
	/*
    Deletes restated data from processed one data, then reloads the updated data from the temp table

History of Changes:
	05/16/22 – first version
Author:
	Shubham Saxena
*/


CREATE OR REPLACE PROCEDURE transient.ecomm_sproc_ana_dist_planner_processed_one
(
	 DEST_PROJECT STRING,
	 SRC_DATASET STRING,
	 SRC_TABLE STRING,
	 DEST_DATASET STRING,
	 INTERMEDIATE_TABLE STRING,
	 DEST_TABLE STRING,
	 FEED_NAME STRING
)
OPTIONS(
description = """

How to Call:
	    call transient.ecomm_sproc_ana_dist_planner_processed_one
	    (
        'ecomm-dlf-dev-01cd47',                 --DEST_PROJECT
        'transient',                            --SRC_DATASET
        'publix_instacart_dist_planner_temp',   --SRC_TABLE
        'processed',                            --DEST_DATASET
        'dim_upc_conversions_flattened',        --INTERMEDIATE_TABLE
        'publix_instacart_dist_planner_fact',   --DEST_TABLE
        'publix'                                --FEED_NAME
	    )
"""
)

BEGIN
DECLARE BQ_PROJECT_NAME DEFAULT DEST_PROJECT;
DECLARE BQ_TRANSIENT_DATASET_NAME DEFAULT SRC_DATASET;
DECLARE BQ_TEMP_TABLE_NAME DEFAULT SRC_TABLE;
DECLARE BQ_PROCESSED_DATASET_NAME DEFAULT DEST_DATASET;
DECLARE BQ_INTER_TABLE_NAME DEFAULT INTERMEDIATE_TABLE;
DECLARE BQ_TARGET_TABLE_NAME DEFAULT DEST_TABLE;
SET FEED_NAME = UPPER(FEED_NAME);

EXECUTE IMMEDIATE CONCAT("""TRUNCATE TABLE `""",BQ_PROJECT_NAME,""".""",BQ_PROCESSED_DATASET_NAME,""".""",BQ_TARGET_TABLE_NAME,"""`""");

EXECUTE IMMEDIATE
    CONCAT("""
    INSERT INTO `""",BQ_PROJECT_NAME,""".""",BQ_PROCESSED_DATASET_NAME,""".""",BQ_TARGET_TABLE_NAME,"""`
    		  SELECT src.gmi_upc,
					 src.gmi_upc_desc,
					 src.cm_tdp_reach,
					 src.customer_name,
					 src.division,
					 src.division_desc,
					 src.banner,
					 src.authorization_flg,
					 src.currency_cd,
					 src.average_inventory_on_hand_units,
                     coalesce(conv.new_base_product_cd, src.base_product_cd) AS base_product_cd,
                     coalesce(conv.new_base_product_desc, src.base_product_desc) AS base_product_desc,
                     coalesce(conv.new_material_cd, src.material_cd) AS material_cd,
                     coalesce(conv.new_material_short_desc, src.material_short_desc) AS material_short_desc,
                     coalesce(conv.new_material_nbr, src.material_nbr) AS material_nbr,
					 coalesce(conv.new_ean_upc_cd, src.ean_upc_cd) as ean_upc_cd,
                     coalesce(conv.new_sls_hier_division_desc, src.sls_hier_division_desc) AS sls_hier_division_desc,
                     coalesce(conv.new_sls_hier_category_desc, src.sls_hier_category_desc) AS sls_hier_category_desc,
                     coalesce(conv.new_sls_hier_sub_category_desc, src.sls_hier_sub_category_desc) AS sls_hier_sub_category_desc,
                     coalesce(conv.new_sls_hier_ppg_desc, src.sls_hier_ppg_desc) AS sls_hier_ppg_desc,
                     src.base_product_cd AS old_base_product_cd,
                     src.base_product_desc AS old_base_product_desc,
                     src.material_cd AS old_material_cd,
                     src.material_short_desc AS old_material_short_desc,
                     src.material_nbr AS old_material_nbr,
					 src.ean_upc_cd AS old_ean_upc_cd,
                     src.sls_hier_division_desc AS old_sls_hier_division_desc,
                     src.sls_hier_category_desc AS old_sls_hier_category_desc,
                     src.sls_hier_sub_category_desc AS old_sls_hier_sub_category_desc,
                     src.sls_hier_ppg_desc AS old_sls_hier_ppg_desc,
					 src.created_by,
					 src.created_datetime,
					 src.modified_by,
					 src.modified_datetime
		FROM `""",BQ_PROJECT_NAME,""".""",BQ_TRANSIENT_DATASET_NAME,""".""",BQ_TEMP_TABLE_NAME,"""` src
      LEFT JOIN
             `""",BQ_PROJECT_NAME,""".""",BQ_PROCESSED_DATASET_NAME,""".""",BQ_INTER_TABLE_NAME,"""` conv
        on ltrim(conv.old_ean_upc_cd, '0') = ltrim(src.ean_upc_cd, '0')
""");

EXCEPTION WHEN ERROR THEN
        EXECUTE IMMEDIATE CONCAT(
            """INSERT INTO processed.ecomm_admin_sproc_error_details (
		        SELECT
			        '""",FEED_NAME,"""' AS FEED_NAME,
                    split(split(@@error.formatted_stack_trace,'transient.')[OFFSET (1)],'[')[OFFSET(0)],
			        @@error.statement_text,
			        @@error.message,
			        current_timestamp()
	        );
	    """);

	    SELECT
	        ERROR (
	            CONCAT(
	            		@@error.message ,' ' ,
	            		@@error.statement_text, ' ' ,
	            		@@error.formatted_stack_trace ,' '
	            	)
	        );

END;