/*
Purpose of the stored proc:
	/*
    Load records for each customer from the raw source tables into delta temp, to be
		used in pulling additional attributes

History of Changes:
	05/16/22 – first version
Author:
	Shubham Saxena
*/

CREATE OR REPLACE PROCEDURE transient.ecomm_sproc_ana_dist_planner_delta_temp
(
     DEST_PROJECT STRING,
     INTERMEDIATE_PROJECT STRING,
     INTERMEDIATE_DATASET STRING,
     DEST_DATASET STRING,
     DEST_TABLE STRING,
     FEED_NAME STRING
)
OPTIONS(
description = """

How to Call:
        call transient.ecomm_sproc_ana_dist_planner_delta_temp
        (
        'ecomm-dlf-dev-01cd47',    --DEST_PROJECT
        'shareddata-prd-cb5872',   --INTERMEDIATE_PROJECT
        'shared_data_sales',       --INTERMEDIATE_DATASET
        'transient',               --DEST_DATASET
        'publix_instacart_dist_planner_delta_temp',  --DEST_TABLE
        'publix'                                     --FEED_NAME
        )
"""
)
BEGIN
DECLARE JOB_RUN_ID DEFAULT 999999;
DECLARE BQ_PROJECT_NAME DEFAULT DEST_PROJECT;
DECLARE BQ_SHARED_PROJECT_NAME DEFAULT INTERMEDIATE_PROJECT;
DECLARE BQ_SHAREDDATA_DATASET_NAME DEFAULT INTERMEDIATE_DATASET;
DECLARE BQ_TRANSIENT_DATASET_NAME DEFAULT DEST_DATASET;
DECLARE TARGET_TABLE_NAME DEFAULT DEST_TABLE;
SET FEED_NAME = UPPER(FEED_NAME);

EXECUTE IMMEDIATE CONCAT("""TRUNCATE TABLE `""",BQ_PROJECT_NAME,""".""",BQ_TRANSIENT_DATASET_NAME,""".""",TARGET_TABLE_NAME,"""`""");

EXECUTE IMMEDIATE
    CONCAT("""
	INSERT INTO `""",BQ_PROJECT_NAME,""".""",BQ_TRANSIENT_DATASET_NAME,""".""",TARGET_TABLE_NAME,"""`

	SELECT
      f.material_cd
      , f.base_product_cd
      , f.cm_tdp_reach
      , date_add(parse_timestamp('%m-%d-%Y', '01-01-1900'), INTERVAL (cast(f.first_delivery_dt as int)-1) DAY) as first_delivery_dt
      , date_add(parse_timestamp('%m-%d-%Y', '01-01-1900'), INTERVAL (cast(f.last_delivery_dt as int)-1) DAY) as last_delivery_dt
      , CAST(""",JOB_RUN_ID,""" AS string) AS created_by
      , current_datetime AS created_datetime
      , CAST(""",JOB_RUN_ID,""" AS string) AS modified_by
      , current_datetime AS modified_datetime
    FROM `""",BQ_SHARED_PROJECT_NAME,""".""",BQ_SHAREDDATA_DATASET_NAME,""".dp_rpt_dmv_facts` f
    inner join `""",BQ_SHARED_PROJECT_NAME,""".""",BQ_SHAREDDATA_DATASET_NAME,""".dp_rpt_dmv_products` p on p.product_join_key = f.product_join_key
    inner join `""",BQ_SHARED_PROJECT_NAME,""".""",BQ_SHAREDDATA_DATASET_NAME,""".dp_rpt_dmv_customers` c on c.customer_join_key = f.customer_join_key
    where  c.customer_cd = '0011868000'
    and cust_material_status_cd = 'A' and latest_cust_material_status_cd = 'Y'
""");

EXCEPTION WHEN ERROR THEN
        EXECUTE IMMEDIATE CONCAT(
            """INSERT INTO processed.ecomm_admin_sproc_error_details (
		        SELECT
			        '""",FEED_NAME,"""' AS FEED_NAME,
                    split(split(@@error.formatted_stack_trace,'transient.')[OFFSET (1)],'[')[OFFSET(0)],
			        @@error.statement_text,
			        @@error.message,
			        current_timestamp()
	        );
	    """);

	    SELECT
	        ERROR (
	            CONCAT(
	            		@@error.message ,' ' ,
	            		@@error.statement_text, ' ' ,
	            		@@error.formatted_stack_trace ,' '
	            	)
	        );

END;