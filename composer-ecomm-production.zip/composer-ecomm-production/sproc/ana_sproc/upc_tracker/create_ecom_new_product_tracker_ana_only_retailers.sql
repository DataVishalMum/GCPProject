/*
Purpose of the stored proc:


History of Changes:
12/17/2021 - Initial Version
2/22/22 - Add additional parameter (BQ_SHARED_GSS_DATASET_NAME) and change tablename reference for dp_v_new_item_intro_detail
3/7/22 - Change usage of is_online_distribution to is_online and is_INSTORE_DISTRIBUTION to is_instore (Nelson W.)
06/29/22 - Changes related to composer work
Author :
	Shubham Saxena
*/

CREATE OR REPLACE PROCEDURE transient.ecomm_sproc_ana_common_new_product_tracker
(
SRC_PROJECT STRING,
SRC_DATASET STRING,
DEST_DATASET STRING,
INTERMEDIATE_PROJECT STRING,
INTERMEDIATE_DATASET STRING,
DEST_LOOKUP_PROJECT STRING,
DEST_LOOKUP_TABLE STRING,
DEST_LOOKUP_DATASET STRING,
SRC_TABLE STRING,
DEST_TABLE STRING,
FEED_NAME STRING
)
OPTIONS(
description = """
How to Call:
CALL transient.ecomm_sproc_ana_common_new_product_tracker
(
'ecomm-dlf-dev-01cd47',                                      --SRC_PROJECT
'transient',                                                 --SRC_DATASET
'processed' ,                                                --DEST_DATASET
'edw-prd-e567f9',                                            --INTERMEDIATE_PROJECT
'enterprise',                                                --INTERMEDIATE_DATASET
'shareddata-prd-cb5872',                                     --DEST_LOOKUP_PROJECT
'sales_ecomm_global_sales_and_share',                        --DEST_LOOKUP_TABLE
'shared_data_sales',                                         --DEST_LOOKUP_DATASET
'stop_and_shop_distribution_availability_with_upc_fact',     --SRC_TABLE
'ecom_stop_and_shop_new_product_tracker',                    --DEST_TABLE
'stop_and_shop'                                              --FEED_NAME
)
"""
)

BEGIN
DECLARE JOB_RUN_ID DEFAULT 999999;
DECLARE BQ_PROJECT_NAME DEFAULT SRC_PROJECT;
DECLARE BQ_TRANSIENT_DATASET_NAME DEFAULT SRC_DATASET;
DECLARE BQ_PROCESSED_DATASET_NAME DEFAULT DEST_DATASET;
DECLARE BQ_EDW_PROJECT_NAME DEFAULT INTERMEDIATE_PROJECT;
DECLARE BQ_ENTERPRISE_DATASET_NAME DEFAULT INTERMEDIATE_DATASET;
DECLARE BQ_SHARED_PROJECT_NAME DEFAULT DEST_LOOKUP_PROJECT;
DECLARE BQ_SHARED_GSS_DATASET_NAME DEFAULT DEST_LOOKUP_TABLE;
DECLARE BQ_SHARED_SALES_DATASET_NAME DEFAULT DEST_LOOKUP_DATASET;
DECLARE DNA_UPC_FACT_TABLE_NAME DEFAULT SRC_TABLE;
DECLARE BQ_TARGET_TABLE_NAME DEFAULT DEST_TABLE;

DECLARE INSTORE_DISTRIBUTION STRING;

SET FEED_NAME = UPPER(FEED_NAME);

EXECUTE IMMEDIATE
CONCAT("""
WITH customer as (select distinct customer_name from
`""",BQ_PROJECT_NAME,"""`.""",BQ_PROCESSED_DATASET_NAME,""".""",DNA_UPC_FACT_TABLE_NAME,""")
SELECT CASE WHEN UPPER(customer_name) IN ('AMAZON_COM','AMAZON_PRIME_NOW','AMAZON_FRESH') THEN '0'
ELSE 'is_instore'
END
FROM customer
""") INTO INSTORE_DISTRIBUTION;

/* <retailer>_new_product_tracker table is Truncate & Load */
EXECUTE IMMEDIATE
CONCAT("""TRUNCATE TABLE  `""" ,BQ_PROJECT_NAME,"""`.""",BQ_PROCESSED_DATASET_NAME,""".""",BQ_TARGET_TABLE_NAME);

	/*Insert Details for passed customer into '<retailer>_new_product_tracker table' table having ingest date greater than extract_start_date
from data_extract_config table */
EXECUTE IMMEDIATE
CONCAT(
"""insert into  `""" ,BQ_PROJECT_NAME,"""`.""",BQ_PROCESSED_DATASET_NAME,""".""",BQ_TARGET_TABLE_NAME,"""

-- No date filter included on new products - all new products are pulled in.
with new_products as (
	select distinct
	-- replaced regexp_replace(d.package_upc, '^0*', '') in hadoop with LTRIM function in GCP
	-- because regex_replace is trimming the leading zeroes
		LTRIM(d.package_upc, '0') as ean_upc_cd,
		p.sls_hier_division_desc,
		p.sls_hier_category_desc,
		p.sls_hier_sub_category_desc,
		p.sls_hier_ppg_desc,
		p.material_short_desc,
		d.ipp_start_date,
		d.ipp_end_date,
		d.sls_lnch_ty_cd
	from `""",BQ_SHARED_PROJECT_NAME,""".""",BQ_SHARED_GSS_DATASET_NAME,""".dp_v_new_item_intro_detail` d
	inner join `""",BQ_SHARED_PROJECT_NAME,""".""",BQ_SHARED_GSS_DATASET_NAME,""".dp_material_raw_v` dm on d.material_key = dm.material_key
	inner join `""",BQ_EDW_PROJECT_NAME,""".""",BQ_ENTERPRISE_DATASET_NAME,""".dim_product_active` p on LTRIM(p.ean_upc_cd, '0') = LTRIM(dm.upc_cd, '0')
	where
		d.sls_lnch_ty_cd in ('T1', 'T2')
		and p.language_cd = 'EN' and p.source_type_cd = 'NA'
),
new_da as (
	select
		np.ean_upc_cd,
		np.sls_hier_division_desc,
		np.sls_hier_category_desc,
		np.sls_hier_sub_category_desc,
		np.sls_hier_ppg_desc,
		np.material_short_desc,
		np.ipp_start_date,
		np.ipp_end_date,
		np.sls_lnch_ty_cd,
		upc_fact.customer_parent,
		case when upper(upc_fact.customer_account)='TARGET'
			then 'TARGET STORE PICK_UP' else upc_fact.customer_account
			end as customer_account,
		upc_fact.customer_name,
		upc_fact.fiscal_week_begin_dt,
		upc_fact.fiscal_year_week_nbr,
		upc_fact.fiscal_year_month_nbr,
		cast(sum(""",INSTORE_DISTRIBUTION,""") as int64) as INSTORE_DISTRIBUTION_count,
		cast(sum(coalesce(upc_fact.is_online,0)) as int64) as online_distribution_count
	from new_products np
	inner join `""",BQ_PROJECT_NAME,""".""",BQ_PROCESSED_DATASET_NAME,""".""",DNA_UPC_FACT_TABLE_NAME,"""` upc_fact

	-- we are using old_ean_upc_cd here for the join because in hadoop, the upc_pre_conversions table is being used
	-- the ean_upc_cd in the upc_pre_conversions (hadoop) is mapped to the old_ean_upc_cd in the upc_fact (GCP) table

		on np.ean_upc_cd = upc_fact.old_ean_upc_cd
	-- where
	-- 	report_fg = 'Y'
	group by
		np.ean_upc_cd,
		np.sls_hier_division_desc,
		np.sls_hier_category_desc,
		np.sls_hier_sub_category_desc,
		np.sls_hier_ppg_desc,
		np.material_short_desc,
		np.ipp_start_date,
		np.ipp_end_date,
		np.sls_lnch_ty_cd,
		upc_fact.customer_parent,
		upc_fact.customer_account,
		upc_fact.customer_name,
		upc_fact.fiscal_week_begin_dt,
		upc_fact.fiscal_year_week_nbr,
		upc_fact.fiscal_year_month_nbr
),
da_AnA as (
	select
		new_da.ean_upc_cd,
		'null' as source_item_name,
		new_da.customer_account,
		new_da.customer_parent,
		new_da.customer_name,
		new_da.fiscal_week_begin_dt,
		new_da.fiscal_year_week_nbr fiscal_year_week_nbr,
		new_da.fiscal_year_month_nbr fiscal_year_month_nbr,
		new_da.sls_hier_division_desc,
		new_da.sls_hier_category_desc,
		new_da.sls_hier_sub_category_desc,
		new_da.sls_hier_ppg_desc,
		new_da.material_short_desc,
		new_da.ipp_start_date,
		new_da.ipp_end_date,
		new_da.sls_lnch_ty_cd,
		0 as ty_sales_eqc_units,
		0 as ty_sales_value_usd,
		new_da.INSTORE_DISTRIBUTION_count,
		new_da.online_distribution_count,
		0 as category_sales_benchmark,
		0 as sub_category_sales_benchmark,
		0 as sub_category_eqc_benchmark,
		'""",JOB_RUN_ID,"""' AS created_by,
		current_datetime AS created_datetime,
		'""",JOB_RUN_ID,"""' AS modified_by,
		current_datetime AS modified_datetime
	from new_da

)
-- INSERT OVERWRITE TABLE ecom_audit.ecom_new_product_tracker
	select
		ean_upc_cd,
		source_item_name,
		ipp_start_date,
		ipp_end_date,
		sls_lnch_ty_cd,
		sls_hier_division_desc,
		sls_hier_category_desc,
		sls_hier_sub_category_desc,
		sls_hier_ppg_desc,
		material_short_desc,
		customer_parent,
		customer_account,
		customer_name,
		fiscal_week_begin_dt,

		-- fiscal_year_week_nbr and fiscal_year_month_nbr columns are added
		-- because these are used to join with the release control table in the new_poduct_tracker view

		fiscal_year_week_nbr,
		fiscal_year_month_nbr,
		max(ty_sales_eqc_units) as ty_sales_eqc_units,
		max(ty_sales_value_usd) as ty_sales_value_usd,
		max(INSTORE_DISTRIBUTION_count) as INSTORE_DISTRIBUTION_count,
		max(online_distribution_count) as online_distribution_count,

		-- The below columns were rounded off to decimal(38,10) in hadoop
		-- so, these columns are rounded to the 10 decimal places in GCP.

		max(category_sales_benchmark) as category_sales_benchmark,
     	max(sub_category_sales_benchmark) as sub_category_sales_benchmark,
        max(sub_category_eqc_benchmark) as sub_category_eqc_benchmark,
		created_by,
		created_datetime,
		modified_by,
		modified_datetime
	from da_AnA
	group by
		ean_upc_cd,
		source_item_name,
		ipp_start_date,
		ipp_end_date,
		sls_lnch_ty_cd,
		sls_hier_division_desc,
		sls_hier_category_desc,
		sls_hier_sub_category_desc,
		sls_hier_ppg_desc,
		material_short_desc,
		ipp_start_date,
		customer_account,
		customer_parent,
		customer_name,
		fiscal_week_begin_dt,
		fiscal_year_week_nbr,
		fiscal_year_month_nbr,
		--category_sales_benchmark,
		--sub_category_sales_benchmark,
		--sub_category_eqc_benchmark,
		created_by,
		created_datetime,
		modified_by,
		modified_datetime
""") ;

EXCEPTION WHEN ERROR THEN
        EXECUTE IMMEDIATE CONCAT(
            """INSERT INTO processed.ecomm_admin_sproc_error_details (
		        SELECT
			        '""",FEED_NAME,"""' AS FEED_NAME,
                    split(split(@@error.formatted_stack_trace,'transient.')[OFFSET (1)],'[')[OFFSET(0)],
			        @@error.statement_text,
			        @@error.message,
			        current_timestamp()
	        );
	    """);

	    SELECT
	        ERROR (
	            CONCAT(
	            		@@error.message ,' ' ,
	            		@@error.statement_text, ' ' ,
	            		@@error.formatted_stack_trace ,' '
	            	)
	        );

END;