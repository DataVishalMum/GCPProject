/*
Purpose of the stored proc:
	/*
    Deletes restated data from processed one data, then reloads the updated data from the temp table

History of Changes:
	25/06/22 – First Version

Author :
	Pawan Rathod

*/


CREATE OR REPLACE PROCEDURE transient.ecomm_sproc_ana_nielsen_iri_processed_one
(
	 SRC_PROJECT STRING,
	 SRC_DATASET STRING,
	 SRC_TABLE STRING,
	 DEST_DATASET STRING,
	 DEST_TABLE STRING,
	 FEED_NAME STRING
)
OPTIONS(
description = """

 How to call:

     CALL transient.ecomm_sproc_ana_nielsen_iri_processed_one (
		"ecomm-dlf-dev-01cd47", -- SRC_PROJECT
        "transient", -- SRC_DATASET
        "heb_iri_temp", -- SRC_TABLE
	    "processed", -- DEST_DATASET
        "heb_iri_fact", -- DEST_TABLE
        "HEB" -- FEED_NAME
	)
"""
)

BEGIN

DECLARE BQ_PROJECT_NAME DEFAULT SRC_PROJECT;
DECLARE BQ_TRANSIENT_DATASET_NAME DEFAULT SRC_DATASET;
DECLARE BQ_TEMP_TABLE_NAME DEFAULT SRC_TABLE;
DECLARE BQ_PROCESSED_DATASET_NAME DEFAULT DEST_DATASET;
DECLARE BQ_TARGET_TABLE_NAME DEFAULT DEST_TABLE;

DECLARE MIN_TMP_FISCAL_WK_BEGIN_DT DATE;

SET FEED_NAME = UPPER(FEED_NAME);

-- find min fiscal week begin date from delta tmp load - to be used to delete records
EXECUTE IMMEDIATE CONCAT("""SELECT COALESCE(MIN(fiscal_week_begin_dt),'1800-01-01') FROM `""",BQ_PROJECT_NAME,"""`.""",BQ_TRANSIENT_DATASET_NAME,""".""",BQ_TEMP_TABLE_NAME) INTO MIN_TMP_FISCAL_WK_BEGIN_DT;

-- delete records from target where fiscal week begin date is greater than/equal to fiscal week begin dt from previous step
EXECUTE IMMEDIATE CONCAT("""DELETE FROM `""",BQ_PROJECT_NAME,""".""",BQ_PROCESSED_DATASET_NAME,""".""",BQ_TARGET_TABLE_NAME,"""` WHERE fiscal_week_begin_dt >= '""",MIN_TMP_FISCAL_WK_BEGIN_DT,"""'""");

-- Fetch all the records from the temp table and insert them into the processed-one table
EXECUTE IMMEDIATE
    CONCAT("""
    INSERT INTO `""",BQ_PROJECT_NAME,""".""",BQ_PROCESSED_DATASET_NAME,""".""",BQ_TARGET_TABLE_NAME,"""`
    		  SELECT src.gmi_upc,
					 src.gmi_upc_desc,
					 src.customer_name,
					 src.division,
					 src.division_desc,
					 src.banner,
					 src.store_number,
					 src.store_street_address,
					 src.store_city,
					 src.store_state,
					 src.store_zipcode,
					 src.authorization_flg,
					 src.pos_qty,
					 src.pos_sales,
					 src.currency_cd,
					 src.average_inventory_on_hand_units,
					 src.fiscal_month_in_year_nbr,
					 src.fiscal_year_nbr,
					 src.fiscal_quarter_in_year_nbr,
					 src.fiscal_week_in_year_nbr,
					 src.fiscal_month_in_year_short_desc,
					 src.fiscal_week_begin_dt,
					 src.fiscal_week_end_dt,
					 src.fiscal_month_begin_dt,
					 src.fiscal_month_end_dt,
					 src.fiscal_quarter_begin_dt,
					 src.fiscal_quarter_end_dt,
					 src.fiscal_year_begin_dt,
					 src.fiscal_year_end_dt,
					 src.fiscal_year_short_desc,
					 src.fiscal_quarter_nbr,
					 src.fiscal_year_month_nbr,
					 src.fiscal_year_week_nbr,
					 src.calendar_year_nbr,
					 src.source_product_hash,
                     coalesce(conv.new_base_product_cd, src.base_product_cd) AS base_product_cd,
                     coalesce(conv.new_base_product_desc, src.base_product_desc) AS base_product_desc,
                     coalesce(conv.new_material_cd, src.material_cd) AS material_cd,
                     coalesce(conv.new_material_short_desc, src.material_short_desc) AS material_short_desc,
                     coalesce(conv.new_material_nbr, src.material_nbr) AS material_nbr,
					 coalesce(conv.new_ean_upc_cd, src.ean_upc_cd) as ean_upc_cd,
                     coalesce(conv.new_sls_hier_division_desc, src.sls_hier_division_desc) AS sls_hier_division_desc,
                     coalesce(conv.new_sls_hier_category_desc, src.sls_hier_category_desc) AS sls_hier_category_desc,
                     coalesce(conv.new_sls_hier_sub_category_desc, src.sls_hier_sub_category_desc) AS sls_hier_sub_category_desc,
                     coalesce(conv.new_sls_hier_ppg_desc, src.sls_hier_ppg_desc) AS sls_hier_ppg_desc,
                     src.base_product_cd AS old_base_product_cd,
                     src.base_product_desc AS old_base_product_desc,
                     src.material_cd AS old_material_cd,
                     src.material_short_desc AS old_material_short_desc,
                     src.material_nbr AS old_material_nbr,
					 src.ean_upc_cd AS old_ean_upc_cd,
                     src.sls_hier_division_desc AS old_sls_hier_division_desc,
                     src.sls_hier_category_desc AS old_sls_hier_category_desc,
                     src.sls_hier_sub_category_desc AS old_sls_hier_sub_category_desc,
                     src.sls_hier_ppg_desc AS old_sls_hier_ppg_desc,
					 src.created_by,
					 src.created_datetime,
					 src.modified_by,
					 src.modified_datetime
		FROM `""",BQ_PROJECT_NAME,""".""",BQ_TRANSIENT_DATASET_NAME,""".""",BQ_TEMP_TABLE_NAME,"""` src
      LEFT JOIN
        `""" ,BQ_PROJECT_NAME,"""`.""",BQ_PROCESSED_DATASET_NAME,""".dim_upc_conversions_flattened conv
        on ltrim(conv.old_ean_upc_cd, '0') = ltrim(src.ean_upc_cd, '0')
""");

EXCEPTION WHEN ERROR THEN
        EXECUTE IMMEDIATE CONCAT(
            """INSERT INTO processed.ecomm_admin_sproc_error_details (
		        SELECT
			        '""",FEED_NAME,"""' AS FEED_NAME,
                    split(split(@@error.formatted_stack_trace,'transient.')[OFFSET (1)],'[')[OFFSET(0)],
			        @@error.statement_text,
			        @@error.message,
			        current_timestamp()
	        );
	    """);

	    SELECT
	        ERROR (
	            CONCAT(
	            		@@error.message ,' ' ,
	            		@@error.statement_text, ' ' ,
	            		@@error.formatted_stack_trace ,' '
	            	)
	        );
END;