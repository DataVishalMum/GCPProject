/*
Purpose of the stored proc:
	/*
    Loads tables from delta_temp and joins on dim_product and dim_date to get product and date dimensions, will load into processed one sp

History of Changes:
	25/06/22 – First Version

Author :
	Pawan Rathod

*/

CREATE OR REPLACE PROCEDURE transient.ecomm_sproc_ana_nielsen_iri_temp
(
    SRC_PROJECT STRING,
    SRC_DATASET STRING,
    SRC_TABLE STRING,
    INTERMEDIATE_PROJECT STRING,
    INTERMEDIATE_DATASET STRING,
    SRC_LOOKUP_PROJECT STRING,
    SRC_LOOKUP_DATASET STRING,
    DEST_PROJECT STRING,
    DEST_DATASET STRING,
    DEST_TABLE STRING,
    FEED_NAME STRING
)
OPTIONS(
description = """

 How to call:

     CALL transient.ecomm_sproc_ana_nielsen_iri_temp (
       "ecomm-dlf-dev-01cd47", -- SRC_PROJECT
       "transient", -- SRC_DATASET
       "heb_iri_delta_temp", -- SRC_TABLE
       "edw-prd-e567f9", -- INTERMEDIATE_PROJECT
       "enterprise", -- INTERMEDIATE_DATASET
       "shareddata-prd-cb5872", -- SRC_LOOKUP_PROJECT
       "tdlinx", -- SRC_LOOKUP_DATASET
       "ecomm-dlf-dev-01cd47", -- DEST_PROJECT
       "transient", -- DEST_DATASET
       "heb_iri_temp", -- DEST_TABLE
       "HEB" -- FEED_NAME
	)
"""
)

BEGIN

DECLARE JOB_RUN_ID DEFAULT 999999;
DECLARE BQ_PROJECT_NAME DEFAULT SRC_PROJECT;
DECLARE BQ_RAW_DATASET_NAME DEFAULT SRC_DATASET;
DECLARE BQ_SOURCE_TABLE_NAME DEFAULT SRC_TABLE;
DECLARE BQ_EDW_PROJECT_NAME DEFAULT INTERMEDIATE_PROJECT;
DECLARE BQ_ENTERPRISE_DATASET_NAME DEFAULT INTERMEDIATE_DATASET;
DECLARE BQ_SHAREDDATA_PROJECT_NAME DEFAULT SRC_LOOKUP_PROJECT;
DECLARE BQ_SHAREDDATA_DATASET_NAME DEFAULT SRC_LOOKUP_DATASET;
DECLARE BQ_TARGET_PROJECT_NAME DEFAULT DEST_PROJECT;
DECLARE BQ_TARGET_DATASET_NAME DEFAULT DEST_DATASET;
DECLARE BQ_TARGET_TABLE_NAME DEFAULT DEST_TABLE;

SET FEED_NAME = UPPER(FEED_NAME);

EXECUTE IMMEDIATE
  CONCAT("""TRUNCATE TABLE  `""",BQ_TARGET_PROJECT_NAME,"""`.""",BQ_TARGET_DATASET_NAME,""".""",BQ_TARGET_TABLE_NAME);

EXECUTE IMMEDIATE
  CONCAT( """INSERT INTO  `""",BQ_TARGET_PROJECT_NAME,"""`.""",BQ_TARGET_DATASET_NAME,""".""",BQ_TARGET_TABLE_NAME,""" (
    select
        prd.ean_upc_cd gmi_upc
        , prd.ean_upc_cd gmi_upc_desc
        , CASE
            WHEN src.store_name IN (
                'ACME MARKET',
                'ALBERTSONS',
                'ALBERTSONS MARKET',
                'ALBERTSONS MARKET STREET',
                'ALBERTSONS SAV ON',
                'AMIGOS UNITED',
                'CARRS QUALITY CENTER',
                'HAGGEN NORTHWEST FRESH',
                'JEWEL FOOD STORE',
                'JEWEL OSCO',
                'KINGS',
                'KINGS FOOD MARKETS',
                'KINGS FRESH IDEAS',
                'LUCKY',
                'LUCKY CALIFORNIA',
                'LUCKY STORE',
                'LUCKYS SUPERMARKET',
                'MARKET STREET',
                'PAC N SAVE',
                'PAVILIONS',
                'RANDALLS FOOD MARKET',
                'SAFEWAY STORE',
                'SAFEWAY SUPER STORE',
                'SHAWS SUPERMARKET',
                'STAR MARKET',
                'TOM THUMB FOOD & PHARMACY',
                'TOM THUMB MARKET',
                'UNITED',
                'UNITED SUPERMARKET',
                'UNITED SUPERMARKETS',
                'VONS',
                'VONS FOOD & DRUG',
                'VONS MARKET') THEN 'ALBERTSONS_SAFEWAY'
            WHEN src.store_name = 'HANNAFORD' THEN 'ADUSA_HANNAFORD'
            WHEN src.store_name = 'FOOD LION' THEN 'ADUSA_FOODLION'
            WHEN src.store_name IN ('SHOPRITE SUPER GRADE A', 'SHOPRITE') THEN 'SHOPRITE'
            WHEN src.store_name IN ('HY VEE FOOD STORE','HY VEE PHARMACY','HY VEE DRUGSTORES','HY VEE MAINSTREET','HY VEE FAST & FRESH') THEN 'HYVEE'
            WHEN src.store_name IN ('GIANT','GIANT FOOD') THEN 'ADUSA_GIANT_FOOD'
            WHEN src.store_name = 'STOP & SHOP' THEN 'ADUSA_STOP_AND_SHOP'
            WHEN src.store_name IN ('MARTINS','MARTINS FOOD MARKET','GIANT FOOD STORE','GIANT FOOD & DRUGSTORE','GIANT SUPER FOOD STORE','GIANT HEIRLOOM MARKET',
                 'GIANT FOOD & PHARMACY','MARTINS FOOD & DRUGSTORE','MARTINS FOOD & PHARMACY','MARTINS FOOD','SUPER GIANT FOOD & DRUGSTORE') AND store.owner_nm = 'The Giant Company'
                  THEN 'ADUSA_GIANT_COMPANY'
            ELSE retailer_name
            END as customer_name
        , prd.gmi_division_cd division
        , prd.gmi_division_desc division_desc
        , src.store_name banner
        , src.tdlinx_store_cd store_number
        , store_street_address_txt store_street_address
        , store_city_nm store_city
        , store_state_cd store_state
        , store_zip_cd store_zipcode
        , NULL authorization_flg
        , unit_sales pos_qty
        , dollar_sales pos_sales
        , 'USD' currency_cd
        , 0 average_inventory_on_hand_units
        , date.fiscal_month_in_year_nbr fiscal_month_in_year_nbr
        , date.fiscal_year_nbr fiscal_year_nbr
        , date.fiscal_quarter_in_year_nbr fiscal_quarter_in_year_nbr
        , date.fiscal_week_in_year_nbr fiscal_week_in_year_nbr
        , date.fiscal_month_in_year_short_desc fiscal_month_in_year_short_desc
        , date.fiscal_week_begin_dt fiscal_week_begin_dt
        , date.fiscal_week_end_dt fiscal_week_end_dt
        , date.fiscal_month_begin_dt fiscal_month_begin_dt
        , date.fiscal_month_end_dt fiscal_month_end_dt
        , date.fiscal_quarter_begin_dt fiscal_quarter_begin_dt
        , date.fiscal_quarter_end_dt fiscal_quarter_end_dt
        , date.fiscal_year_begin_dt fiscal_year_begin_dt
        , date.fiscal_year_end_dt fiscal_year_end_dt
        , date.fiscal_year_short_desc fiscal_year_short_desc
        , date.fiscal_quarter_nbr fiscal_quarter_nbr
        , date.fiscal_year_month_nbr fiscal_year_month_nbr
        , date.fiscal_year_week_nbr fiscal_year_week_nbr
        , date.calendar_year_nbr calendar_year_nbr
        , CONCAT(src.cal_wk_end_dt, src.tdlinx_store_cd, src.product_code, src.retailer_name) source_product_hash
        , prd.base_product_cd base_product_cd
        , prd.base_product_desc base_product_desc
        , prd.material_cd material_cd
        , prd.material_short_desc material_short_desc
        , prd.material_nbr material_nbr
        , prd.ean_upc_cd ean_upc_cd
        , prd.sls_hier_division_desc sls_hier_division_desc
        , prd.sls_hier_category_desc sls_hier_category_desc
        , prd.sls_hier_sub_category_desc sls_hier_sub_category_desc
        , prd.sls_hier_ppg_desc sls_hier_ppg_desc
        , CAST(""",JOB_RUN_ID,""" AS string) created_by
        , current_datetime created_datetime
        , CAST(""",JOB_RUN_ID,""" AS string) modified_by
        , current_datetime modified_datetime
    from `""",BQ_PROJECT_NAME,""".""",BQ_RAW_DATASET_NAME,""".""",BQ_SOURCE_TABLE_NAME,"""` src
    left join `""",BQ_EDW_PROJECT_NAME,""".""",BQ_ENTERPRISE_DATASET_NAME,""".dim_product_active` prd
        on src.material_code = prd.material_cd
        and language_cd = 'EN'
        and source_type_cd = 'NA'
        and material_type_cd in ('CNPK', 'FINI')
    left join `""",BQ_EDW_PROJECT_NAME,""".""",BQ_ENTERPRISE_DATASET_NAME,""".dim_date` date
        on cast(src.cal_wk_end_dt as date) = date.fiscal_dt
        and date.language_cd='EN'
        and date.fiscal_year_variant_cd = '07'
    left join `""",BQ_SHAREDDATA_PROJECT_NAME,""".""",BQ_SHAREDDATA_DATASET_NAME,""".tdlinx_store` store
        on src.tdlinx_store_cd = store.tdlinx_store_cd
)
""");

EXCEPTION WHEN ERROR THEN
        EXECUTE IMMEDIATE CONCAT(
            """INSERT INTO processed.ecomm_admin_sproc_error_details (
		        SELECT
			        '""",FEED_NAME,"""' AS FEED_NAME,
                    split(split(@@error.formatted_stack_trace,'transient.')[OFFSET (1)],'[')[OFFSET(0)],
			        @@error.statement_text,
			        @@error.message,
			        current_timestamp()
	        );
	    """);

	    SELECT
	        ERROR (
	            CONCAT(
	            		@@error.message ,' ' ,
	            		@@error.statement_text, ' ' ,
	            		@@error.formatted_stack_trace ,' '
	            	)
	        );
END;