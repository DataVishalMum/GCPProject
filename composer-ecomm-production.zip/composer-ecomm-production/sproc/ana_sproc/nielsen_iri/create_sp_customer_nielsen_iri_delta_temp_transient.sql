/*
Purpose of the stored proc:

    Load records for each customer from the raw source tables into delta temp, to be
		used in pulling additional attributes

History of Changes:
	25/06/22 – First Version

Author :
	Pawan Rathod

*/

CREATE OR REPLACE PROCEDURE transient.ecomm_sproc_ana_nielsen_iri_delta_temp
(
	 DEST_PROJECT STRING,
	 DEST_DATASET STRING,
	 SRC_PROJECT STRING,
	 SRC_DATASET STRING,
	 CUSTOMER_NAME STRING,
	 SRC_TABLE STRING,
	 DEST_TABLE STRING,
	 FEED_NAME STRING
)
OPTIONS(
description = """

 How to call:

     CALL transient.ecomm_sproc_ana_nielsen_iri_delta_temp (
        "ecomm-dlf-dev-01cd47", -- DEST_PROJECT
        "transient", -- DEST_DATASET
        "shareddata-prd-cb5872", -- SRC_PROJECT
        "retail_heb", -- SRC_DATASET
        "HEB", -- CUSTOMER_NAME
        "heb_gmi_pos_data", -- SRC_TABLE
        "heb_iri_delta_temp", -- DEST_TABLE
        "HEB" -- FEED_NAME
	)
"""
)

BEGIN

DECLARE BQ_PROJECT_NAME DEFAULT DEST_PROJECT;
DECLARE BQ_TRANSIENT_DATASET_NAME DEFAULT DEST_DATASET;
DECLARE BQ_SHARED_PROJECT_NAME DEFAULT SRC_PROJECT;
DECLARE BQ_RETAILER_DATASET_NAME DEFAULT SRC_DATASET;
DECLARE RAW_TABLE_NAME DEFAULT SRC_TABLE;
DECLARE TARGET_TABLE_NAME DEFAULT DEST_TABLE;

SET CUSTOMER_NAME = UPPER(CUSTOMER_NAME);

SET FEED_NAME = UPPER(FEED_NAME);

EXECUTE IMMEDIATE CONCAT("""TRUNCATE TABLE `""",BQ_PROJECT_NAME,""".""",BQ_TRANSIENT_DATASET_NAME,""".""",TARGET_TABLE_NAME,"""`""");

-- Fetch all the records from the raw table

EXECUTE IMMEDIATE
    CONCAT("""
	INSERT INTO `""",BQ_PROJECT_NAME,""".""",BQ_TRANSIENT_DATASET_NAME,""".""",TARGET_TABLE_NAME,"""`
    SELECT cal_wk_end_dt,
		   tdlinx_store_cd,
		   store_name,
		   product_code,
		   material_code,
		   dollar_sales,
		   unit_sales,
		   retailer_name
	FROM `""",BQ_SHARED_PROJECT_NAME,""".""",BQ_RETAILER_DATASET_NAME,""".""",RAW_TABLE_NAME,"""`
	WHERE ('""",CUSTOMER_NAME,"""' = 'ALBERTSONS/SAFEWAY' AND store_name IN ('ACME MARKET','ALBERTSONS',	'ALBERTSONS MARKET','ALBERTSONS MARKET STREET',	'ALBERTSONS SAV ON','AMIGOS UNITED',
			                               'CARRS QUALITY CENTER','HAGGEN NORTHWEST FRESH','JEWEL FOOD STORE','JEWEL OSCO','KINGS','KINGS FOOD MARKETS','KINGS FRESH IDEAS','LUCKY',
	                               		   'LUCKY CALIFORNIA','LUCKY STORE','LUCKYS SUPERMARKET','MARKET STREET','PAC N SAVE','PAVILIONS','RANDALLS FOOD MARKET','SAFEWAY STORE',
			                               'SAFEWAY SUPER STORE','SHAWS SUPERMARKET','STAR MARKET','TOM THUMB FOOD & PHARMACY','TOM THUMB MARKET','UNITED','UNITED SUPERMARKET','UNITED SUPERMARKETS',
			                               'VONS','VONS FOOD & DRUG','VONS MARKET'))
	  OR ('""",CUSTOMER_NAME,"""' = 'HEB' AND store_name IN ('H E B', 'H E B PLUS'))
	  OR ('""",CUSTOMER_NAME,"""' = 'ADUSA_HANNAFORD' AND store_name = 'HANNAFORD')
	  OR ('""",CUSTOMER_NAME,"""' = 'ADUSA_FOODLION' AND store_name = 'FOOD LION')
      OR ('""",CUSTOMER_NAME,"""' = 'HYVEE' AND store_name IN ('HY VEE FOOD STORE','HY VEE PHARMACY','HY VEE DRUGSTORES','HY VEE MAINSTREET','HY VEE FAST & FRESH'))
      OR ('""",CUSTOMER_NAME,"""' = 'SHOPRITE' AND store_name IN ('SHOPRITE SUPER GRADE A', 'SHOPRITE'))
      OR ('""",CUSTOMER_NAME,"""' = 'ADUSA_GIANT_FOOD' AND store_name IN ('GIANT','GIANT FOOD'))
      OR ('""",CUSTOMER_NAME,"""' = 'ADUSA_STOP_AND_SHOP' AND store_name = 'STOP & SHOP')
      OR ('""",CUSTOMER_NAME,"""' = 'ADUSA_GIANT_COMPANY' AND store_name IN ('MARTINS','MARTINS FOOD MARKET','GIANT FOOD STORE','GIANT FOOD & DRUGSTORE','GIANT SUPER FOOD STORE',
                                    'GIANT HEIRLOOM MARKET','GIANT FOOD & PHARMACY','MARTINS FOOD & DRUGSTORE','MARTINS FOOD & PHARMACY','MARTINS FOOD','SUPER GIANT FOOD & DRUGSTORE'))

""");

EXCEPTION WHEN ERROR THEN
        EXECUTE IMMEDIATE CONCAT(
            """INSERT INTO processed.ecomm_admin_sproc_error_details (
		        SELECT
			        '""",FEED_NAME,"""' AS FEED_NAME,
                    split(split(@@error.formatted_stack_trace,'transient.')[OFFSET (1)],'[')[OFFSET(0)],
			        @@error.statement_text,
			        @@error.message,
			        current_timestamp()
	        );
	    """);

	    SELECT
	        ERROR (
	            CONCAT(
	            		@@error.message ,' ' ,
	            		@@error.statement_text, ' ' ,
	            		@@error.formatted_stack_trace ,' '
	            	)
	        );
END;