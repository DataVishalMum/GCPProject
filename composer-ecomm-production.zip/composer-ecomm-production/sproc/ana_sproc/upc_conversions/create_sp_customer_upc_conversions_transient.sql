/*
History of Changes:
06/29/22 - Changes related to composer work

Author :
	Shubham Saxena
*/

CREATE OR REPLACE PROCEDURE transient.ecomm_sproc_ana_e2open_upc_conversions
(
	SRC_PROJECT STRING,
    INTERMEDIATE_PROJECT STRING,
    DEST_DATASET STRING,
    INTERMEDIATE_DATASET STRING,
	SRC_TABLE STRING,
    INTERMEDIATE_TABLE STRING,
    DNA_FEED_NAME STRING,
	DEST_TABLE STRING,
	FEED_NAME STRING
)
OPTIONS(
description = """

How to call:
           CALL transient.ecomm_sproc_ana_e2open_upc_conversions
          (
    'ecomm-dlf-dev-01cd47',  --SRC_PROJECT
    'edw-prd-e567f9',        --INTERMEDIATE_PROJECT
    'processed',             --DEST_DATASET
    'enterprise',            --INTERMEDIATE_DATASET
    'meijer_distribution_availability_with_upc_fact',  --SRC_TABLE
    'meijer_weekly_agg_fact',                          --INTERMEDIATE_TABLE
    'MEIJER_DISTRIBUTION_AVAILABILITY_SUBCATG_AGG_FACT', --DNA_FEED_NAME
    'meijer_distribution_availability_upc_conversions'   --DEST_TABLE
    'MEIJER'                                             --FEED_NAME
          )
"""
)

BEGIN
DECLARE JOB_RUN_ID DEFAULT 999999;
DECLARE BQ_PROJECT_NAME DEFAULT SRC_PROJECT;
DECLARE BQ_EDW_PROJECT_NAME DEFAULT INTERMEDIATE_PROJECT;
DECLARE BQ_PROCESSED_DATASET_NAME DEFAULT DEST_DATASET;
DECLARE BQ_ENTERPRISE_DATASET_NAME DEFAULT INTERMEDIATE_DATASET;
DECLARE DNA_WITH_UPC_FACT_TABLE_NAME DEFAULT SRC_TABLE;
DECLARE BQ_GSS_PROC2_TABLE_NAME DEFAULT INTERMEDIATE_TABLE;
DECLARE BQ_TARGET_TABLENAME DEFAULT DEST_TABLE;

DECLARE INSTORE_DISTRIBUTION STRING;
SET DNA_FEED_NAME = UPPER(DNA_FEED_NAME);
SET FEED_NAME = UPPER(FEED_NAME);

EXECUTE IMMEDIATE
CONCAT("""
WITH customer as (select distinct customer_name from
`""",BQ_PROJECT_NAME,"""`.""",BQ_PROCESSED_DATASET_NAME,""".""",DNA_WITH_UPC_FACT_TABLE_NAME,""")
SELECT CASE WHEN UPPER(customer_name) IN ('AMAZON_COM','AMAZON_PRIME_NOW','AMAZON_FRESH') THEN '0'
ELSE 'is_instore_distribution'
END
FROM customer
""") INTO INSTORE_DISTRIBUTION;

EXECUTE IMMEDIATE CONCAT("""TRUNCATE TABLE `""",BQ_PROJECT_NAME,""".""",BQ_PROCESSED_DATASET_NAME,""".""",BQ_TARGET_TABLENAME,"""`""");

EXECUTE IMMEDIATE
CONCAT(
"""
INSERT INTO `""",BQ_PROJECT_NAME,"""`.""",BQ_PROCESSED_DATASET_NAME,""".""",BQ_TARGET_TABLENAME,"""
with conversions as (
    select
        o.ean_upc_cd old_ean_upc_cd,
        n.ean_upc_cd as new_ean_upc_cd,
        cast(conversion_date as DATE) as conversion_date
    from `""",BQ_PROJECT_NAME,""".""",BQ_PROCESSED_DATASET_NAME,""".dim_upc_conversions` conv
	left join `""",BQ_EDW_PROJECT_NAME,""".""",BQ_ENTERPRISE_DATASET_NAME,""".dim_product_active` o

-- There can be a chance of joining with more than one record as we are joining on the substring
-- No two records with same substring values were found in the conversion table as of now

		on substring(o.ean_upc_cd,1,10) = substring(conv.old_ean_upc_cd,1,10)
	left join `""",BQ_EDW_PROJECT_NAME,""".""",BQ_ENTERPRISE_DATASET_NAME,""".dim_product_active` n
		on substring(n.ean_upc_cd,1,10) = substring(conv.new_ean_upc_cd,1,10)
	where o.language_cd = 'EN'
	    and o.material_type_cd = 'CNPK'
        and o.source_type_cd = 'NA'
	    and n.language_cd = 'EN'
	    and n.material_type_cd = 'CNPK'
        and n.source_type_cd = 'NA'
),
--Getting metrics for product 5 weeks before conversion and 26 weeks after
--Get distribution metrics for old ean_upc_cd at ean/week/customer level
old_da as (
	select
		conv.new_ean_upc_cd,
		conv.old_ean_upc_cd,
		conv.conversion_date,
		case when old.customer_account = 'Target' then 'Target STORE PICK-UP' else old.customer_account end customer_account,
		old.customer_parent,
		old.customer_name,
		old.fiscal_week_begin_dt,
		cast(sum(""",INSTORE_DISTRIBUTION,""") as int64) as old_ean_instore_distribution_count,
		cast(sum(old.is_online_distribution) as int) as old_ean_online_distribution_count
	from conversions conv
	inner join `""",BQ_PROJECT_NAME,"""`.""",BQ_PROCESSED_DATASET_NAME,""".""",DNA_WITH_UPC_FACT_TABLE_NAME,""" old
		on conv.old_ean_upc_cd = old.old_ean_upc_cd
    inner join `""",BQ_PROJECT_NAME,"""`.""",BQ_PROCESSED_DATASET_NAME,""".ecom_data_release_control cntrl
	on old.fiscal_year_week_nbr=cntrl.fiscal_year_week_nbr
	and old.fiscal_year_month_nbr=cntrl.fiscal_year_month_nbr
	where
		old.fiscal_week_begin_dt >= date_sub(conv.conversion_date,interval 35 day)
		and old.fiscal_week_begin_dt <= date_add(conv.conversion_date,interval 182 day)
        and cntrl.staging_flg='Y'
		and cntrl.release_flg='Y'
		and cntrl.feed_name='""",DNA_FEED_NAME,"""'
	group by
		conv.new_ean_upc_cd,
		conv.old_ean_upc_cd,
		conv.conversion_date,
		old.customer_account,
		old.customer_parent,
		old.customer_name,
		old.fiscal_week_begin_dt
),
--Get distribution metrics for n ean_upc_cd at ean/week/customer level
new_da as (
	select
		conv.new_ean_upc_cd,
		conv.old_ean_upc_cd,
		conv.conversion_date,
		case when n.customer_account = 'Target' then 'Target STORE PICK-UP' else n.customer_account end customer_account,
		n.customer_parent,
		n.customer_name,
		n.fiscal_week_begin_dt,
		cast(sum(""",INSTORE_DISTRIBUTION,""") as int64) as new_ean_instore_distribution_count,
		cast(sum(n.is_online_distribution) as int) as new_ean_online_distribution_count
	from conversions conv
	inner join `""",BQ_PROJECT_NAME,"""`.""",BQ_PROCESSED_DATASET_NAME,""".""",DNA_WITH_UPC_FACT_TABLE_NAME,""" n
		on conv.new_ean_upc_cd = n.old_ean_upc_cd
    inner join `""",BQ_PROJECT_NAME,"""`.""",BQ_PROCESSED_DATASET_NAME,""".ecom_data_release_control cntrl
	on n.fiscal_year_week_nbr=cntrl.fiscal_year_week_nbr
	and n.fiscal_year_month_nbr=cntrl.fiscal_year_month_nbr
	where
		n.fiscal_week_begin_dt >= date_sub(conv.conversion_date,interval 35 day)
		and n.fiscal_week_begin_dt <= date_add(conv.conversion_date,interval 182 day)
        and cntrl.staging_flg='Y'
		and cntrl.release_flg='Y'
		and cntrl.feed_name='""",DNA_FEED_NAME,"""'
	group by
		conv.new_ean_upc_cd,
		conv.old_ean_upc_cd,
		conv.conversion_date,
		n.customer_account,
		n.customer_parent,
		n.customer_name,
		n.fiscal_week_begin_dt
),
--Get sales metrics for n ean_upc_cd at ean/week/customer level
new_sales as (
	select
		conv.new_ean_upc_cd,
		conv.old_ean_upc_cd,
		conv.conversion_date,
		ns.customer_account,
		ns.customer_parent,
		ns.customer_name,
		ns.fiscal_week_begin_dt,
		sum(ns.ty_sales_eqc_units) as new_ty_sales_eqc_units,
		sum(ns.ty_sales_value_usd) as new_ty_sales_value_usd
	from conversions conv
	inner join `""",BQ_PROJECT_NAME,"""`.""",BQ_PROCESSED_DATASET_NAME,""".""",BQ_GSS_PROC2_TABLE_NAME,""" ns
		on (case when ns.ean_upc_cd is null then ns.upc else substring(ns.ean_upc_cd, 1, length(ns.ean_upc_cd) -1) end) = substring(conv.new_ean_upc_cd, 1, length(conv.new_ean_upc_cd) - 1)
	inner join `""",BQ_PROJECT_NAME,"""`.""",BQ_PROCESSED_DATASET_NAME,""".ecom_data_release_control cntrl
	on ns.fiscal_year_week_nbr=cntrl.fiscal_year_week_nbr
	and ns.fiscal_year_month_nbr=cntrl.fiscal_year_month_nbr
	where
		ns.fiscal_week_begin_dt >= CAST(date_sub(conv.conversion_date,interval 35 day) AS TIMESTAMP)
		and ns.fiscal_week_begin_dt <= CAST(date_add(conv.conversion_date,interval 182 day) AS TIMESTAMP)
		and ns.country = 'US'
		and ns.manufacturer like '%General%Mills%'
		and ns.report_fg = 'Y'
		and ns.grain = 'WEEK'
		and cntrl.staging_flg='Y'
		and cntrl.release_flg='Y'
		and cntrl.feed_name='""",FEED_NAME,"""'
	group by
		conv.new_ean_upc_cd,
		conv.old_ean_upc_cd,
		conv.conversion_date,
		ns.customer_account,
		ns.customer_parent,
		ns.customer_name,
		ns.fiscal_week_begin_dt
),
--Get sales metrics for old ean_upc_cd at ean/week/customer level
old_sales as (
	select
		conv.old_ean_upc_cd,
		conv.new_ean_upc_cd,
		conv.conversion_date,
		os.customer_account,
		os.customer_parent,
		os.customer_name,
		os.fiscal_week_begin_dt,
		sum(os.ty_sales_eqc_units) as old_ty_sales_eqc_units,
		sum(os.ty_sales_value_usd) as old_ty_sales_value_usd
	from conversions conv
	inner join  `""",BQ_PROJECT_NAME,"""`.""",BQ_PROCESSED_DATASET_NAME,""".""",BQ_GSS_PROC2_TABLE_NAME,""" os
		on (case when os.ean_upc_cd is null then os.upc else substring(os.ean_upc_cd, 1, length(os.ean_upc_cd) -1) end) = substring(conv.old_ean_upc_cd, 1, length(conv.old_ean_upc_cd) - 1)
	inner join `""",BQ_PROJECT_NAME,"""`.""",BQ_PROCESSED_DATASET_NAME,""".ecom_data_release_control cntrl
	on os.fiscal_year_week_nbr=cntrl.fiscal_year_week_nbr
	and os.fiscal_year_month_nbr=cntrl.fiscal_year_month_nbr
	where
		os.fiscal_week_begin_dt >= CAST(date_sub(conv.conversion_date,interval 35 day) AS TIMESTAMP)
		and os.fiscal_week_begin_dt <= CAST(date_add(conv.conversion_date,interval 182 day) AS TIMESTAMP)
		and os.country = 'US'
		and os.manufacturer like '%General%Mills%'
		and os.report_fg = 'Y'
		and os.grain = 'WEEK'
		and cntrl.staging_flg='Y'
		and cntrl.release_flg='Y'
		and cntrl.feed_name='""",FEED_NAME,"""'
	group by
		conv.old_ean_upc_cd,
		conv.new_ean_upc_cd,
		conv.conversion_date,
		os.customer_account,
		os.customer_parent,
		os.customer_name,
		os.fiscal_week_begin_dt
),
--Full outer join metrics together
da_and_sales as (
	select
		coalesce(new_sales.new_ean_upc_cd, old_sales.new_ean_upc_cd, old_da.new_ean_upc_cd, new_da.new_ean_upc_cd) new_ean_upc_cd,
		coalesce(new_sales.old_ean_upc_cd, old_sales.old_ean_upc_cd, old_da.old_ean_upc_cd, new_da.old_ean_upc_cd) old_ean_upc_cd,
		coalesce(new_sales.conversion_date, old_sales.conversion_date, new_da.conversion_date, old_da.conversion_date) conversion_date,
		coalesce(new_sales.customer_account, old_sales.customer_account, new_da.customer_account, old_da.customer_account) customer_account,
		coalesce(new_sales.customer_parent, old_sales.customer_parent, new_da.customer_parent, old_da.customer_parent) customer_parent,
		coalesce(new_sales.customer_name, old_sales.customer_name, new_da.customer_name, old_da.customer_name) customer_name,
		coalesce(CAST(new_sales.fiscal_week_begin_dt AS DATE), CAST(old_sales.fiscal_week_begin_dt AS DATE), new_da.fiscal_week_begin_dt, old_da.fiscal_week_begin_dt) fiscal_week_begin_dt,
		new_sales.new_ty_sales_eqc_units,
		old_sales.old_ty_sales_eqc_units,
		new_sales.new_ty_sales_value_usd,
		old_sales.old_ty_sales_value_usd,
		new_da.new_ean_instore_distribution_count,
		new_da.new_ean_online_distribution_count,
		old_da.old_ean_instore_distribution_count,
		old_da.old_ean_online_distribution_count
	from new_sales
	full outer join old_sales
		on new_sales.new_ean_upc_cd = old_sales.new_ean_upc_cd
		and new_sales.customer_account = old_sales.customer_account
		and new_sales.customer_parent = old_sales.customer_parent
		and new_sales.customer_name = old_sales.customer_name
		and new_sales.fiscal_week_begin_dt = old_sales.fiscal_week_begin_dt
	full outer join old_da
		on old_sales.old_ean_upc_cd = old_da.old_ean_upc_cd
		and old_sales.fiscal_week_begin_dt = CAST(old_da.fiscal_week_begin_dt AS TIMESTAMP)
		and old_sales.customer_account = old_da.customer_account
		and old_sales.customer_parent = old_da.customer_parent
		and old_sales.customer_name = old_da.customer_name
	full outer join new_da
		on new_sales.new_ean_upc_cd = new_da.new_ean_upc_cd
		and new_sales.fiscal_week_begin_dt = CAST(new_da.fiscal_week_begin_dt AS TIMESTAMP)
		and new_sales.customer_account = new_da.customer_account
		and new_sales.customer_parent = new_da.customer_parent
		and new_sales.customer_name = new_da.customer_name
),
--Aggregate metrics by n and old ean_upc_cd/customer/week to consolidate results from full outer joins
final as (
	select
		new_ean_upc_cd,
		old_ean_upc_cd,
		conversion_date,
		customer_account,
		customer_parent,
		customer_name,
		fiscal_week_begin_dt,
		max(new_ty_sales_eqc_units) as new_ty_sales_eqc_units,
		max(old_ty_sales_eqc_units) as old_ty_sales_eqc_units,
		max(new_ty_sales_value_usd) as new_ty_sales_value_usd,
		max(old_ty_sales_value_usd) as old_ty_sales_value_usd,
		max(new_ean_instore_distribution_count) as new_ean_instore_distribution_count,
		max(new_ean_online_distribution_count) as new_ean_online_distribution_count,
		max(old_ean_instore_distribution_count) as old_ean_instore_distribution_count,
		max(old_ean_online_distribution_count) as old_ean_online_distribution_count
	from da_and_sales
	group by new_ean_upc_cd,
		old_ean_upc_cd,
		conversion_date,
		customer_account,
		customer_parent,
		customer_name,
		fiscal_week_begin_dt
),
--Get division and category fields from enterprise product table to join with old and n ean_upc_cd
hier as (
	select distinct ean_upc_cd,
		sls_hier_division_desc,
		sls_hier_category_desc,
		sls_hier_sub_category_desc,
		sls_hier_ppg_desc,
		material_short_desc
		from `""",BQ_EDW_PROJECT_NAME,""".""",BQ_ENTERPRISE_DATASET_NAME,""".dim_product_active` n
		where language_cd = 'EN'
	and material_type_cd = 'CNPK'
    and source_type_cd = 'NA'
)
--INSERT OVERWRITE TABLE ecom_audit.ecom_ppa_tracker
select
    dates.fiscal_week_begin_dt,
	ean.customer_account,
	ean.customer_parent,
	ean.customer_name,
	ean.old_ean_upc_cd,
    ean.new_ean_upc_cd,
	ean.conversion_date,
	o.sls_hier_division_desc as old_sls_hier_division_desc,
	o.sls_hier_category_desc as old_sls_hier_category_desc,
	o.sls_hier_sub_category_desc as old_sls_hier_sub_category_desc,
	o.sls_hier_ppg_desc as old_sls_hier_ppg_desc,
	o.material_short_desc as old_material_short_desc,
	n.sls_hier_division_desc as new_sls_hier_division_desc,
	n.sls_hier_category_desc as new_sls_hier_category_desc,
	n.sls_hier_sub_category_desc as new_sls_hier_sub_category_desc,
	n.sls_hier_ppg_desc as new_sls_hier_ppg_desc,
	n.material_short_desc as new_material_short_desc,
    ppa.old_ean_instore_distribution_count,
    ppa.old_ean_online_distribution_count,
    ppa.new_ean_instore_distribution_count,
    ppa.new_ean_online_distribution_count,
	concat(ean.new_ean_upc_cd,' ',n.material_short_desc) as new_ean_display_name,
	concat(ean.old_ean_upc_cd,' ',o.material_short_desc) as old_ean_display_name,
    ppa.new_ty_sales_value_usd,
	ppa.old_ty_sales_value_usd,
    ppa.old_ty_sales_eqc_units,
    ppa.new_ty_sales_eqc_units,
	avgs.old_ean_avg_ty_sales_eqc,
    avgs.old_ean_avg_instore_distribution,
    avgs.old_ean_avg_online_distribution,
	avgs.old_ean_avg_ty_sales_value_usd,
     '""",JOB_RUN_ID,"""' created_by
	, current_datetime created_datetime
	, '""",JOB_RUN_ID,"""' modified_by
	, current_datetime modified_datetime
from (
-- Cross joining distinct customer and old/n ean_upc_cd combinations with
-- all the weeks we're tracking for conversions. This serves as the base to join on
-- distribution and sales metrics for old and n ean_upc_cd's,
-- as well as trend lines of the avg sales and distribution for old ean_upc_cds up till the conversion date.

select distinct
    f.customer_account,
    f.customer_parent,
	f.customer_name,
    f.old_ean_upc_cd,
    f.new_ean_upc_cd,
    f.conversion_date
from final f
) ean
left join (
select
    f.customer_account,
	f.customer_name,
    f.new_ean_upc_cd,
    f.conversion_date,
    f.old_ean_upc_cd,
    avg(f.old_ty_sales_eqc_units) as old_ean_avg_ty_sales_eqc,
    avg(f.old_ean_instore_distribution_count) as old_ean_avg_instore_distribution,
    avg(f.old_ean_online_distribution_count) as old_ean_avg_online_distribution,
    avg(f.old_ty_sales_value_usd) as old_ean_avg_ty_sales_value_usd
from final f
where 
--1=1 and 
f.fiscal_week_begin_dt between date_sub(f.conversion_date, interval 35 day) and f.conversion_date
group by f.customer_account, 
	f.customer_name,
    f.new_ean_upc_cd,
    f.conversion_date, 
    f.old_ean_upc_cd
    ) avgs
on ean.customer_account = avgs.customer_account
	and ean.customer_name = avgs.customer_name
    and ean.new_ean_upc_cd = avgs.new_ean_upc_cd
    and ean.conversion_date = avgs.conversion_date
    and ean.old_ean_upc_cd = avgs.old_ean_upc_cd
cross join (
select distinct fiscal_week_begin_dt 
from final dates
where fiscal_week_begin_dt < current_date()
) dates
left join final ppa on ean.customer_account = ppa.customer_account 
	and ean.customer_name = ppa.customer_name
    and dates.fiscal_week_begin_dt = ppa.fiscal_week_begin_dt 
    and ean.new_ean_upc_cd = ppa.new_ean_upc_cd
    and ean.old_ean_upc_cd = ppa.old_ean_upc_cd
left join hier o
    on ean.old_ean_upc_cd = o.ean_upc_cd
left join hier n
    on ean.new_ean_upc_cd = n.ean_upc_cd
where dates.fiscal_week_begin_dt >= date_sub(ean.conversion_date, interval 35 day)""");


EXCEPTION WHEN ERROR THEN
        EXECUTE IMMEDIATE CONCAT(
            """INSERT INTO processed.ecomm_admin_sproc_error_details (
		        SELECT
			        '""",FEED_NAME,"""' AS FEED_NAME,
                    split(split(@@error.formatted_stack_trace,'transient.')[OFFSET (1)],'[')[OFFSET(0)],
			        @@error.statement_text,
			        @@error.message,
			        current_timestamp()
	        );
	    """);

	    SELECT
	        ERROR (
	            CONCAT(
	            		@@error.message ,' ' ,
	            		@@error.statement_text, ' ' ,
	            		@@error.formatted_stack_trace ,' '
	            	)
	        );

END;