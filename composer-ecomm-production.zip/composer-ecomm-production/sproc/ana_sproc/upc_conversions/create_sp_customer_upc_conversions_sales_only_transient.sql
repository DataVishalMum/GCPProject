/*
CALL transient.sp_customer_upc_conversions_sales_only
(
    -99,
    'ecomm-dlf-dev-01cd47',
    'shareddata-prd-cb5872',
    'edw-prd-e567f9',
    'processed',
    'sales_ecomm_global_sales_and_share',
    'enterprise',
    'instacart_distribution_availability_with_upc_fact',
    'instacart_weekly_agg_fact',
    'INSTACART_DISTRIBUTION_AVAILABILITY_SUBCATG_AGG_FACT',
    'INSTACART',
    'instacart_sales_share_upc_conversions'
)
*/
CREATE PROCEDURE IF NOT EXISTS transient.sp_customer_upc_conversions_sales_only
(
	job_run_id INT64,
	bq_project_name string,
    bq_shared_project_name string,
    bq_edw_project_name string,
    bq_processed_dataset_name string,
    bq_shared_dataset_name string,
    bq_enterprise_dataset_name string,
	dna_with_upc_fact_table_name string,
    gss_proc2_table_name string,
    dna_feed_name string,
    gss_feed_name string,
    target_table_name string
)

BEGIN
--Ensure that old and n ean_upc_cd format matches enterprise product table

--DECLARE instore_distribution string;
--
--EXECUTE IMMEDIATE
--CONCAT("""
--WITH customer as (select distinct customer_name from
--`""",bq_project_name,"""`.""",bq_processed_dataset_name,""".""",dna_with_upc_fact_table_name,""")
--SELECT CASE WHEN UPPER(customer_name) IN ('AMAZON_COM','AMAZON_PRIME_NOW','AMAZON_FRESH') THEN '0'
--ELSE 'is_instore_distribution'
--END
--FROM customer
--""") INTO instore_distribution;

EXECUTE IMMEDIATE CONCAT("""TRUNCATE TABLE `""",bq_project_name,""".""",bq_processed_dataset_name,""".""",target_table_name,"""`""");

EXECUTE IMMEDIATE
CONCAT(
"""
INSERT INTO `""",bq_project_name,"""`.""",bq_processed_dataset_name,""".""",target_table_name,"""
with conversions as (
    select
        o.ean_upc_cd old_ean_upc_cd,
        n.ean_upc_cd as new_ean_upc_cd,
        cast(conversion_date as date) as conversion_date
        from `""",bq_project_name,""".""",bq_processed_dataset_name,""".dim_upc_conversions` conv
              left join `""",bq_edw_project_name,""".""",bq_enterprise_dataset_name,""".dim_product_active` o

-- There can be a chance of joining with more than one record as we are joining on the substring
-- No two records with same substring values were found in the conversion table as of now

                             on substring(o.ean_upc_cd,1,10) = substring(conv.old_ean_upc_cd,1,10)
              left join `""",bq_edw_project_name,""".""",bq_enterprise_dataset_name,""".dim_product_active` n
                             on substring(n.ean_upc_cd,1,10) = substring(conv.new_ean_upc_cd,1,10)
              where o.language_cd = 'EN'
                  and o.material_type_cd = 'CNPK'
        and o.source_type_cd = 'NA'
                  and n.language_cd = 'EN'
                  and n.material_type_cd = 'CNPK'
        and n.source_type_cd = 'NA'
),
--Getting metrics for product 5 weeks before conversion and 26 weeks after
--Get sales metrics for n ean_upc_cd at ean/week/customer level
new_sales as (
              select
                             conv.new_ean_upc_cd,
                             conv.old_ean_upc_cd,
                             conv.conversion_date,
                             ns.customer_account,
                             ns.customer_parent,
                             ns.customer_name,
                             ns.fiscal_week_begin_dt,
                             sum(ns.ty_sales_eqc_units) as new_ty_sales_eqc_units,
                             sum(ns.ty_sales_value_usd) as new_ty_sales_value_usd
              from conversions conv
              inner join `""",bq_project_name,"""`.""",bq_processed_dataset_name,""".""",gss_proc2_table_name,""" ns
                             on (case when ns.ean_upc_cd is null then ns.upc else substring(ns.ean_upc_cd, 1, length(ns.ean_upc_cd) -1) end) = substring(conv.new_ean_upc_cd, 1, length(conv.new_ean_upc_cd) - 1)
              inner join `""",bq_project_name,"""`.""",bq_processed_dataset_name,""".ecom_data_release_control cntrl
              on ns.fiscal_year_week_nbr=cntrl.fiscal_year_week_nbr
              and ns.fiscal_year_month_nbr=cntrl.fiscal_year_month_nbr
              where
                             ns.fiscal_week_begin_dt >= CAST(date_sub(conv.conversion_date,interval 35 day) AS TIMESTAMP)
                             and ns.fiscal_week_begin_dt <= CAST(date_add(conv.conversion_date,interval 182 day) AS TIMESTAMP)
                             and ns.country = 'US'
                             and ns.manufacturer like '%General%Mills%'
                             and ns.report_fg = 'Y'
                             and ns.grain = 'WEEK'
                             and cntrl.staging_flg='Y'
                             and cntrl.release_flg='Y'
                             and cntrl.feed_name='""",gss_feed_name,"""'
              group by
                             conv.new_ean_upc_cd,
                             conv.old_ean_upc_cd,
                             conv.conversion_date,
                             ns.customer_account,
                             ns.customer_parent,
                             ns.customer_name,
                             ns.fiscal_week_begin_dt
),
--Get sales metrics for old ean_upc_cd at ean/week/customer level
old_sales as (
              select
                             conv.old_ean_upc_cd,
                             conv.new_ean_upc_cd,
                             conv.conversion_date,
                             os.customer_account,
                             os.customer_parent,
                             os.customer_name,
                             os.fiscal_week_begin_dt,
                             sum(os.ty_sales_eqc_units) as old_ty_sales_eqc_units,
                             sum(os.ty_sales_value_usd) as old_ty_sales_value_usd
              from conversions conv
              inner join  `""",bq_project_name,"""`.""",bq_processed_dataset_name,""".""",gss_proc2_table_name,""" os
                             on (case when os.ean_upc_cd is null then os.upc else substring(os.ean_upc_cd, 1, length(os.ean_upc_cd) -1) end) = substring(conv.old_ean_upc_cd, 1, length(conv.old_ean_upc_cd) - 1)
              inner join `""",bq_project_name,"""`.""",bq_processed_dataset_name,""".ecom_data_release_control cntrl
              on os.fiscal_year_week_nbr=cntrl.fiscal_year_week_nbr
              and os.fiscal_year_month_nbr=cntrl.fiscal_year_month_nbr
              where
                            os.fiscal_week_begin_dt >= CAST(date_sub(conv.conversion_date,interval 35 day) AS TIMESTAMP)
                             and os.fiscal_week_begin_dt <= CAST(date_add(conv.conversion_date,interval 182 day) AS TIMESTAMP)
                             and os.country = 'US'
                             and os.manufacturer like '%General%Mills%'
                             and os.report_fg = 'Y'
                             and os.grain = 'WEEK'
                             and cntrl.staging_flg='Y'
                             and cntrl.release_flg='Y'
                             and cntrl.feed_name='""",gss_feed_name,"""'
              group by
                             conv.old_ean_upc_cd,
                             conv.new_ean_upc_cd,
                             conv.conversion_date,
                             os.customer_account,
                             os.customer_parent,
                             os.customer_name,
                             os.fiscal_week_begin_dt
),
--Full outer join metrics together
da_and_sales as (
              select
                             coalesce(new_sales.new_ean_upc_cd, old_sales.new_ean_upc_cd) new_ean_upc_cd,
                             coalesce(new_sales.old_ean_upc_cd, old_sales.old_ean_upc_cd) old_ean_upc_cd,
                             coalesce(new_sales.conversion_date, old_sales.conversion_date) conversion_date,
                             coalesce(new_sales.customer_account, old_sales.customer_account) customer_account,
                             coalesce(new_sales.customer_parent, old_sales.customer_parent) customer_parent,
                             coalesce(new_sales.customer_name, old_sales.customer_name) customer_name,
                             coalesce(CAST(new_sales.fiscal_week_begin_dt AS DATE), CAST(old_sales.fiscal_week_begin_dt AS DATE)) fiscal_week_begin_dt,
                             new_sales.new_ty_sales_eqc_units,
                             old_sales.old_ty_sales_eqc_units,
                             new_sales.new_ty_sales_value_usd,
                             old_sales.old_ty_sales_value_usd,
                             0 as new_ean_instore_distribution_count,
                             0 new_ean_online_distribution_count,
                             0 as old_ean_instore_distribution_count,
                             0 as old_ean_online_distribution_count
              from new_sales
              full outer join old_sales
                             on new_sales.new_ean_upc_cd = old_sales.new_ean_upc_cd
                             and new_sales.customer_account = old_sales.customer_account
                             and new_sales.customer_parent = old_sales.customer_parent
                             and new_sales.customer_name = old_sales.customer_name
                             and new_sales.fiscal_week_begin_dt = old_sales.fiscal_week_begin_dt
),
--Aggregate metrics by n and old ean_upc_cd/customer/week to consolidate results from full outer joins
final as (
              select
                             new_ean_upc_cd,
                             old_ean_upc_cd,
                             conversion_date,
                             customer_account,
                             customer_parent,
                             customer_name,
                             fiscal_week_begin_dt,
                             max(new_ty_sales_eqc_units) as new_ty_sales_eqc_units,
                             max(old_ty_sales_eqc_units) as old_ty_sales_eqc_units,
                             max(new_ty_sales_value_usd) as new_ty_sales_value_usd,
                             max(old_ty_sales_value_usd) as old_ty_sales_value_usd,
                             max(new_ean_instore_distribution_count) as new_ean_instore_distribution_count,
                             max(new_ean_online_distribution_count) as new_ean_online_distribution_count,
                             max(old_ean_instore_distribution_count) as old_ean_instore_distribution_count,
                             max(old_ean_online_distribution_count) as old_ean_online_distribution_count
              from da_and_sales
              group by new_ean_upc_cd,
                             old_ean_upc_cd,
                             conversion_date,
                             customer_account,
                             customer_parent,
                             customer_name,
                             fiscal_week_begin_dt
),
--Get division and category fields from enterprise product table to join with old and n ean_upc_cd
hier as (
              select distinct ean_upc_cd,
                             sls_hier_division_desc,
                             sls_hier_category_desc,
                             sls_hier_sub_category_desc,
                             sls_hier_ppg_desc,
                             material_short_desc
                             from `""",bq_edw_project_name,""".""",bq_enterprise_dataset_name,""".dim_product_active` n
                             where language_cd = 'EN'
              and material_type_cd = 'CNPK'
    and source_type_cd = 'NA'
)
--INSERT OVERWRITE TABLE ecom_audit.ecom_ppa_tracker
select
    dates.fiscal_week_begin_dt,
              ean.customer_account,
              ean.customer_parent,
              ean.customer_name,
              ean.old_ean_upc_cd,
    ean.new_ean_upc_cd,
              ean.conversion_date,
              o.sls_hier_division_desc as old_sls_hier_division_desc,
              o.sls_hier_category_desc as old_sls_hier_category_desc,
              o.sls_hier_sub_category_desc as old_sls_hier_sub_category_desc,
              o.sls_hier_ppg_desc as old_sls_hier_ppg_desc,
              o.material_short_desc as old_material_short_desc,
              n.sls_hier_division_desc as new_sls_hier_division_desc,
              n.sls_hier_category_desc as new_sls_hier_category_desc,
              n.sls_hier_sub_category_desc as new_sls_hier_sub_category_desc,
              n.sls_hier_ppg_desc as new_sls_hier_ppg_desc,
              n.material_short_desc as new_material_short_desc,
    ppa.old_ean_instore_distribution_count,
    ppa.old_ean_online_distribution_count,
    ppa.new_ean_instore_distribution_count,
    ppa.new_ean_online_distribution_count,
              concat(ean.new_ean_upc_cd,' ',n.material_short_desc) as new_ean_display_name,
              concat(ean.old_ean_upc_cd,' ',o.material_short_desc) as old_ean_display_name,
    ppa.new_ty_sales_value_usd,
              ppa.old_ty_sales_value_usd,
    ppa.old_ty_sales_eqc_units,
    ppa.new_ty_sales_eqc_units,
              avgs.old_ean_avg_ty_sales_eqc,
    avgs.old_ean_avg_instore_distribution,
    avgs.old_ean_avg_online_distribution,
              avgs.old_ean_avg_ty_sales_value_usd,
     '""",job_run_id,"""' created_by
              , current_datetime created_datetime
              , '""",job_run_id,"""' modified_by
              , current_datetime modified_datetime
from (
-- Cross joining distinct customer and old/n ean_upc_cd combinations with
-- all the weeks we're tracking for conversions. This serves as the base to join on
-- distribution and sales metrics for old and n ean_upc_cd's,
-- as well as trend lines of the avg sales and distribution for old ean_upc_cds up till the conversion date.

select distinct
    f.customer_account,
    f.customer_parent,
              f.customer_name,
    f.old_ean_upc_cd,
    f.new_ean_upc_cd,
    f.conversion_date
from final f
) ean
left join (
select
    f.customer_account,
              f.customer_name,
    f.new_ean_upc_cd,
    f.conversion_date,
    f.old_ean_upc_cd,
    avg(f.old_ty_sales_eqc_units) as old_ean_avg_ty_sales_eqc,
    avg(f.old_ean_instore_distribution_count) as old_ean_avg_instore_distribution,
    avg(f.old_ean_online_distribution_count) as old_ean_avg_online_distribution,
    avg(f.old_ty_sales_value_usd) as old_ean_avg_ty_sales_value_usd
from final f
where
--1=1 and
f.fiscal_week_begin_dt between date_sub(f.conversion_date, interval 35 day) and f.conversion_date
group by f.customer_account,
              f.customer_name,
    f.new_ean_upc_cd,
    f.conversion_date,
    f.old_ean_upc_cd
    ) avgs
on ean.customer_account = avgs.customer_account
              and ean.customer_name = avgs.customer_name
    and ean.new_ean_upc_cd = avgs.new_ean_upc_cd
    and ean.conversion_date = avgs.conversion_date
    and ean.old_ean_upc_cd = avgs.old_ean_upc_cd
cross join (
select distinct fiscal_week_begin_dt
from final dates
where fiscal_week_begin_dt < current_date()
) dates
left join final ppa on ean.customer_account = ppa.customer_account
              and ean.customer_name = ppa.customer_name
    and dates.fiscal_week_begin_dt = ppa.fiscal_week_begin_dt
    and ean.new_ean_upc_cd = ppa.new_ean_upc_cd
    and ean.old_ean_upc_cd = ppa.old_ean_upc_cd
left join hier o
    on ean.old_ean_upc_cd = o.ean_upc_cd
left join hier n
    on ean.new_ean_upc_cd = n.ean_upc_cd
where dates.fiscal_week_begin_dt >= date_sub(ean.conversion_date, interval 35 day)""");
EXCEPTION WHEN ERROR THEN
    SELECT
              ERROR (
                             CONCAT(
                                           @@error.message ,' ' ,
                                           @@error.statement_text, ' ' ,
                                           @@error.formatted_stack_trace ,' '
                                           )
                             )
              ;
END
