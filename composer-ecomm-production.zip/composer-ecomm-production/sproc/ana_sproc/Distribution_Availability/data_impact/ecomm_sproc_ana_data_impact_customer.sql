CREATE OR REPLACE PROCEDURE processed.ecomm_sproc_ana_data_impact_euau_customer()
OPTIONS(strict_mode=false)
BEGIN
TRUNCATE TABLE 
  raw.ecomm_ana_data_impact_euau_customer;
INSERT INTO
  raw.ecomm_ana_data_impact_euau_customer
SELECT 
  source,
  source_field,
  customer_name_source,
  customer_name,
  customer_parent,
  customer_country_cd,
  customer_note,
FROM raw.ecomm_ana_data_impact_euau_customer_extrnl;
END;