/*
Purpose of the stored proc:
	/*
"Smoothing" = the process of filling in gaps in online distribution
    - We smooth online data when calculating distribution, but we don't use smoothing for availability calculations.
    - We smooth at the ean/store/week level
    - When there's a data gap, this is when it'll get smoothed:
        [1] distribution exists for the ean/store 1 week before and 1 week after the missing data
        [2] distribution exists for the ean/store 2 weeks before and 1 week after the missing data
        [3] distribution exists for the ean/store 1 week before and 2 weeks after the missing data

History of Changes:
	05/23/22 – first version (Publix Instacart-specific)

Author :
	Shubham Saxena
*/

CREATE PROCEDURE IF NOT EXISTS transient.ecomm_sproc_ana_publix_instacart_distribution_availability_smoothed
(
	SRC_PROJECT STRING,
    SRC_DATASET STRING,
    DEST_DATASET STRING,
	INTERMEDIATE_PROJECT STRING,
	INTERMEDIATE_DATASET STRING,
	SRC_TABLE STRING,
	DEST_TABLE STRING,
	FEED_NAME STRING
)
OPTIONS(
description = """

How to Call:
		call transient.ecomm_sproc_ana_publix_instacart_distribution_availability_smoothed
		(
		'ecomm-dlf-dev-01cd47',                                         --SRC_PROJECT
		'transient' ,                                                   --SRC_DATASET
        'processed',                                                    --DEST_DATASET
		'edw-dev-c119a7',                                               --INTERMEDIATE_PROJECT
        'enterprise',                                                   --INTERMEDIATE_DATASET
		'publix_instacart_distribution_availability_joined_fact',       --SRC_TABLE
		'publix_instacart_distribution_availability_smoothed_fact',     --DEST_TABLE
		'publix'                                                        --FEED_NAME
		) 
"""
)

BEGIN
DECLARE JOB_RUN_ID DEFAULT 999999;
DECLARE BQ_PROJECT_NAME DEFAULT SRC_PROJECT;
DECLARE BQ_TRANSIENT_DATASET_NAME DEFAULT SRC_DATASET;
DECLARE BQ_PROCESSED_DATASET_NAME DEFAULT DEST_DATASET;
DECLARE BQ_EDW_PROJECT_NAME DEFAULT INTERMEDIATE_PROJECT;
DECLARE BQ_ENTERPRISE_DATASET_NAME DEFAULT INTERMEDIATE_DATASET;
DECLARE BQ_SOURCE_TABLE_NAME DEFAULT SRC_TABLE;
DECLARE BQ_TARGET_TABLE_NAME DEFAULT DEST_TABLE;
-- declare variables
DECLARE
     EXTRACT_START_DATE
	,EXTRACT_END_DATE Timestamp;

SET FEED_NAME = UPPER(FEED_NAME);

/* Get Extract start datetime for incoming table from data_extract_config table */
EXECUTE IMMEDIATE
  CONCAT("""select extract_start_datetime from `""",BQ_PROJECT_NAME,"""`.""",BQ_TRANSIENT_DATASET_NAME,""".""","""data_extract_config
where table_name = '""",BQ_SOURCE_TABLE_NAME,"""' and status = 'running'
and active_flag = 'Y'""") INTO EXTRACT_START_DATE;

/* Get Extract end datetime for incoming table from data_extract_config table */
EXECUTE IMMEDIATE
  CONCAT("""select extract_end_datetime from `""",BQ_PROJECT_NAME,"""`.""",BQ_TRANSIENT_DATASET_NAME,""".""", """data_extract_config
  where table_name = '""",BQ_SOURCE_TABLE_NAME,"""' and status = 'running'  and active_flag = 'Y'""") INTO EXTRACT_END_DATE;

EXECUTE IMMEDIATE
CONCAT(
"""merge  `""" ,BQ_PROJECT_NAME,"""`.""",BQ_PROCESSED_DATASET_NAME,""".""",BQ_TARGET_TABLE_NAME,""" tgt using
(
with weeks_to_smooth as (
    select fch.fiscal_week_begin_dt
	from `""" ,BQ_PROJECT_NAME,"""`.""",BQ_PROCESSED_DATASET_NAME,""".""",BQ_SOURCE_TABLE_NAME,""" combined,
    `""" ,BQ_EDW_PROJECT_NAME,"""`.""",BQ_ENTERPRISE_DATASET_NAME,""".dim_date fch
	where EXTRACT(DATE FROM combined.modified_datetime) > CAST(SUBSTRING('""",EXTRACT_START_DATE,"""',0,10) AS DATE)
	and EXTRACT(DATE FROM combined.modified_datetime) <= CAST(SUBSTRING('""",EXTRACT_END_DATE,"""',0,10) AS DATE)
    and fch.language_cd = 'EN'
    and fch.fiscal_year_variant_cd = '07'
    and fch.fiscal_week_begin_dt between date_sub(combined.fiscal_week_begin_dt, interval 21 day) and date_add(combined.fiscal_week_begin_dt, interval 21 day)
    and combined.is_instore = 1
    group by fch.fiscal_week_begin_dt
),
combined_source as (
    select FARM_FINGERPRINT(CONCAT(combined2.ean_upc_cd,combined2.unique_store_composite_key)) as upc_store_fingerprint
           , combined2.*
      from `""" ,BQ_PROJECT_NAME,"""`.""",BQ_PROCESSED_DATASET_NAME,""".""",BQ_SOURCE_TABLE_NAME,""" combined2
      join weeks_to_smooth wts
        on combined2.fiscal_week_begin_dt = wts.fiscal_week_begin_dt
     where combined2.is_instore = 1
),
-- List of all eans that can exist at a given store (both online and in-store sources)
store_eans as (
    select unique_store_composite_key, ean_upc_cd
      from combined_source
  group by unique_store_composite_key, ean_upc_cd
),
-- List of store/weeks is used for creating a list of all store/week/ean possibilities
joined_store_weeks as (
    select unique_store_composite_key, fiscal_week_begin_dt
      from combined_source
  group by unique_store_composite_key, fiscal_week_begin_dt
),
-- We need all possible store/week/ean combinations to smooth missing online distribution entries
store_week_ean_xjoin as (
    select jsw.fiscal_week_begin_dt
          ,se.unique_store_composite_key
          ,se.ean_upc_cd
          ,FARM_FINGERPRINT(CONCAT(se.ean_upc_cd, se.unique_store_composite_key)) as upc_store_fingerprint
      from store_eans se
      join joined_store_weeks jsw
        on jsw.unique_store_composite_key = se.unique_store_composite_key
),
-- Perform smoothing; figure out which store/week/eans should have online distribution
online_source_smoothed as (
    select xj.*
          ,cs.is_online as is_online_not_smoothed
          ,case when cs.is_online is not null then cs.is_online
                when past_1.is_online = 1 and future_1.is_online = 1 then 1
                when past_1.is_online = 1 and future_2.is_online = 1 then 1
                when past_2.is_online = 1 and future_1.is_online = 1 then 1
                else cs.is_online
           end is_online_smoothed
      from store_week_ean_xjoin xj
      left join combined_source cs
        on cs.unique_store_composite_key = xj.unique_store_composite_key
       and cs.ean_upc_cd = xj.ean_upc_cd
       and cs.fiscal_week_begin_dt = xj.fiscal_week_begin_dt
      left join combined_source past_1
        on past_1.upc_store_fingerprint = xj.upc_store_fingerprint
       and past_1.fiscal_week_begin_dt = date_sub(xj.fiscal_week_begin_dt, interval 7 day)
      left join combined_source past_2
        on past_2.upc_store_fingerprint = xj.upc_store_fingerprint
       and past_2.fiscal_week_begin_dt = date_sub(xj.fiscal_week_begin_dt, interval 14 day)
      left join combined_source future_1
        on future_1.upc_store_fingerprint = xj.upc_store_fingerprint
       and future_1.fiscal_week_begin_dt = date_add(xj.fiscal_week_begin_dt, interval 7 day)
      left join combined_source future_2
        on future_2.upc_store_fingerprint = xj.upc_store_fingerprint
       and future_2.fiscal_week_begin_dt = date_add(xj.fiscal_week_begin_dt, interval 14 day)
)
-- This is effectively an 'outer join' between in-store and online sources, (except for the common week filtering)
-- so we use nvl() on most columns since we don't know which source(s) will contain the data.
-- Which source comes first in the nvl() is trivial, since they should be equal if they both exist.

select
      FARM_FINGERPRINT(CONCAT(cs.ean_upc_cd,cs.unique_store_composite_key,CAST(cs.fiscal_week_begin_dt AS STRING))) smoothedkey_fingerprint
      ,cs.store_number
      ,cs.banner
      ,cs.store_street_address
      ,cs.store_city
      ,cs.store_state
      ,cs.store_zipcode
      ,cs.division
      ,cs.upc_cd
      ,cs.unique_store_composite_key
      ,cs.cm_tdp_reach
      ,cs.sls_hier_division_desc
      ,cs.sls_hier_category_desc
      ,cs.sls_hier_sub_category_desc
      ,cs.sls_hier_ppg_desc
      ,cs.base_product_cd
      ,cs.base_product_desc
      ,cs.material_cd
      ,cs.material_nbr
      ,cs.ean_upc_cd
      ,cs.material_short_desc
      ,cs.old_sls_hier_division_desc
      ,cs.old_sls_hier_category_desc
      ,cs.old_sls_hier_sub_category_desc
      ,cs.old_sls_hier_ppg_desc
      ,cs.old_base_product_cd
      ,cs.old_base_product_desc
      ,cs.old_material_cd
      ,cs.old_material_nbr
      ,cs.old_ean_upc_cd
      ,cs.old_material_short_desc
      ,oss.is_online_smoothed is_online
      ,case when ifnull(oss.is_online_not_smoothed,0)=0 and oss.is_online_smoothed=1 then 1 else 0 end is_smoothed
      ,cs.stock_flg
      ,cs.is_available
	  ,cs.is_instore
	  ,cs.authorization_flg
      ,cs.fiscal_year_week_nbr
      ,cs.fiscal_month_in_year_nbr
      ,cs.fiscal_year_nbr
      ,cs.fiscal_week_in_year_nbr
      ,cs.fiscal_week_begin_dt
      ,cs.fiscal_year_month_nbr
      ,cs.customer_name
      ,'""",JOB_RUN_ID,"""' created_by
      , current_datetime created_datetime
	  , '""",JOB_RUN_ID,"""' modified_by
	  , current_datetime modified_datetime
  from combined_source cs
  left join online_source_smoothed oss
   on oss.upc_store_fingerprint = cs.upc_store_fingerprint
  and oss.fiscal_week_begin_dt = cs.fiscal_week_begin_dt
) smoothed
on tgt.smoothedkey_fingerprint = smoothed.smoothedkey_fingerprint

-- Update in 'When matched' logic taken from Kaia's branch

WHEN MATCHED THEN
  UPDATE SET is_instore = smoothed.is_instore,
  is_online = smoothed.is_online,
  is_smoothed = smoothed.is_smoothed
WHEN NOT MATCHED THEN
INSERT
  (
     smoothedkey_fingerprint
    ,store_number
    ,banner
    ,store_street_address
    ,store_city
    ,store_state
    ,store_zipcode
    ,division
    ,upc_cd
    ,unique_store_composite_key
    ,cm_tdp_reach
    ,sls_hier_division_desc
    ,sls_hier_category_desc
    ,sls_hier_sub_category_desc
    ,sls_hier_ppg_desc
    ,base_product_cd
    ,base_product_desc
    ,material_cd
    ,material_nbr
    ,ean_upc_cd
    ,material_short_desc
    ,old_sls_hier_division_desc
    ,old_sls_hier_category_desc
    ,old_sls_hier_sub_category_desc
    ,old_sls_hier_ppg_desc
    ,old_base_product_cd
    ,old_base_product_desc
    ,old_material_cd
    ,old_material_nbr
    ,old_ean_upc_cd
    ,old_material_short_desc
    ,is_online
    ,is_smoothed
    ,stock_flg
    ,is_available
	,is_instore
	,authorization_flg
    ,fiscal_year_week_nbr
    ,fiscal_month_in_year_nbr
    ,fiscal_year_nbr
    ,fiscal_week_in_year_nbr
    ,fiscal_week_begin_dt
    ,fiscal_year_month_nbr
    ,customer_name
    ,created_by
    ,created_datetime
	,modified_by
	,modified_datetime
  )
VALUES
  (
     smoothed.smoothedkey_fingerprint
    ,smoothed.store_number
    ,smoothed.banner
    ,smoothed.store_street_address
    ,smoothed.store_city
    ,smoothed.store_state
    ,smoothed.store_zipcode
    ,smoothed.division
    ,smoothed.upc_cd
    ,smoothed.unique_store_composite_key
    ,smoothed.cm_tdp_reach
    ,smoothed.sls_hier_division_desc
    ,smoothed.sls_hier_category_desc
    ,smoothed.sls_hier_sub_category_desc
    ,smoothed.sls_hier_ppg_desc
    ,smoothed.base_product_cd
    ,smoothed.base_product_desc
    ,smoothed.material_cd
    ,smoothed.material_nbr
    ,smoothed.ean_upc_cd
    ,smoothed.material_short_desc
    ,smoothed.old_sls_hier_division_desc
    ,smoothed.old_sls_hier_category_desc
    ,smoothed.old_sls_hier_sub_category_desc
    ,smoothed.old_sls_hier_ppg_desc
    ,smoothed.old_base_product_cd
    ,smoothed.old_base_product_desc
    ,smoothed.old_material_cd
    ,smoothed.old_material_nbr
    ,smoothed.old_ean_upc_cd
    ,smoothed.old_material_short_desc
    ,smoothed.is_online
    ,smoothed.is_smoothed
    ,smoothed.stock_flg
    ,smoothed.is_available
	,smoothed.is_instore
	,smoothed.authorization_flg
    ,smoothed.fiscal_year_week_nbr
    ,smoothed.fiscal_month_in_year_nbr
    ,smoothed.fiscal_year_nbr
    ,smoothed.fiscal_week_in_year_nbr
    ,smoothed.fiscal_week_begin_dt
    ,smoothed.fiscal_year_month_nbr
    ,smoothed.customer_name
    ,smoothed.created_by
    ,smoothed.created_datetime
	,smoothed.modified_by
	,smoothed.modified_datetime
)
""");

EXCEPTION WHEN ERROR THEN
        EXECUTE IMMEDIATE CONCAT(
            """INSERT INTO processed.ecomm_admin_sproc_error_details (
		        SELECT
			        '""",FEED_NAME,"""' AS FEED_NAME,
                    split(split(@@error.formatted_stack_trace,'transient.')[OFFSET (1)],'[')[OFFSET(0)],
			        @@error.statement_text,
			        @@error.message,
			        current_timestamp()
	        );
	    """);

	    SELECT
	        ERROR (
	            CONCAT(
	            		@@error.message ,' ' ,
	            		@@error.statement_text, ' ' ,
	            		@@error.formatted_stack_trace ,' '
	            	)
	        );

END;