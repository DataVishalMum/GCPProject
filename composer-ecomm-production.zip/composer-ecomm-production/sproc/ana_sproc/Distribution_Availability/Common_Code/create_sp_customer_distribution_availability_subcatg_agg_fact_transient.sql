/*
Purpose of the stored proc:
	/*
    Aggregate distribution and availability metric columns needed for aggregation, add customer zone, calculate year over year metrics,
    fill in gaps so each customer/store/week represents all possible sub-categories, and add rolling time flags

History of Changes:
	06/07/21 – first version
    07/12/21 - Added farm_fingerprint to improve performance
    07/23/21 - Removed self join for ly calculation and used LEAD function
    03/15/22 - Remove unneeded fiscal calendar attributes (Nelson W.)
	06/29/22 - Changes related to composer work
Author :
	Shubham Saxena
*/

CREATE OR REPLACE PROCEDURE transient.ecomm_sproc_ana_common_distribution_availability_subcatg_agg_fact
(
	SRC_PROJECT STRING,
    INTERMEDIATE_PROJECT STRING,
	INTERMEDIATE_DATASET STRING,
    SRC_DATASET STRING,
    DEST_DATASET STRING,
    SRC_TABLE STRING,
	DEST_TABLE STRING,
	FEED_NAME STRING
)
OPTIONS(
description = """
How to Call:
call transient.ecomm_sproc_ana_common_distribution_availability_subcatg_agg_fact
(
'ecomm-dlf-dev-01cd47',
'edw-prd-e567f9',
'enterprise',
'transient',
'processed',
'stop_and_shop_distribution_availability_with_upc_fact',
'stop_and_shop_distribution_availability_subcatg_agg_fact',
'stop_and_stop'
)
"""
)

BEGIN
DECLARE JOB_RUN_ID DEFAULT 999999;
DECLARE BQ_PROJECT_NAME DEFAULT SRC_PROJECT;
DECLARE BQ_EDW_PROJECT_NAME DEFAULT INTERMEDIATE_PROJECT;
DECLARE BQ_ENTERPRISE_DATASET_NAME DEFAULT INTERMEDIATE_DATASET;
DECLARE BQ_TRANSIENT_DATASET_NAME DEFAULT SRC_DATASET;
DECLARE BQ_PROCESSED_DATASET_NAME DEFAULT DEST_DATASET;
DECLARE BQ_SOURCE_TABLE_NAME DEFAULT SRC_TABLE;
DECLARE BQ_TARGET_TABLE_NAME DEFAULT DEST_TABLE;


-- declare variables
DECLARE
	 EXTRACT_START_DATE
	,EXTRACT_END_DATE TIMESTAMP;

DECLARE SLS_HIER_DIVISION_DESC_FILTER STRING;

SET FEED_NAME = UPPER(FEED_NAME);

--Update divsions here if it needs any change.
set SLS_HIER_DIVISION_DESC_FILTER = "'MORNING FOODS','MEALS-BAKING','SNACKS'";


/* Get Extract start datetime for incoming table from data_extract_config table */
EXECUTE IMMEDIATE
  CONCAT("""select extract_start_datetime from `""",BQ_PROJECT_NAME,"""`.""",BQ_TRANSIENT_DATASET_NAME,""".""","""data_extract_config
where table_name = '""",BQ_SOURCE_TABLE_NAME,"""' and status = 'running'
and active_flag = 'Y'""") INTO EXTRACT_START_DATE;

/* Get Extract end datetime for incoming table from data_extract_config table */
EXECUTE IMMEDIATE
  CONCAT("""select extract_end_datetime from `""",BQ_PROJECT_NAME,"""`.""",BQ_TRANSIENT_DATASET_NAME,""".""", """data_extract_config
  where table_name = '""",BQ_SOURCE_TABLE_NAME,"""' and status = 'running'  and active_flag = 'Y'""") INTO EXTRACT_END_DATE;

EXECUTE IMMEDIATE
CONCAT(
"""merge `""" ,BQ_PROJECT_NAME,"""`.""",BQ_PROCESSED_DATASET_NAME,""".""",BQ_TARGET_TABLE_NAME,""" tgt using
(
with customer_max_week as (
    select customer_name
          ,max(fiscal_week_begin_dt) fiscal_week_begin_dt
          ,max(fiscal_year_week_nbr) fiscal_year_week_nbr
          ,max(fiscal_year_nbr) fiscal_year_nbr
      from `""" ,BQ_PROJECT_NAME,"""`.""",BQ_PROCESSED_DATASET_NAME,""".""",BQ_SOURCE_TABLE_NAME,"""
       where EXTRACT(DATE FROM modified_datetime) > CAST(SUBSTRING('""",EXTRACT_START_DATE,"""',0,10) AS DATE)
      and EXTRACT(DATE FROM modified_datetime)  <= CAST(SUBSTRING('""",EXTRACT_END_DATE,"""',0,10) AS DATE)
     group by customer_name
),
-- Get a list of weeks over the past 2 years to fill in gaps for year-over-year calculations.
-- We may be missing weeks of data this year, but we still want to report on the corresponding last-year distribution.
all_relevant_weeks as (
    select distinct cal.fiscal_year_week_nbr
                   ,cal.fiscal_month_in_year_nbr
                   ,cal.fiscal_year_nbr
                   ,cal.fiscal_week_in_year_nbr
                   ,cal.fiscal_week_begin_dt
                   ,cal.fiscal_year_month_nbr
                   ,cal.fiscal_month_in_year_short_desc
      from `""" ,BQ_EDW_PROJECT_NAME,"""`.""",BQ_ENTERPRISE_DATASET_NAME,""".dim_date cal
          ,customer_max_week cmw
     where cal.language_cd = 'EN'
       and cal.fiscal_year_variant_cd = '07'
       and cal.fiscal_year_week_nbr between cmw.fiscal_year_week_nbr - 200 and cmw.fiscal_year_week_nbr
       group by cal.fiscal_year_week_nbr
                ,cal.fiscal_month_in_year_nbr
                ,cal.fiscal_year_nbr
                ,cal.fiscal_week_in_year_nbr
                ,cal.fiscal_week_begin_dt
                ,cal.fiscal_year_month_nbr
                ,cal.fiscal_month_in_year_short_desc
),
-- Cross-join weeks with stores and categories to get a list of all possible store/weeks/categories for distribution.
-- This is done to enable a clean "outer join" type logic between this-year and last-year data.
possible_store_week_categories as (
    select arw.*, st.*
      from all_relevant_weeks arw
      cross join (select distinct customer_name,
                unique_store_composite_key,
                sls_hier_sub_category_desc
            from `""" ,BQ_PROJECT_NAME,"""`.""",BQ_PROCESSED_DATASET_NAME,""".""",BQ_SOURCE_TABLE_NAME,"""
            ) st
),

-- Remove UPC level granularity; aggregate to customer/week/sub-category level
-- 'fiscal_week_in_year_nbr' column is used to help fetch ly data in the next query.

agg_count as (select
unique_store_composite_key
,fiscal_year_week_nbr
,sls_hier_sub_category_desc
,fiscal_week_in_year_nbr
,customer_name
,ifnull(sum(is_instore_distribution), 0) instore_distribution_count
          ,ifnull(sum(is_instore_distribution_authorized), 0) instore_distribution_authorized_count
          ,ifnull(sum(is_instore_distribution_not_authorized), 0) instore_distribution_not_authorized_count
          ,ifnull(sum(is_online_distribution), 0) online_distribution_count
          ,ifnull(sum(is_online_distribution_authorized), 0) online_distribution_authorized_count
          ,ifnull(sum(is_online_distribution_not_authorized), 0) online_distribution_not_authorized_count
          ,ifnull(sum(is_available),0) available_count
		  from `""" ,BQ_PROJECT_NAME,"""`.""",BQ_PROCESSED_DATASET_NAME,""".""",BQ_SOURCE_TABLE_NAME,"""
group by
unique_store_composite_key
,fiscal_year_week_nbr
,sls_hier_sub_category_desc
,fiscal_week_in_year_nbr
,customer_name),

-- Fetching all the columns from the source data

src_data as (select * except(rnk) from (
    select
    src.unique_store_composite_key
    ,src.fiscal_year_week_nbr
    ,src.sls_hier_sub_category_desc
    ,src.customer_name,
    agg.fiscal_week_in_year_nbr,
    src.country,
    src.customer_desc,
    src.customer_parent,
    src.customer_account,
    src.segment,
    src.retailer_type,
    src.store_display_name,
    src.banner,
    src.store_number,
    src.store_street_address,
    src.store_city,
    src.store_state,
    src.store_zipcode,
    src.sls_hier_division_desc,
    src.sls_hier_category_desc,
    agg.instore_distribution_count,
    agg.instore_distribution_authorized_count,
    agg.instore_distribution_not_authorized_count,
    agg.online_distribution_count,
    agg.online_distribution_authorized_count,
    agg.online_distribution_not_authorized_count,
    agg.available_count,

    -- While joining the aggregated data back to source table, we may end up having duplicates.
    -- deduping on the sub-category level

    row_number() over (partition by  src.unique_store_composite_key
          ,src.fiscal_year_week_nbr
          ,src.sls_hier_sub_category_desc) rnk
    from `""" ,BQ_PROJECT_NAME,"""`.""",BQ_PROCESSED_DATASET_NAME,""".""",BQ_SOURCE_TABLE_NAME,""" src
    join agg_count agg
    on src.unique_store_composite_key = agg.unique_store_composite_key
       and src.fiscal_year_week_nbr = agg.fiscal_year_week_nbr
       and src.sls_hier_sub_category_desc = agg.sls_hier_sub_category_desc)
where rnk =1
),

-- Fetching the 'last-year' (ly) data.
-- Using lead function instead of self join because self join gives intermittent results
-- This is a known issue with GCP BQ.

ly_calc as (
SELECT
  unique_store_composite_key,
  fiscal_year_week_nbr,
  sls_hier_sub_category_desc,
  customer_name,
  country,
  customer_desc,
  customer_parent,
  customer_account,
  segment,
  retailer_type,
  store_display_name,
  banner,
  store_number,
  store_street_address,
  store_city,
  store_state,
  store_zipcode,
  sls_hier_division_desc,
  sls_hier_category_desc,
  instore_distribution_count,
  instore_distribution_authorized_count,
  instore_distribution_not_authorized_count,
  online_distribution_count,
  online_distribution_authorized_count,
  online_distribution_not_authorized_count,
  available_count,
  LEAD (agg.country,1,NULL) OVER (PARTITION BY agg.unique_store_composite_key, agg.fiscal_week_in_year_nbr, agg.sls_hier_sub_category_desc ORDER BY agg.fiscal_year_week_nbr DESC) ly_country,
  LEAD (agg.customer_desc,1,NULL) OVER (PARTITION BY agg.unique_store_composite_key, agg.fiscal_week_in_year_nbr, agg.sls_hier_sub_category_desc ORDER BY agg.fiscal_year_week_nbr DESC) ly_customer_desc,
  LEAD (agg.customer_parent,1,NULL) OVER (PARTITION BY agg.unique_store_composite_key, agg.fiscal_week_in_year_nbr, agg.sls_hier_sub_category_desc ORDER BY agg.fiscal_year_week_nbr DESC) ly_customer_parent,
  LEAD (agg.customer_account,1,NULL) OVER (PARTITION BY agg.unique_store_composite_key, agg.fiscal_week_in_year_nbr, agg.sls_hier_sub_category_desc ORDER BY agg.fiscal_year_week_nbr DESC) ly_customer_account,
  LEAD (agg.segment,1,NULL) OVER (PARTITION BY agg.unique_store_composite_key, agg.fiscal_week_in_year_nbr, agg.sls_hier_sub_category_desc ORDER BY agg.fiscal_year_week_nbr DESC) ly_segment,
  LEAD (agg.retailer_type,1,NULL) OVER (PARTITION BY agg.unique_store_composite_key, agg.fiscal_week_in_year_nbr, agg.sls_hier_sub_category_desc ORDER BY agg.fiscal_year_week_nbr DESC) ly_retailer_type,
  LEAD (agg.store_display_name,1,NULL) OVER (PARTITION BY agg.unique_store_composite_key, agg.fiscal_week_in_year_nbr, agg.sls_hier_sub_category_desc ORDER BY agg.fiscal_year_week_nbr DESC) ly_store_display_name,
  LEAD (agg.banner,1,NULL) OVER (PARTITION BY agg.unique_store_composite_key, agg.fiscal_week_in_year_nbr, agg.sls_hier_sub_category_desc ORDER BY agg.fiscal_year_week_nbr DESC) ly_banner,
  LEAD (agg.store_number,1,NULL) OVER (PARTITION BY agg.unique_store_composite_key, agg.fiscal_week_in_year_nbr, agg.sls_hier_sub_category_desc ORDER BY agg.fiscal_year_week_nbr DESC) ly_store_number,
  LEAD (agg.store_street_address,1,NULL) OVER (PARTITION BY agg.unique_store_composite_key, agg.fiscal_week_in_year_nbr, agg.sls_hier_sub_category_desc ORDER BY agg.fiscal_year_week_nbr DESC) ly_store_street_address,
  LEAD (agg.store_city,1,NULL) OVER (PARTITION BY agg.unique_store_composite_key, agg.fiscal_week_in_year_nbr, agg.sls_hier_sub_category_desc ORDER BY agg.fiscal_year_week_nbr DESC) ly_store_city,
  LEAD (agg.store_state,1,NULL) OVER (PARTITION BY agg.unique_store_composite_key, agg.fiscal_week_in_year_nbr, agg.sls_hier_sub_category_desc ORDER BY agg.fiscal_year_week_nbr DESC) ly_store_state,
  LEAD (agg.store_zipcode,1,NULL) OVER (PARTITION BY agg.unique_store_composite_key, agg.fiscal_week_in_year_nbr, agg.sls_hier_sub_category_desc ORDER BY agg.fiscal_year_week_nbr DESC) ly_store_zipcode,
  LEAD (agg.sls_hier_division_desc,1,NULL) OVER (PARTITION BY agg.unique_store_composite_key, agg.fiscal_week_in_year_nbr, agg.sls_hier_sub_category_desc ORDER BY agg.fiscal_year_week_nbr DESC) ly_sls_hier_division_desc,
  LEAD (agg.sls_hier_category_desc,1,NULL) OVER (PARTITION BY agg.unique_store_composite_key, agg.fiscal_week_in_year_nbr, agg.sls_hier_sub_category_desc ORDER BY agg.fiscal_year_week_nbr DESC) ly_sls_hier_category_desc,
  LEAD (agg.instore_distribution_count,1,NULL) OVER (PARTITION BY agg.unique_store_composite_key, agg.fiscal_week_in_year_nbr, agg.sls_hier_sub_category_desc ORDER BY agg.fiscal_year_week_nbr DESC) ly_instore_distribution_count,
  LEAD (agg.instore_distribution_authorized_count,1,NULL) OVER (PARTITION BY agg.unique_store_composite_key, agg.fiscal_week_in_year_nbr, agg.sls_hier_sub_category_desc ORDER BY agg.fiscal_year_week_nbr DESC) ly_instore_distribution_authorized_count,
  LEAD (agg.instore_distribution_not_authorized_count,1,NULL) OVER (PARTITION BY agg.unique_store_composite_key, agg.fiscal_week_in_year_nbr, agg.sls_hier_sub_category_desc ORDER BY agg.fiscal_year_week_nbr DESC) ly_instore_distribution_not_authorized_count,
  LEAD (agg.online_distribution_count,1,NULL) OVER (PARTITION BY agg.unique_store_composite_key, agg.fiscal_week_in_year_nbr, agg.sls_hier_sub_category_desc ORDER BY agg.fiscal_year_week_nbr DESC) ly_online_distribution_count,
  LEAD (agg.online_distribution_authorized_count,1,NULL) OVER (PARTITION BY agg.unique_store_composite_key, agg.fiscal_week_in_year_nbr, agg.sls_hier_sub_category_desc ORDER BY agg.fiscal_year_week_nbr DESC) ly_online_distribution_authorized_count,
  LEAD (agg.online_distribution_not_authorized_count,1,NULL) OVER (PARTITION BY agg.unique_store_composite_key, agg.fiscal_week_in_year_nbr, agg.sls_hier_sub_category_desc ORDER BY agg.fiscal_year_week_nbr DESC) ly_online_distribution_not_authorized_count,
  LEAD (agg.available_count,1,NULL) OVER (PARTITION BY agg.unique_store_composite_key, agg.fiscal_week_in_year_nbr, agg.sls_hier_sub_category_desc ORDER BY agg.fiscal_year_week_nbr DESC) ly_available_count
FROM
  src_data agg

),
-- Add year-over-year calculations
year_over_year as (
    select pswc.customer_name
          ,pswc.unique_store_composite_key
          ,pswc.fiscal_year_week_nbr
          ,pswc.sls_hier_sub_category_desc
          ,ifnull(src.country, ly_country) country
          ,ifnull(src.customer_desc, ly_customer_desc) customer_desc
          ,ifnull(src.customer_parent, ly_customer_parent) customer_parent
          ,ifnull(src.customer_account, ly_customer_account) customer_account
          ,ifnull(src.segment, ly_segment) segment
          ,ifnull(src.retailer_type, ly_retailer_type) retailer_type
          ,ifnull(src.store_display_name, ly_store_display_name) store_display_name
          ,ifnull(src.banner, ly_banner) banner
          ,ifnull(src.store_number, ly_store_number) store_number
          ,ifnull(src.store_street_address, ly_store_street_address) store_street_address
          ,ifnull(src.store_city, ly_store_city) store_city
          ,ifnull(src.store_state, ly_store_state) store_state
          ,ifnull(src.store_zipcode, ly_store_zipcode) store_zipcode
          ,ifnull(src.sls_hier_division_desc, ly_sls_hier_division_desc) sls_hier_division_desc
          ,ifnull(src.sls_hier_category_desc, ly_sls_hier_category_desc) sls_hier_category_desc
          ,ifnull(instore_distribution_count, 0) instore_distribution_count
          ,ifnull(instore_distribution_authorized_count, 0) instore_distribution_authorized_count
          ,ifnull(instore_distribution_not_authorized_count, 0) instore_distribution_not_authorized_count
          ,ifnull(online_distribution_count, 0) online_distribution_count
          ,ifnull(online_distribution_authorized_count, 0) online_distribution_authorized_count
          ,ifnull(online_distribution_not_authorized_count, 0) online_distribution_not_authorized_count
          ,ifnull(available_count, 0) available_count
          ,ifnull(ly_instore_distribution_count, 0) ly_instore_distribution_count
          ,ifnull(ly_instore_distribution_authorized_count, 0) ly_instore_distribution_authorized_count
          ,ifnull(ly_instore_distribution_not_authorized_count, 0) ly_instore_distribution_not_authorized_count
          ,ifnull(ly_online_distribution_count, 0) ly_online_distribution_count
          ,ifnull(ly_online_distribution_authorized_count, 0) ly_online_distribution_authorized_count
          ,ifnull(ly_online_distribution_not_authorized_count, 0) ly_online_distribution_not_authorized_count
          ,ifnull(ly_available_count, 0) ly_available_count
          ,pswc.fiscal_month_in_year_nbr
          ,pswc.fiscal_year_nbr
          ,pswc.fiscal_week_in_year_nbr
          ,pswc.fiscal_week_begin_dt
          ,pswc.fiscal_year_month_nbr
          ,pswc.fiscal_month_in_year_short_desc
          ,row_number() over (partition by pswc.unique_store_composite_key
          ,pswc.fiscal_year_week_nbr,ifnull(src.sls_hier_division_desc, ly_sls_hier_division_desc)
          order by pswc.fiscal_year_week_nbr desc) rnk
      from possible_store_week_categories pswc
      left join ly_calc src
        on src.unique_store_composite_key = pswc.unique_store_composite_key
       and src.fiscal_year_week_nbr = pswc.fiscal_year_week_nbr
       and src.sls_hier_sub_category_desc = pswc.sls_hier_sub_category_desc
     --where
     --ifnull(src.customer_name, ly.customer_name) is not null

),
-- fill in gaps so each customer/store/week represents all possible sub-categories
customer_subcategories as (
    select distinct src.customer_name,
        src.sls_hier_division_desc,
        prd.sls_hier_category_desc,
        prd.sls_hier_sub_category_desc
      from (select distinct customer_name,
                sls_hier_division_desc
                from `""" ,BQ_PROJECT_NAME,"""`.""",BQ_PROCESSED_DATASET_NAME,""".""",BQ_SOURCE_TABLE_NAME,"""
                where sls_hier_division_desc in (""",SLS_HIER_DIVISION_DESC_FILTER,""")

            ) src
      join `""" ,BQ_EDW_PROJECT_NAME,"""`.""",BQ_ENTERPRISE_DATASET_NAME,""".dim_product_active prd
        on prd.sls_hier_division_desc = src.sls_hier_division_desc
        and prd.source_type_cd = 'NA'
),
fill_subcategory_gaps as (
    select distinct cs.customer_name
                   ,cs.sls_hier_division_desc
                   ,cs.sls_hier_category_desc
                   ,cs.sls_hier_sub_category_desc
                   ,yoy.unique_store_composite_key
                   ,yoy.store_number
                   ,yoy.banner
                   ,yoy.store_street_address
                   ,yoy.store_city
                   ,yoy.store_state
                   ,yoy.store_zipcode
                   ,yoy.store_display_name
                   ,yoy.country
                   ,yoy.segment
                   ,yoy.retailer_type
                   ,yoy.customer_desc
                   ,yoy.customer_parent
                   ,yoy.customer_account
                   ,yoy.fiscal_year_week_nbr
                   ,yoy.fiscal_month_in_year_nbr
                   ,yoy.fiscal_year_nbr
                   ,yoy.fiscal_week_in_year_nbr
                   ,yoy.fiscal_week_begin_dt
                   ,yoy.fiscal_year_month_nbr
                   ,yoy.fiscal_month_in_year_short_desc
      from customer_subcategories cs
      join year_over_year yoy
        on yoy.customer_name = cs.customer_name
       and yoy.sls_hier_division_desc = cs.sls_hier_division_desc
       and yoy.rnk = 1
),
-- Get the customer zone from the flattened XREF; we only want one per customer
customer_zone as (
    select customer_name, zone_hierarchy from (
    select *, rank() over (partition by customer_name
                           order by xref_order, sales_split desc, zone_hierarchy, retailer
              ) zone_rank
    from `""" ,BQ_PROJECT_NAME,"""`.""",BQ_PROCESSED_DATASET_NAME,""".lkp_nar_zone_mapping ) t
    where zone_rank = 1
)
-- Add rolling week 'time flag' columns, which are used in the Ops Scorecard
select
    FARM_FINGERPRINT(CONCAT(fsg.unique_store_composite_key,CAST(fsg.fiscal_week_begin_dt AS STRING),fsg.sls_hier_sub_category_desc)) subcatgfactkey_fingerprint
      ,fsg.store_number
      ,fsg.banner
      ,fsg.store_street_address
      ,fsg.store_city
      ,fsg.store_state
      ,fsg.store_zipcode
      ,fsg.unique_store_composite_key
      ,fsg.store_display_name
      ,fsg.retailer_type
      ,fsg.sls_hier_division_desc
      ,fsg.sls_hier_category_desc
      ,fsg.sls_hier_sub_category_desc
      ,yoy.instore_distribution_count
      ,yoy.instore_distribution_authorized_count
      ,yoy.instore_distribution_not_authorized_count
      ,yoy.online_distribution_count
      ,yoy.online_distribution_authorized_count
      ,yoy.online_distribution_not_authorized_count
      ,yoy.available_count
      ,yoy.ly_instore_distribution_count
      ,yoy.ly_instore_distribution_authorized_count
      ,yoy.ly_instore_distribution_not_authorized_count
      ,yoy.ly_online_distribution_count
      ,yoy.ly_online_distribution_authorized_count
      ,yoy.ly_online_distribution_not_authorized_count
      ,yoy.ly_available_count
      ,if(yoy.customer_name is null, TRUE, FALSE) null_row_flg
      ,fsg.fiscal_year_week_nbr
      ,fsg.fiscal_month_in_year_nbr
      ,fsg.fiscal_year_nbr
      ,fsg.fiscal_week_in_year_nbr
      ,fsg.fiscal_week_begin_dt
      ,fsg.fiscal_year_month_nbr
      ,fsg.country
      ,fsg.segment
      ,fsg.customer_desc
      ,fsg.customer_parent
      ,fsg.customer_account
      ,cz.zone_hierarchy customer_zone
      ,cmw.fiscal_week_begin_dt as max_customer_date
      ,if(fsg.fiscal_year_nbr = cmw.fiscal_year_nbr, TRUE, FALSE) latest_year_ty_flg
      ,if(fsg.fiscal_year_nbr = cmw.fiscal_year_nbr - 1, TRUE, FALSE) previous_year_ty_flg
      ,if(fsg.fiscal_year_nbr = cmw.fiscal_year_nbr - 2, TRUE, FALSE) previous_year_ly_flg
      ,case when date_diff(date(cmw.fiscal_week_begin_dt), date(fsg.fiscal_week_begin_dt), WEEK) <= 51 then TRUE
            else FALSE
       end latest_rolling_52_weeks_flg
      ,case when date_diff(date(cmw.fiscal_week_begin_dt), date(fsg.fiscal_week_begin_dt), WEEK) between 52 and 103 then TRUE
            else FALSE
       end previous_rolling_52_weeks_flg
      ,concat(cast(fsg.fiscal_month_in_year_nbr as string), '-', fsg.fiscal_month_in_year_short_desc) fiscal_month_period_desc
      ,cast(date(fsg.fiscal_week_begin_dt) as string) fiscal_week_begin_dt_desc
      ,'""",JOB_RUN_ID,"""' created_by
      ,current_datetime created_datetime
	  ,'""",JOB_RUN_ID,"""' modified_by
	  ,current_datetime modified_datetime
      ,fsg.customer_name
  from fill_subcategory_gaps fsg
  join customer_max_week cmw
    on cmw.customer_name = fsg.customer_name
  left join year_over_year yoy
    on yoy.customer_name = fsg.customer_name
   and yoy.unique_store_composite_key = fsg.unique_store_composite_key
   and yoy.fiscal_year_week_nbr = fsg.fiscal_year_week_nbr
   and yoy.sls_hier_sub_category_desc = fsg.sls_hier_sub_category_desc
  left join customer_zone cz
    on cz.customer_name = fsg.customer_name
) agg
on tgt.subcatgfactkey_fingerprint = agg.subcatgfactkey_fingerprint
WHEN MATCHED THEN
UPDATE SET instore_distribution_count = agg.instore_distribution_count
    ,instore_distribution_authorized_count = agg.instore_distribution_authorized_count
    ,instore_distribution_not_authorized_count = agg.instore_distribution_not_authorized_count
    ,online_distribution_count = agg.online_distribution_count
    ,online_distribution_authorized_count = agg.online_distribution_authorized_count
    ,online_distribution_not_authorized_count = agg.online_distribution_not_authorized_count
    ,available_count = agg.available_count
    ,null_row_flg = agg.null_row_flg
WHEN NOT MATCHED THEN
INSERT (
    subcatgfactkey_fingerprint
    ,store_number
    ,banner
    ,store_street_address
    ,store_city
    ,store_state
    ,store_zipcode
    ,unique_store_composite_key
    ,store_display_name
    ,retailer_type
    ,sls_hier_division_desc
    ,sls_hier_category_desc
    ,sls_hier_sub_category_desc
    ,instore_distribution_count
    ,instore_distribution_authorized_count
    ,instore_distribution_not_authorized_count
    ,online_distribution_count
    ,online_distribution_authorized_count
    ,online_distribution_not_authorized_count
    ,available_count
    ,ly_instore_distribution_count
    ,ly_instore_distribution_authorized_count
    ,ly_instore_distribution_not_authorized_count
    ,ly_online_distribution_count
    ,ly_online_distribution_authorized_count
    ,ly_online_distribution_not_authorized_count
    ,ly_available_count
    ,null_row_flg
    ,fiscal_year_week_nbr
    ,fiscal_month_in_year_nbr
    ,fiscal_year_nbr
    ,fiscal_week_in_year_nbr
    ,fiscal_week_begin_dt
    ,fiscal_year_month_nbr
    ,country
    ,segment
    ,customer_desc
    ,customer_parent
    ,customer_account
    ,customer_zone
    ,max_customer_date
    ,latest_year_ty_flg
    ,previous_year_ty_flg
    ,previous_year_ly_flg
    ,latest_rolling_52_weeks_flg
    ,previous_rolling_52_weeks_flg
    ,fiscal_month_period_desc
    ,fiscal_week_begin_dt_desc
    ,created_by
    ,created_datetime
    ,modified_by
    ,modified_datetime
    ,customer_name
)
VALUES (
    agg.subcatgfactkey_fingerprint
    ,agg.store_number
    ,agg.banner
    ,agg.store_street_address
    ,agg.store_city
    ,agg.store_state
    ,agg.store_zipcode
    ,agg.unique_store_composite_key
    ,agg.store_display_name
    ,agg.retailer_type
    ,agg.sls_hier_division_desc
    ,agg.sls_hier_category_desc
    ,agg.sls_hier_sub_category_desc
    ,agg.instore_distribution_count
    ,agg.instore_distribution_authorized_count
    ,agg.instore_distribution_not_authorized_count
    ,agg.online_distribution_count
    ,agg.online_distribution_authorized_count
    ,agg.online_distribution_not_authorized_count
    ,agg.available_count
    ,agg.ly_instore_distribution_count
    ,agg.ly_instore_distribution_authorized_count
    ,agg.ly_instore_distribution_not_authorized_count
    ,agg.ly_online_distribution_count
    ,agg.ly_online_distribution_authorized_count
    ,agg.ly_online_distribution_not_authorized_count
    ,agg.ly_available_count
    ,agg.null_row_flg
    ,agg.fiscal_year_week_nbr
    ,agg.fiscal_month_in_year_nbr
    ,agg.fiscal_year_nbr
    ,agg.fiscal_week_in_year_nbr
    ,agg.fiscal_week_begin_dt
    ,agg.fiscal_year_month_nbr
    ,agg.country
    ,agg.segment
    ,agg.customer_desc
    ,agg.customer_parent
    ,agg.customer_account
    ,agg.customer_zone
    ,agg.max_customer_date
    ,agg.latest_year_ty_flg
    ,agg.previous_year_ty_flg
    ,agg.previous_year_ly_flg
    ,agg.latest_rolling_52_weeks_flg
    ,agg.previous_rolling_52_weeks_flg
    ,agg.fiscal_month_period_desc
    ,agg.fiscal_week_begin_dt_desc
    ,agg.created_by
    ,agg.created_datetime
    ,agg.modified_by
    ,agg.modified_datetime
    ,agg.customer_name
)
""");

EXCEPTION WHEN ERROR THEN
        EXECUTE IMMEDIATE CONCAT(
            """INSERT INTO processed.ecomm_admin_sproc_error_details (
		        SELECT
			        '""",FEED_NAME,"""' AS FEED_NAME,
                    split(split(@@error.formatted_stack_trace,'transient.')[OFFSET (1)],'[')[OFFSET(0)],
			        @@error.statement_text,
			        @@error.message,
			        current_timestamp()
	        );
	    """);

	    SELECT
	        ERROR (
	            CONCAT(
	            		@@error.message ,' ' ,
	            		@@error.statement_text, ' ' ,
	            		@@error.formatted_stack_trace ,' '
	            	)
	        );

END;