/*
Purpose of the stored proc: 
	Create a flattened table of converted upc's with their new ean, old ean, and product_na data about 
    the new ean to use in distribution and availability tables
History of Changes (date format: mm/dd/yy):
	05/28/21 – first version
    07/14/21 - Changed references to enterprise project
    11/29/21 - Changed all transient dataset references to reference processed layer instead
Author : 
	Kaia Arthur
How to Call:
		call transient.sp_upc_conversions_flattened
		(
		 99,
		'ecomm-dlf-dev-01cd47',
		'processed' ,
        'edw-prd-e567f9',
        'enterprise',
		'dim_upc_conversions_flattened',
        'dim_upc_conversions'
		)

*/

CREATE OR REPLACE PROCEDURE transient.sp_upc_conversions_flattened
( 
	job_run_id INT64,
	bq_project_name string,
	bq_processed_dataset_name string,
    bq_enterprise_project_name string,
    bq_enterprise_dataset_name string,
	bq_processed_table_name string,
    bq_source_table_name string
)
BEGIN

/* Delta Temp Table is Truncate & Load */
EXECUTE IMMEDIATE
CONCAT("""TRUNCATE TABLE  `""" ,bq_project_name,"""`.""",bq_processed_dataset_name,""".""",bq_processed_table_name);

EXECUTE IMMEDIATE
CONCAT(
"""insert into  `""" ,bq_project_name,"""`.""",bq_processed_dataset_name,""".""",bq_processed_table_name,"""
( 
with remove_exact_swaps as (
    select uc1.new_ean_upc_cd,
    uc1.old_ean_upc_cd,
    uc1.conversion_date
    from `""" ,bq_project_name,"""`.""",bq_processed_dataset_name,""".""",bq_source_table_name,""" uc1
    left join `""" ,bq_project_name,"""`.""",bq_processed_dataset_name,""".""",bq_source_table_name,""" uc2
    on uc1.old_ean_upc_cd = uc2.new_ean_upc_cd
    and uc1.new_ean_upc_cd = uc2.old_ean_upc_cd
    and uc1.conversion_date = uc2.conversion_date
    where uc2.conversion_date is null
),
remove_multi_step_swaps as (
    select distinct new_ean_upc_cd,
    old_ean_upc_cd,
    conversion_date
    from remove_exact_swaps conv
    where conv.old_ean_upc_cd not in (
        select uc1.old_ean_upc_cd
        from remove_exact_swaps uc1
        join remove_exact_swaps uc2
            on uc1.old_ean_upc_cd = uc2.new_ean_upc_cd
            and uc1.conversion_date = uc2.conversion_date
        )
), 
newest_eans as (
    select
    old.old_ean_upc_cd,
    coalesce(new2.new_ean_upc_cd,new1.new_ean_upc_cd,old.new_ean_upc_cd) new_ean_upc_cd,
    coalesce(new2.conversion_date,new1.conversion_date,old.conversion_date) conversion_date
    from remove_multi_step_swaps as old
    left join remove_multi_step_swaps new1
    on old.new_ean_upc_cd = new1.old_ean_upc_cd
    left join remove_multi_step_swaps new2
    on new1.new_ean_upc_cd = new2.old_ean_upc_cd
)
select ne.new_ean_upc_cd
    ,ne.old_ean_upc_cd
    ,pna.sls_hier_division_desc new_sls_hier_division_desc	
    ,pna.sls_hier_category_desc new_sls_hier_category_desc
    ,pna.sls_hier_sub_category_desc new_sls_hier_sub_category_desc
    ,pna.sls_hier_ppg_desc new_sls_hier_ppg_desc
    ,pna.base_product_cd new_base_product_cd
    ,pna.base_product_desc new_base_product_desc
    ,pna.material_cd new_material_cd
    ,pna.material_short_desc new_material_short_desc
    ,pna.material_nbr new_material_nbr
    from newest_eans ne
    left join `""" ,bq_enterprise_project_name,"""`.""",bq_enterprise_dataset_name,""".dim_product_active pna
    on ne.new_ean_upc_cd = pna.ean_upc_cd
    where pna.language_cd='EN' 
    and pna.material_type_cd = 'CNPK'
)
""");


EXCEPTION WHEN ERROR THEN
    SELECT  
	ERROR (
		CONCAT(
    			@@error.message ,' ' ,
    			@@error.statement_text, ' ' ,
    			@@error.formatted_stack_trace ,' '
			)
		)
	;
END

