/*Purpose of the stored proc: 

	- Insert Entries into Data Release control table for distinct fiscal_year_week_nbr records in Incoming Delta data, 
	- Default value for staging_flag set as 'Y' and release flag as 'N'
	
	This Table will referred to release the specific data for Reporting Purpose specific to each customer
	
History of Changes:
	08/06 - First Version
Author : 
	Navdisha Singla
How to call:
call  transient.sp_ecom_distribution_availability_data_release_control_insert
		(
		-99,
		'ecomm-dlf-dev-01cd47',
		'processed',
        'processed',
		'kroger_distribution_availability_subcatg_agg_fact',
		'KROGER_DISTRIBUTION_AVAILABILITY',
		'KROGER_DISTRIBUTION_AVAILABILITY_SUBCATG_AGG_FACT'
		);
*/


CREATE OR REPLACE PROCEDURE transient.sp_ecom_distribution_availability_data_release_control_insert
( 
	job_run_id INT64,
	bq_project_name string,
	bq_processed_dataset_name string,
    bq_dataset_name string,
	bq_source_table string,
	customer_name string,
	feed_name string
	
)
BEGIN
-- declare variables
DECLARE job_run_id_string String;

-- set variables
set job_run_id_string = cast(job_run_id as string);
	
-- Insert fresh records from source table into target 'ecom_data_release_control' table 
-- with default flag values: staging_flg as 'Y' & release_flg as 'N'

EXECUTE IMMEDIATE CONCAT(
"""MERGE `""" ,bq_project_name,"""`.""",bq_processed_dataset_name,""".ecom_data_release_control tgt
USING
  (
  SELECT
  fiscal_year_week_nbr ,
  fiscal_year_month_nbr,
  fiscal_year_nbr,
  '""",customer_name,"""' AS customer_name,
  '""",feed_name,"""' AS feed_name
  FROM
  `""",bq_project_name,"""`.""",bq_dataset_name,""".""",bq_source_table,""" src_tbl

-- Using group by to fetch unique combination of week, month and year numbers
-- We are not using 'DISTINCT' as 'GROUP BY' is a less costly operation when the volume goes up.

  group by 
  fiscal_year_week_nbr ,
  fiscal_year_month_nbr,
  fiscal_year_nbr
  ) src  
ON
	  tgt.fiscal_year_week_nbr = src.fiscal_year_week_nbr
  AND tgt.customer_name = src.customer_name
  AND tgt.feed_name 	= src.feed_name
  WHEN NOT MATCHED
  THEN
INSERT
  (	 	         
	 customer_name   
	,feed_name
	,fiscal_year_week_nbr 
	,fiscal_year_month_nbr
	,fiscal_year_nbr
	,staging_flg       
	,release_flg       
	,created_by        
	,created_datetime  
	,modified_by      
	,modified_datetime 
	) 
	
VALUES
  (
	'""",customer_name,"""', 
	'""",feed_name,"""',
	src.fiscal_year_week_nbr,
	src.fiscal_year_month_nbr,
	src.fiscal_year_nbr,
	'Y',
	'N',
	'""",job_run_id_string,"""'
	,current_datetime,
	'""",job_run_id_string,
	"""',current_datetime
  )
""");
	  
	  
	
EXCEPTION WHEN ERROR THEN
    SELECT  
	ERROR (
		CONCAT(
    			@@error.message ,' ' ,
    			@@error.statement_text, ' ' ,
    			@@error.formatted_stack_trace ,' '
			)
		)
	;

END
