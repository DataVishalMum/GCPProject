/*
Purpose of the stored proc:
	/*
Joining together in-store and online datasets
    - For distribution, we only care about "common store/weeks" - when there's both in-store and online data.
    - For availability, we care about all online store/weeks, regardless of whether or not there's in-store data.

History of Changes:
	04/06/22 – Nate Adams - Made copy from normal joined procedure specifically for nielsen/iri data sources
	06/28/22 - Changes related to composer work
Author :
	Shubham Saxena
*/

CREATE OR REPLACE PROCEDURE transient.ecomm_sproc_ana_common_distribution_availability_joined
(
SRC_PROJECT STRING,
SRC_LOOKUP_DATASET STRING,
SRC_DATASET STRING,
DEST_DATASET STRING,
INTERMEDIATE_PROJECT STRING,
INTERMEDIATE_DATASET STRING,
INTERMEDIATE_TABLE STRING,
DEST_TABLE STRING,
SRC_TABLE STRING,
SOURCE_LOOKUP_TABLE STRING,
XREF_TABLE STRING,
DEST_LOOKUP_TABLE STRING,
FEED_NAME STRING
)
OPTIONS(
description = """
How to Call:

CALL transient.ecomm_sproc_ana_common_distribution_availability_joined
(
'ecomm-dlf-dev-01cd47',                         --SRC_PROJECT
'raw',                                          --SRC_LOOKUP_DATASET
'transient',                                    --SRC_DATASET
'processed',                                    --DEST_DATASET
'edw-prd-e567f9',                               --INTERMEDIATE_PROJECT
'enterprise',                                   --INTERMEDIATE_DATASET
'dim_date',                                     --INTERMEDIATE_TABLE
'stop_and_shop_distribution_availability_joined_fact', --DEST_TABLE
'stop_and_shop_datasembly_fact',                       --SRC_TABLE
'stop_and_shop_nielsen_fact',                          --SOURCE_LOOKUP_TABLE
'stop_and_shop_nielsen_temp',                          --XREF_TABLE
'stop_and_shop_datasembly_delta_temp',                 --DEST_LOOKUP_TABLE
'stop_and_shop'                                        --FEED_NAME
)
"""
)

BEGIN

DECLARE JOB_RUN_ID DEFAULT 999999;
DECLARE BQ_PROJECT_NAME DEFAULT SRC_PROJECT;
DECLARE BQ_RAW_DATASET_NAME DEFAULT SRC_LOOKUP_DATASET;
DECLARE BQ_TRANSIENT_DATASET_NAME DEFAULT SRC_DATASET;
DECLARE BQ_PROCESSED_DATASET_NAME DEFAULT DEST_DATASET;
DECLARE BQ_EDW_PROJECT_NAME DEFAULT INTERMEDIATE_PROJECT;
DECLARE BQ_ENTERPRISE_DATASET_NAME DEFAULT INTERMEDIATE_DATASET;
DECLARE BQ_INTER_TABLE_NAME DEFAULT INTERMEDIATE_TABLE;
DECLARE BQ_TARGET_TABLE_NAME DEFAULT DEST_TABLE;
DECLARE BQ_ONLINE_SOURCE_NAME DEFAULT SRC_TABLE;
DECLARE BQ_IN_STORE_SOURCE_NAME DEFAULT SOURCE_LOOKUP_TABLE;
DECLARE BQ_IN_STORE_DELTA_TEMP DEFAULT XREF_TABLE;
DECLARE BQ_ONLINE_DELTA_TEMP DEFAULT DEST_LOOKUP_TABLE;
-- declare variables
DECLARE
	 IN_STORE_EXTRACT_START_DATE
	,IN_STORE_EXTRACT_END_DATE
    ,ONLINE_EXTRACT_START_DATE
	,ONLINE_EXTRACT_END_DATE TIMESTAMP;

DECLARE IN_STORE_UPC_COL STRING;
DECLARE MAX_INSTORE_DT DATE;

SET FEED_NAME = UPPER(FEED_NAME);

EXECUTE IMMEDIATE
  CONCAT("""select max(fiscal_week_begin_dt) from `""" ,BQ_PROJECT_NAME,"""`.""",BQ_PROCESSED_DATASET_NAME,""".""",BQ_IN_STORE_SOURCE_NAME,"""""") INTO MAX_INSTORE_DT;

/* Get Extract start datetime for incoming in store table from data_extract_config table */
EXECUTE IMMEDIATE
  CONCAT("""select extract_start_datetime from `""",BQ_PROJECT_NAME,"""`.""",BQ_TRANSIENT_DATASET_NAME,""".""","""data_extract_config
where table_name = '""",BQ_IN_STORE_SOURCE_NAME,"""' and status = 'running'
and active_flag = 'Y'""") INTO IN_STORE_EXTRACT_START_DATE;

/* Get Extract end datetime for incoming in store table from data_extract_config table */
EXECUTE IMMEDIATE
  CONCAT("""select extract_end_datetime from `""",BQ_PROJECT_NAME,"""`.""",BQ_TRANSIENT_DATASET_NAME,""".""", """data_extract_config
  where table_name = '""",BQ_IN_STORE_SOURCE_NAME,"""' and status = 'running'  and active_flag = 'Y'""") INTO IN_STORE_EXTRACT_END_DATE;

/* Get Extract start datetime for incoming online table from data_extract_config table */
EXECUTE IMMEDIATE
  CONCAT("""select extract_start_datetime from `""",BQ_PROJECT_NAME,"""`.""",BQ_TRANSIENT_DATASET_NAME,""".""","""data_extract_config
where table_name = '""",BQ_ONLINE_SOURCE_NAME,"""' and status = 'running'
and active_flag = 'Y'""") INTO ONLINE_EXTRACT_START_DATE;

/* Get Extract end datetime for incoming online table from data_extract_config table */
EXECUTE IMMEDIATE
  CONCAT("""select extract_end_datetime from `""",BQ_PROJECT_NAME,"""`.""",BQ_TRANSIENT_DATASET_NAME,""".""", """data_extract_config
  where table_name = '""",BQ_ONLINE_SOURCE_NAME,"""' and status = 'running'  and active_flag = 'Y'""") INTO ONLINE_EXTRACT_END_DATE;


-- We have 'gmi_upc' as the UPC column for the E2OPEN sources, whereas 'UPC' for datasembly
-- Publix Com and Instacart are fetching data from datasembly

  EXECUTE IMMEDIATE  CONCAT("""   WITH
  dr AS (
  SELECT
    COUNT(*) cnt
  FROM
    """,BQ_PROCESSED_DATASET_NAME,""".INFORMATION_SCHEMA.COLUMNS
  WHERE
    table_name = '""",BQ_IN_STORE_SOURCE_NAME,"""'
    AND column_name = 'gmi_upc')
SELECT
  CASE
    WHEN cnt = 0 THEN 'upc'
  ELSE
  'gmi_upc'
END
FROM
  dr""") INTO IN_STORE_UPC_COL;


EXECUTE IMMEDIATE
CONCAT(
"""merge  `""" ,BQ_PROJECT_NAME,"""`.""",BQ_PROCESSED_DATASET_NAME,""".""",BQ_TARGET_TABLE_NAME,""" tgt using
(
with online_delta_weeks as (
    select distinct fiscal_week_begin_dt
    from `""" ,BQ_PROJECT_NAME,"""`.""",BQ_PROCESSED_DATASET_NAME,""".""",BQ_ONLINE_SOURCE_NAME,""" os
    where EXTRACT(DATE FROM modified_datetime) > CAST(SUBSTRING('""",ONLINE_EXTRACT_START_DATE,"""',0,10) AS DATE)
      and EXTRACT(DATE FROM modified_datetime)  <= CAST(SUBSTRING('""",ONLINE_EXTRACT_END_DATE,"""',0,10) AS DATE)),
instore_delta_weeks as (
    select distinct fiscal_week_begin_dt
    from `""" ,BQ_PROJECT_NAME,"""`.""",BQ_PROCESSED_DATASET_NAME,""".""",BQ_IN_STORE_SOURCE_NAME,""" iss
    where EXTRACT(DATE FROM modified_datetime) > CAST(SUBSTRING('""",IN_STORE_EXTRACT_START_DATE,"""',0,10) AS DATE)
      and EXTRACT(DATE FROM modified_datetime)  <= CAST(SUBSTRING('""",IN_STORE_EXTRACT_END_DATE,"""',0,10) AS DATE)),
--Combine delta weeks to use to pull appropriate weeks from both sources
combined_weeks as (
    select distinct fiscal_week_begin_dt
    from `""",BQ_PROJECT_NAME,"""`.""",BQ_TRANSIENT_DATASET_NAME,""".""",BQ_ONLINE_DELTA_TEMP,"""
    union distinct
    select distinct fiscal_week_begin_dt
    from `""",BQ_PROJECT_NAME,"""`.""",BQ_TRANSIENT_DATASET_NAME,""".""",BQ_IN_STORE_DELTA_TEMP,"""
    union distinct
    select distinct fiscal_week_begin_dt
    from `""",BQ_PROJECT_NAME,"""`.""",BQ_PROCESSED_DATASET_NAME,""".""",BQ_ONLINE_SOURCE_NAME,"""
    where fiscal_week_begin_dt > '""",MAX_INSTORE_DT,"""'
),
online_source as (
    select os.*
	  ,1 is_online
	  ,concat(left(os.store_street_address, 3), left(os.store_zipcode,5)) unique_store_composite_key
      ,case when os.stock_flg = TRUE then 1
                else 0
           end is_available
--Need to window over our natural keys because we may have duplicate eans for a store/week
--after fuzzy matching. Where duplicates exist, we want to take the row that is in stock/available.
    ,row_number() over (
          partition by cast(cast(regexp_replace(SUBSTRING(os.store_number, -5, 5),'[A-Za-z]','') as INT64) as STRING), initcap(os.store_city), os.store_state, os.fiscal_week_begin_dt, os.ean_upc_cd
            order by os.stock_flg desc
      ) os_rank
    from `""" ,BQ_PROJECT_NAME,"""`.""",BQ_PROCESSED_DATASET_NAME,""".""",BQ_ONLINE_SOURCE_NAME,""" os
	  join combined_weeks cw
      on cw.fiscal_week_begin_dt = os.fiscal_week_begin_dt
),
--Need to window over our natural keys because we may have duplicate eans for a store/week
--after fuzzy matching. Where duplicates exist, we want to take the row where the product is authorized.
instore_source as (
    select iss.*
	  ,1 is_instore
      ,concat(left(iss.store_street_address, 3), left(iss.store_zipcode,5)) unique_store_composite_key
	  ,row_number() over (
          partition by iss.store_number, initcap(iss.store_city), iss.store_state, iss.fiscal_week_begin_dt, iss.ean_upc_cd
            order by iss.authorization_flg desc
      ) iss_rank
      from `""" ,BQ_PROJECT_NAME,"""`.""",BQ_PROCESSED_DATASET_NAME,""".""",BQ_IN_STORE_SOURCE_NAME,""" iss
      join combined_weeks cw
        on cw.fiscal_week_begin_dt = iss.fiscal_week_begin_dt
),
-- List of all eans that can exist at a given store (both online and in-store sources)
-- to serve as a base for what is effectively a full outer join of products during weeks
-- when we have both in-store and online data for a given store
store_eans as (
    select distinct unique_store_composite_key, ean_upc_cd
    from online_source
    union distinct
    select distinct unique_store_composite_key, ean_upc_cd
    from instore_source
),
online_store_weeks as (
    select distinct
        fiscal_week_begin_dt
        , unique_store_composite_key
        , CASE when fiscal_week_begin_dt > '""",MAX_INSTORE_DT,"""' THEN '""",MAX_INSTORE_DT,"""'
                      else fiscal_week_begin_dt
                      end join_week
    from online_source
),
instore_store_weeks as (
    select distinct fiscal_week_begin_dt, unique_store_composite_key
    from instore_source
),
store_week_ean_xjoin as (
    select osw.fiscal_week_begin_dt
      ,se.unique_store_composite_key
      ,se.ean_upc_cd
      ,osw.join_week
    from store_eans se
    join online_store_weeks osw
      on osw.unique_store_composite_key = se.unique_store_composite_key
    join instore_store_weeks isw
      on isw.unique_store_composite_key = osw.unique_store_composite_key
      and isw.fiscal_week_begin_dt = osw.join_week
)
-- This is effectively an 'outer join' between in-store and online sources, (except for the common week filtering)
-- so we use ifnull() on most columns since we don't know which source(s) will contain the data.
-- In-store is used first in ifnull() to get store fields because E2Open has cleaner, more consistent store data than Datasembly
-- Order for ifnull() is trivial for the fields that originally come from product_na table
select * except (rnk)
from (
select
     FARM_FINGERPRINT(CONCAT(ifnull(isrc.ean_upc_cd, osrc.ean_upc_cd),swe.unique_store_composite_key,CAST(swe.fiscal_week_begin_dt AS STRING))) joinedkey_fingerprint
    ,ifnull(osrc.store_number,isrc.store_number) store_number
    ,ifnull(isrc.customer_name, osrc.customer_name) banner
    ,ifnull(isrc.store_street_address, osrc.store_street_address) store_street_address
    ,initcap(ifnull(isrc.store_city, osrc.store_city)) store_city
    ,ifnull(isrc.store_state, osrc.store_state) store_state
    ,ifnull(isrc.store_zipcode, osrc.store_zipcode) store_zipcode
    ,isrc.division
    ,ifnull(isrc.""",IN_STORE_UPC_COL,""", osrc.upc) upc_cd
    ,swe.unique_store_composite_key
    ,ifnull(isrc.sls_hier_division_desc, osrc.sls_hier_division_desc) sls_hier_division_desc
    ,ifnull(isrc.sls_hier_category_desc, osrc.sls_hier_category_desc) sls_hier_category_desc
    ,ifnull(isrc.sls_hier_sub_category_desc, osrc.sls_hier_sub_category_desc) sls_hier_sub_category_desc
    ,ifnull(isrc.sls_hier_ppg_desc, osrc.sls_hier_ppg_desc) sls_hier_ppg_desc
    ,ifnull(isrc.base_product_cd, osrc.base_product_cd) base_product_cd
    ,ifnull(isrc.base_product_desc, osrc.base_product_desc) base_product_desc
    ,ifnull(isrc.material_cd, osrc.material_cd) material_cd
    ,ifnull(isrc.material_nbr, osrc.material_nbr) material_nbr
    ,ifnull(isrc.ean_upc_cd, osrc.ean_upc_cd) ean_upc_cd
    ,ifnull(isrc.material_short_desc, osrc.material_short_desc) material_short_desc
    ,ifnull(isrc.old_sls_hier_division_desc, osrc.old_sls_hier_division_desc) old_sls_hier_division_desc
    ,ifnull(isrc.old_sls_hier_category_desc, osrc.old_sls_hier_category_desc) old_sls_hier_category_desc
    ,ifnull(isrc.old_sls_hier_sub_category_desc, osrc.old_sls_hier_sub_category_desc) old_sls_hier_sub_category_desc
    ,ifnull(isrc.old_sls_hier_ppg_desc, osrc.old_sls_hier_ppg_desc) old_sls_hier_ppg_desc
    ,ifnull(isrc.old_base_product_cd, osrc.old_base_product_cd) old_base_product_cd
    ,ifnull(isrc.old_base_product_desc, osrc.old_base_product_desc) old_base_product_desc
    ,ifnull(isrc.old_material_cd, osrc.old_material_cd) old_material_cd
    ,ifnull(isrc.old_material_nbr, osrc.old_material_nbr) old_material_nbr
    ,ifnull(isrc.old_ean_upc_cd, osrc.old_ean_upc_cd) old_ean_upc_cd
    ,ifnull(isrc.old_material_short_desc, osrc.old_material_short_desc) old_material_short_desc
    ,osrc.is_online
    ,osrc.stock_flg
    ,osrc.is_available
    ,isrc.is_instore
    ,isrc.authorization_flg
    ,fch.fiscal_year_week_nbr
    ,fch.fiscal_month_in_year_nbr
    ,fch.fiscal_year_nbr
    ,fch.fiscal_week_in_year_nbr
    ,swe.fiscal_week_begin_dt
    ,fch.fiscal_year_month_nbr
    ,ifnull(isrc.customer_name, osrc.customer_name) customer_name
    -- We are getting duplicates on the ean_upc_cd, unique_store_composite_key and fiscal week combination
    -- During a merge, if a row in the table to be updated joins with more than one row from the FROM clause,
    -- then the query generates the following runtime error: UPDATE/MERGE must match at most one source row for each target row
    ,row_number() over(partition by ifnull(isrc.ean_upc_cd, osrc.ean_upc_cd),swe.unique_store_composite_key,fch.fiscal_week_begin_dt
    order by ifnull(osrc.stock_flg,isrc.authorization_flg) desc) rnk
    ,'""",JOB_RUN_ID,"""' created_by
    , current_datetime created_datetime
    , '""",JOB_RUN_ID,"""' modified_by
    , current_datetime modified_datetime
from store_week_ean_xjoin swe
left join (select * from online_source where os_rank =1) osrc
  on osrc.fiscal_week_begin_dt = swe.fiscal_week_begin_dt
  and osrc.unique_store_composite_key = swe.unique_store_composite_key
  and osrc.ean_upc_cd = swe.ean_upc_cd
left join (select * from instore_source where iss_rank =1 ) isrc
  on isrc.fiscal_week_begin_dt = swe.join_week
  and isrc.unique_store_composite_key = swe.unique_store_composite_key
  and isrc.ean_upc_cd = swe.ean_upc_cd
left join `""" ,BQ_EDW_PROJECT_NAME,"""`.""",BQ_ENTERPRISE_DATASET_NAME,""".""",BQ_INTER_TABLE_NAME,""" fch
  on fch.language_cd = 'EN'
  and fch.fiscal_year_variant_cd = '07'
  --and fch.fiscal_calendar_level_cd = 'WEEK'
  and fch.fiscal_week_begin_dt = swe.fiscal_week_begin_dt
where (isrc.ean_upc_cd is not null
  or osrc.ean_upc_cd is not null))
  WHERE rnk = 1
) joined
on tgt.joinedkey_fingerprint = joined.joinedkey_fingerprint
WHEN MATCHED THEN
  UPDATE SET is_instore = joined.is_instore,
    authorization_flg = joined.authorization_flg,
    division = joined.division,
    is_online = joined.is_online,
    stock_flg = joined.stock_flg,
    is_available = joined.is_available
WHEN NOT MATCHED THEN
INSERT
  (
      joinedkey_fingerprint
    ,store_number
    ,banner
    ,store_street_address
    ,store_city
    ,store_state
    ,store_zipcode
    ,division
    ,upc_cd
    ,unique_store_composite_key
    ,sls_hier_division_desc
    ,sls_hier_category_desc
    ,sls_hier_sub_category_desc
    ,sls_hier_ppg_desc
    ,base_product_cd
    ,base_product_desc
    ,material_cd
    ,material_nbr
    ,ean_upc_cd
    ,material_short_desc
    ,old_sls_hier_division_desc
    ,old_sls_hier_category_desc
    ,old_sls_hier_sub_category_desc
    ,old_sls_hier_ppg_desc
    ,old_base_product_cd
    ,old_base_product_desc
    ,old_material_cd
    ,old_material_nbr
    ,old_ean_upc_cd
    ,old_material_short_desc
    ,is_online
    ,stock_flg
    ,is_available
	,is_instore
	,authorization_flg
    ,fiscal_year_week_nbr
    ,fiscal_month_in_year_nbr
    ,fiscal_year_nbr
    ,fiscal_week_in_year_nbr
    ,fiscal_week_begin_dt
    ,fiscal_year_month_nbr
    ,customer_name
    ,created_by
    ,created_datetime
	,modified_by
	,modified_datetime
  )
VALUES
  (
      joined.joinedkey_fingerprint
    ,joined.store_number
    ,joined.banner
    ,joined.store_street_address
    ,joined.store_city
    ,joined.store_state
    ,joined.store_zipcode
    ,joined.division
    ,joined.upc_cd
    ,joined.unique_store_composite_key
    ,joined.sls_hier_division_desc
    ,joined.sls_hier_category_desc
    ,joined.sls_hier_sub_category_desc
    ,joined.sls_hier_ppg_desc
    ,joined.base_product_cd
    ,joined.base_product_desc
    ,joined.material_cd
    ,joined.material_nbr
    ,joined.ean_upc_cd
    ,joined.material_short_desc
    ,joined.old_sls_hier_division_desc
    ,joined.old_sls_hier_category_desc
    ,joined.old_sls_hier_sub_category_desc
    ,joined.old_sls_hier_ppg_desc
    ,joined.old_base_product_cd
    ,joined.old_base_product_desc
    ,joined.old_material_cd
    ,joined.old_material_nbr
    ,joined.old_ean_upc_cd
    ,joined.old_material_short_desc
    ,joined.is_online
    ,joined.stock_flg
    ,joined.is_available
	,joined.is_instore
	,joined.authorization_flg
    ,joined.fiscal_year_week_nbr
    ,joined.fiscal_month_in_year_nbr
    ,joined.fiscal_year_nbr
    ,joined.fiscal_week_in_year_nbr
    ,joined.fiscal_week_begin_dt
    ,joined.fiscal_year_month_nbr
    ,joined.customer_name
    ,joined.created_by
    ,joined.created_datetime
	,joined.modified_by
	,joined.modified_datetime
)
""");

EXCEPTION WHEN ERROR THEN
        EXECUTE IMMEDIATE CONCAT(
            """INSERT INTO processed.ecomm_admin_sproc_error_details (
		        SELECT
			        '""",FEED_NAME,"""' AS FEED_NAME,
                    split(split(@@error.formatted_stack_trace,'transient.')[OFFSET (1)],'[')[OFFSET(0)],
			        @@error.statement_text,
			        @@error.message,
			        current_timestamp()
	        );
	    """);

	    SELECT
	        ERROR (
	            CONCAT(
	            		@@error.message ,' ' ,
	            		@@error.statement_text, ' ' ,
	            		@@error.formatted_stack_trace ,' '
	            	)
	        );

END;