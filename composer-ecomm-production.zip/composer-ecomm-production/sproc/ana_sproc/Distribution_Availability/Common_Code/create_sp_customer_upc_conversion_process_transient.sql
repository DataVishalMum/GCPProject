/*
Purpose of the stored proc:
	UPC Conversion with product attributes
History of Changes (date format: mm/dd/yy):
	03/19/22 – first version
	06/27/22 - Changes related to composer work
Author :
	Shubham Saxena
*/

CREATE OR REPLACE PROCEDURE transient.ecomm_sproc_ana_common_upc_conversion_process
(
	SRC_PROJECT STRING,
	SRC_DATASET STRING,
    INTERMEDIATE_DATASET STRING,
	INTERMEDIATE_TABLE STRING,
    SRC_TABLE STRING,
    DEST_TABLE STRING,
	FEED_NAME STRING
)
OPTIONS(
description = """

 How to call:

CALL transient.ecomm_sproc_ana_common_upc_conversion_process
(
'ecomm-dlf-dev-01cd47',                                -- SRC_PROJECT
'transient',       									   -- SRC_DATASET
'processed',										   -- INTERMEDIATE_DATASET
'dim_upc_conversions_flattened'						   -- INTERMEDIATE_TABLE
'stop_and_shop_datasembly_product_temp',	           -- SRC_TABLE
'stop_and_shop_datasembly_product_upc_converted',      -- DEST_TABLE
'stop_and_shop'                                        -- FEED_NAME
)
"""
)

BEGIN

DECLARE BQ_PROJECT_NAME DEFAULT SRC_PROJECT;
DECLARE BQ_TRANSIENT_DATASET_NAME DEFAULT SRC_DATASET;
DECLARE BQ_PROCESSED_DATASET_NAME DEFAULT INTERMEDIATE_DATASET;
DECLARE BQ_INTER_TABLE_NAME DEFAULT INTERMEDIATE_TABLE;
DECLARE RAW_TABLE_NAME DEFAULT SRC_TABLE;
DECLARE BQ_TARGET_TABLE_NAME DEFAULT DEST_TABLE;
SET FEED_NAME = UPPER(FEED_NAME);

-- truncate data from the target table
EXECUTE IMMEDIATE
CONCAT("""
TRUNCATE TABLE
  `""",BQ_PROJECT_NAME,""".""",BQ_TRANSIENT_DATASET_NAME,""".""",BQ_TARGET_TABLE_NAME,"""`""");

EXECUTE IMMEDIATE
    CONCAT("""
    INSERT INTO `""",BQ_PROJECT_NAME,""".""",BQ_TRANSIENT_DATASET_NAME,""".""",BQ_TARGET_TABLE_NAME,"""`
    SELECT
        src.upc
        ,xref_upc_sk
        ,coalesce(conv.new_ean_upc_cd, src.ean_upc_cd) as ean_upc_cd
        ,base_product_ean_upc_derived_cd
        ,coalesce(conv.new_sls_hier_division_desc, src.sls_hier_division_desc) AS sls_hier_division_desc
        ,coalesce(conv.new_sls_hier_category_desc, src.sls_hier_category_desc) AS sls_hier_category_desc
        ,coalesce(conv.new_sls_hier_sub_category_desc, src.sls_hier_sub_category_desc) AS sls_hier_sub_category_desc
        ,coalesce(conv.new_sls_hier_ppg_desc, src.sls_hier_ppg_desc) AS sls_hier_ppg_desc
        ,coalesce(conv.new_base_product_cd, src.base_product_cd) AS base_product_cd
        ,coalesce(conv.new_base_product_desc, src.base_product_desc) AS base_product_desc
        ,coalesce(conv.new_material_cd, src.material_cd) AS material_cd
        ,coalesce(conv.new_material_short_desc, src.material_short_desc) AS material_short_desc
        ,coalesce(conv.new_material_nbr, src.material_nbr) AS material_nbr
        ,src.sls_hier_division_desc AS old_sls_hier_division_desc
        ,src.sls_hier_category_desc AS old_sls_hier_category_desc
        ,src.sls_hier_sub_category_desc AS old_sls_hier_sub_category_desc
        ,src.sls_hier_ppg_desc AS old_sls_hier_ppg_desc
        ,src.base_product_cd AS old_base_product_cd
        ,src.base_product_desc AS old_base_product_desc
        ,src.material_cd AS old_material_cd
        ,src.material_nbr AS old_material_nbr
        ,src.ean_upc_cd AS old_ean_upc_cd
        ,src.material_short_desc AS old_material_short_desc
        ,src.gph_hier_top_desc
        ,src.gph_hier_family_desc
        ,src.gph_hier_category_desc
        ,src.gph_hier_flavor_format_desc
        ,src.gph_hier_package_size_desc
        ,src.base_uom_to_eqc_fctr
        ,src.base_uom_to_ecv_fctr
        ,src.all_cd
        ,src.all_desc
        ,src.sls_hier_sub_category_desc_ly
        ,src.sls_hier_division_desc_ly
        ,src.sls_hier_category_desc_ly
        ,src.bph1_hier_bph20_desc
        ,src.bph1_hier_bph30_desc
        ,src.bph1_hier_bph40_desc
        ,src.bph1_hier_bph50_desc
        ,src.bph1_hier_bph60_desc
        ,src.bph1_hier_bph70_desc
        ,src.material_type_cd
        ,src.sls_hier_division_cd
        ,src.sls_hier_category_cd
        ,src.sls_hier_sub_category_cd
        ,src.sls_hier_accrual_group_cd
        ,src.sls_hier_ppg_cd
        ,src.gph_hier_top_cd
        ,src.gph_hier_family_cd
        ,src.gph_hier_category_cd
        ,src.gph_hier_flavor_format_cd
        ,src.gph_hier_package_size_cd
        ,src.ean_upc_derived_cd
        ,src.hier_cd
        ,src.language_cd
        ,src.version_cd
        ,src.hier_level_cd
        ,src.divested_fg
        ,src.is_gmi_flag
        ,src.created_by
        ,src.created_datetime
        ,src.modified_by
        ,src.modified_datetime
    FROM `""",BQ_PROJECT_NAME,""".""",BQ_TRANSIENT_DATASET_NAME,""".""",BQ_SOURCE_TABLE_NAME,"""` src
      LEFT JOIN
        `""" ,BQ_PROJECT_NAME,""".""",BQ_PROCESSED_DATASET_NAME,""".""",BQ_INTER_TABLE_NAME,"""` conv
        on ltrim(conv.old_ean_upc_cd, '0') = ltrim(src.ean_upc_cd, '0')
""");

EXCEPTION WHEN ERROR THEN
        EXECUTE IMMEDIATE CONCAT(
            """INSERT INTO processed.ecomm_admin_sproc_error_details (
		        SELECT
			        '""",FEED_NAME,"""' AS FEED_NAME,
                    split(split(@@error.formatted_stack_trace,'transient.')[OFFSET (1)],'[')[OFFSET(0)],
			        @@error.statement_text,
			        @@error.message,
			        current_timestamp()
	        );
	    """);

	    SELECT
	        ERROR (
	            CONCAT(
	            		@@error.message ,' ' ,
	            		@@error.statement_text, ' ' ,
	            		@@error.formatted_stack_trace ,' '
	            	)
	        );

END;