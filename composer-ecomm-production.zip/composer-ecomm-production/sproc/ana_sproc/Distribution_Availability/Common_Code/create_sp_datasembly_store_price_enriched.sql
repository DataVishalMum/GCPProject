/*
Purpose of the stored proc:

    Loads data from Source tables into enriched table which will be used as a source for downstream applications.
	
History of Changes:
	02/08/22 – first version

Author : 
	Shubham Saxena

*/

CREATE OR REPLACE PROCEDURE transient.ecomm_sproc_datasembly_store_price_enriched
(
 SRC_PROJECT STRING,
 SRC_DATASET STRING,
 SRC_TABLE STRING,
 INTERMEDIATE_TABLE STRING,
 SRC_LOOKUP_PROJECT STRING,
 SRC_LOOKUP_DATASET STRING,
 SRC_LOOKUP_TABLE STRING,
 DEST_PROJECT STRING,
 DEST_DATASET STRING,
 DEST_TABLE STRING,
 FEED_NAME STRING
 )
OPTIONS (description="""

 How to call:

     CALL transient.ecomm_sproc_datasembly_store_price_enriched (
        "shareddata-prd-cb5872", -- SRC_PROJECT
        "shared_data_srm", -- SRC_DATASET
        "datasembly_store", -- SRC_TABLE
        "datasembly_store_price", -- INTERMEDIATE_TABLE
        "edw-prd-e567f9", -- SRC_LOOKUP_PROJECT
        "enterprise", -- SRC_LOOKUP_DATASET
        "dim_date", -- SRC_LOOKUP_TABLE
        "ecomm-dlf-dev-01cd47", -- DEST_PROJECT
        "transient", -- DEST_DATASET
        "ecom_datasembly_store_price_enriched", -- DEST_TABLE
        "DATASEMBLY_STORE_PRICE_ENRICHED" -- FEED_NAME
	)
""")
BEGIN

EXECUTE IMMEDIATE CONCAT("""TRUNCATE TABLE `""",DEST_PROJECT,""".""",DEST_DATASET,""".""",DEST_TABLE,"""`;""");

EXECUTE IMMEDIATE CONCAT("""INSERT INTO `""",DEST_PROJECT,""".""",DEST_DATASET,""".""",DEST_TABLE,"""`
    SELECT
      SAFE_CAST(dsp.report_date AS DATE) AS report_date,
      CASE
        WHEN DATE(dsp.report_date)<=DATE_ADD(DATE(dsp.source_file_name_dt),INTERVAL 6 DAY) THEN DATE_ADD(DATE(dsp.report_date), INTERVAL 1 DAY)
        ELSE DATE(dsp.report_date)
      END AS report_date2,
      UPPER(ds.chain_nm) AS customer_name, ##  case statement moved into materialized views,
      dsp.upc_cd AS upc,
      dsp.sku,
      dsp.banner_id,
      dsp.host,
      dsp.channel_method_desc,
      dsp.store_id,
      SAFE_CAST(dsp.store_inferred_fg AS BOOL) AS store_inferred_fg,
      ##dsp.country,
      dsp.postal_cd,
      dsp.in_stock,
      CASE
        WHEN LOWER(dsp.in_stock) = 'true' THEN TRUE
        WHEN LOWER(dsp.in_stock) = 'false' THEN FALSE
        END AS stock_flg,
      dsp.price_0_price,
      dsp.price_0_multiple,
      dsp.price_0_unit_price,
      dsp.price_0_unit_price_units,
      dsp.price_0_unit_price_multiple,
      SAFE_CAST(dsp.price_0_sold_per_unit AS BOOL) AS price_0_sold_per_unit,
      SAFE_CAST(dsp.price_0_in_store_price AS BOOL) AS price_0_in_store_price,
      SAFE_CAST(dsp.price_0_promotion AS BOOL) AS price_0_promotion,
      SAFE_CAST(dsp.price_0_loyalty AS BOOL) AS price_0_loyalty,
      SAFE_CAST(dsp.price_0_rollback AS BOOL) AS price_0_rollback,
      SAFE_CAST(dsp.price_0_clearance AS BOOL) AS price_0_clearance,
      dsp.price_0_membership,
      dsp.price_0_currency,
      dsp.price_1_price,
      dsp.price_1_multiple,
      dsp.price_1_unit_price,
      dsp.price_1_unit_price_units,
      dsp.price_1_unit_price_multiple,
      SAFE_CAST(dsp.price_1_sold_per_unit AS BOOL) AS price_1_sold_per_unit,
      SAFE_CAST(dsp.price_1_in_store_price AS BOOL) AS price_1_in_store_price,
      SAFE_CAST(dsp.price_1_promotion AS BOOL) AS price_1_promotion,
      SAFE_CAST(dsp.price_1_loyalty AS BOOL) AS price_1_loyalty,
      SAFE_CAST(dsp.price_1_rollback AS BOOL) AS price_1_rollback,
      SAFE_CAST(dsp.price_1_clearance AS BOOL) AS price_1_clearance,
      dsp.price_1_membership,
      dsp.price_1_currency,
      dsp.category,
      --dsp.source_file_version_nbr,
      --dsp.source_file_suffix_cd,
      --dsp.source_file_year_nbr,
      SAFE_CAST(dsp.source_file_name_dt AS DATE) AS source_file_name_dt,
      dsp.source_file_name_dt AS rctl_file_name,
      SAFE_CAST(dsp.source_file_name_dt AS DATE) AS file_dt,
      dsp.runid,
      TIMESTAMP_SECONDS(CAST(dsp.runid/1000 AS int64)) ingest_date,
      ds.chain_nm,
      ds.banner_nm AS banner,
      CASE
        WHEN SAFE_CAST(ds.store_number AS INT64) IS NULL THEN '00000000'
      ELSE
      ds.store_number
    END
      store_number,
      ds.address_desc AS store_street_address,
      INITCAP(ds.city_nm) AS store_city,
      ds.state_cd AS store_state,
      ds.postal_cd AS store_zipcode,
      ds.country_cd AS store_country,
      ds.latitude_nbr AS store_latitude,
      ds.longitude_nbr AS store_longitude,
      SAFE_CAST(ds.store_operational_fg AS BOOL) AS store_operational_fg,
      ##ds.updated_date,
      SAFE_CAST(ds.channel_pickup AS BOOL) AS channel_pickup,
      SAFE_CAST(ds.channel_local_delivery AS BOOL) AS channel_local_delivery,
      SAFE_CAST(ds.channel_in_store AS BOOL) AS channel_in_store,
      --ds.source_file_version_nbr,
      --ds.source_file_suffix_cd,
      --ds.source_file_year_nbr,
      --ds.source_file_name_dt,
      --ds.runid,
      cal.date_sk,
      cal.fiscal_year_week_nbr,
      cal.fiscal_month_in_year_nbr,
      cal.fiscal_year_nbr,
      cal.fiscal_week_in_year_nbr,
      cal.fiscal_week_begin_dt,
      cal.fiscal_year_month_nbr,
      CURRENT_DATETIME AS created_datetime,
      NULL AS created_by,
      CURRENT_DATETIME AS modified_datetime,
      NULL AS modified_by,
      NULL AS rnk
    FROM
      `""",SRC_PROJECT,""".""",SRC_DATASET,""".""",INTERMEDIATE_TABLE,"""` dsp
    INNER JOIN
      `""",SRC_PROJECT,""".""",SRC_DATASET,""".""",SRC_TABLE,"""` ds
    ON
      dsp.banner_id = ds.banner_id
      AND dsp.store_id = ds.store_id
    INNER JOIN
      `""",SRC_LOOKUP_PROJECT,""".""",SRC_LOOKUP_DATASET,""".""",SRC_LOOKUP_TABLE,"""` cal
    ON
      (CASE
        WHEN DATE(dsp.report_date)<=DATE_ADD(DATE(dsp.source_file_name_dt),INTERVAL 6 DAY) THEN DATE_ADD(DATE(dsp.report_date), INTERVAL 1 DAY)
        ELSE DATE(dsp.report_date) END) = cal.fiscal_dt
      AND cal.language_cd = 'EN'
      AND cal.fiscal_year_variant_cd = '07'
    WHERE
      1=1
      AND DATE(CAST(dsp.report_date AS DATE)) BETWEEN DATE_SUB(CURRENT_DATE(), INTERVAL 60 DAY) AND CURRENT_DATE()
      AND dsp.upc_cd IS NOT NULL;
""");

EXCEPTION WHEN ERROR THEN
        EXECUTE IMMEDIATE CONCAT(
            """INSERT INTO processed.ecomm_admin_sproc_error_details (
		        SELECT
			        '""",FEED_NAME,"""' AS FEED_NAME,
                    split(split(@@error.formatted_stack_trace,'transient.')[OFFSET (1)],'[')[OFFSET(0)],
			        @@error.statement_text,
			        @@error.message,
			        current_timestamp()
	        );
	    """);

	    SELECT
	        ERROR (
	            CONCAT(
	            		@@error.message ,' ' ,
	            		@@error.statement_text, ' ' ,
	            		@@error.formatted_stack_trace ,' '
	            	)
	        );

END;