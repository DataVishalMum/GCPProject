/*
  Purpose OF the stored proc :
		Consolidated Product Temp TABLE DATA insertion
  History OF Changes :
	05/17/21 - first version
	03/15/22 - adding the old product attributes which are now inserted in an earlier UPC conversion step and removing
	un-needed fiscal calendar attributes (Nelson W.)
	06/28/22 - Changes related to composer work
  Author :
		Shubham Saxena
*/

CREATE OR REPLACE PROCEDURE transient.ecomm_sproc_ana_common_distribution_fact
(
    SRC_PROJECT STRING,
    SRC_DATASET STRING,
    DEST_DATASET STRING,
    INTERMEDIATE_PROJECT STRING,
    INTERMEDIATE_DATASET STRING,
	INTERMEDIATE_TABLE STRING,
    DEST_TABLE STRING,
    SRC_TABLE STRING,
    SOURCE_LOOKUP_TABLE STRING,
	FEED_NAME STRING
)
OPTIONS(
description = """

How to call:

CALL transient.ecomm_sproc_ana_common_distribution_fact
(
'ecomm-dlf-dev-01cd47', -- SRC_PROJECT
'transient',            -- SRC_DATASET
'processed',            -- DEST_DATASET
'edw-prd-e567f9',       -- INTERMEDIATE_PROJECT
'enterprise',			-- INTERMEDIATE_DATASET
'dim_product_active'    -- INTERMEDIATE_TABLE
'stop_and_shop_datasembly_fact', --DEST_TABLE
'stop_and_shop_datasembly_processed_zero', -- SRC_TABLE
'stop_and_shop_datasembly_product_upc_converted', -- SOURCE_LOOKUP_TABLE
'stop_and_shop'          --FEED_NAME
)
"""
)
BEGIN
DECLARE JOB_RUN_ID DEFAULT 999999;
DECLARE BQ_PROJECT_NAME DEFAULT SRC_PROJECT;
DECLARE BQ_TRANSIENT_DATASET_NAME DEFAULT SRC_DATASET;
DECLARE BQ_PROCESSED_DATASET_NAME DEFAULT DEST_DATASET;
DECLARE BQ_EDW_PROJECT_NAME DEFAULT INTERMEDIATE_PROJECT;
DECLARE BQ_ENTERPRISE_DATASET_NAME DEFAULT INTERMEDIATE_DATASET;
DECLARE BQ_INTER_TABLE_NAME DEFAULT INTERMEDIATE_TABLE;
DECLARE BQ_TARGET_TABLENAME DEFAULT DEST_TABLE;
DECLARE BQ_PROCESSED0_TEMP_TABLENAME DEFAULT SRC_TABLE;
DECLARE BQ_PRODUCT_TEMP_TABLENAME DEFAULT SOURCE_LOOKUP_TABLE;

DECLARE UPC_COL STRING;
-- Instore tables has 'gmi_upc'  as the UPC column.

SET FEED_NAME = UPPER(FEED_NAME);

EXECUTE IMMEDIATE  CONCAT("""   WITH
  dr AS (
  SELECT
    COUNT(*) cnt
  FROM
    """,BQ_TRANSIENT_DATASET_NAME,""".INFORMATION_SCHEMA.COLUMNS
  WHERE
    table_name = '""",BQ_PROCESSED0_TEMP_TABLENAME,"""'
    AND column_name = 'gmi_upc')
SELECT
  CASE
    WHEN cnt = 0 THEN 'upc'
  ELSE
  'gmi_upc'
END
FROM
  dr""") INTO UPC_COL;

-- Truncate Consolidate Product Temp TABLE
EXECUTE IMMEDIATE
  CONCAT("""TRUNCATE TABLE  `""",BQ_PROJECT_NAME,"""`.""",BQ_PROCESSED_DATASET_NAME,""".""",BQ_TARGET_TABLENAME);


-- INSERT details INTO Customer specific Consolidate product temp TABLE
-- Enriching source table with the required columns of the product table

EXECUTE IMMEDIATE
  CONCAT( """INSERT INTO  `""",BQ_PROJECT_NAME,"""`.""",BQ_PROCESSED_DATASET_NAME,""".""",BQ_TARGET_TABLENAME,""" (
     SELECT
      fact_sk
      ,dim.material_sk
      ,date_sk
      ,processed0.* except (fact_sk,date_sk,created_by,created_datetime,modified_by,modified_datetime)
      ,product.base_product_cd
      ,product.base_product_desc
      ,product.material_cd
      ,product.material_short_desc
      ,product.material_nbr
      ,product.ean_upc_cd
      ,product.sls_hier_division_desc
      ,product.sls_hier_category_desc
      ,product.sls_hier_sub_category_desc
      ,product.sls_hier_ppg_desc
      ,product.old_base_product_cd
      ,product.old_base_product_desc
      ,product.old_material_cd
      ,product.old_material_short_desc
      ,product.old_material_nbr
      ,product.old_ean_upc_cd
      ,product.old_sls_hier_division_desc
      ,product.old_sls_hier_category_desc
      ,product.old_sls_hier_sub_category_desc
      ,product.old_sls_hier_ppg_desc
      ,CAST(""",JOB_RUN_ID,""" AS string) AS created_by
      ,CURRENT_DATETIME AS created_datetime
      ,CAST(""",JOB_RUN_ID,""" AS string) AS modified_by
      ,CURRENT_DATETIME AS modified_datetime
    FROM
      `""",BQ_PROJECT_NAME,"""`.""",BQ_TRANSIENT_DATASET_NAME,""".""",BQ_PROCESSED0_TEMP_TABLENAME,""" processed0
    LEFT JOIN
      `""",BQ_PROJECT_NAME,"""`.""",BQ_TRANSIENT_DATASET_NAME,""".""",BQ_PRODUCT_TEMP_TABLENAME,""" product
    ON
      processed0.""",UPC_COL,""" = product.upc
    LEFT JOIN `""",BQ_EDW_PROJECT_NAME,"""`.""",BQ_ENTERPRISE_DATASET_NAME,""".""",BQ_INTER_TABLE_NAME,""" dim
    ON product.material_nbr = dim.material_nbr
    AND product.material_type_cd = dim.material_type_cd
    AND product.language_cd = dim.language_cd

    -- We only need below 3 sls divisions to process all DnA retailers. (We are doing the same in hadoop)

    WHERE UPPER(product.sls_hier_division_desc) in ('MORNING FOODS','MEALS-BAKING','SNACKS')
    )
""") ;

EXCEPTION WHEN ERROR THEN
        EXECUTE IMMEDIATE CONCAT(
            """INSERT INTO processed.ecomm_admin_sproc_error_details (
		        SELECT
			        '""",FEED_NAME,"""' AS FEED_NAME,
                    split(split(@@error.formatted_stack_trace,'transient.')[OFFSET (1)],'[')[OFFSET(0)],
			        @@error.statement_text,
			        @@error.message,
			        current_timestamp()
	        );
	    """);

	    SELECT
	        ERROR (
	            CONCAT(
	            		@@error.message ,' ' ,
	            		@@error.statement_text, ' ' ,
	            		@@error.formatted_stack_trace ,' '
	            	)
	        );

END;