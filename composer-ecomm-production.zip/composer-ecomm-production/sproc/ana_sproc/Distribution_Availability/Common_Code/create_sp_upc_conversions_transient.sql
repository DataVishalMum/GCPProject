/*
Purpose of the stored proc: 
	Create a table of converted upc's with their new ean, old ean, and conversions date
History of Changes (date format: mm/dd/yy):
	05/28/21 – first version 
    07/14/21 - Changed references to enterprise project
    11/29/21 - Changed all transient dataset references to reference processed layer instead
    12/14/21 - Added parameters for transient dataset and table name, and added union statement to pull records
               from this table in final select (to be updated bi-yearly manually)
Author : 
	Kaia Arthur
How to Call:
		call transient.sp_upc_conversions
		(
		 99,
		'ecomm-dlf-dev-01cd47',
		'processed',
        'edw-prd-e567f9',
        'enterprise',
		'dim_upc_conversions',
        'transient',
        'upc_conversions'
		)

*/

CREATE OR REPLACE PROCEDURE transient.sp_upc_conversions
( 
	job_run_id INT64,
	bq_project_name string,
	bq_processed_dataset_name string,
    bq_enterprise_project_name string,
    bq_enterprise_dataset_name string,
	bq_processed_table_name string,
	bq_transient_dataset_name string,
	bq_transient_table_name string
)
BEGIN

/* Delta Temp Table is Truncate & Load */
EXECUTE IMMEDIATE
CONCAT("""TRUNCATE TABLE  `""" ,bq_project_name,"""`.""",bq_processed_dataset_name,""".""",bq_processed_table_name);

EXECUTE IMMEDIATE
CONCAT(
"""insert into  `""" ,bq_project_name,"""`.""",bq_processed_dataset_name,""".""",bq_processed_table_name,"""
( 
with conversions as (
    select max(newProd.start_ship_dt) conversion_date,
        oldProdHier.child_material_cd old_material_cd,
        newProdHier.child_material_cd new_material_cd
    from `""" ,bq_enterprise_project_name,"""`.""",bq_enterprise_dataset_name,""".dim_product_active newProd
    join `""" ,bq_enterprise_project_name,"""`.""",bq_enterprise_dataset_name,""".dim_product_relationship_linkage_vert_na newProdHier 
        on (newProd.material_cd = newProdHier.parent_material_cd and newProd.language_cd = newProdHier.language_cd) --join to get the child packages for the new case
    left join `""" ,bq_enterprise_project_name,"""`.""",bq_enterprise_dataset_name,""".dim_product_active oldProd 
        on (lpad(newProd.conversion_base_product_cd, 18, '0') = oldProd.material_cd and newProd.language_cd = oldProd.language_cd) --STEP didn't put leading 0's on the conversion code, so use the material_nbr to remove leading 0's
    left join `""" ,bq_enterprise_project_name,"""`.""",bq_enterprise_dataset_name,""".dim_product_relationship_linkage_vert_na oldProdHier 
        on (oldProd.material_cd = oldProdHier.parent_material_cd and oldProd.language_cd = oldProdHier.language_cd and newProdHier.child_level_nbr = oldProdHier.child_level_nbr) --join to get the packages for the old case.
    where newProd.language_cd = 'EN' --filter on just the new because we're going to the conversion table
      and newProd.material_type_cd = 'FINI'
      and newProd.conversion_base_product_cd is not null
      and newProd.publish_to_pricelist_flg = 'Y' 
      and newProd.ci_launch_type_cd = 'RSZCONV'
      and newProd.ean_upc_cd != oldProd.ean_upc_cd
    group by newProdHier.child_material_cd,
        oldProdHier.child_material_cd
),
newest as (
    select p.ean_upc_cd as old_ean_upc_cd,
    p2.ean_upc_cd as new_ean_upc_cd,
    c.conversion_date,
    row_number() over (partition by p.ean_upc_cd order by c.conversion_date desc) as most_recent_conversion
    from conversions c
    inner join `""" ,bq_enterprise_project_name,"""`.""",bq_enterprise_dataset_name,""".dim_product_active p on c.old_material_cd = p.material_cd and p.language_cd = 'EN'
    inner join `""" ,bq_enterprise_project_name,"""`.""",bq_enterprise_dataset_name,""".dim_product_active p2 on c.new_material_cd = p2.material_cd and p2.language_cd = 'EN'
    where p.ean_upc_cd != p2.ean_upc_cd
)
    select distinct
        old_ean_upc_cd,
        new_ean_upc_cd,
        conversion_date
    from newest
    where most_recent_conversion = 1
    union all
    select distinct
        old_ean_upc_cd,
        new_ean_upc_cd,
        conversion_date
    from `""",bq_project_name,"""`.""",bq_transient_dataset_name,""".""",bq_transient_table_name,"""
)
""");

EXCEPTION WHEN ERROR THEN
    SELECT  
	ERROR (
		CONCAT(
    			@@error.message ,' ' ,
    			@@error.statement_text, ' ' ,
    			@@error.formatted_stack_trace ,' '
			)
		)
	;

END;