/*
Purpose of the stored proc: 
	/*
    Add distribution and availability metric columns needed for aggregation, join data with customer xref and calculate consecutive missing weeks logic

History of Changes:
	05/27/21 – first version 
    07/12/21 - Added farm_fingerprint to improve performance
    11/17/21 - Updates to consecutive missing weeks logic
    03/15/22 - Removed UPC conversions logic as this is now done in an earlier sproc, added old product attributes from earlier sproc, and removed
    unneeded fiscal calendar attributes (Nelson W.)
    3/18/22 - Update to consecutive missing weeks logic to reset count when there are no instore sales for upc/store that has been ever online
	06/29/22 - Changes related to composer work

Author :
	Shubham Saxena
*/

CREATE OR REPLACE PROCEDURE transient.ecomm_sproc_ana_common_distribution_availability_with_upc
(
	SRC_PROJECT STRING,
	SRC_LOOKUP_DATASET STRING,
    SRC_DATASET STRING,
    DEST_DATASET STRING,
	SOURCE_LOOKUP_TABLE STRING,
	DEST_TABLE STRING,
    SRC_TABLE STRING,
	FEED_NAME STRING
)
OPTIONS(
description = """

How to Call:
call transient.ecomm_sproc_ana_common_distribution_availability_with_upc
(
'ecomm-dlf-dev-01cd47',
'raw',
'transient',
'processed',
'lkp_customer',
'stop_and_shop_distribution_availability_with_upc_fact',
'stop_and_shop_distribution_availability_smoothed_fact',
'stop_and_shop'
)
"""
)

BEGIN
DECLARE JOB_RUN_ID DEFAULT 999999;
DECLARE BQ_PROJECT_NAME DEFAULT SRC_PROJECT;
DECLARE BQ_RAW_DATASET_NAME DEFAULT SRC_LOOKUP_DATASET;
DECLARE BQ_TRANSIENT_DATASET_NAME DEFAULT SRC_DATASET;
DECLARE BQ_PROCESSED_DATASET_NAME DEFAULT DEST_DATASET;
DECLARE BQ_LOOKUP_SOURCE_NAME DEFAULT SOURCE_LOOKUP_TABLE;
DECLARE BQ_PROCESSED_TABLE_NAME DEFAULT DEST_TABLE;
DECLARE BQ_SOURCE_TABLE_NAME DEFAULT SRC_TABLE;

-- declare variables
DECLARE
	 EXTRACT_START_DATE
	,EXTRACT_END_DATE TIMESTAMP;

SET FEED_NAME = UPPER(FEED_NAME);

/* Get Extract start datetime for incoming table from data_extract_config table */
EXECUTE IMMEDIATE
  CONCAT("""select extract_start_datetime from `""",BQ_PROJECT_NAME,"""`.""",BQ_TRANSIENT_DATASET_NAME,""".""","""data_extract_config
where table_name = '""",BQ_SOURCE_TABLE_NAME,"""' and status = 'running'
and active_flag = 'Y'""") INTO EXTRACT_START_DATE;

/* Get Extract end datetime for incoming table from data_extract_config table */
EXECUTE IMMEDIATE
  CONCAT("""select extract_end_datetime from `""",BQ_PROJECT_NAME,"""`.""",BQ_TRANSIENT_DATASET_NAME,""".""", """data_extract_config
  where table_name = '""",BQ_SOURCE_TABLE_NAME,"""' and status = 'running'  and active_flag = 'Y'""") INTO EXTRACT_END_DATE;

EXECUTE IMMEDIATE
CONCAT(
"""merge  `""" ,BQ_PROJECT_NAME,"""`.""",BQ_PROCESSED_DATASET_NAME,""".""",BQ_PROCESSED_TABLE_NAME,""" tgt using
(
with distribution_exists as (
    select ean_upc_cd
          ,banner
          ,min(fiscal_week_begin_dt) earliest_week_scraped
          ,TRUE online_distribution_exists_flg
    from `""" ,BQ_PROJECT_NAME,"""`.""",BQ_PROCESSED_DATASET_NAME,""".""",BQ_SOURCE_TABLE_NAME,"""
    where is_online = 1
    group by ean_upc_cd, banner
    having min(fiscal_week_begin_dt) is not null
),
-- get max fiscal date for each customer/store/upc combination - to be used in consecutive missing weeks calc to determine
-- which record the consecutive missing weeks value should be assigned to
max_src_upc_weeks as (
    select customer_name
           ,unique_store_composite_key
           ,ean_upc_cd
           ,max(fiscal_week_begin_dt) max_dt
     from `""" ,BQ_PROJECT_NAME,"""`.""",BQ_PROCESSED_DATASET_NAME,""".""",BQ_SOURCE_TABLE_NAME,"""
     group by customer_name
              ,unique_store_composite_key
              ,ean_upc_cd
),

combined_src as (
    select
        FARM_FINGERPRINT(CONCAT(src.ean_upc_cd,src.unique_store_composite_key,CAST(src.fiscal_week_begin_dt AS STRING),src.old_ean_upc_cd)) withupckey_fingerprint
        ,store_number
        ,src.banner
        ,store_street_address
        ,store_city
        ,store_state
        ,store_zipcode
        ,division
        ,upc_cd
        ,src.unique_store_composite_key
        ,src.sls_hier_division_desc
        ,src.sls_hier_category_desc
        ,src.sls_hier_sub_category_desc
        ,src.sls_hier_ppg_desc
        ,src.base_product_cd
        ,src.base_product_desc
        ,src.material_cd
        ,src.material_nbr
        ,src.ean_upc_cd
        ,src.material_short_desc
        ,src.old_sls_hier_division_desc
        ,src.old_sls_hier_category_desc
        ,src.old_sls_hier_sub_category_desc
        ,src.old_sls_hier_ppg_desc
        ,src.old_base_product_cd
        ,src.old_base_product_desc
        ,src.old_material_cd
        ,src.old_material_nbr
        ,src.old_ean_upc_cd
        ,src.old_material_short_desc
        ,is_online
        ,is_smoothed
        ,stock_flg
        ,is_available
        ,de.online_distribution_exists_flg
        ,is_instore
        ,authorization_flg
        ,fiscal_year_week_nbr
        ,fiscal_month_in_year_nbr
        ,fiscal_year_nbr
        ,fiscal_week_in_year_nbr
        ,fiscal_week_begin_dt
        ,fiscal_year_month_nbr
        ,src.customer_name
        ,case when is_instore=1 and authorization_flg != FALSE then 1 else 0 end is_instore_distribution
        ,case when is_instore=1 and authorization_flg = TRUE then 1 else 0 end is_instore_distribution_authorized
        ,case when is_instore=1 and authorization_flg = FALSE then 1 else 0 end is_instore_distribution_not_authorized
        ,case when is_online=1 then 1 else 0 end is_online_distribution
        ,case when is_online=1 and is_instore=1 and authorization_flg = TRUE then 1 else 0 end is_online_distribution_authorized
        ,case when is_online=1 and is_instore=1 and authorization_flg = FALSE then 1 else 0 end is_online_distribution_not_authorized
       ,case when src.customer_name in ('KROGER', 'INSTACART_KROGER') and length(src.store_number) > 3 then concat(regexp_replace(substring(src.store_number,1, 3), '^0*', ''),
                    ' ', src.division,
                    ' - ',
                    regexp_replace(substring(src.store_number,-5, 5), '^0*', ''))
                when src.customer_name in ('KROGER', 'INSTACART_KROGER') and length(src.store_number) <= 3 then concat(cast(src.division as int), ' ', src.division, ' - ', src.store_number)
                when src.customer_name = 'INSTACART' then concat(src.banner,' - ',store_zipcode)
                else concat(src.banner,' - ',store_number)
            end store_display_name
        ,'Brick and Mortar' retailer_type
        , cust.country
        , cust.segment
        , cust.customer_desc
        , cust.customer_parent
        , cust.customer_account
        ,case when src.store_zipcode is null then 0
                when length(src.store_zipcode) = 5 then 2 -- 5 digit zip codes are preferred
                else 1
           end store_zipcode_score
    from `""" ,BQ_PROJECT_NAME,"""`.""",BQ_PROCESSED_DATASET_NAME,""".""",BQ_SOURCE_TABLE_NAME,""" src
    left join `""" ,BQ_PROJECT_NAME,"""`.""",BQ_TRANSIENT_DATASET_NAME,""".""",BQ_LOOKUP_SOURCE_NAME,""" cust
        on cust.customer_name = src.customer_name
    left join distribution_exists de
        on de.ean_upc_cd = src.ean_upc_cd
        and de.banner = src.banner
    left join max_src_upc_weeks mxu
        on mxu.customer_name = src.customer_name
       and mxu.unique_store_composite_key = src.unique_store_composite_key
       and mxu.ean_upc_cd = src.ean_upc_cd
    -- logic for incremental - either modified within the last run OR is the most recent fiscal week for that store/upc
    where ((EXTRACT(DATE FROM src.modified_datetime)  > CAST(SUBSTRING('""",EXTRACT_START_DATE,"""',0,10) AS DATE)
        and EXTRACT(DATE FROM src.modified_datetime)   <= CAST(SUBSTRING('""",EXTRACT_END_DATE,"""',0,10) AS DATE))
        or mxu.max_dt = src.fiscal_week_begin_dt)
),

-- get max fiscal week for each customer; needed for consecutive_missing_weeks calcs
max_weeks as (
    select customer_name, max(fiscal_week_begin_dt) max_dt
      from combined_src src
     group by customer_name
),
-- get max fiscal date for each customer/store/upc combination - to be used in consecutive missing weeks calc to determine
-- which record the consecutive missing weeks value should be assigned to
max_upc_weeks as (
    select customer_name
           ,unique_store_composite_key
           ,ean_upc_cd
           ,max(fiscal_week_begin_dt) max_dt
     from combined_src
     group by customer_name
              ,unique_store_composite_key
              ,ean_upc_cd
),

-- create a flag in the data for when the online distribution is missing - will be used to pull the max flagged fiscal week
last_acceptable_weeks as (
    select src.customer_name
          ,src.ean_upc_cd
          ,src.unique_store_composite_key
          ,src.fiscal_week_begin_dt
          ,case when src.is_online is null
           then 1 else 0
           end as missing_wk_flg
      from combined_src src
),

-- pull the most recent week for each store/upc combo where the missing week flag is 0
-- (which means that online distribution is present)
max_unflagged_fiscal_wk as (
    select customer_name
           ,ean_upc_cd
           ,unique_store_composite_key
           ,max(fiscal_week_begin_dt) as max_present_wk
    from last_acceptable_weeks
    where missing_wk_flg = 0
    group by customer_name
             ,ean_upc_cd
             ,unique_store_composite_key
),

--for upc/store/week combos where item is instore but not online,
--create a field for the fiscal_week_begin_dt of the previous week if there were no instore sales
--(which means that there will not be a row for that week in the data)
--captures weeks that are missing from the data so that they will not be included in consecutive_missing_weeks
last_not_instore_weeks as (
        select src.customer_name
          ,src.ean_upc_cd
          ,src.unique_store_composite_key
          ,src.fiscal_week_begin_dt
          ,case when src_past.is_instore is null
           then date_sub(src.fiscal_week_begin_dt, INTERVAL 1 WEEK)
           else null
           end as not_instore_wk
      from combined_src src
      left join combined_src src_past
      on src.customer_name = src_past.customer_name
      and src.ean_upc_cd = src_past.ean_upc_cd
      and src.unique_store_composite_key = src_past.unique_store_composite_key
      and date_sub(src.fiscal_week_begin_dt, INTERVAL 1 WEEK) = src_past.fiscal_week_begin_dt
    where src.is_online is null
          and src.is_instore = 1
          ),

--pull the most recent not_instore_wk
--which means the most recent week when there were no instore sales
max_not_instore_fiscal_wk as (
    select customer_name
           ,ean_upc_cd
           ,unique_store_composite_key
           ,max(not_instore_wk) as max_not_instore_wk
    from last_not_instore_weeks
    group by customer_name
             ,ean_upc_cd
             ,unique_store_composite_key
),

--if the item has ever been online for a given store, pull the most recent week when online distribution is present OR the item was not instore
--if the item has never been online for a given store, returns null
max_nonmissing_assortment_wk as (
select mufw.customer_name
        ,mufw.ean_upc_cd
        ,mufw.unique_store_composite_key
        ,greatest(coalesce(mni.max_not_instore_wk, '1800-01-01'), mufw.max_present_wk) max_nonmissing_wk
from max_unflagged_fiscal_wk mufw
left join max_not_instore_fiscal_wk mni
on mni.unique_store_composite_key = mufw.unique_store_composite_key
and mni.ean_upc_cd = mufw.ean_upc_cd
and mni.customer_name = mufw.customer_name
),

-- pull min fiscal week for each customer/store/upc combination, to be used when there is no max unflagged fiscal week value
-- (which means that no records have online distribution for a particular customer/store/upc combination)
min_flagged_fiscal_wk as (
    select customer_name
           ,ean_upc_cd
           ,unique_store_composite_key
           ,min(fiscal_week_begin_dt) as min_missing_wk
    from last_acceptable_weeks
    where missing_wk_flg = 1
    group by customer_name
             ,ean_upc_cd
             ,unique_store_composite_key
),

-- calculate dates used for missing weeks calculation:
-- max_nonmissing_wk - last time online distribution was found, looks for most recent date between incremental load data and target table (if neither found, evaluates
-- to null - '1800-01-01' used as placeholder date so that greatest function doesn't return null value
-- min_missing_wk - if no max_nonmissing_wk, coalesces target table and incremental value for minimum flagged week (target table value will always be less)
missing_weeks_raw as (
    select src.customer_name
          ,src.ean_upc_cd
          ,src.unique_store_composite_key
          ,nullif(greatest(coalesce(tgt.max_nonmissing_wk, '1800-01-01'), coalesce(mnaw.max_nonmissing_wk, '1800-01-01')),'1800-01-01') as max_nonmissing_wk
          ,CASE WHEN mnaw.max_nonmissing_wk IS NULL
                THEN COALESCE(tgt.min_missing_wk, mff.min_missing_wk)
           END AS min_missing_wk
          ,mw.max_dt as max_retailer_dt
          ,maxw.max_dt as max_upc_dt
      from combined_src src
      join max_weeks mw
        on mw.customer_name = src.customer_name
      join max_upc_weeks maxw
        on maxw.customer_name = src.customer_name
       and maxw.ean_upc_cd = src.ean_upc_cd
       and maxw.unique_store_composite_key = src.unique_store_composite_key
      left join max_nonmissing_assortment_wk mnaw
        on mnaw.customer_name = src.customer_name
       and mnaw.ean_upc_cd = src.ean_upc_cd
       and mnaw.unique_store_composite_key = src.unique_store_composite_key
      left join min_flagged_fiscal_wk mff
        on mff.customer_name = src.customer_name
       and mff.ean_upc_cd = src.ean_upc_cd
       and mff.unique_store_composite_key = src.unique_store_composite_key
      left join (
          select customer_name,
                 unique_store_composite_key,
                 ean_upc_cd,
                 max(max_nonmissing_wk) as max_nonmissing_wk,
                 min(min_missing_wk) as min_missing_wk
          from `""" ,BQ_PROJECT_NAME,"""`.""",BQ_PROCESSED_DATASET_NAME,""".""",BQ_PROCESSED_TABLE_NAME,"""
          group by customer_name,
                   unique_store_composite_key,
                   ean_upc_cd
      ) tgt
        on tgt.customer_name = src.customer_name
       and tgt.ean_upc_cd = src.ean_upc_cd
       and tgt.unique_store_composite_key = src.unique_store_composite_key
     where src.fiscal_week_begin_dt = maxw.max_dt
),

-- calculate consecutive missing weeks:
-- if no online distribution exists ever, take difference between max retailer dt and first time data appeared and add one week
-- otherwise, take the difference between max retailer dt and most recent acceptable date (where online dist was found) in weeks
missing_weeks as (
    select *,
           CASE WHEN max_nonmissing_wk IS NULL AND min_missing_wk IS NOT NULL THEN DATE_DIFF(max_retailer_dt, min_missing_wk, WEEK) + 1
           ELSE DATE_DIFF(max_retailer_dt, max_nonmissing_wk, WEEK)
           END AS consecutive_missing_weeks
    from missing_weeks_raw
)

select src.*
        , coalesce(mw.consecutive_missing_weeks, 0) as consecutive_missing_weeks
        , mw.max_nonmissing_wk
        , mw.min_missing_wk
        , mw.max_retailer_dt
        , mw.max_upc_dt
        ,'""",JOB_RUN_ID,"""' created_by
        , current_datetime created_datetime
        , '""",JOB_RUN_ID,"""' modified_by
        , current_datetime modified_datetime
from combined_src src
left join max_weeks maxw
    on maxw.customer_name = src.customer_name
left join missing_weeks mw
    on mw.customer_name = src.customer_name
   and mw.ean_upc_cd = src.ean_upc_cd
   and mw.unique_store_composite_key = src.unique_store_composite_key
   and mw.max_upc_dt = src.fiscal_week_begin_dt
) dist
on tgt.withupckey_fingerprint = dist.withupckey_fingerprint
WHEN MATCHED THEN
  UPDATE SET is_instore = dist.is_instore,
    authorization_flg = dist.authorization_flg,
    division = dist.division,
    is_online = dist.is_online,
    stock_flg = dist.stock_flg,
    is_available = dist.is_available,
    is_instore_distribution = dist.is_instore_distribution,
    is_instore_distribution_authorized = dist.is_instore_distribution_authorized,
    is_instore_distribution_not_authorized = dist.is_instore_distribution_not_authorized,
    is_online_distribution = dist.is_online_distribution,
    is_online_distribution_authorized = dist.is_online_distribution_authorized,
    is_online_distribution_not_authorized = dist.is_online_distribution_not_authorized,
    consecutive_missing_weeks = dist.consecutive_missing_weeks,
    max_nonmissing_wk = dist.max_nonmissing_wk,
    min_missing_wk = dist.min_missing_wk,
    max_retailer_dt = dist.max_retailer_dt,
    max_upc_dt = dist.max_upc_dt,
    modified_by = dist.modified_by,
    modified_datetime = dist.modified_datetime
WHEN NOT MATCHED THEN
INSERT
  (
    withupckey_fingerprint
    ,store_number
    ,banner
    ,store_street_address
    ,store_city
    ,store_state
    ,store_zipcode
    ,division
    ,upc_cd
    ,unique_store_composite_key
    ,sls_hier_division_desc
    ,sls_hier_category_desc
    ,sls_hier_sub_category_desc
    ,sls_hier_ppg_desc
    ,base_product_cd
    ,base_product_desc
    ,material_cd
    ,material_nbr
    ,ean_upc_cd
    ,material_short_desc
    ,old_sls_hier_division_desc
    ,old_sls_hier_category_desc
    ,old_sls_hier_sub_category_desc
    ,old_sls_hier_ppg_desc
    ,old_base_product_cd
    ,old_base_product_desc
    ,old_material_cd
    ,old_material_nbr
    ,old_ean_upc_cd
    ,old_material_short_desc
    ,is_online
    ,is_smoothed
    ,stock_flg
    ,is_available
    ,online_distribution_exists_flg
    ,is_instore
    ,authorization_flg
    ,fiscal_year_week_nbr
    ,fiscal_month_in_year_nbr
    ,fiscal_year_nbr
    ,fiscal_week_in_year_nbr
    ,fiscal_week_begin_dt
    ,fiscal_year_month_nbr
    ,customer_name
    ,is_instore_distribution
    ,is_instore_distribution_authorized
    ,is_instore_distribution_not_authorized
    ,is_online_distribution
    ,is_online_distribution_authorized
    ,is_online_distribution_not_authorized
    ,store_display_name
    ,retailer_type
    ,country
    ,segment
    ,customer_desc
    ,customer_parent
    ,customer_account
    ,consecutive_missing_weeks
    ,max_nonmissing_wk
    ,min_missing_wk
    ,max_retailer_dt
    ,max_upc_dt
    ,created_by
    ,created_datetime
    ,modified_by
    ,modified_datetime
)
VALUES
(
    dist.withupckey_fingerprint
    ,dist.store_number
    ,dist.banner
    ,dist.store_street_address
    ,dist.store_city
    ,dist.store_state
    ,dist.store_zipcode
    ,dist.division
    ,dist.upc_cd
    ,dist.unique_store_composite_key
    ,dist.sls_hier_division_desc
    ,dist.sls_hier_category_desc
    ,dist.sls_hier_sub_category_desc
    ,dist.sls_hier_ppg_desc
    ,dist.base_product_cd
    ,dist.base_product_desc
    ,dist.material_cd
    ,dist.material_nbr
    ,dist.ean_upc_cd
    ,dist.material_short_desc
    ,dist.old_sls_hier_division_desc
    ,dist.old_sls_hier_category_desc
    ,dist.old_sls_hier_sub_category_desc
    ,dist.old_sls_hier_ppg_desc
    ,dist.old_base_product_cd
    ,dist.old_base_product_desc
    ,dist.old_material_cd
    ,dist.old_material_nbr
    ,dist.old_ean_upc_cd
    ,dist.old_material_short_desc
    ,dist.is_online
    ,dist.is_smoothed
    ,dist.stock_flg
    ,dist.is_available
    ,dist.online_distribution_exists_flg
    ,dist.is_instore
    ,dist.authorization_flg
    ,dist.fiscal_year_week_nbr
    ,dist.fiscal_month_in_year_nbr
    ,dist.fiscal_year_nbr
    ,dist.fiscal_week_in_year_nbr
    ,dist.fiscal_week_begin_dt
    ,dist.fiscal_year_month_nbr
    ,dist.customer_name
    ,dist.is_instore_distribution
    ,dist.is_instore_distribution_authorized
    ,dist.is_instore_distribution_not_authorized
    ,dist.is_online_distribution
    ,dist.is_online_distribution_authorized
    ,dist.is_online_distribution_not_authorized
    ,dist.store_display_name
    ,dist.retailer_type
    ,dist.country
    ,dist.segment
    ,dist.customer_desc
    ,dist.customer_parent
    ,dist.customer_account
    ,dist.consecutive_missing_weeks
    ,dist.max_nonmissing_wk
    ,dist.min_missing_wk
    ,dist.max_retailer_dt
    ,dist.max_upc_dt
    ,dist.created_by
    ,dist.created_datetime
    ,dist.modified_by
    ,dist.modified_datetime
)
""");

EXCEPTION WHEN ERROR THEN
        EXECUTE IMMEDIATE CONCAT(
            """INSERT INTO processed.ecomm_admin_sproc_error_details (
		        SELECT
			        '""",FEED_NAME,"""' AS FEED_NAME,
                    split(split(@@error.formatted_stack_trace,'transient.')[OFFSET (1)],'[')[OFFSET(0)],
			        @@error.statement_text,
			        @@error.message,
			        current_timestamp()
	        );
	    """);

	    SELECT
	        ERROR (
	            CONCAT(
	            		@@error.message ,' ' ,
	            		@@error.statement_text, ' ' ,
	            		@@error.formatted_stack_trace ,' '
	            	)
	        );

END;