/*
Purpose of the stored proc: 
	/*
    Add distribution and availability metric columns needed for aggregation, join data with customer xref, and overwrite converted upc's
    with new upc's while adding columns to preserve pre-conversion upc data
	
History of Changes:
	05/27/21 – first version 
    08/17/21 - remove duplicates created by upc conversions

Author : 
	Kaia Arthur
How to Call:
		call transient.sp_pure_player_distribution_availability_with_upc
		(
		 99,
		'ecomm-dlf-dev-01cd47',
		'processed',
		'transient',
        'processed',
		'amazon_distribution_availability_with_upc',
        'amazon_profitero_distribution_consolidate_product_temp'
		)

*/

CREATE PROCEDURE IF NOT EXISTS transient.sp_pure_player_distribution_availability_with_upc
( 
	job_run_id INT64,
	bq_project_name string,
	bq_processed_dataset_name string,
    bq_transient_dataset_name string,
    bq_target_dataset_name string,
	bq_target_table_name string,
    bq_source_table_name string
)
BEGIN
Declare sql STRING;

-- Truncate Table
EXECUTE IMMEDIATE
  CONCAT("""TRUNCATE TABLE  `""",bq_project_name,"""`.""",bq_target_dataset_name,""".""",bq_target_table_name);

set sql = 
CONCAT(
"""insert into  `""" ,bq_project_name,"""`.""",bq_target_dataset_name,""".""",bq_target_table_name,"""
(
--join with the converted eans table to overwrite any pre-conversion eans with their new, post-conversion ean
--preserve old ean in new column
--hard code is_online_distribution and retailer type
--get additional customer fields from customer lookup table
with upc_conversions as 
(select 
    src.banner
    ,upc
    ,coalesce(conv.new_sls_hier_division_desc,src.sls_hier_division_desc) sls_hier_division_desc
    ,coalesce(conv.new_sls_hier_category_desc,src.sls_hier_category_desc) sls_hier_category_desc
    ,coalesce(conv.new_sls_hier_sub_category_desc,src.sls_hier_sub_category_desc) sls_hier_sub_category_desc
    ,coalesce(conv.new_sls_hier_ppg_desc,src.sls_hier_ppg_desc) sls_hier_ppg_desc
    ,coalesce(conv.new_base_product_cd,src.base_product_cd) base_product_cd
    ,coalesce(conv.new_base_product_desc,src.base_product_desc) base_product_desc
    ,coalesce(conv.new_material_cd,src.material_cd) material_cd
    ,coalesce(conv.new_material_nbr,src.material_nbr) material_nbr
    ,coalesce(conv.new_ean_upc_cd,src.ean_upc_cd) ean_upc_cd
    ,coalesce(conv.new_material_short_desc,src.material_short_desc) material_short_desc
    ,case when conv.old_ean_upc_cd is not null then src.sls_hier_division_desc else null end old_sls_hier_division_desc
    ,case when conv.old_ean_upc_cd is not null then src.sls_hier_category_desc else null end old_sls_hier_category_desc
    ,case when conv.old_ean_upc_cd is not null then src.sls_hier_sub_category_desc else null end old_sls_hier_sub_category_desc
    ,case when conv.old_ean_upc_cd is not null then src.sls_hier_ppg_desc else null end old_sls_hier_ppg_desc
    ,case when conv.old_ean_upc_cd is not null then src.base_product_cd else null end old_base_product_cd
    ,case when conv.old_ean_upc_cd is not null then src.base_product_desc else null end old_base_product_desc
    ,case when conv.old_ean_upc_cd is not null then src.material_cd else null end old_material_cd
    ,case when conv.old_ean_upc_cd is not null then src.material_nbr else null end old_material_nbr
   ,case when conv.old_ean_upc_cd is not null then src.ean_upc_cd else null end old_ean_upc_cd
    ,case when conv.old_ean_upc_cd is not null then src.material_short_desc else null end old_material_short_desc
	,stock_flg
    ,case when stock_flg = true then 1
                else 0
           end is_available
    ,fiscal_year_week_nbr
    ,fiscal_month_in_year_nbr
    ,fiscal_year_nbr
    ,fiscal_week_in_year_nbr
    ,fiscal_week_begin_dt
    ,fiscal_year_month_nbr
    ,src.customer_name
    ,1 is_online_distribution
    ,'Pure Player' retailer_type
    , country
    , segment
    , customer_desc
    , customer_parent
    , customer_account
    ,'""",job_run_id,"""' created_by
    , current_datetime created_datetime
	, '""",job_run_id,"""' modified_by
	, current_datetime modified_datetime
    ,row_number() over 
        (partition by banner, fiscal_week_begin_dt, coalesce(conv.new_ean_upc_cd,src.ean_upc_cd)
            order by stock_flg desc
      ) rank  
from `""" ,bq_project_name,"""`.""",bq_processed_dataset_name,""".""",bq_source_table_name,"""  src
left join `""" ,bq_project_name,"""`.""",bq_transient_dataset_name,""".upc_conversions_flattened conv
    on ltrim(conv.old_ean_upc_cd, '0') = ltrim(src.ean_upc_cd, '0')
left join `""" ,bq_project_name,"""`.""",bq_processed_dataset_name,""".lkp_customer cust
    on cust.customer_name = src.customer_name
)
-- remove duplicates created by upc conversions
select * except(rank) from
upc_conversions
    where rank = 1
)
""");

SELECT sql;

Execute immediate sql;

EXCEPTION WHEN ERROR THEN
    SELECT  
	ERROR (
		CONCAT(
    			@@error.message ,' ' ,
    			@@error.statement_text, ' ' ,
    			@@error.formatted_stack_trace ,' '
			)
		)
	;

END