/*
Purpose of the stored proc: 
	/*
    Aggregate distribution and availability metric columns needed for aggregation, add customer zone, calculate year over year metrics, 
    fill in gaps so each customer/week represents all possible sub-categories, and add rolling time flags
	
History of Changes:
	06/07/21 – first version 
Author : 
	Kaia Arthur
How to Call:
		call transient.sp_pure_player_distribution_availability_subcatg_aggregated
		(
		 99,
		'ecomm-dlf-dev-01cd47',
		'transient',
        'processed',
		'processed',
        'amazon_com_distribution_availability_subcatg_agg_fact',
        'edw-qa-c89f9d',
        'enterprise',
		'amazon_com_distribution_availability_with_upc_fact'
		);

*/

CREATE PROCEDURE IF NOT EXISTS transient.sp_pure_player_distribution_availability_subcatg_aggregated
( 
	job_run_id INT64,
	bq_project_name string,
    bq_transient_dataset_name string,
    bq_processed_dataset_name string,
	bq_target_dataset_name string,
	bq_target_table_name string,
    bq_edw_project_name string,
	bq_enterprise_dataset_name string,
    bq_source_table_name string
)
BEGIN

DECLARE sql,sls_hier_division_desc_filter STRING;
DECLARE source_table_count INT64;

--Update divsions here if it needs any change.
set sls_hier_division_desc_filter = "'MORNING FOODS','MEALS-BAKING','SNACKS'";


    -- We are checking the source count here. If the source count is zero, we do not proceed with rest of the commands and terminate the procedure.
    -- This ensures that the table is not truncated if there are no records in the source and also eliminates any NULL exceptions.

EXECUTE IMMEDIATE 
CONCAT("""Select count(*) from `""",bq_project_name,""".""",bq_processed_dataset_name,""".""",bq_source_table_name,"""`""")
INTO source_table_count;
IF source_table_count != 0 THEN
-- Truncate Table
EXECUTE IMMEDIATE
  CONCAT("""TRUNCATE TABLE  `""",bq_project_name,"""`.""",bq_target_dataset_name,""".""",bq_target_table_name);

set sql = 
CONCAT(
"""insert into `""" ,bq_project_name,"""`.""",bq_target_dataset_name,""".""",bq_target_table_name,"""
(
with customer_max_week as (
    select customer_name
          ,max(fiscal_week_begin_dt) fiscal_week_begin_dt
          ,max(fiscal_year_week_nbr) fiscal_year_week_nbr
          ,max(fiscal_year_nbr) fiscal_year_nbr
      from `""" ,bq_project_name,"""`.""",bq_processed_dataset_name,""".""",bq_source_table_name,"""
     group by customer_name
),
-- Get a list of weeks over the past 2 years to fill in gaps for year-over-year calculations.
-- We may be missing weeks of data this year, but we still want to report on the corresponding last-year distribution.
all_relevant_weeks as (
    select distinct cal.fiscal_year_week_nbr
                   ,cal.fiscal_month_in_year_nbr
                   ,cal.fiscal_year_nbr
                   ,cal.fiscal_week_in_year_nbr
                   ,cal.fiscal_week_begin_dt
                   ,cal.fiscal_year_month_nbr
                   ,min(cal.calendar_year_nbr) calendar_year_nbr 
      from `""" ,bq_edw_project_name,"""`.""",bq_enterprise_dataset_name,""".dim_date cal
          ,customer_max_week cmw
     where cal.language_cd = 'EN'
       and cal.fiscal_year_variant_cd = '07'
       and cal.fiscal_year_week_nbr between cmw.fiscal_year_week_nbr - 200 and cmw.fiscal_year_week_nbr
       group by cal.fiscal_year_week_nbr
                ,cal.fiscal_month_in_year_nbr
                ,cal.fiscal_year_nbr
                ,cal.fiscal_week_in_year_nbr
                ,cal.fiscal_week_begin_dt
                ,cal.fiscal_year_month_nbr
),
-- Cross-join weeks with customers and categories to get a list of all possible customer/weeks/categories for distribution.
-- This is done to enable a clean "outer join" type logic between this-year and last-year data.
possible_customer_week_categories as (
    select arw.*, st.*
      from all_relevant_weeks arw
      cross join (select distinct customer_name,
                sls_hier_sub_category_desc 
            from `""" ,bq_project_name,"""`.""",bq_processed_dataset_name,""".""",bq_source_table_name,"""
            ) st
),


-- Remove UPC level granularity; aggregate to customer/week/sub-category level
agg_count as (select 
fiscal_year_week_nbr
,sls_hier_sub_category_desc
,fiscal_week_in_year_nbr
,customer_name
,ifnull(sum(is_online_distribution), 0) online_distribution_count
          ,ifnull(sum(is_available),0) available_count
		  from `""" ,bq_project_name,"""`.""",bq_processed_dataset_name,""".""",bq_source_table_name,"""
group by 
fiscal_year_week_nbr
,sls_hier_sub_category_desc
,fiscal_week_in_year_nbr
,customer_name),


-- Fetching all the columns from the source data

src_data as (select * except(rnk) from (
    select 
    src.fiscal_year_week_nbr
    ,src.sls_hier_sub_category_desc
    ,src.customer_name,
    agg.fiscal_week_in_year_nbr,
    src.country,
    src.customer_desc,
    src.customer_parent,
    src.customer_account,
    src.segment,
    src.retailer_type,
    src.banner,
    src.sls_hier_division_desc,
    src.sls_hier_category_desc,
    agg.online_distribution_count,
    agg.available_count,

    -- While joining the aggregated data back to source table, we may end up having duplicates.
    -- deduping on the sub-category level

    row_number() over (partition by  src.fiscal_year_week_nbr
          ,src.sls_hier_sub_category_desc) rnk
    from `""" ,bq_project_name,"""`.""",bq_processed_dataset_name,""".""",bq_source_table_name,""" src
    join agg_count agg
    on src.fiscal_year_week_nbr = agg.fiscal_year_week_nbr
       and src.sls_hier_sub_category_desc = agg.sls_hier_sub_category_desc)
where rnk =1
),

-- Fetching the 'last-year' (ly) data.
-- Using lead function instead of self join because self join gives intermittent results
-- This is a known issue with GCP BQ.

ly_calc as (
SELECT
  fiscal_year_week_nbr,
  sls_hier_sub_category_desc,
  customer_name,
  country,
  customer_desc,
  customer_parent,
  customer_account,
  segment,
  retailer_type,
  banner,
  sls_hier_division_desc,
  sls_hier_category_desc,
  online_distribution_count,
  available_count,
  LEAD (agg.country,1,NULL) OVER (PARTITION BY agg.fiscal_week_in_year_nbr, agg.sls_hier_sub_category_desc ORDER BY agg.fiscal_year_week_nbr DESC) ly_country,
  LEAD (agg.customer_desc,1,NULL) OVER (PARTITION BY agg.fiscal_week_in_year_nbr, agg.sls_hier_sub_category_desc ORDER BY agg.fiscal_year_week_nbr DESC) ly_customer_desc,
  LEAD (agg.customer_parent,1,NULL) OVER (PARTITION BY agg.fiscal_week_in_year_nbr, agg.sls_hier_sub_category_desc ORDER BY agg.fiscal_year_week_nbr DESC) ly_customer_parent,
  LEAD (agg.customer_account,1,NULL) OVER (PARTITION BY agg.fiscal_week_in_year_nbr, agg.sls_hier_sub_category_desc ORDER BY agg.fiscal_year_week_nbr DESC) ly_customer_account,
  LEAD (agg.segment,1,NULL) OVER (PARTITION BY agg.fiscal_week_in_year_nbr, agg.sls_hier_sub_category_desc ORDER BY agg.fiscal_year_week_nbr DESC) ly_segment,
  LEAD (agg.retailer_type,1,NULL) OVER (PARTITION BY agg.fiscal_week_in_year_nbr, agg.sls_hier_sub_category_desc ORDER BY agg.fiscal_year_week_nbr DESC) ly_retailer_type,
  LEAD (agg.banner,1,NULL) OVER (PARTITION BY agg.fiscal_week_in_year_nbr, agg.sls_hier_sub_category_desc ORDER BY agg.fiscal_year_week_nbr DESC) ly_banner,
  LEAD (agg.sls_hier_division_desc,1,NULL) OVER (PARTITION BY agg.fiscal_week_in_year_nbr, agg.sls_hier_sub_category_desc ORDER BY agg.fiscal_year_week_nbr DESC) ly_sls_hier_division_desc,
  LEAD (agg.sls_hier_category_desc,1,NULL) OVER (PARTITION BY agg.fiscal_week_in_year_nbr, agg.sls_hier_sub_category_desc ORDER BY agg.fiscal_year_week_nbr DESC) ly_sls_hier_category_desc,
  LEAD (agg.online_distribution_count,1,NULL) OVER (PARTITION BY agg.fiscal_week_in_year_nbr, agg.sls_hier_sub_category_desc ORDER BY agg.fiscal_year_week_nbr DESC) ly_online_distribution_count,
  LEAD (agg.available_count,1,NULL) OVER (PARTITION BY agg.fiscal_week_in_year_nbr, agg.sls_hier_sub_category_desc ORDER BY agg.fiscal_year_week_nbr DESC) ly_available_count
FROM
  src_data agg

),

-- Add year-over-year calculations
year_over_year as (
    select pcwc.customer_name
          ,pcwc.fiscal_year_week_nbr
          ,pcwc.sls_hier_sub_category_desc
          ,ifnull(src.country, ly_country) country
          ,ifnull(src.customer_desc, ly_customer_desc) customer_desc
          ,ifnull(src.customer_parent, ly_customer_parent) customer_parent
          ,ifnull(src.customer_account, ly_customer_account) customer_account
          ,ifnull(src.segment, ly_segment) segment
          ,ifnull(src.retailer_type, ly_retailer_type) retailer_type
          ,ifnull(src.banner, ly_banner) banner
          ,ifnull(src.sls_hier_division_desc, ly_sls_hier_division_desc) sls_hier_division_desc
          ,ifnull(src.sls_hier_category_desc, ly_sls_hier_category_desc) sls_hier_category_desc
          ,pcwc.calendar_year_nbr
          ,ifnull(src.online_distribution_count, 0) online_distribution_count
          ,ifnull(src.available_count, 0) available_count
          ,ifnull(ly_online_distribution_count, 0) ly_online_distribution_count
          ,ifnull(ly_available_count, 0) ly_available_count
          ,pcwc.fiscal_month_in_year_nbr
          ,pcwc.fiscal_year_nbr
          ,pcwc.fiscal_week_in_year_nbr
          ,pcwc.fiscal_week_begin_dt
          ,pcwc.fiscal_year_month_nbr
      from possible_customer_week_categories pcwc
      left join ly_calc src
        on src.customer_name = pcwc.customer_name
       and src.fiscal_year_week_nbr = pcwc.fiscal_year_week_nbr
       and src.sls_hier_sub_category_desc = pcwc.sls_hier_sub_category_desc
),

-- fill in gaps so each customer/week represents all possible sub-categories
customer_subcategories as (
    select distinct src.customer_name, 
        src.sls_hier_division_desc, 
        prd.sls_hier_category_desc, 
        prd.sls_hier_sub_category_desc
      from (select distinct customer_name, 
                sls_hier_division_desc 
                from `""" ,bq_project_name,"""`.""",bq_processed_dataset_name,""".""",bq_source_table_name,"""
                where sls_hier_division_desc in (""",sls_hier_division_desc_filter,""")
            ) src
      join `""" ,bq_edw_project_name,"""`.""",bq_enterprise_dataset_name,""".dim_product_active prd
        on prd.sls_hier_division_desc = src.sls_hier_division_desc
),
fill_subcategory_gaps as (
    select distinct cs.customer_name
                   ,cs.sls_hier_division_desc
                   ,cs.sls_hier_category_desc
                   ,cs.sls_hier_sub_category_desc
                   ,yoy.banner
                   ,yoy.country
                   ,yoy.segment
                   ,yoy.retailer_type
                   ,yoy.customer_desc
                   ,yoy.customer_parent
                   ,yoy.customer_account
                   ,yoy.fiscal_year_week_nbr
                   ,yoy.fiscal_month_in_year_nbr
                   ,yoy.fiscal_year_nbr
                   ,yoy.fiscal_week_in_year_nbr
                   ,yoy.fiscal_week_begin_dt
                   ,yoy.fiscal_year_month_nbr
                   ,yoy.calendar_year_nbr
      from customer_subcategories cs
      join year_over_year yoy
        on yoy.customer_name = cs.customer_name
       and yoy.sls_hier_division_desc = cs.sls_hier_division_desc
),
-- Get the customer zone from the flattened XREF; we only want one per customer
customer_zone as (
    select customer_name, zone_hierarchy from (
    select *, rank() over (partition by customer_name
                           order by xref_order, sales_split desc, zone_hierarchy, retailer
              ) zone_rank
    from `""" ,bq_project_name,"""`.""",bq_processed_dataset_name,""".lkp_nar_zone_mapping ) t
    where zone_rank = 1
)
-- Add rolling week "time flag" columns, which are used in the Ops Scorecard
select fsg.banner
      ,fsg.retailer_type
      ,fsg.sls_hier_division_desc
      ,fsg.sls_hier_category_desc
      ,fsg.sls_hier_sub_category_desc
      ,yoy.online_distribution_count
      ,yoy.available_count
      ,yoy.ly_online_distribution_count
      ,yoy.ly_available_count
      ,if(yoy.customer_name is null, true, false) null_row_flg
      ,fsg.fiscal_year_week_nbr
      ,fsg.fiscal_month_in_year_nbr
      ,fsg.fiscal_year_nbr
      ,fsg.fiscal_week_in_year_nbr
      ,fsg.fiscal_week_begin_dt
      ,fsg.fiscal_year_month_nbr
      ,fsg.calendar_year_nbr
      ,fsg.country
      ,fsg.segment
      ,fsg.customer_desc
      ,fsg.customer_parent
      ,fsg.customer_account
      ,cz.zone_hierarchy customer_zone
      ,cmw.fiscal_week_begin_dt as max_customer_date
      ,if(fsg.fiscal_year_nbr = cmw.fiscal_year_nbr, true, false) latest_year_ty_flg
      ,if(fsg.fiscal_year_nbr = cmw.fiscal_year_nbr - 1, true, false) previous_year_ty_flg
      ,if(fsg.fiscal_year_nbr = cmw.fiscal_year_nbr - 2, true, false) previous_year_ly_flg
      ,case when date_diff(date(cmw.fiscal_week_begin_dt), date(fsg.fiscal_week_begin_dt), WEEK) <= 51 then true
            else false
       end latest_rolling_52_weeks_flg
      ,case when date_diff(date(cmw.fiscal_week_begin_dt), date(fsg.fiscal_week_begin_dt), WEEK) between 52 and 103 then true
            else false
       end previous_rolling_52_weeks_flg
      ,concat(cast(fsg.fiscal_month_in_year_nbr as string), '-', fsg.fiscal_month_in_year_short_desc) fiscal_month_period_desc
      ,cast(date(fsg.fiscal_week_begin_dt) as string) fiscal_week_begin_dt_desc
      ,'""",job_run_id,"""' created_by
      ,current_datetime created_datetime
	  ,'""",job_run_id,"""' modified_by
	  ,current_datetime modified_datetime 
      ,fsg.customer_name
  from fill_subcategory_gaps fsg
  join customer_max_week cmw
    on cmw.customer_name = fsg.customer_name
  left join year_over_year yoy
    on yoy.customer_name = fsg.customer_name
   and yoy.fiscal_year_week_nbr = fsg.fiscal_year_week_nbr
   and yoy.sls_hier_sub_category_desc = fsg.sls_hier_sub_category_desc
  left join customer_zone cz
    on cz.customer_name = fsg.customer_name
) 
""");
select sql;

EXECUTE IMMEDIATE sql;
END IF;

EXCEPTION WHEN ERROR THEN
    SELECT  
	ERROR (
		CONCAT(
    			@@error.message ,' ' ,
    			@@error.statement_text, ' ' ,
    			@@error.formatted_stack_trace ,' '
			)
		)
	;

END