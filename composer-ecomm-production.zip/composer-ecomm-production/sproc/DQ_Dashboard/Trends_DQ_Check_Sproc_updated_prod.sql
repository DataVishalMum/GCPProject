CREATE OR REPLACE PROCEDURE `ecomm-dlf-qa-ee8fb9.transient.prod_sp_trends_comparison`()
BEGIN
DECLARE create_table STRING;
SET create_table=CONCAT(
		"""CREATE OR REPLACE TABLE `ecomm-dlf-qa-ee8fb9.transient.DataQuality_Trends_PROD`""",
		"""	(retailer     STRING,
			 manufacturer     STRING,
			 fiscal_week_begin_dt     DATE,
			 row_count     INT64,
			 row_count_avg_last_4_week     FLOAT64,
			 percent_diff_row_count_4_week     FLOAT64,
			 row_count_avg_last_13_week     FLOAT64,
			 percent_diff_row_count_13_week     FLOAT64,
			 row_count_previous_week     INT64,
			 sales     FLOAT64,
			 sales_avg_last_4_week     FLOAT64,
			 percent_diff_sales_4_week     FLOAT64,
			 sales_avg_last_13_week     FLOAT64,
			 percent_diff_sales_13_week     FLOAT64,
			 sales_of_previous_year     FLOAT64,
			 units     INT64,
			 units_avg_last_4_week     FLOAT64,
			 percent_diff_units_4_week     FLOAT64,
			 units_avg_last_13_week     FLOAT64,
			 percent_diff_units_13_week     FLOAT64,
			 units_of_previous_year     INT64,
			 execution_dttm     TIMESTAMP
			);"""
		);
		
EXECUTE IMMEDIATE create_table;

EXECUTE IMMEDIATE CONCAT("""TRUNCATE TABLE ecomm-dlf-qa-ee8fb9.transient.DataQuality_Trends_PROD;""");

EXECUTE IMMEDIATE ("""CREATE OR REPLACE TEMP TABLE UNION_DATA AS (
select customer_name,fiscal_week_begin_dt,ty_sales_value,ly_sales_value,ty_sales_units,ly_sales_units,manufacturer,upc 
from `ecomm-analytics-prd-6238a8.output.gss_sales_share_us_nar_report_stage`
WHERE (NOT (coalesce(upc,source_item_code,'0') LIKE '%840243%'
        OR coalesce(upc,source_item_code,'0') LIKE '%859610%')) AND (CAST(fiscal_week_begin_dt AS DATE) >= DATE_SUB(current_date, INTERVAL 75 WEEK))
UNION DISTINCT
select customer_name,fiscal_week_begin_dt,ty_sales_value,ly_sales_value,ty_sales_units,ly_sales_units,manufacturer,upc 
from `ecomm-analytics-prd-6238a8.output.gss_sales_share_ca_nar_report_stage`
WHERE (NOT (coalesce(upc,source_item_code,'0') LIKE '%840243%'
        OR coalesce(upc,source_item_code,'0') LIKE '%859610%')) AND (CAST(fiscal_week_begin_dt AS DATE) >= DATE_SUB(current_date, INTERVAL 75 WEEK))
UNION DISTINCT
select customer_name,fiscal_week_begin_dt,ty_sales_value,ly_sales_value,ty_sales_units,ly_sales_units,manufacturer,upc 
from `ecomm-analytics-prd-6238a8.output.gss_sales_share_euau_report_stage`
WHERE (NOT (coalesce(upc,source_item_code,'0') LIKE '%840243%'
        OR coalesce(upc,source_item_code,'0') LIKE '%859610%')) AND (CAST(fiscal_week_begin_dt AS DATE) >= DATE_SUB(current_date, INTERVAL 75 WEEK))
UNION DISTINCT
select CASE WHEN upper(customer_name)='INSTACART' THEN 'INSTACART_BLUE' WHEN upper(customer_name)='KROGER' THEN 'KROGER_BLUE'
WHEN upper(customer_name)='HYVEE' THEN 'HYVEE_BLUE' WHEN upper(customer_name)='MEIJER' THEN 'MEIJER_BLUE' WHEN upper(customer_name)='SHOPRITE' THEN 'SHOPRITE_BLUE'
ELSE customer_name end as customer_name ,cast(fiscal_week_begin_dt as DATE) as fiscal_week_begin_dt,ty_sales_value,ly_sales_value,ty_sales_units,ly_sales_units,manufacturer,upc
from `ecomm-analytics-prd-6238a8.output.gss_sales_share_blue_report_stage`
WHERE (CAST(fiscal_week_begin_dt AS DATE) >= DATE_SUB(current_date, INTERVAL 75 WEEK))
UNION DISTINCT
select customer_name , CAST(fiscal_week_begin_dt AS DATE) as fiscal_week_begin_dt,ty_sales_value,ly_sales_value,ty_sales_units,ly_sales_units,manufacturer,upc 
from `ecomm-analytics-prd-6238a8.output.gss_sales_share_france_report_stage`
WHERE (CAST(fiscal_week_begin_dt AS DATE) >= DATE_SUB(current_date, INTERVAL 75 WEEK))
)""");

EXECUTE IMMEDIATE
CONCAT(
"""INSERT INTO `ecomm-dlf-qa-ee8fb9.transient.DataQuality_Trends_PROD`""",
"""(
WITH CTE AS (
SELECT customer_name,
CASE
              WHEN (lower(manufacturer) LIKE ('%general%mills%')
                    OR lower(manufacturer) LIKE ('%gmi%')) THEN 'GMI'
              ELSE 'Non-GMI'
          END AS manufacturer,
			 CASE WHEN customer_name='CORNERSHOP_CANADA' THEN (
				CASE WHEN EXTRACT(DAYOFWEEK FROM DATE_TRUNC(fiscal_week_begin_dt,MONTH))=2 
					THEN DATE_TRUNC(fiscal_week_begin_dt,MONTH) 
				ELSE DATE_TRUNC(DATE_ADD(DATE_TRUNC(fiscal_week_begin_dt,MONTH), INTERVAL 1 WEEK), WEEK(MONDAY))
				END
				) 
			ELSE fiscal_week_begin_dt END AS start_date,
             count(*) AS count_data,
             COALESCE(sum(ty_sales_value),1) AS sum_sales_value_cc,
             COALESCE(sum(ty_sales_units),1) AS sum_sales_unit_cc,
			 COALESCE(sum(ly_sales_value),1) AS sum_ly_sales_value_cc,
			 COALESCE(sum(ly_sales_units),1) AS sum_ly_sales_unit_cc
      FROM UNION_DATA
      GROUP BY customer_name,fiscal_week_begin_dt,
	  CASE
              WHEN (lower(manufacturer) LIKE ('%general%mills%')
                    OR lower(manufacturer) LIKE ('%gmi%')) THEN 'GMI'
              ELSE 'Non-GMI'
          END
),
all_manu AS
  (SELECT customer_name,
          start_date,
          count_data,
          AVG(count_data) OVER( PARTITION BY customer_name
                               ORDER BY start_date DESC ROWS BETWEEN 1 FOLLOWING AND 4 FOLLOWING) AS last_4_week_count_avg,
          AVG(count_data) OVER( PARTITION BY customer_name
                               ORDER BY start_date DESC ROWS BETWEEN 1 FOLLOWING AND 13 FOLLOWING) AS last_13_week_count_avg,
          lead(count_data,1,-99999999999) OVER ( PARTITION BY customer_name
                                          ORDER BY start_date DESC) AS count_data_pre,
          sum_sales_value_cc,
          AVG(sum_sales_value_cc) OVER( PARTITION BY customer_name
                                       ORDER BY start_date DESC ROWS BETWEEN 1 FOLLOWING AND 4 FOLLOWING) AS last_4_week_sales_avg,
          AVG(sum_sales_value_cc) OVER( PARTITION BY customer_name
                                       ORDER BY start_date DESC ROWS BETWEEN 1 FOLLOWING AND 13 FOLLOWING) AS last_13_week_sales_avg,
          sum_ly_sales_value_cc AS sum_ly_sales_value_cc,
          sum_sales_unit_cc,
          AVG(sum_sales_unit_cc) OVER( PARTITION BY customer_name
                                      ORDER BY start_date DESC ROWS BETWEEN 1 FOLLOWING AND 4 FOLLOWING) AS last_4_week_units_avg,
          AVG(sum_sales_unit_cc) OVER( PARTITION BY customer_name
                                      ORDER BY start_date DESC ROWS BETWEEN 1 FOLLOWING AND 13 FOLLOWING) AS last_13_week_units_avg,
          sum_ly_sales_unit_cc AS sum_ly_sales_unit_cc,
		 'ALL' as manufacturer
   FROM (
   SELECT customer_name,
			CASE WHEN customer_name='CORNERSHOP_CANADA' THEN (
				CASE WHEN EXTRACT(DAYOFWEEK FROM DATE_TRUNC(fiscal_week_begin_dt,MONTH))=2 
					THEN DATE_TRUNC(fiscal_week_begin_dt,MONTH)
				ELSE DATE_TRUNC(DATE_ADD(DATE_TRUNC(fiscal_week_begin_dt,MONTH), INTERVAL 1 WEEK), WEEK(MONDAY))
				END
				) 
			ELSE fiscal_week_begin_dt END AS start_date,
             count(*) AS count_data,
             COALESCE(sum(ty_sales_value),1) AS sum_sales_value_cc,
             COALESCE(sum(ty_sales_units),1) AS sum_sales_unit_cc,
			 COALESCE(sum(ly_sales_value),1) AS sum_ly_sales_value_cc,
			 COALESCE(sum(ly_sales_units),1) AS sum_ly_sales_unit_cc
      FROM UNION_DATA
      GROUP BY customer_name,
			CASE WHEN customer_name='CORNERSHOP_CANADA' THEN (
				CASE WHEN EXTRACT(DAYOFWEEK FROM DATE_TRUNC(fiscal_week_begin_dt,MONTH))=2 
					THEN DATE_TRUNC(fiscal_week_begin_dt,MONTH)
				ELSE DATE_TRUNC(DATE_ADD(DATE_TRUNC(fiscal_week_begin_dt,MONTH), INTERVAL 1 WEEK), WEEK(MONDAY))
				END
				) 
			ELSE fiscal_week_begin_dt END 
   )
   q),
gmi_manu AS
  (SELECT customer_name,
          start_date,
          count_data,
          AVG(count_data) OVER( PARTITION BY customer_name
                               ORDER BY start_date DESC ROWS BETWEEN 1 FOLLOWING AND 4 FOLLOWING) AS last_4_week_count_avg,
          AVG(count_data) OVER( PARTITION BY customer_name
                               ORDER BY start_date DESC ROWS BETWEEN 1 FOLLOWING AND 13 FOLLOWING) AS last_13_week_count_avg,
          lead(count_data,1,-99999999999) OVER ( PARTITION BY customer_name
                                          ORDER BY start_date DESC) AS count_data_pre,
          sum_sales_value_cc,
          AVG(sum_sales_value_cc) OVER( PARTITION BY customer_name
                                       ORDER BY start_date DESC ROWS BETWEEN 1 FOLLOWING AND 4 FOLLOWING) AS last_4_week_sales_avg,
          AVG(sum_sales_value_cc) OVER( PARTITION BY customer_name
                                       ORDER BY start_date DESC ROWS BETWEEN 1 FOLLOWING AND 13 FOLLOWING) AS last_13_week_sales_avg,
          sum_ly_sales_value_cc AS sum_ly_sales_value_cc,
          sum_sales_unit_cc,
          AVG(sum_sales_unit_cc) OVER( PARTITION BY customer_name
                                      ORDER BY start_date DESC ROWS BETWEEN 1 FOLLOWING AND 4 FOLLOWING) AS last_4_week_units_avg,
          AVG(sum_sales_unit_cc) OVER( PARTITION BY customer_name
                                      ORDER BY start_date DESC ROWS BETWEEN 1 FOLLOWING AND 13 FOLLOWING) AS last_13_week_units_avg,
          sum_ly_sales_unit_cc AS sum_ly_sales_unit_cc,
		  'GMI' as manufacturer
   FROM cte where cte.manufacturer='GMI'),
ngmi_manu AS
  (SELECT customer_name,
          start_date,
          count_data,
          AVG(count_data) OVER( PARTITION BY customer_name
                               ORDER BY start_date DESC ROWS BETWEEN 1 FOLLOWING AND 4 FOLLOWING) AS last_4_week_count_avg,
          AVG(count_data) OVER( PARTITION BY customer_name
                               ORDER BY start_date DESC ROWS BETWEEN 1 FOLLOWING AND 13 FOLLOWING) AS last_13_week_count_avg,
          lead(count_data,1,-99999999999) OVER ( PARTITION BY customer_name
                                          ORDER BY start_date DESC) AS count_data_pre,
          sum_sales_value_cc,
          AVG(sum_sales_value_cc) OVER( PARTITION BY customer_name
                                       ORDER BY start_date DESC ROWS BETWEEN 1 FOLLOWING AND 4 FOLLOWING) AS last_4_week_sales_avg,
          AVG(sum_sales_value_cc) OVER( PARTITION BY customer_name
                                       ORDER BY start_date DESC ROWS BETWEEN 1 FOLLOWING AND 13 FOLLOWING) AS last_13_week_sales_avg,
          sum_ly_sales_value_cc AS sum_ly_sales_value_cc,
          sum_sales_unit_cc,
          AVG(sum_sales_unit_cc) OVER( PARTITION BY customer_name
                                      ORDER BY start_date DESC ROWS BETWEEN 1 FOLLOWING AND 4 FOLLOWING) AS last_4_week_units_avg,
          AVG(sum_sales_unit_cc) OVER( PARTITION BY customer_name
                                      ORDER BY start_date DESC ROWS BETWEEN 1 FOLLOWING AND 13 FOLLOWING) AS last_13_week_units_avg,
          sum_ly_sales_unit_cc AS sum_ly_sales_unit_cc,
		  'Non-GMI' as manufacturer
   FROM cte where cte.manufacturer='Non-GMI') 
SELECT case when upper(customer_name) = 'WALMART_ODP' then 'WALMART_OPD'
		   else customer_name end as retailer,
		   manufacturer,
		   start_date AS fiscal_week_begin_dt,
		   count_data AS row_count,
		   last_4_week_count_avg AS row_count_avg_last_4_week,
		   CASE WHEN coalesce(last_4_week_count_avg,0) = 0 then (count_data-last_4_week_count_avg)
		   else ((count_data-last_4_week_count_avg)/coalesce(last_4_week_count_avg,1))*100 end AS percent_diff_row_count_4_week,
		   last_13_week_count_avg AS row_count_avg_last_13_week,
		   CASE WHEN coalesce(last_13_week_count_avg,0) = 0 then (count_data-last_13_week_count_avg)
		   else ((count_data-last_13_week_count_avg)/coalesce(last_13_week_count_avg,1))*100 end AS percent_diff_row_count_13_week,
		   count_data_pre AS row_count_previous_week,
		   sum_sales_value_cc AS sales,
		   last_4_week_sales_avg AS sales_avg_last_4_week,
		   case when coalesce(last_4_week_sales_avg,0) = 0 then (sum_sales_value_cc-last_4_week_sales_avg) else 
		   ((sum_sales_value_cc-last_4_week_sales_avg)/coalesce(last_4_week_sales_avg,1))*100 end AS percent_diff_sales_4_week,
		   last_13_week_sales_avg AS sales_avg_last_13_week,
		   case when coalesce(last_13_week_sales_avg,0) = 0  then (sum_sales_value_cc-last_13_week_sales_avg) else 
		   ((sum_sales_value_cc-last_13_week_sales_avg)/coalesce(last_13_week_sales_avg,1))*100 end AS percent_diff_sales_13_week,
		   sum_ly_sales_value_cc AS sales_of_previous_year,
		   sum_sales_unit_cc AS units,
		   last_4_week_units_avg AS units_avg_last_4_week,
		   case when coalesce(last_4_week_units_avg,0) = 0 then (sum_sales_unit_cc-last_4_week_units_avg) else 
		   ((sum_sales_unit_cc-last_4_week_units_avg)/coalesce(last_4_week_units_avg,1))*100 end AS percent_diff_units_4_week,
		   last_13_week_units_avg AS units_avg_last_13_week,
		   case when coalesce(last_13_week_units_avg,0) = 0 then (sum_sales_unit_cc-last_13_week_units_avg) else
		   ((sum_sales_unit_cc-last_13_week_units_avg)/coalesce(last_13_week_units_avg,1))*100 end AS percent_diff_units_13_week,
		   sum_ly_sales_unit_cc AS units_of_previous_year,
		   current_timestamp() AS execution_dttm
	FROM all_manu
	WHERE count_data_pre <> -99999999999
	UNION ALL
	SELECT case when upper(customer_name) = 'WALMART_ODP' then 'WALMART_OPD'
		   else customer_name end as retailer,
		   manufacturer,
		   start_date AS fiscal_week_begin_dt,
		   count_data AS row_count,
		   last_4_week_count_avg AS row_count_avg_last_4_week,
		   CASE WHEN coalesce(last_4_week_count_avg,0) = 0 then (count_data-last_4_week_count_avg)
		   else ((count_data-last_4_week_count_avg)/coalesce(last_4_week_count_avg,1))*100 end AS percent_diff_row_count_4_week,
		   last_13_week_count_avg AS row_count_avg_last_13_week,
		   CASE WHEN coalesce(last_13_week_count_avg,0) = 0 then (count_data-last_13_week_count_avg)
		   else ((count_data-last_13_week_count_avg)/coalesce(last_13_week_count_avg,1))*100 end AS percent_diff_row_count_13_week,
		   count_data_pre AS row_count_previous_week,
		   sum_sales_value_cc AS sales,
		   last_4_week_sales_avg AS sales_avg_last_4_week,
		   case when coalesce(last_4_week_sales_avg,0) = 0 then (sum_sales_value_cc-last_4_week_sales_avg) else 
		   ((sum_sales_value_cc-last_4_week_sales_avg)/coalesce(last_4_week_sales_avg,1))*100 end AS percent_diff_sales_4_week,
		   last_13_week_sales_avg AS sales_avg_last_13_week,
		   case when coalesce(last_13_week_sales_avg,0) = 0  then (sum_sales_value_cc-last_13_week_sales_avg) else 
		   ((sum_sales_value_cc-last_13_week_sales_avg)/coalesce(last_13_week_sales_avg,1))*100 end AS percent_diff_sales_13_week,
		   sum_ly_sales_value_cc AS sales_of_previous_year,
		   sum_sales_unit_cc AS units,
		   last_4_week_units_avg AS units_avg_last_4_week,
		   case when coalesce(last_4_week_units_avg,0) = 0 then (sum_sales_unit_cc-last_4_week_units_avg) else 
		   ((sum_sales_unit_cc-last_4_week_units_avg)/coalesce(last_4_week_units_avg,1))*100 end AS percent_diff_units_4_week,
		   last_13_week_units_avg AS units_avg_last_13_week,
		   case when coalesce(last_13_week_units_avg,0) = 0 then (sum_sales_unit_cc-last_13_week_units_avg) else
		   ((sum_sales_unit_cc-last_13_week_units_avg)/coalesce(last_13_week_units_avg,1))*100 end AS percent_diff_units_13_week,
		   sum_ly_sales_unit_cc AS units_of_previous_year,
		   current_timestamp() AS execution_dttm
	FROM gmi_manu
	WHERE count_data_pre <> -99999999999
	UNION ALL
	SELECT case when upper(customer_name) = 'WALMART_ODP' then 'WALMART_OPD'
		   else customer_name end as retailer,
		   manufacturer,
		   start_date AS fiscal_week_begin_dt,
		   count_data AS row_count,
		   last_4_week_count_avg AS row_count_avg_last_4_week,
		   CASE WHEN coalesce(last_4_week_count_avg,0) = 0 then (count_data-last_4_week_count_avg)
		   else ((count_data-last_4_week_count_avg)/coalesce(last_4_week_count_avg,1))*100 end AS percent_diff_row_count_4_week,
		   last_13_week_count_avg AS row_count_avg_last_13_week,
		   CASE WHEN coalesce(last_13_week_count_avg,0) = 0 then (count_data-last_13_week_count_avg)
		   else ((count_data-last_13_week_count_avg)/coalesce(last_13_week_count_avg,1))*100 end AS percent_diff_row_count_13_week,
		   count_data_pre AS row_count_previous_week,
		   sum_sales_value_cc AS sales,
		   last_4_week_sales_avg AS sales_avg_last_4_week,
		   case when coalesce(last_4_week_sales_avg,0) = 0 then (sum_sales_value_cc-last_4_week_sales_avg) else 
		   ((sum_sales_value_cc-last_4_week_sales_avg)/coalesce(last_4_week_sales_avg,1))*100 end AS percent_diff_sales_4_week,
		   last_13_week_sales_avg AS sales_avg_last_13_week,
		   case when coalesce(last_13_week_sales_avg,0) = 0  then (sum_sales_value_cc-last_13_week_sales_avg) else 
		   ((sum_sales_value_cc-last_13_week_sales_avg)/coalesce(last_13_week_sales_avg,1))*100 end AS percent_diff_sales_13_week,
		   sum_ly_sales_value_cc AS sales_of_previous_year,
		   sum_sales_unit_cc AS units,
		   last_4_week_units_avg AS units_avg_last_4_week,
		   case when coalesce(last_4_week_units_avg,0) = 0 then (sum_sales_unit_cc-last_4_week_units_avg) else 
		   ((sum_sales_unit_cc-last_4_week_units_avg)/coalesce(last_4_week_units_avg,1))*100 end AS percent_diff_units_4_week,
		   last_13_week_units_avg AS units_avg_last_13_week,
		   case when coalesce(last_13_week_units_avg,0) = 0 then (sum_sales_unit_cc-last_13_week_units_avg) else
		   ((sum_sales_unit_cc-last_13_week_units_avg)/coalesce(last_13_week_units_avg,1))*100 end AS percent_diff_units_13_week,
		   sum_ly_sales_unit_cc AS units_of_previous_year,
		   current_timestamp() AS execution_dttm
	FROM ngmi_manu
	WHERE count_data_pre <> -99999999999
);"""
);

SET create_table=CONCAT(
		"""CREATE OR REPLACE TABLE `ecomm-dlf-qa-ee8fb9.transient.Job_Run_Status_PROD`""",
		"""	(
			 grain     STRING,
			 customer_name_prod     STRING,
			 fiscal_week_begin_dt_prod     DATE,
			 customer_name_stage     STRING,
			 fiscal_week_begin_dt_stage     DATE,
			 job_run_status     STRING,
			 execution_dttm     TIMESTAMP
			);"""
		);
		
EXECUTE IMMEDIATE create_table;

EXECUTE IMMEDIATE CONCAT("""TRUNCATE TABLE ecomm-dlf-qa-ee8fb9.transient.Job_Run_Status_PROD;""");

EXECUTE IMMEDIATE ("""CREATE OR REPLACE TEMP TABLE prod_run_details AS (
select customer_name,grain, max(fiscal_week_begin_dt) as fiscal_week_begin_dt from `ecomm-analytics-prd-6238a8.output.gss_sales_share_us_nar_report` group by customer_name,grain
union all
select customer_name,grain, max(fiscal_week_begin_dt) as fiscal_week_begin_dt from `ecomm-analytics-prd-6238a8.output.gss_sales_share_ca_nar_report` group by customer_name,grain
union all
select customer_name,grain, max(fiscal_week_begin_dt) as fiscal_week_begin_dt from `ecomm-analytics-prd-6238a8.output.gss_sales_share_euau_report` group by customer_name,grain
union all
select CASE WHEN upper(customer_name)='INSTACART' THEN 'INSTACART_BLUE' WHEN upper(customer_name)='KROGER' THEN 'KROGER_BLUE' WHEN upper(customer_name)='HYVEE' THEN 'HYVEE_BLUE'
WHEN upper(customer_name)='MEIJER' THEN 'MEIJER_BLUE' WHEN upper(customer_name)='SHOPRITE' THEN 'SHOPRITE_BLUE'
ELSE customer_name end as customer_name,'WEEK' as grain, cast(max(fiscal_week_begin_dt) as DATE) as fiscal_week_begin_dt from `ecomm-analytics-prd-6238a8.output.gss_sales_share_blue_report` group by customer_name,grain
union all
select customer_name,grain, cast(max(fiscal_week_begin_dt) as DATE) as fiscal_week_begin_dt from `ecomm-analytics-prd-6238a8.output.gss_sales_share_france_report` group by customer_name,grain
)""");

EXECUTE IMMEDIATE ("""CREATE OR REPLACE TEMP TABLE stage_run_details AS (
select customer_name, max(fiscal_week_begin_dt) as fiscal_week_begin_dt from `ecomm-analytics-prd-6238a8.output.gss_sales_share_us_nar_report_stage` group by customer_name
union all
select customer_name, max(fiscal_week_begin_dt) as fiscal_week_begin_dt from `ecomm-analytics-prd-6238a8.output.gss_sales_share_ca_nar_report_stage` group by customer_name
union all
select customer_name, max(fiscal_week_begin_dt) as fiscal_week_begin_dt from `ecomm-analytics-prd-6238a8.output.gss_sales_share_euau_report_stage` group by customer_name
union all
select CASE WHEN upper(customer_name)='INSTACART' THEN 'INSTACART_BLUE' WHEN upper(customer_name)='KROGER' THEN 'KROGER_BLUE' WHEN upper(customer_name)='HYVEE' THEN 'HYVEE_BLUE'
WHEN upper(customer_name)='MEIJER' THEN 'MEIJER_BLUE' WHEN upper(customer_name)='SHOPRITE' THEN 'SHOPRITE_BLUE'
ELSE customer_name end as customer_name, cast(max(fiscal_week_begin_dt) as DATE) as fiscal_week_begin_dt from `ecomm-analytics-prd-6238a8.output.gss_sales_share_blue_report_stage` group by customer_name
union all
select customer_name, cast(max(fiscal_week_begin_dt) as DATE) as fiscal_week_begin_dt from `ecomm-analytics-prd-6238a8.output.gss_sales_share_france_report_stage` group by customer_name
)""");

EXECUTE IMMEDIATE
CONCAT("""INSERT INTO `ecomm-dlf-qa-ee8fb9.transient.Job_Run_Status_PROD`""",
"""(SELECT prod.grain as grain , prod.customer_name as customer_name_prod ,prod.fiscal_week_begin_dt as fiscal_week_begin_dt_prod ,stage.customer_name as customer_name_stage,stage.fiscal_week_begin_dt as fiscal_week_begin_dt_stage,
case when prod.customer_name=stage.customer_name and prod.fiscal_week_begin_dt<stage.fiscal_week_begin_dt then 'GCP Job ran with New Data'
when prod.customer_name=stage.customer_name and prod.fiscal_week_begin_dt>=stage.fiscal_week_begin_dt then 'Data is not Refreshed'
end as job_run_status,
current_timestamp()  AS execution_dttm
from prod_run_details prod
left join stage_run_details stage on prod.customer_name=stage.customer_name
order by prod.customer_name asc);""");
END;

