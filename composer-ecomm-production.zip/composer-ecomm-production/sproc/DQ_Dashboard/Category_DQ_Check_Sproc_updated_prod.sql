create or replace procedure `ecomm-dlf-qa-ee8fb9.transient.prod_sp_category_comparison`()
BEGIN
DECLARE create_table STRING;

SET create_table=CONCAT(
		"""CREATE OR REPLACE TABLE `ecomm-dlf-qa-ee8fb9.transient.DataQuality_Category_Trends_PROD`""",
		"""	(PARAMTER     STRING,
			 RETAILER     STRING,
			 FISCAL_WEEK_BEGIN_DT     DATE,
			 CATEGORY_NAMES     STRING,
			 MANUFACTURER     STRING,
			 SALES     FLOAT64,
			 AVG_4_WEEKS_SALES     FLOAT64,
			 AVG_13_WEEKS_SALES     FLOAT64,
			 LY_SALES     FLOAT64,
			 UNITS     INT64,
			 PERCENT_DIFF_SALES_13_WEEK FLOAT64,
			 PERCENT_DIFF_SALES_4_WEEK FLOAT64,
			 PERCENT_DIFF_SALES_LY FLOAT64,
			 EXECUTION_DTTM     TIMESTAMP
			);"""
		);
		
EXECUTE IMMEDIATE create_table;

EXECUTE IMMEDIATE CONCAT("""TRUNCATE TABLE ecomm-dlf-qa-ee8fb9.transient.DataQuality_Category_Trends_PROD;""");

EXECUTE IMMEDIATE ("""CREATE OR REPLACE TEMP TABLE category_analysis_table AS (
SELECT customer_name,
       fiscal_week_begin_dt,
       ty_sales_value,
       ty_sales_units,
	   sls_hier_division_desc,
	   sls_hier_category_desc,
	   global_category,
       resolved_brand,
       manufacturer,
       upc,
	   ly_sales_value
from `ecomm-analytics-prd-6238a8.output.gss_sales_share_us_nar_report_stage`
WHERE (NOT (coalesce(upc,'0') LIKE '%840243%'
        OR coalesce(upc,'0') LIKE '%859610%')) AND (CAST(fiscal_week_begin_dt AS DATE) >= DATE_SUB(current_date, INTERVAL 75 WEEK))
UNION DISTINCT
SELECT customer_name,
       fiscal_week_begin_dt,
       ty_sales_value,
       ty_sales_units,
	   sls_hier_division_desc,
	   sls_hier_category_desc,
	   global_category,
       resolved_brand,
       manufacturer,
       upc,
	   ly_sales_value
from `ecomm-analytics-prd-6238a8.output.gss_sales_share_ca_nar_report_stage`
WHERE (NOT (coalesce(upc,'0') LIKE '%840243%'
        OR coalesce(upc,'0') LIKE '%859610%')) AND (CAST(fiscal_week_begin_dt AS DATE) >= DATE_SUB(current_date, INTERVAL 75 WEEK))
UNION DISTINCT
SELECT customer_name,
       fiscal_week_begin_dt,
       ty_sales_value,
       ty_sales_units,
	   bph20_desc,
	   bph30_desc,
	   global_category,
       resolved_brand,
       manufacturer,
       upc,
	   ly_sales_value
from `ecomm-analytics-prd-6238a8.output.gss_sales_share_euau_report_stage`
WHERE (NOT (coalesce(upc,'0') LIKE '%840243%'
        OR coalesce(upc,'0') LIKE '%859610%')) AND (CAST(fiscal_week_begin_dt AS DATE) >= DATE_SUB(current_date, INTERVAL 75 WEEK))
UNION DISTINCT
SELECT CASE WHEN upper(customer_name)='INSTACART' THEN 'INSTACART_BLUE' WHEN upper(customer_name)='KROGER' THEN 'KROGER_BLUE'
WHEN upper(customer_name)='MEIJER' THEN 'MEIJER_BLUE' WHEN upper(customer_name)='SHOPRITE' THEN 'SHOPRITE_BLUE'
 ELSE customer_name end as customer_name,
       CAST(fiscal_week_begin_dt AS DATE) as fiscal_week_begin_dt,
       ty_sales_value,
       ty_sales_units,
	   species as sls_hier_division_desc,
	   foodform as sls_hier_category_desc,
	   subcategory as global_category,
       brandhigh as resolved_brand,
       manufacturer,
       upc,
	   ly_sales_value
from `ecomm-analytics-prd-6238a8.output.gss_sales_share_blue_report_stage`
WHERE (CAST(fiscal_week_begin_dt AS DATE) >= DATE_SUB(current_date, INTERVAL 75 WEEK))
UNION DISTINCT
SELECT customer_name,
       CAST(fiscal_week_begin_dt AS DATE) as fiscal_week_begin_dt,
       ty_sales_value,
       ty_sales_units,
	   sls_hier_division_desc,
	   sls_hier_category_desc,
	   global_category,
       resolved_brand,
       manufacturer,
       upc,
	   ly_sales_value
from `ecomm-analytics-prd-6238a8.output.gss_sales_share_france_report_stage`
WHERE (CAST(fiscal_week_begin_dt AS DATE) >= DATE_SUB(current_date, INTERVAL 75 WEEK))
)""");

EXECUTE IMMEDIATE ("""CREATE OR REPLACE TEMP TABLE agg_data AS (
WITH sls_hier_division_desc_cte AS (
  SELECT
    'sls_hier_division_desc' AS param,
    customer_name,
    fiscal_week_begin_dt,
    sls_hier_division_desc AS agg_name,
    CASE
      WHEN (LOWER(manufacturer) LIKE ('%general%mills%') OR LOWER(manufacturer) LIKE ('%gmi%')) THEN 'GMI'
    ELSE
    'Non-GMI'
  END
    AS manufacturer,
    COALESCE(SUM(ty_sales_value),0) AS sales,
    COALESCE(SUM(ty_sales_units),0) AS units,
	COALESCE(SUM(ly_sales_value),0) AS ly_sales
  FROM
    category_analysis_table
  GROUP BY
    customer_name,
    fiscal_week_begin_dt,
    sls_hier_division_desc,
    CASE
      WHEN (LOWER(manufacturer) LIKE ('%general%mills%') OR LOWER(manufacturer) LIKE ('%gmi%')) THEN 'GMI'
    ELSE
    'Non-GMI'
  END
    ),
sls_hier_category_desc_cte AS (
  SELECT
    'sls_hier_category_desc' AS param,
    customer_name,
    fiscal_week_begin_dt,
    sls_hier_category_desc AS agg_name,
    CASE
      WHEN (LOWER(manufacturer) LIKE ('%general%mills%') OR LOWER(manufacturer) LIKE ('%gmi%')) THEN 'GMI'
    ELSE
    'Non-GMI'
  END
    AS manufacturer,
    COALESCE(SUM(ty_sales_value),0) AS sales,
    COALESCE(SUM(ty_sales_units),0) AS units,
	COALESCE(SUM(ly_sales_value),0) AS ly_sales
  FROM
    category_analysis_table
  GROUP BY
    customer_name,
    fiscal_week_begin_dt,
    sls_hier_category_desc,
    CASE
      WHEN (LOWER(manufacturer) LIKE ('%general%mills%') OR LOWER(manufacturer) LIKE ('%gmi%')) THEN 'GMI'
    ELSE
    'Non-GMI'
  END
    ),
global_category_cte AS (
  SELECT
    'global_category' AS param,
    customer_name,
    fiscal_week_begin_dt,
    global_category AS agg_name,
    CASE
      WHEN (LOWER(manufacturer) LIKE ('%general%mills%') OR LOWER(manufacturer) LIKE ('%gmi%')) THEN 'GMI'
    ELSE
    'Non-GMI'
  END
    AS manufacturer,
    COALESCE(SUM(ty_sales_value),0) AS sales,
    COALESCE(SUM(ty_sales_units),0) AS units,
	COALESCE(SUM(ly_sales_value),0) AS ly_sales
  FROM
    category_analysis_table
  GROUP BY
    customer_name,
    fiscal_week_begin_dt,
    global_category,
    CASE
      WHEN (LOWER(manufacturer) LIKE ('%general%mills%') OR LOWER(manufacturer) LIKE ('%gmi%')) THEN 'GMI'
    ELSE
    'Non-GMI'
  END
    ),
 resolved_brand_cte AS (
  SELECT
    'resolved_brand' AS param,
    customer_name,
    fiscal_week_begin_dt,
    resolved_brand AS agg_name,
    CASE
      WHEN (LOWER(manufacturer) LIKE ('%general%mills%') OR LOWER(manufacturer) LIKE ('%gmi%')) THEN 'GMI'
    ELSE
    'Non-GMI'
  END
    AS manufacturer,
    COALESCE(SUM(ty_sales_value),0) AS sales,
    COALESCE(SUM(ty_sales_units),0) AS units,
	COALESCE(SUM(ly_sales_value),0) AS ly_sales
  FROM
    category_analysis_table
  GROUP BY
    customer_name,
    fiscal_week_begin_dt,
    resolved_brand,
    CASE
      WHEN (LOWER(manufacturer) LIKE ('%general%mills%') OR LOWER(manufacturer) LIKE ('%gmi%')) THEN 'GMI'
    ELSE
    'Non-GMI'
  END
    ),
manufacturer_cte AS (
  SELECT
    'manufacturer' AS param,
    customer_name,
    fiscal_week_begin_dt,
    manufacturer AS agg_name,
    manufacturer AS manufacturer,
    COALESCE(SUM(ty_sales_value),0) AS sales,
    COALESCE(SUM(ty_sales_units),0) AS units,
	COALESCE(SUM(ly_sales_value),0) AS ly_sales
  FROM
    category_analysis_table
  GROUP BY
    customer_name,
    fiscal_week_begin_dt,
    manufacturer ),
null_upc_cte as (
  SELECT
    'umapped_null_upc' AS param,
    customer_name,
    fiscal_week_begin_dt,
    'null' AS agg_name,
    CASE
      WHEN (LOWER(manufacturer) LIKE ('%general%mills%') OR LOWER(manufacturer) LIKE ('%gmi%')) THEN 'GMI'
    ELSE
    'Non-GMI'
  END
    AS manufacturer,
	COALESCE(SUM(ty_sales_value),0) AS sales,
    COALESCE(COUNT(*),0) AS units,
	COALESCE(SUM(ly_sales_value),0) AS ly_sales
  FROM
    category_analysis_table
  WHERE (coalesce(upc,
        ' ') =' ')
  GROUP BY
    customer_name,
    fiscal_week_begin_dt,
    CASE
      WHEN (LOWER(manufacturer) LIKE ('%general%mills%') OR LOWER(manufacturer) LIKE ('%gmi%')) THEN 'GMI'
    ELSE
    'Non-GMI'
  END
)
SELECT
  param,
  customer_name,
  fiscal_week_begin_dt,
  UPPER(agg_name) as agg_name,
  manufacturer,
  sales,
  units,
  ly_sales
FROM
  sls_hier_division_desc_cte
UNION ALL
SELECT
  param,
  customer_name,
  fiscal_week_begin_dt,
  UPPER(agg_name) as agg_name,
  manufacturer,
  sales,
  units,
  ly_sales
FROM
  sls_hier_category_desc_cte
UNION ALL
SELECT
  param,
  customer_name,
  fiscal_week_begin_dt,
  UPPER(agg_name) as agg_name,
  manufacturer,
  sales,
  units,
  ly_sales
FROM
  global_category_cte
UNION ALL
SELECT
  param,
  customer_name,
  fiscal_week_begin_dt,
  UPPER(agg_name) as agg_name,
  manufacturer,
  sales,
  units,
  ly_sales
FROM
  resolved_brand_cte
UNION ALL
SELECT
  param,
  customer_name,
  fiscal_week_begin_dt,
  UPPER(agg_name) as agg_name,
  CASE
    WHEN (LOWER(manufacturer) LIKE ('%general%mills%') OR LOWER(manufacturer) LIKE ('%gmi%')) THEN 'GMI'
  ELSE
  'Non-GMI'
END
  AS manufacturer,
  sales,
  units,
  ly_sales
FROM
  manufacturer_cte
UNION ALL
SELECT
  param,
  customer_name,
  fiscal_week_begin_dt,
  UPPER(agg_name) as agg_name,
  manufacturer,
  sales,
  units,
  ly_sales
FROM
  null_upc_cte
)""");

EXECUTE IMMEDIATE CONCAT(""" INSERT INTO `ecomm-dlf-qa-ee8fb9.transient.DataQuality_Category_Trends_PROD`
(
SELECT
param,
customer_name,
fiscal_week_begin_dt,
agg_name,
manufacturer,
sales,
last_4_week_sales_avg,
last_13_week_sales_avg,
ly_sales,
units,
IF(last_13_week_sales_avg !=0 ,((sales-last_13_week_sales_avg)/last_13_week_sales_avg)*100,(0-last_13_week_sales_avg)*100) as var_wrt_13_week_avg,
IF(last_4_week_sales_avg !=0 ,((sales-last_4_week_sales_avg)/last_4_week_sales_avg)*100,(0-last_4_week_sales_avg)*100) as var_wrt_4_week_avg,
IF(ly_sales !=0 ,((sales-ly_sales)/ly_sales)*100,(0-ly_sales)*100) as var_wrt_ly_sales,
CURRENT_TIMESTAMP()
FROM 
(
SELECT
param,
customer_name,
fiscal_week_begin_dt,
agg_name,
manufacturer,
sales,
AVG(sales) OVER( PARTITION BY param,customer_name,agg_name ORDER BY fiscal_week_begin_dt DESC ROWS BETWEEN 1 FOLLOWING AND 4 FOLLOWING) AS last_4_week_sales_avg,
AVG(sales) OVER( PARTITION BY param,customer_name,agg_name ORDER BY fiscal_week_begin_dt DESC ROWS BETWEEN 1 FOLLOWING AND 13 FOLLOWING) AS last_13_week_sales_avg,
ly_sales,
units,
CURRENT_TIMESTAMP()
from agg_data
WHERE (CAST(fiscal_week_begin_dt AS DATE) >= DATE_SUB(current_date, INTERVAL 60 WEEK))
)q
)""");
END;