  /*
Purpose of the stored proc: 
	History Data extraction for 'harris_teeter' customer
History of Changes:
	06/02 – first version 
Author : 
	Anil Byna
How to Call:
CALL
  transient.sp_harris_teeter_delta_temp_hist(99,
    'ecomm-dlf-dev-01cd47',
    'transient',
    'HARRIS_TEETER',
    'shareddata-prd-cb5872',
    'shared_data_ecom',
    'ecom_harris_teeter_weekly_sales_raw_v');
CALL
  transient.sp_dim_source_to_enterprise_upc_xref(99,
    'ecomm-dlf-dev-01cd47',
    'transient',
    'processed',
    'raw',
    'shareddata-prd-cb5872',
    'shared_data_enterprise',
    'HARRIS_TEETER',
    'harris_teeter_delta_temp',
    'dim_source_to_enterprise_upc_xref');
CALL
  transient.sp_customer_processed_zero(99,
    'ecomm-dlf-dev-01cd47',
    'transient',
    'harris_teeter_delta_temp',
    'harris_teeter_processed_zero',
    'harris_teeter_processed_zero_archive',
    'HARRIS_TEETER',
    'HARRIS_TEETER');
*/
CREATE PROCEDURE IF NOT EXISTS
  transient.sp_harris_teeter_delta_temp_hist ( job_run_id INT64,
    bq_project_name STRING,
    bq_transient_dataset_name STRING,
    customer_name STRING,
    bq_prod_project_name STRING,
    bq_prod_dataset_name STRING,
    raw_table_name STRING )
BEGIN
EXECUTE IMMEDIATE
  CONCAT("""TRUNCATE TABLE  `""",bq_project_name,"""`.""",bq_transient_dataset_name,""".""","""harris_teeter_delta_temp"""); /*Insert Details for passed customer into 'kroger_ship_sales_delta_temp' table having ingest date greater than extract_start_date 
from data_extract_config table */
EXECUTE IMMEDIATE
  CONCAT( """insert into  `""",bq_project_name,"""`.""",bq_transient_dataset_name,""".""","""harris_teeter_delta_temp  
( 
with dr as 
(
	select
	  'WEEK' AS grain 
	, 'HARRIS_TEETER'  AS retailer	  
	, '""",customer_name,"""' AS customer_name
	,  cast(parse_date('%Y-%m-%d', h.week_end_date ) as timestamp) as week_end_date
	,  h.upc
	,  h.description
	,  h.sz
	,  h.uom
	,  cast(h.total_sales as FLOAT64) total_sales
	,  cast(h.express_lane_sales as FLOAT64) express_lane_sales
	,  CAST(ROUND(SAFE_CAST(total_units as NUMERIC)) as INT64) as total_units
	,  CAST(ROUND(SAFE_CAST(express_lane_units as NUMERIC)) as INT64) as express_lane_units
	,  CAST(ROUND(SAFE_CAST(total_visits as NUMERIC)) as INT64) as total_visits
	,  CAST(ROUND(SAFE_CAST(express_lane_visits as NUMERIC)) as INT64) as express_lane_visits
	,  safe_cast(h.el_pct_sls as FLOAT64) el_pct_sls
	,  safe_cast(h.el_pct_unts as FLOAT64) el_pct_unts
	
	,  cast(h.express_lane_sales as FLOAT64) ty_sales_value
	,  CAST(ROUND(SAFE_CAST(express_lane_units as NUMERIC)) as INT64) as ty_sales_units
	,  h.description AS source_item_name
	, 'History load' original_file_name
	, '01/01/0001' file_dt
	, GENERATE_UUID() rctl_uuid
	, current_timestamp ingest_date
	, 'History load' rctl_file_name	
	, '""",job_run_id,"""' created_by 
	, current_datetime created_datetime 
	, '""",job_run_id,"""' modified_by 
	, current_datetime modified_datetime 
	
	-- the following ranking is done to avoid duplicates if there are duplicates
	-- for the same vendor file natural key in the raw table replicated from hadoop. 
	-- The data is partitioned on the natural key of the vendor file. 
	-- The data is then ordered descending on pynamic_version_ts which is 
	-- the create timestamp of the record in the raw table.  
	-- Picking rank = 1 will result in the record with latest create timestamp 
	-- to be selected in case duplicate records exist in the raw table 
	-- ***across different create timestamps***.
	
	, ROW_NUMBER() over (
							partition by upc,
										cast(parse_date('%Y-%m-%d', h.week_end_date ) as timestamp)
							order by 
								hadoop_update_ts desc
						) rnk_1
						
	from 
		`""",bq_prod_project_name,"""`.""",bq_prod_dataset_name,""".""",raw_table_name,""" h 
)
    select
	  grain 
	, retailer	  
	, customer_name
	,  week_end_date
	,  upc
	,  description
	,  sz
	,  uom
	,  total_sales
	,  express_lane_sales
	,  total_units
	,  express_lane_units
	,  total_visits total_visits
	,  express_lane_visits
	,  el_pct_sls
	,  el_pct_unts
	, source_item_name
	, ty_sales_value
	, ty_sales_units
	, original_file_name
	, file_dt
	, ingest_date
	, rctl_file_name
	, rctl_uuid	
	, created_by 
	, created_datetime 
	, modified_by 
	, modified_datetime 
    from 
		dr 
	where 
		rnk_1 = 1
 )
""") ; EXCEPTION
    WHEN ERROR THEN SELECT ERROR ( CONCAT( @@error.message,' ', @@error.statement_text, ' ', @@error.formatted_stack_trace,' ' ) ) ;
END