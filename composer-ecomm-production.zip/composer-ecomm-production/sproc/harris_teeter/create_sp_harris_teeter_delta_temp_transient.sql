/*
Purpose of the stored proc: 
	Delta Data extraction for 'harris_teeter' customer
History of Changes:
	04/21 – first version 
Author : 
	Dan Bicknell
How to Call:
		call transient.sp_harris_teeter_delta_temp
		(
		 99,
		'ecomm-dlf-dev-01cd47',
		'raw',
		'transient' ,
		'harris_teeter',
		'harris_teeter_sales'
		)

*/



CREATE PROCEDURE IF NOT EXISTS transient.sp_harris_teeter_delta_temp
( 
	job_run_id INT64,
	bq_project_name string,
	bq_raw_dataset_name string,
	bq_transient_dataset_name string,	
	customer_name string, 
	raw_table_name string
)
BEGIN
-- declare variables
DECLARE extract_start_date,extract_end_date Timestamp;

/* Get Extract start datetime for incoming table from data_extract_config table */
EXECUTE IMMEDIATE
  CONCAT("""select extract_start_datetime from `""",bq_project_name,"""`.""",bq_transient_dataset_name,""".""","""data_extract_config
where table_name = '""",raw_table_name,"""' and status = 'running' 
and active_flag = 'Y'""") INTO extract_start_date;

/* Get Extract end datetime for incoming table from data_extract_config table */
EXECUTE IMMEDIATE
  CONCAT("""select extract_end_datetime from `""",bq_project_name,"""`.""",bq_transient_dataset_name,""".""", """data_extract_config 
  where table_name = '""",raw_table_name,"""' and status = 'running'  and active_flag = 'Y'""") INTO extract_end_date;


EXECUTE IMMEDIATE
CONCAT("""TRUNCATE TABLE  `""" ,bq_project_name,"""`.""",bq_transient_dataset_name,""".""","""harris_teeter_delta_temp""");

	/*Insert Details for passed customer into 'kroger_ship_sales_delta_temp' table having ingest date greater than extract_start_date 
from data_extract_config table */
EXECUTE IMMEDIATE
CONCAT(
"""insert into  `""" ,bq_project_name,"""`.""",bq_transient_dataset_name,""".""","""harris_teeter_delta_temp  
( 
with dr as 
(
	select
	  'WEEK' AS grain 
	, 'HARRIS_TEETER'  AS retailer	  
	, '""",customer_name,"""' AS customer_name


	,  cast(parse_date('%Y-%m-%d', h.week_end_date ) as timestamp) as week_end_date
	,  h.upc
	,  h.description
	,  h.sz
	,  h.uom
	,  cast(h.total_sales as FLOAT64) total_sales
	,  cast(h.express_lane_sales as FLOAT64) express_lane_sales
	,  CAST(ROUND(SAFE_CAST(total_units as NUMERIC)) as INT64) as total_units
	,  CAST(ROUND(SAFE_CAST(express_lane_units as NUMERIC)) as INT64) as express_lane_units
	,  CAST(ROUND(SAFE_CAST(total_visits as NUMERIC)) as INT64) as total_visits
	,  CAST(ROUND(SAFE_CAST(express_lane_visits as NUMERIC)) as INT64) as express_lane_visits
	,  safe_cast(h.el_pct_sls as FLOAT64) el_pct_sls
	,  safe_cast(h.el_pct_unts as FLOAT64) el_pct_unts

	,  cast(h.express_lane_sales as FLOAT64) ty_sales_value
	,  CAST(ROUND(SAFE_CAST(express_lane_units as NUMERIC)) as INT64) as ty_sales_units
	,  h.description AS source_item_name

	
	, original_file_name
	, file_dt
	, rctl_uuid
	, timestamp(ingest_date) ingest_date
	, rctl_file_name	
	, '""",job_run_id,"""' created_by 
	, current_datetime created_datetime 
	, '""",job_run_id,"""' modified_by 
	, current_datetime modified_datetime 
	
	-- the following ranking is done to avoid duplicates if multiple files
	-- are loaded in one run. The data is partitioned on the natural key 
	-- of the file. The data is then ordered descending on file_dt which is 
	-- the timestamp on the file.  Picking rank = 1 will result in the record 
	-- with latest file_dt being picked in case duplicate records
	-- exist in the raw table ***across different files***.
	
	, dense_rank() over (
							partition by upc,
										cast(parse_date('%Y-%m-%d', h.week_end_date ) as timestamp)
							order by 
								PARSE_timestamp("%m-%d-%Y %H:%M:%S", h.file_dt) desc
						) rnk_1
						
	
	-- the following ranking is done to avoid duplicates if the ****same file
	-- is loaded multiple times****. The data is partitioned on the natural key 
	-- of the file and the file_dt which is the timestamp on the file
	-- The data is then ordered descending on ingest_date which is the current timestamp
	-- coming from the ingestion framework.  Picking rank = 1 will result
	-- in the record with latest ingest_date being picked in case duplicate records
	-- exist in the raw table.  THIS SCENARIO WILL TYPICALLY NOT OCCUR.
	-- Please note the use of ROW_NUMBER function to pick one record.
	-- This function will be needed when the entire RAW table is read to reprocess history.
	
	, row_number() over (
							partition by upc,
										cast(parse_date('%Y-%m-%d', h.week_end_date ) as timestamp),
										PARSE_timestamp("%m-%d-%Y %H:%M:%S", file_dt)
							order by 
								 ingest_date desc
						) rnk_2

	from 
		`""" ,bq_project_name,"""`.""",bq_raw_dataset_name,""".""",raw_table_name,""" h 
	where 
		h.ingest_date > '""",extract_start_date,"""' 
	and h.ingest_date  <= '""",extract_end_date,"""'
)
    select
	  grain 
	, retailer	  
	, customer_name
	
	,  week_end_date
	,  upc
	,  description
	,  sz
	,  uom
	,  total_sales
	,  express_lane_sales
	,  total_units
	,  express_lane_units
	,  total_visits total_visits
	,  express_lane_visits
	,  el_pct_sls
	,  el_pct_unts

	, source_item_name
	, ty_sales_value
	, ty_sales_units
	, original_file_name
	, file_dt
	, ingest_date
	, rctl_file_name
	, rctl_uuid	
	, created_by 
	, created_datetime 
	, modified_by 
	, modified_datetime 
    from 
		dr 
	where 
		rnk_1 = 1  and rnk_2 = 1
 )
""") ;

EXCEPTION WHEN ERROR THEN
    SELECT  
	ERROR (
		CONCAT(
    			@@error.message ,' ' ,
    			@@error.statement_text, ' ' ,
    			@@error.formatted_stack_trace ,' '
			)
		)
	;

END


