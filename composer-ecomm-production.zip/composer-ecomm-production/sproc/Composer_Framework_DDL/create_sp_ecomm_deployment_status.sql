CREATE OR REPLACE PROCEDURE transient.sp_ecomm_deployment_status()
OPTIONS(
description= """ This procedure is used to compare sproc and ddl across DEV, QA & PROD.

	How to Call:

	CALL transient.sp_ecomm_deployment_status();

"""
)
BEGIN

CREATE OR REPLACE TABLE processed.ecomm_deployment_status
(
  match_type STRING,
  specific_schema STRING,
  specific_name STRING,
  status STRING,
  run_date DATE
);

INSERT INTO processed.ecomm_deployment_status
WITH sproc_details as (
    SELECT
    		'SPROC' as match_type,
    		p.specific_schema,
    		p.specific_name,
    		CASE
    		     WHEN
    		              COALESCE(p.routine_definition,'p') <> COALESCE(q.routine_definition,'q')
    		          AND COALESCE(p.routine_definition,'p') <> COALESCE(d.routine_definition,'d')
    		          THEN 'Sproc are not matching in all 3 environments'
    			 WHEN
    			          COALESCE(p.routine_definition,'p') <> COALESCE(q.routine_definition,'q')
    		          AND COALESCE(p.routine_definition,'p') =  COALESCE(d.routine_definition,'d')
    		          THEN 'Prod Sproc is not matching with QA. But matches with Dev'
    			 WHEN
    			          COALESCE(p.routine_definition,'p') <> COALESCE(d.routine_definition,'d')
    		          AND COALESCE(p.routine_definition,'p') =  COALESCE(q.routine_definition,'q')
    		          THEN 'Prod Sproc is not matching with Dev. But matches with QA'
    			 WHEN
    		              COALESCE(q.routine_definition,'q') <> COALESCE(d.routine_definition,'d')
    		          THEN 'QA Sproc is not matching with Dev'
    			 WHEN
    		              COALESCE(p.routine_definition,'p') = COALESCE(q.routine_definition,'q')
    		          AND COALESCE(p.routine_definition,'p') = COALESCE(d.routine_definition,'d')
    		          THEN 'Sproc are matching in all 3 environments'
    			 WHEN
    		              COALESCE(q.routine_definition,'q') = COALESCE(d.routine_definition,'d')
    		          THEN 'QA Sproc is matching with Dev'
    			 ELSE ''
    		END as status,
    		current_date() as run_date
    FROM `ecomm-dlf-prd-634888`.transient.INFORMATION_SCHEMA.ROUTINES       p
    INNER JOIN `ecomm-dlf-qa-ee8fb9`.transient.INFORMATION_SCHEMA.ROUTINES  q  on p.specific_name = q.specific_name
    INNER JOIN `ecomm-dlf-dev-01cd47`.transient.INFORMATION_SCHEMA.ROUTINES d  on p.specific_name = d.specific_name
),
table_details as (
    SELECT
    		'TABLE' as match_type,
    		p.table_schema,
    		p.table_name,
    		CASE
    		    WHEN
    		              COALESCE(REPLACE(p.ddl,CONCAT(p.table_catalog,'.'),''),'p') <> COALESCE(REPLACE(q.ddl,CONCAT(q.table_catalog,'.'),''),'q')
    		          AND COALESCE(REPLACE(p.ddl,CONCAT(p.table_catalog,'.'),''),'p') <> COALESCE(REPLACE(d.ddl,CONCAT(d.table_catalog,'.'),''),'d')
    		          THEN 'Table are not matching in all 3 environments'
    			 WHEN
    			          COALESCE(REPLACE(p.ddl,CONCAT(p.table_catalog,'.'),''),'p') <> COALESCE(REPLACE(q.ddl,CONCAT(q.table_catalog,'.'),''),'q')
    		          AND COALESCE(REPLACE(p.ddl,CONCAT(p.table_catalog,'.'),''),'p') =  COALESCE(REPLACE(d.ddl,CONCAT(d.table_catalog,'.'),''),'d')
    		          THEN 'Prod Table is not matching with QA. But matches with Dev'
    			 WHEN
    			          COALESCE(REPLACE(p.ddl,CONCAT(p.table_catalog,'.'),''),'p') <> COALESCE(REPLACE(d.ddl,CONCAT(d.table_catalog,'.'),''),'d')
    		          AND COALESCE(REPLACE(p.ddl,CONCAT(p.table_catalog,'.'),''),'p') =  COALESCE(REPLACE(q.ddl,CONCAT(q.table_catalog,'.'),''),'q')
    		          THEN 'Prod Table is not matching with Dev. But matches with QA'
    			 WHEN
    			          COALESCE(REPLACE(q.ddl,CONCAT(q.table_catalog,'.'),''),'q') <> COALESCE(REPLACE(d.ddl,CONCAT(d.table_catalog,'.'),''),'d')
    		          THEN 'QA Table is not matching with Dev'
    			 WHEN
    			          COALESCE(REPLACE(p.ddl,CONCAT(p.table_catalog,'.'),''),'p') = COALESCE(REPLACE(q.ddl,CONCAT(q.table_catalog,'.'),''),'q')
    		          AND COALESCE(REPLACE(p.ddl,CONCAT(p.table_catalog,'.'),''),'p') = COALESCE(REPLACE(d.ddl,CONCAT(d.table_catalog,'.'),''),'d')
    		          THEN 'Table are matching in all 3 environments'
    			 WHEN
    			          COALESCE(REPLACE(q.ddl,CONCAT(q.table_catalog,'.'),''),'q') = COALESCE(REPLACE(d.ddl,CONCAT(d.table_catalog,'.'),''),'d')
    		          THEN 'QA Table is matching with Dev'
    			 ELSE ''
    		END as status,
    		current_date() as run_date
    FROM `ecomm-dlf-prd-634888`.transient.INFORMATION_SCHEMA.TABLES       p
    INNER JOIN `ecomm-dlf-qa-ee8fb9`.transient.INFORMATION_SCHEMA.TABLES  q  on   p.table_schema = q.table_schema
    																	     AND  p.table_name   = q.table_name
    INNER JOIN `ecomm-dlf-dev-01cd47`.transient.INFORMATION_SCHEMA.TABLES d  on   p.table_schema = d.table_schema
    																	     AND  p.table_name   = d.table_name
)
SELECT *
FROM table_details
UNION DISTINCT
SELECT *
FROM sproc_details;

END;