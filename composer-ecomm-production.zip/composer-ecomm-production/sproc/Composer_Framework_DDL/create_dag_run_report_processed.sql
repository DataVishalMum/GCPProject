CREATE OR REPLACE TABLE processed.dag_run_logs
(
  dag_id STRING,
  task_id STRING,
  dag_execution_date TIMESTAMP,
  dag_status STRING,
  task_execution_date TIMESTAMP,
  task_status STRING,
  logs_path STRING,
  dag_url STRING,
  triggered_by STRING
);