/*
Purpose of the stored proc: 
	Delta Data extraction for 'chewy' customer
History of Changes:
	12/09 – first version
Author : 
	Pawan Rathod
How to Call:
		call transient.sp_chewy_delta_temp
		(
		 99,
		'ecomm-dlf-dev-01cd47',
		'raw',
		'transient' ,
		'chewy_sales',
		'chewy_delta_temp',
		'CHEWY'
		);

One time : INSERT INTO `ecomm-dlf-dev-01cd47.transient.gmi_customer_metadata_reference` VALUES ('CHEWY','CHEWY','upc,report_date','customer_name,upc,source_item_name','upc,fiscal_year_week_nbr,source_item_name,manufacturer,customer_account,resolved_category,global_category_parent,resolved_brand,zone_hierarchy','customer_name,source_item_name,upc,source_product_hash','report_date','','CHEWY','','ty_cogs_value,ly_cogs_value','gss_sales_share_blue_report');
insert into `ecomm-dlf-dev-01cd47.transient.data_extract_config`  values ( 'chewy_sales', cast ('1800-01-01 00:00:00' as timestamp), cast ('1800-01-01 00:00:00' as timestamp), 'Y','complete','GMI',current_timestamp,'GMI',current_timestamp ) ;
*/

CREATE PROCEDURE IF NOT EXISTS
  transient.sp_chewy_delta_temp ( job_run_id int64,
    bq_project_name string,
    bq_raw_dataset_name string,
    bq_transient_dataset_name string,
    bq_raw_table_name string,
    bq_delta_temp_tablename string,
    customer_name string )
BEGIN

-- declare variables
DECLARE 
	 extract_start_date
	,extract_end_date Timestamp;

/* Get Extract start datetime for incoming table from data_extract_config table */
EXECUTE IMMEDIATE
  CONCAT("""select extract_start_datetime from `""",bq_project_name,"""`.""",bq_transient_dataset_name,""".""","""data_extract_config
where table_name = '""",bq_raw_table_name,"""' and status = 'running'
and active_flag = 'Y'""") INTO extract_start_date;

/* Get Extract end datetime for incoming table from data_extract_config table */
EXECUTE IMMEDIATE
  CONCAT("""select extract_end_datetime from `""",bq_project_name,"""`.""",bq_transient_dataset_name,""".""", """data_extract_config 
  where table_name = '""",bq_raw_table_name,"""' and status = 'running'  and active_flag = 'Y'""") INTO extract_end_date;

/* Delta Temp Table is Truncate & Load */
EXECUTE IMMEDIATE
CONCAT("""TRUNCATE TABLE  `""" ,bq_project_name,"""`.""",bq_transient_dataset_name,""".""",bq_delta_temp_tablename);

	/*Insert Details for passed customer into 'chewy_delta_temp' table having ingest date greater than extract_start_date
from data_extract_config table */
EXECUTE IMMEDIATE
CONCAT("""insert into  `""" ,bq_project_name,"""`.""",bq_transient_dataset_name,""".""",bq_delta_temp_tablename,
"""
(
   WITH
     bb AS(
     SELECT
       DISTINCT platformproductidentifier,
       nielsenupc
       FROM `""" ,bq_project_name,"""`.processed.lkp_stonehenge_product_master
       WHERE lower(platformname) = 'chewy.com'),
     dr AS (
     SELECT
       'WEEK' AS grain,
       'CHEWY' AS retailer,
       '""",customer_name,"""' AS customer_name,
       CAST(DATE_ADD(PARSE_DATE('%m/%d/%Y',trim(ecs.week_of)), INTERVAL 1 DAY) as TIMESTAMP) AS report_date,
       bb.nielsenupc AS upc,
       ecs.brand,
       ecs.part_number,
       vendor_part_number,
       COALESCE(bb.nielsenupc) AS source_item_code,
       SAFE_CAST(null as STRING) as source_item_name,
       COALESCE(SAFE_CAST(regexp_replace(ecs.cogs,  r"[^0-9.]", '') as float64),0) as ty_cogs_value,
       COALESCE(SAFE_CAST(regexp_replace(ecs.cpu,  r"[^0-9.]", '') as float64),0) as cpu,
       COALESCE(SAFE_CAST(regexp_replace(ecs.sales,  r"[^0-9.]", '') as float64),0) as ty_sales_value,
       COALESCE(SAFE_CAST(regexp_replace(ecs.units_sold,  r"[^0-9.]", '') as int64),0) as ty_sales_units,
       ecs.original_file_name,
       ecs.file_dt,
       ecs.rctl_uuid,
       TIMESTAMP(ecs.ingest_date) ingest_date,
       ecs.rctl_file_name,
       '""",job_run_id,"""' created_by,
       current_datetime created_datetime,
       '""",job_run_id,"""' modified_by,
       current_datetime modified_datetime,

	   -- the following ranking is done to avoid duplicates if multiple files
	   -- are loaded in one run. The data is partitioned on the natural key
	   -- of the file. The data is then ordered descending on file_dt which is
	   -- the timestamp on the file.  Picking rank = 1 will result in the record
	   -- with latest file_dt being picked in case duplicate records
	   -- exist in the raw table ***across different files***.

       DENSE_RANK() OVER (PARTITION BY bb.nielsenupc,ecs.week_of
                          ORDER BY PARSE_TIMESTAMP("%m-%d-%Y %H:%M:%S", ecs.file_dt) DESC
                          ) AS rnk_1,

	   -- the following ranking is done to avoid duplicates if the ****same file
	   -- is loaded multiple times****. The data is partitioned on the natural key
	   -- of the file and the file_dt which is the timestamp on the file
	   -- The data is then ordered descending on ingest_date which is the current timestamp
	   -- coming from the ingestion framework.  Picking rank = 1 will result
	   -- in the record with latest ingest_date being picked in case duplicate records
	   -- exist in the raw table.  THIS SCENARIO WILL TYPICALLY NOT OCCUR.
	   -- Please note the use of ROW_NUMBER function to pick one record.
	   -- This function will be needed when the entire RAW table is read to reprocess history.

       ROW_NUMBER() OVER (PARTITION BY
                          bb.nielsenupc,
                          ecs.week_of,
                          PARSE_TIMESTAMP("%m-%d-%Y %H:%M:%S", ecs.file_dt)
                          ORDER BY ecs.ingest_date DESC, COALESCE(SAFE_CAST(regexp_replace(ecs.sales,  r"[^0-9.]", '') as float64),0) DESC
                          ) rnk_2

       FROM
         `""" ,bq_project_name,"""`.""",bq_raw_dataset_name,""".""",bq_raw_table_name,""" ecs
       LEFT JOIN
         bb on bb.platformproductidentifier = ecs.part_number
       WHERE
             ecs.ingest_date > '""",extract_start_date,"""'
	     AND ecs.ingest_date <= '""",extract_end_date,"""')
   SELECT
     grain,
     retailer,
     customer_name,
     report_date,
     upc,
     brand,
     part_number,
     vendor_part_number,
     source_item_name,
     source_item_code,
     ty_cogs_value,
     cpu,
     ty_sales_value,
     ty_sales_units,
     original_file_name,
     file_dt,
     ingest_date,
     rctl_file_name,
     rctl_uuid,
     created_by,
     created_datetime,
     modified_by,
     modified_datetime
   FROM
     dr
   WHERE
     rnk_1 = 1
     AND rnk_2 = 1
 )
""") ;

EXCEPTION WHEN ERROR THEN
    SELECT  
	ERROR (
		CONCAT(
    			@@error.message ,' ' ,
    			@@error.statement_text, ' ' ,
    			@@error.formatted_stack_trace ,' '
			)
		)
	;

END;

