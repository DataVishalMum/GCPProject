/*
Purpose of the stored proc:
	History Load for 'asda' customer
History of Changes:
	15/06 – first version
Author :
	Vijayandra Mahadik
How to Call:
CALL
  transient.sp_asda_delta_temp_hist
  (  -99,
    'ecomm-dlf-dev-01cd47',
    'transient',
    'ASDA',
    'shareddata-prd-cb5872',
    'sales_ecomm_global_sales_and_share',
    'ecom_asda_nielsen_sales_raw_v',
    'asda_delta_temp'
   );
*/

CREATE PROCEDURE IF NOT EXISTS
  transient.sp_asda_delta_temp_hist (
    job_run_id int64,
    bq_project_name string,
    bq_transient_dataset_name string,
    customer_name string,
    bq_prod_project_name STRING,
    bq_prod_dataset_name STRING,
    bq_raw_table_name string,
    bq_delta_temp_tablename string)
BEGIN

/* Delta Temp Table is Truncate & Load */
EXECUTE IMMEDIATE
CONCAT("""TRUNCATE TABLE  `""" ,bq_project_name,"""`.""",bq_transient_dataset_name,""".""",bq_delta_temp_tablename);

	/*Insert Details for passed customer into 'asda_delta_temp' table having ingest date greater than extract_start_date
from data_extract_config table */
EXECUTE IMMEDIATE
CONCAT("""insert into  `""" ,bq_project_name,"""`.""",bq_transient_dataset_name,""".""",bq_delta_temp_tablename,
"""
(
   WITH
     dr AS (
     SELECT
	   'WEEK' AS grain,
	   'ASDA' AS retailer,
	   '""",customer_name,"""' AS customer_name,
	   nielsen_division,
	   product_description as source_item_name,
	   sector,
	   sub_sector,
	   format,
	   manufacturer as nielsen_manufacturer,
	   brand as nielsen_brand,
	   sub_brand as nielsen_sub_brand,
	   weight_packsize,
	   nielsen_upc as source_item_code,
	   nielsen_upc,
	   nielsen_upc as upc,
	   nielsen_database,
       -- week_end_date is of the form 'WE 04 July 2020'; day= %d (01-31); month= %B (full month name);
       CAST(PARSE_DATE('%d %B %Y',
           SUBSTR(week_end_date,4)) AS TIMESTAMP) as week_end_date,
	   cast(sales as FLOAT64) ty_sales_value,
	   cast(units as INT64)as  ty_sales_units,
       'History load' as original_file_name,
       '01/01/0001' as file_dt,
       current_timestamp as ingest_date,
       'History load' as rctl_file_name,
       GENERATE_UUID() as rctl_uuid,
       '""",job_run_id,"""' created_by,
       current_datetime created_datetime,
       '""",job_run_id,"""' modified_by,
       current_datetime modified_datetime,

	   -- the following ranking is done to avoid duplicates if multiple files
	   -- are loaded in one run. The data is partitioned on the natural key
	   -- of the file. The data is then ordered descending on hadoop_update_ts which is
	   -- the timestamp on the file.  Picking rank = 1 will result in the record
	   -- with latest file_dt being picked in case duplicate records
	   -- exist in the raw table ***across different files***.

       ROW_NUMBER() OVER (PARTITION BY nielsen_upc,
                                       CAST(PARSE_DATE('%d %B %Y',
                                            SUBSTR(week_end_date,4)) AS TIMESTAMP)
                          ORDER BY hadoop_update_ts DESC
                          ) AS rnk_1,

       FROM
         `""" ,bq_prod_project_name,"""`.""",bq_prod_dataset_name,""".""",bq_raw_table_name,"""
	      where week_end_date is not null)
   SELECT
     grain,
     retailer,
     customer_name,
     nielsen_division,
     source_item_name,
     sector,
     sub_sector,
     format,
     nielsen_manufacturer,
     nielsen_brand,
     nielsen_sub_brand,
     weight_packsize,
     source_item_code,
     nielsen_upc,
     upc,
     nielsen_database,
     week_end_date,
     ty_sales_value,
     ty_sales_units,
     original_file_name,
     file_dt,
     ingest_date,
     rctl_file_name,
     rctl_uuid,
     created_by,
     created_datetime,
     modified_by,
     modified_datetime
   FROM
     dr
   WHERE
     rnk_1 = 1
 )
""") ;

EXCEPTION WHEN ERROR THEN
    SELECT
	ERROR (
		CONCAT(
    			@@error.message ,' ' ,
    			@@error.statement_text, ' ' ,
    			@@error.formatted_stack_trace ,' '
			)
		)
	;

END