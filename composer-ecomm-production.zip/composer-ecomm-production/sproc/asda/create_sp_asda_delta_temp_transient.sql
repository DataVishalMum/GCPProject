/*
Purpose of the stored proc:
	Delta Data extraction for 'asda' customer
History of Changes:
	05/06 – first version
Author :
	Vijayandra Mahadik
How to Call:
		call transient.sp_asda_delta_temp
		(
		 -99,
		'ecomm-dlf-dev-01cd47',
		'raw',
		'transient',
		'asda_sales_share',
		'asda_delta_temp',
		'ASDA'
		)

*/

CREATE PROCEDURE IF NOT EXISTS
  transient.sp_asda_delta_temp (
    job_run_id int64,
    bq_project_name string,
    bq_raw_dataset_name string,
    bq_transient_dataset_name string,
    bq_raw_table_name string,
    bq_delta_temp_tablename string,
    customer_name string )
BEGIN

-- declare variables
DECLARE
	 extract_start_date
	,extract_end_date Timestamp;

/* Get Extract start datetime for incoming table from data_extract_config table */
EXECUTE IMMEDIATE
  CONCAT("""select extract_start_datetime from `""",bq_project_name,"""`.""",bq_transient_dataset_name,""".""","""data_extract_config
where table_name = '""",bq_raw_table_name,"""' and status = 'running'
and active_flag = 'Y'""") INTO extract_start_date;

/* Get Extract end datetime for incoming table from data_extract_config table */
EXECUTE IMMEDIATE
  CONCAT("""select extract_end_datetime from `""",bq_project_name,"""`.""",bq_transient_dataset_name,""".""", """data_extract_config
  where table_name = '""",bq_raw_table_name,"""' and status = 'running'  and active_flag = 'Y'""") INTO extract_end_date;

/* Delta Temp Table is Truncate & Load */
EXECUTE IMMEDIATE
CONCAT("""TRUNCATE TABLE  `""" ,bq_project_name,"""`.""",bq_transient_dataset_name,""".""",bq_delta_temp_tablename);

	/*Insert Details for passed customer into 'asda_delta_temp' table having ingest date greater than extract_start_date
from data_extract_config table */
EXECUTE IMMEDIATE
CONCAT("""insert into  `""" ,bq_project_name,"""`.""",bq_transient_dataset_name,""".""",bq_delta_temp_tablename,
"""
(
   WITH
     dr AS (
     SELECT
	   'WEEK' AS grain,
	   'ASDA' AS retailer,
	   '""",customer_name,"""' AS customer_name,
	   nielsen_division,
	   product_description as source_item_name,
	   sector,
	   sub_sector,
	   format,
	   manufacturer as nielsen_manufacturer,
	   brand as nielsen_brand,
	   sub_brand as nielsen_sub_brand,
	   weight_packsize,
	   nielsen_upc as source_item_code,
	   nielsen_upc,
	   nielsen_upc as upc,
	   nielsen_database,
       -- week_end_date is of the form 'WE 04 July 2020'; day= %d (01-31); month= %B (full month name);
       CAST(PARSE_DATE('%d %B %Y',
           SUBSTR(week_end_date,4)) AS TIMESTAMP) as week_end_date,
	   cast(sales as FLOAT64) ty_sales_value,
	   cast(units as INT64)as  ty_sales_units,
	   original_file_name,
	   file_dt,
	   timestamp(ingest_date) ingest_date,
	   rctl_file_name,
	   rctl_uuid,
       '""",job_run_id,"""' created_by,
       current_datetime created_datetime,
       '""",job_run_id,"""' modified_by,
       current_datetime modified_datetime,

	   -- the following ranking is done to avoid duplicates if multiple files
	   -- are loaded in one run. The data is partitioned on the natural key
	   -- of the file. The data is then ordered descending on file_dt which is
	   -- the timestamp on the file.  Picking rank = 1 will result in the record
	   -- with latest file_dt being picked in case duplicate records
	   -- exist in the raw table ***across different files***.

       DENSE_RANK() OVER (PARTITION BY nielsen_upc,
                                       CAST(PARSE_DATE('%d %B %Y',
                                            SUBSTR(week_end_date,4)) AS TIMESTAMP)
                          ORDER BY PARSE_TIMESTAMP("%m-%d-%Y %H:%M:%S", file_dt) DESC
                          ) AS rnk_1,

	   -- the following ranking is done to avoid duplicates if the ****same file
	   -- is loaded multiple times****. The data is partitioned on the natural key
	   -- of the file and the file_dt which is the timestamp on the file
	   -- The data is then ordered descending on ingest_date which is the current timestamp
	   -- coming from the ingestion framework.  Picking rank = 1 will result
	   -- in the record with latest ingest_date being picked in case duplicate records
	   -- exist in the raw table.  THIS SCENARIO WILL TYPICALLY NOT OCCUR.
	   -- Please note the use of ROW_NUMBER function to pick one record.
	   -- This function will be needed when the entire RAW table is read to reprocess history.

       ROW_NUMBER() OVER (PARTITION BY nielsen_upc,
                                       CAST(PARSE_DATE('%d %B %Y',
                                            SUBSTR(week_end_date,4)) AS TIMESTAMP),
                                       PARSE_TIMESTAMP("%m-%d-%Y %H:%M:%S", file_dt)
                          ORDER BY ingest_date DESC
                          ) rnk_2

       FROM
         `""" ,bq_project_name,"""`.""",bq_raw_dataset_name,""".""",bq_raw_table_name,"""
	      where ingest_date > '""",extract_start_date,"""'
	      and ingest_date  <= '""",extract_end_date,"""')
   SELECT
     grain,
     retailer,
     customer_name,
     nielsen_division,
     source_item_name,
     sector,
     sub_sector,
     format,
     nielsen_manufacturer,
     nielsen_brand,
     nielsen_sub_brand,
     weight_packsize,
     source_item_code,
     nielsen_upc,
     upc,
     nielsen_database,
     week_end_date,
     ty_sales_value,
     ty_sales_units,
     original_file_name,
     file_dt,
     ingest_date,
     rctl_file_name,
     rctl_uuid,
     created_by,
     created_datetime,
     modified_by,
     modified_datetime
   FROM
     dr
   WHERE
     rnk_1 = 1
     AND rnk_2 = 1
 )
""") ;

EXCEPTION WHEN ERROR THEN
    SELECT
	ERROR (
		CONCAT(
    			@@error.message ,' ' ,
    			@@error.statement_text, ' ' ,
    			@@error.formatted_stack_trace ,' '
			)
		)
	;

END