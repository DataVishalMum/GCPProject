/*
insert into raw.instacart_share_category_type_list values ('Granola', 'default' );
insert into raw.instacart_share_category_type_list values ('Trail Mix & Snack Mix', 'default' );
insert into raw.instacart_share_category_type_list values ('Yogurt', 'default' );
insert into raw.instacart_share_category_type_list values ('Crackers', 'default' );
insert into raw.instacart_share_category_type_list values ('Frozen Appetizers & Sides', 'default' );
insert into raw.instacart_share_category_type_list values ('Hot Cereal & Pancake Mixes', 'default' );
insert into raw.instacart_share_category_type_list values ('Chips & Pretzels', 'default' );
insert into raw.instacart_share_category_type_list values ('Soup, Broth & Bouillon', 'default' );
insert into raw.instacart_share_category_type_list values ('Breakfast Bar Aggregate', 'default' );
insert into raw.instacart_share_category_type_list values ('Frozen Pizza', 'default' );
insert into raw.instacart_share_category_type_list values ('Breakfast Bars & Pastries', 'default' );
insert into raw.instacart_share_category_type_list values ('Fruit & Vegetable Snacks', 'default' );
insert into raw.instacart_share_category_type_list values ('Frozen Breakfast', 'default' );
insert into raw.instacart_share_category_type_list values ('Total GMI (Aisles Shown)', 'default' );
insert into raw.instacart_share_category_type_list values ('Breakfast Bars', 'default' );
insert into raw.instacart_share_category_type_list values ('Energy & Granola Bars', 'default' );
insert into raw.instacart_share_category_type_list values ('Total Bars Aggregate', 'default' );
insert into raw.instacart_share_category_type_list values ('Baking Supplies & Decor', 'default' );
insert into raw.instacart_share_category_type_list values ('Baking Ingredients', 'default' );
insert into raw.instacart_share_category_type_list values ('Instant Foods', 'default' );
insert into raw.instacart_share_category_type_list values ('Baking Aggregate', 'default' );
insert into raw.instacart_share_category_type_list values ('Cereal', 'default' );
insert into raw.instacart_share_category_type_list values ('Latino Foods', 'default' );
insert into raw.instacart_share_category_type_list values ('Doughs, Gelatins & Bake Mixes', 'default' );
insert into raw.instacart_share_category_type_list values ('Nutrition & Snack Bars', 'default' );
*/
select 1;




