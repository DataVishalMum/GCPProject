import os
import sys

parent_dir = os.path.dirname(__file__)
sys.path.append(parent_dir)

from airflow import AirflowException, configuration
from dynamic_operators import DynamicOperators
from airflow.models.variable import Variable
from airflow.utils.trigger_rule import TriggerRule
from airflow.operators.dummy_operator import DummyOperator
from datetime import timedelta, datetime
from airflow import DAG

from airflow.operators.dagrun_operator import TriggerDagRunOperator

from dag_configs import reporting_data_load_config, common_code_data_load_config, sales_alert_config

# Get Environment Specific Variables
ECOMM_COMPOSER = Variable.get('ecomm-composer')
ECOMM_DLF = Variable.get('ecomm-dlf-data')
ECOMM_ANALYTICS = Variable.get('ecomm-analytics')
ECOMM_EDW = Variable.get('ecomm-edw')

# dml_file_path = "/home/airflow/gcs/dags/composer-ecomm/data_pipeline/dml_scripts/"

def create_dag(dag_config: dict,
               catchup: bool = False,
               schedule_interval: str = None,
               template_searchpath = '/home/airflow/gcs/dags/composer-ecomm/'):
    """Function to create dag objects based on config
    If any default arg is present in the config they would override
    the default_args values set in the function
    :param catchup: Perform scheduler catchup (or only run latest)?
            Defaults to False
    :param dag_config: configuration for creating the dag object
    :param template_searchpath: the directory to search for files
            the default value is set to '/home/airflow/gcs/dags/composer-ecomm/'
    :return: dag object
    """
    default_args = {
        'owner':'ecomm',
        'start_date': datetime(2021, 1, 1),
        'depends_on_past': False,
        'retries': 1,
        "email": "bb4357a1.genmills.onmicrosoft.com@amer.teams.ms",
        'email_on_retry': False,
        'email_on_failure': True,
        'retry_delay': timedelta(minutes=3),
#             'bigquery_conn_id': 'bigquery_ecomm_analytics',
#             'gcp_conn_id': 'bigquery_ecomm_analytics',
#             'conn_id': 'bigquery_ecomm_analytics',
        'use_legacy_sql': False
    }

    # Override default argument from configuration if any
    replaced_args = {k: default_args[k] if dag_config.get(
        k, None) is None else dag_config[k] for k in default_args}

    dag_id = dag_config['dag_id']

    created_dag = DAG(dag_id=dag_id,
                      schedule_interval=schedule_interval,
                      start_date=datetime(2021, 7, 1),
                      default_args=replaced_args,
                      catchup=catchup,
                      template_searchpath=template_searchpath,
                      orientation='TB',
                      max_active_runs=1,
                      is_paused_upon_creation=True
                      )
    return created_dag



dag_builder_list = [
    reporting_data_load_config.source_configs,
    common_code_data_load_config.source_configs,
    sales_alert_config.source_configs
]

# all_customer_ingest_config = reporting_data_load_config + common_code_data_load_config

# Since we will have a list of lists for dag configs, flatten them to a single list
flattened_dag_list = [config for sublist in dag_builder_list for config in sublist]


for dag_config in flattened_dag_list:


    # Loop through the config and dynamically create DAG's
    dag = create_dag(dag_config,
                      schedule_interval = dag_config['schedule_interval'] if 'schedule_interval' in dag_config else None,
                     template_searchpath=dag_config.get('template_searchpath','/home/airflow/gcs/dags/composer-ecomm/data_pipeline/dml_scripts/')
                     )
    globals()[dag.dag_id] = dag

    start_task = DummyOperator(
        task_id='start_task', dag=dag)

    start_task.doc = "This is a dummy operator to start the DAG"

    dag_failure = DummyOperator(
        task_id='dag_failure',
        trigger_rule=TriggerRule.ONE_FAILED,
        dag=dag
    )
    dag_failure.doc = "Chain Failure related operators to this"

    dag_success = DummyOperator(
        task_id='dag_success',
        trigger_rule=TriggerRule.NONE_FAILED,
        dag=dag
    )
    dag_success.doc = "Chain Success related operators to this"

    current_start_loading_group = [start_task]

    if 'modeling_steps' in dag_config:

        all_etl_task_complete = DummyOperator(
            task_id='all_etl_task_complete',
            trigger_rule=TriggerRule.NONE_FAILED,
            dag=dag)

        all_etl_task_complete.doc = \
            "This is a dummy operator to " \
            "mark the completion of all transformation tasks"

        for loading_group in dag_config['modeling_steps']:

            # Set the data loading group as the last group run
            start_loading_group = current_start_loading_group[-1:]

            end_loading_group = DummyOperator(
                task_id='end_group_{}'.format(loading_group), dag=dag)
            end_loading_group.doc_md = """
                This dummy operator marks the ending point of a group
                of modeling/transformation data steps
            """
            for config_step in dag_config['modeling_steps'][loading_group]:

                if not hasattr(DynamicOperators, config_step.get('operation','bigquery_job')):
                    raise AirflowException(f"Provided Operator '{config_step['operation']}' not defined in dynamic_operators.py")

                step_task = getattr(DynamicOperators, config_step.get('operation','bigquery_job'))(
                    dag=dag,
                    config=config_step,
                    group=loading_group,
                    params={**config_step, **{}, 'ECOMM_DLF':ECOMM_DLF, 'ECOMM_ANALYTICS':ECOMM_ANALYTICS, 'ECOMM_EDW':ECOMM_EDW}
                )
                start_loading_group >> step_task >> end_loading_group

            # Set the currently loaded data group as the start of the next group
            current_start_loading_group.append(end_loading_group)

        current_start_loading_group[-1] >> all_etl_task_complete

        # Chain Dummy Operators for success or failure work
        all_etl_task_complete >> [dag_success, dag_failure]

