import os

# Root folder from where we calculate location of other files
DAG_ROOT_DIR = os.path.realpath(os.path.dirname(__file__))
