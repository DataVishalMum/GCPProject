from dags.frameworks.dynamic.utils.available_base_task_params import *
from dags.frameworks.dynamic.utils.available_tasks import (GssTask, AaTask, BaseTask, GcsFileLoadTask, GssTableIngestionTask)
from dags.frameworks.dynamic.utils.classes.attributes import Attribute
from dags.frameworks.dynamic.utils.classes.categories import Category
from dags.frameworks.dynamic.utils.classes.dag_configs import DagConfig
from dags.frameworks.dynamic.utils.classes.dag_modeling_steps import (DagModelingStep, StepOverride)
from dags.frameworks.dynamic.utils.classes.task_config import TaskConfig
from dags.frameworks.dynamic.utils.classes.transformations import Transform
from dags.frameworks.dynamic.utils.classes.data_types import DataType
from dags.frameworks.dynamic.utils.classes.parameters import Parameter
from dags.frameworks.dynamic.utils.classes.file_load_strategy import FileLoadStrategy

dag = DagConfig()
config = TaskConfig()
attribute = Attribute()
transform = Transform()
dataType = DataType()
modelingStep = DagModelingStep()
override = StepOverride()
category = Category()
gcsTasks = GcsFileLoadTask()
gssTasks = GssTask()
gssTableIngestionTasks = GssTableIngestionTask()
aaTasks = AaTask()
baseTasks = BaseTask()
param = Parameter()
fileloadstrategy = FileLoadStrategy()

# noinspection PyInterpreter
configuration = {
    dag.title: {
        dag.ScheduleInterval: "0 10 * * WED",
        dag.DagName: "ecomm_ana_nielsen_albertsons_safeway_ingestion",
        dag.CustomerName: "ALBERTSONS_SAFEWAY_DATASEMBLY",
        dag.FeedName: "ALBERTSONS_SAFEWAY_DATASEMBLY",
        dag.TagsStringArray: ["ecomm", "ana", "nielsen", "albertsons_safeway"],
        dag.IsPublicFlag: True
    },
    dag.ModelingSteps: [
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: baseTasks.NielsenIriDeltaTemp,
                        override.SprocParams: [
                            {
                                NielsenIriDeltaTemp.SourceDataset.value: "sales",
                                NielsenIriDeltaTemp.SourceCustomerName.value: "ALBERTSONS/SAFEWAY",
                                NielsenIriDeltaTemp.SourceTable.value: "nro_retailer_nielsen_gmi_pos_data",
                                NielsenIriDeltaTemp.DestinationTable.value: "albertsons_safeway_nielsen_delta_temp"
                            }
                        ]
                    }
                ]
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: baseTasks.NielsenIriTemp,
                        override.SprocParams: [
                            {
                                NielsenIriTemp.SourceTable.value: "albertsons_safeway_nielsen",
                                NielsenIriTemp.DestinationTable.value: "albertsons_safeway_nielsen_temp"
                            }
                        ]
                    }
                ]
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: baseTasks.NielsenIriProcessedOne,
                        override.SprocParams: [
                            {
                                NielsenIriProcessedOne.SourceTable.value: "albertsons_safeway_nielsen_temp",
                                NielsenIriProcessedOne.DestinationTable.value: "albertsons_safeway_nielsen"
                            }
                        ]
                    }
                ]
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: baseTasks.SourceTableDataExtractConfigInsert,
                        override.SprocParams: [
                            {
                                SourceTableDataExtractConfigInsert.SourceDataset.value: "transient",
                                SourceTableDataExtractConfigInsert.SourceTable.value: "albertsons_safeway_datasembly_store_price_mv",
                                SourceTableDataExtractConfigInsert.ColumnName.value: "ingest_date"
                            }
                        ]
                    }
                ]
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: baseTasks.CustomerDatasemblyDeltaTemp,
                        override.SprocParams: [{
                            CustomerDatasemblyDeltaTemp.DestinationTable.value: "albertsons_safeway_datasembly_delta_temp",
                            CustomerDatasemblyDeltaTemp.SourceTable.value: "albertsons_safeway_datasembly_store_price"
                        }]
                    }
                ]
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: baseTasks.DataQualityChecksRun,
                        override.SprocParams: [
                            {
                                DataQualityChecksRun.RecordKey.value: "7522055615490591225,7467412201880024447,4574693673978072731"
                            }
                        ]
                    }
                ]
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: baseTasks.SrcToEcommCatalogUpcMappingTable,
                        override.SprocParams: [{
                            SrcToEcommCatalogUpcMappingTable.SourceTable.value: "albertsons_safeway_datasembly_delta_temp",
                            SrcToEcommCatalogUpcMappingTable.UpcColumnName.value: "upc",
                            SrcToEcommCatalogUpcMappingTable.RpcColumnName.value: "rpc_column_name",
                            SrcToEcommCatalogUpcMappingTable.ProductTitleColumnName.value: "product_title_column"
                        }]
                    }
                ]
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: baseTasks.CustomerProcessedZero,
                        override.SprocParams: [{
                            CustomerProcessedZero.SourceTable.value: "albertsons_safeway_datasembly_delta_temp",
                            CustomerProcessedZero.DestinationTable.value: "albertsons_safeway_datasembly_processed_zero"
                        }]
                    }
                ]
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: baseTasks.DistributionFact,
                        override.SprocParams: [{
                            DistributionFact.DestinationTable.value: "albertsons_safeway",
                            DistributionFact.SourceTable.value: "albertsons_safeway"
                        }]
                    }
                ]
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: baseTasks.DistributionAvailabilityJoined,
                        override.SprocParams: [{
                            DistributionAvailabilityJoined.DestinationTable.value: "albertsons_safeway",
                            DistributionAvailabilityJoined.SourceTable.value: "albertsons_safeway",
                            DistributionAvailabilityJoined.IntermediateTable.value: "albertsons_safeway_nielsen"
                        }]
                    }
                ]
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: baseTasks.DistributionAvailabilitySmoothed,
                        override.SprocParams: [{
                            DistributionAvailabilitySmoothed.SourceTable.value: "albertsons_safeway",
                            DistributionAvailabilitySmoothed.DestinationTable.value: "albertsons_safeway"
                        }]
                    }
                ]
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: baseTasks.DistributionAvailabilityWithUpc,
                        override.SprocParams: [{
                            DistributionAvailabilityWithUpc.DestinationTable.value: "albertsons_safeway",
                            DistributionAvailabilityWithUpc.SourceTable.value: "albertsons_safeway"
                        }]
                    }
                ]
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: baseTasks.DistributionAvailabilitySubcatgAggFact,
                        override.SprocParams: [{
                            DistributionAvailabilitySubcatgAggFact.SourceTable.value: "albertsons_safeway",
                            DistributionAvailabilitySubcatgAggFact.DestinationTable.value: "albertsons_safeway"
                        }]
                    }
                ]
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: baseTasks.EcomDataReleaseControlInsert,
                        override.SprocParams: [{
                            EcomDataReleaseControlInsert.SourceTable.value: "albertsons_safeway_distribution_availability_subcatg_agg_fact",
                            EcomDataReleaseControlInsert.SourceCustomerName.value: "ALBERTSONS_SAFEWAY_DISTRIBUTION_AVAILABILITY",
                            EcomDataReleaseControlInsert.SourceFeedName.value:"ALBERTSONS_SAFEWAY_DISTRIBUTION_AVAILABILITY_SUBCATG_AGG_FACT"
                        }]
                    }
                ]
            }
        },
        # {
        #     modelingStep.Step: {
        #         modelingStep.Category: category.Base,
        #         modelingStep.Overrides: [
        #             {
        #                 override.Task: baseTasks.UpcConversionsDnaOnly,
        #                 override.SprocParams: [{
        #                     UpcConversionsDnaOnly.SourceTable.value: "albertsons_safeway",
        #                     UpcConversionsDnaOnly.IntermediateTable.value: "albertsons_safeway",
        #                     UpcConversionsDnaOnly.DestinationFeedName.value: "albertsons_safeway",
        #                     UpcConversionsDnaOnly.DestinationTable.value: "albertsons_safeway"
        #                 }]
        #             }
        #         ]
        #     }
        # },
        # {
        #     modelingStep.Step: {
        #         modelingStep.Category: category.Base,
        #         modelingStep.Overrides: [
        #             {
        #                 override.Task: baseTasks.NewProductTracker,
        #                 override.SprocParams: [{
        #                     NewProductTracker.SourceTable.value: "albertsons_safeway",
        #                     NewProductTracker.DestinationTable.value: "ecom_albertsons_safeway"
        #                 }]
        #             }
        #         ]
        #     }
        # },
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: gssTableIngestionTasks.DataExtractConfigUpdate,
                        override.SprocParams: [
                            {
                                DataExtractConfigUpdate.SourceTable.value: "albertsons_safeway_datasembly_store_price_mv"
                            }
                        ]
                    }
                ]
            }
        }
    ]
}