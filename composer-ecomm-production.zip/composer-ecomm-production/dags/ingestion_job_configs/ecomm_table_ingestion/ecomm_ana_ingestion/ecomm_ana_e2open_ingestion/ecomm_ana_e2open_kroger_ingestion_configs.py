from dags.frameworks.dynamic.utils.available_base_task_params import *
from dags.frameworks.dynamic.utils.available_tasks import (GssTask, AaTask, BaseTask, GcsFileLoadTask, GssTableIngestionTask)
from dags.frameworks.dynamic.utils.classes.attributes import Attribute
from dags.frameworks.dynamic.utils.classes.categories import Category
from dags.frameworks.dynamic.utils.classes.dag_configs import DagConfig
from dags.frameworks.dynamic.utils.classes.dag_modeling_steps import (DagModelingStep, StepOverride)
from dags.frameworks.dynamic.utils.classes.task_config import TaskConfig
from dags.frameworks.dynamic.utils.classes.transformations import Transform
from dags.frameworks.dynamic.utils.classes.data_types import DataType
from dags.frameworks.dynamic.utils.classes.parameters import Parameter
from dags.frameworks.dynamic.utils.classes.file_load_strategy import FileLoadStrategy

dag = DagConfig()
config = TaskConfig()
attribute = Attribute()
transform = Transform()
dataType = DataType()
modelingStep = DagModelingStep()
override = StepOverride()
category = Category()
gcsTasks = GcsFileLoadTask()
gssTasks = GssTask()
gssTableIngestionTasks = GssTableIngestionTask()
aaTasks = AaTask()
baseTasks = BaseTask()
param = Parameter()
fileloadstrategy = FileLoadStrategy()

# noinspection PyInterpreter
configuration = {
    dag.title: {
        dag.ScheduleInterval: "0 22 * * WED",
        dag.DagName: "ecomm_ana_e2open_kroger_ingestion",
        dag.CustomerName: "kroger",
        dag.FeedName: "kroger",
        dag.TagsStringArray: ["ecomm", "ana", "e2open", "kroger"],
        dag.IsPublicFlag: True
    },
    dag.ModelingSteps: [
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: baseTasks.SourceTableDataExtractConfigInsert,
                        override.SprocParams: [
                            {
                                SourceTableDataExtractConfigInsert.SourceProject.value: "edw-prd-e567f9",
                                SourceTableDataExtractConfigInsert.SourceDataset.value: "customer_direct",
                                SourceTableDataExtractConfigInsert.SourceTable.value: "e2open_storefacts_kroger_us",
                                SourceTableDataExtractConfigInsert.ColumnName.value: "gcp_create_ts"
                            }
                        ]
                    }
                ]
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: baseTasks.E2OpenDeltaTemp,
                        override.SprocParams: [
                            {
                                E2OpenDeltaTemp.SourceDataset.value: "customer_direct",
                                E2OpenDeltaTemp.SourceTable.value: "e2open_storefacts_kroger_us",
                                E2OpenDeltaTemp.DestinationTable.value: "kroger"
                            }
                        ]
                    }
                ]
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: gssTableIngestionTasks.DataExtractConfigUpdate,
                        override.SprocParams: [
                            {
                                DataExtractConfigUpdate.SourceTable.value: "e2open_storefacts_kroger_us"
                            }
                        ]
                    }
                ]
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: baseTasks.DataQualityChecksRun,
                        override.SprocParams: [
                            {
                                DataQualityChecksRun.RecordKey.value: "5606845387164562941,7977552822283678158,5150993731377286350"
                            }
                        ]
                    }
                ]
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: baseTasks.SrcToEcommCatalogUpcMappingTable,
                        override.SprocParams: [{
                            SrcToEcommCatalogUpcMappingTable.SourceTable.value: "kroger_e2open_delta_temp",
                            SrcToEcommCatalogUpcMappingTable.UpcColumnName.value: "gmi_upc",
                            SrcToEcommCatalogUpcMappingTable.RpcColumnName.value: "rpc_column_name",
                            SrcToEcommCatalogUpcMappingTable.ProductTitleColumnName.value: "product_title_column"
                        }]
                    }
                ]
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: baseTasks.CustomerProcessedZero,
                        override.SprocParams: [{
                            CustomerProcessedZero.SourceTable.value: "kroger_e2open_delta_temp",
                            CustomerProcessedZero.DestinationTable.value: "kroger_e2open_processed_zero",
                            CustomerProcessedZero.SourceFeedName.value: "KROGER_E2OPEN"
                        }]
                    }
                ]
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: baseTasks.DistributionFactE2Open,
                        override.SprocParams: [{
                            DistributionFactE2Open.DestinationTable.value: "kroger",
                            DistributionFactE2Open.SourceTable.value: "kroger"
                        }]
                    }
                ]
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: baseTasks.DistributionWeeklyAggFact,
                        override.SprocParams: [
                            {
                                DistributionWeeklyAggFact.SourceTable.value: "kroger",
                                DistributionWeeklyAggFact.DestinationTable.value: "kroger"
                            }
                        ]
                    }
                ]
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: baseTasks.SourceTableDataExtractConfigInsert,
                        override.SprocParams: [
                            {
                                SourceTableDataExtractConfigInsert.SourceDataset.value: "transient",
                                SourceTableDataExtractConfigInsert.SourceTable.value: "kroger_datasembly_store_price_mv",
                                SourceTableDataExtractConfigInsert.ColumnName.value: "ingest_date"
                            }
                        ]
                    }
                ]
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: baseTasks.CustomerDatasemblyDeltaTemp,
                        override.SprocParams: [{
                            CustomerDatasemblyDeltaTemp.DestinationTable.value: "kroger_datasembly_delta_temp",
                            CustomerDatasemblyDeltaTemp.SourceTable.value: "kroger_datasembly_store_price"
                        }]
                    }
                ]
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: baseTasks.DataQualityChecksRun,
                        override.SprocParams: [
                            {
                                DataQualityChecksRun.RecordKey.value: "4140443307966742903,8184060904925262852,981710504016764018"
                            }
                        ]
                    }
                ]
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: baseTasks.SrcToEcommCatalogUpcMappingTable,
                        override.SprocParams: [{
                            SrcToEcommCatalogUpcMappingTable.SourceTable.value: "kroger_datasembly_delta_temp",
                            SrcToEcommCatalogUpcMappingTable.UpcColumnName.value: "upc",
                            SrcToEcommCatalogUpcMappingTable.RpcColumnName.value: "rpc_column_name",
                            SrcToEcommCatalogUpcMappingTable.ProductTitleColumnName.value: "product_title_column"
                        }]
                    }
                ]
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: baseTasks.CustomerProcessedZero,
                        override.SprocParams: [{
                            CustomerProcessedZero.SourceTable.value: "kroger_datasembly_delta_temp",
                            CustomerProcessedZero.DestinationTable.value: "kroger_datasembly_processed_zero",
                            CustomerProcessedZero.SourceFeedName.value: "KROGER_DATASEMBLY"
                        }]
                    }
                ]
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: baseTasks.DistributionFact,
                        override.SprocParams: [{
                            DistributionFact.DestinationTable.value: "kroger",
                            DistributionFact.SourceTable.value: "kroger"
                        }]
                    }
                ]
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: baseTasks.DistributionAvailabilityJoinedE2Open,
                        override.SprocParams: [{
                            DistributionAvailabilityJoinedE2Open.DestinationTable.value: "kroger",
                            DistributionAvailabilityJoinedE2Open.SourceTable.value: "kroger",
                            DistributionAvailabilityJoinedE2Open.IntermediateTable.value: "kroger"
                        }]
                    }
                ]
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: baseTasks.DistributionAvailabilitySmoothed,
                        override.SprocParams: [{
                            DistributionAvailabilitySmoothed.SourceTable.value: "kroger",
                            DistributionAvailabilitySmoothed.DestinationTable.value: "kroger"
                        }]
                    }
                ]
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: baseTasks.DistributionAvailabilityWithUpc,
                        override.SprocParams: [{
                            DistributionAvailabilityWithUpc.DestinationTable.value: "kroger",
                            DistributionAvailabilityWithUpc.SourceTable.value: "kroger"
                        }]
                    }
                ]
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: baseTasks.DistributionAvailabilitySubcatgAggFact,
                        override.SprocParams: [{
                            DistributionAvailabilitySubcatgAggFact.SourceTable.value: "kroger",
                            DistributionAvailabilitySubcatgAggFact.DestinationTable.value: "kroger"
                        }]
                    }
                ]
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: baseTasks.EcomDataReleaseControlInsert,
                        override.SprocParams: [{
                            EcomDataReleaseControlInsert.SourceTable.value: "kroger_distribution_availability_subcatg_agg_fact",
                            EcomDataReleaseControlInsert.SourceCustomerName.value: "KROGER_DISTRIBUTION_AVAILABILITY",
                            EcomDataReleaseControlInsert.SourceFeedName.value:"KROGER_DISTRIBUTION_AVAILABILITY_SUBCATG_AGG_FACT"
                        }]
                    }
                ]
            }
        },
        # {
        #     modelingStep.Step: {
        #         modelingStep.Category: category.Base,
        #         modelingStep.Overrides: [
        #             {
        #                 override.Task: baseTasks.UpcConversionsE2Open,
        #                 override.SprocParams: [{
        #                     UpcConversionsE2Open.SourceTable.value: "kroger",
        #                     UpcConversionsE2Open.IntermediateTable.value: "kroger",
        #                     UpcConversionsE2Open.DestinationFeedName.value: "kroger",
        #                     UpcConversionsE2Open.DestinationTable.value: "kroger"
        #                 }]
        #             }
        #         ]
        #     }
        # },
        # {
        #     modelingStep.Step: {
        #         modelingStep.Category: category.Base,
        #         modelingStep.Overrides: [
        #             {
        #                 override.Task: baseTasks.NewProductTracker,
        #                 override.SprocParams: [{
        #                     NewProductTracker.SourceTable.value: "kroger",
        #                     NewProductTracker.DestinationTable.value: "ecom_kroger"
        #                 }]
        #             }
        #         ]
        #     }
        # },
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: gssTableIngestionTasks.DataExtractConfigUpdate,
                        override.SprocParams: [
                            {
                                DataExtractConfigUpdate.SourceTable.value: "kroger_datasembly_store_price_mv"
                            }
                        ]
                    }
                ]
            }
        }
    ]
}