from dags.frameworks.dynamic.utils.available_base_task_params import *
from dags.frameworks.dynamic.utils.available_tasks import (GssTask, AaTask, BaseTask, GcsFileLoadTask, GssTableIngestionTask)
from dags.frameworks.dynamic.utils.classes.attributes import Attribute
from dags.frameworks.dynamic.utils.classes.categories import Category
from dags.frameworks.dynamic.utils.classes.dag_configs import DagConfig
from dags.frameworks.dynamic.utils.classes.dag_modeling_steps import (DagModelingStep, StepOverride)
from dags.frameworks.dynamic.utils.classes.task_config import TaskConfig
from dags.frameworks.dynamic.utils.classes.transformations import Transform
from dags.frameworks.dynamic.utils.classes.data_types import DataType
from dags.frameworks.dynamic.utils.classes.parameters import Parameter
from dags.frameworks.dynamic.utils.classes.file_load_strategy import FileLoadStrategy


dag = DagConfig()
config = TaskConfig()
attribute = Attribute()
transform = Transform()
dataType = DataType()
modelingStep = DagModelingStep()
override = StepOverride()
category = Category()
gcsTasks = GcsFileLoadTask()
gssTasks = GssTask()
gssTableIngestionTasks = GssTableIngestionTask()
aaTasks = AaTask()
baseTasks = BaseTask()
param = Parameter()
fileloadstrategy = FileLoadStrategy()

# noinspection PyInterpreter
configuration = {
    dag.title: {
        dag.ScheduleInterval: "0 22 * * WED",
        dag.DagName: "ecomm_ana_e2open_target_ingestion",
        dag.CustomerName: "target",
        dag.FeedName: "target",
        dag.TagsStringArray: ["ecomm", "ana", "e2open", "target"],
        dag.IsPublicFlag: True
    },
    dag.ModelingSteps: [
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: baseTasks.SourceTableDataExtractConfigInsert,
                        override.SprocParams: [
                            {
                                SourceTableDataExtractConfigInsert.SourceProject.value: "edw-prd-e567f9",
                                SourceTableDataExtractConfigInsert.SourceDataset.value: "customer_direct",
                                SourceTableDataExtractConfigInsert.SourceTable.value: "e2open_storefacts_target_weekly_us",
                                SourceTableDataExtractConfigInsert.ColumnName.value: "gcp_create_ts"
                            }
                        ]
                    }
                ]
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: baseTasks.E2OpenTargetDeltaTemp,
                        override.SprocParams: [
                            {
                                E2OpenTargetDeltaTemp.SourceDataset.value: "customer_direct",
                                E2OpenTargetDeltaTemp.SourceTable.value: "e2open_storefacts_target_weekly_us",
                                E2OpenTargetDeltaTemp.DestinationTable.value: "target"
                            }
                        ]
                    }
                ]
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: gssTableIngestionTasks.DataExtractConfigUpdate,
                        override.SprocParams: [
                            {
                                DataExtractConfigUpdate.SourceTable.value: "e2open_storefacts_target_weekly_us"
                            }
                        ]
                    }
                ]
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: baseTasks.DataQualityChecksRun,
                        override.SprocParams: [
                            {
                                DataQualityChecksRun.RecordKey.value: "8337718031416702386,6789427981136337107,4645489643571318037"
                            }
                        ]
                    }
                ]
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: baseTasks.SrcToEcommCatalogUpcMappingTable,
                        override.SprocParams: [{
                            SrcToEcommCatalogUpcMappingTable.SourceTable.value: "target_e2open_delta_temp",
                            SrcToEcommCatalogUpcMappingTable.UpcColumnName.value: "gmi_upc",
                            SrcToEcommCatalogUpcMappingTable.RpcColumnName.value: "rpc_column_name",
                            SrcToEcommCatalogUpcMappingTable.ProductTitleColumnName.value: "product_title_column"
                        }]
                    }
                ]
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: baseTasks.CustomerProcessedZero,
                        override.SprocParams: [{
                            CustomerProcessedZero.SourceTable.value: "target_e2open_delta_temp",
                            CustomerProcessedZero.DestinationTable.value: "target_e2open_processed_zero",
                            CustomerProcessedZero.SourceFeedName.value: "TARGET_E2OPEN"
                        }]
                    }
                ]
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: baseTasks.DistributionFactE2Open,
                        override.SprocParams: [{
                            DistributionFactE2Open.DestinationTable.value: "target",
                            DistributionFactE2Open.SourceTable.value: "target"
                        }]
                    }
                ]
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: baseTasks.DistributionTargetWeeklyAggFact,
                        override.SprocParams: [
                            {
                                DistributionTargetWeeklyAggFact.SourceTable.value: "target",
                                DistributionTargetWeeklyAggFact.DestinationTable.value: "target"
                            }
                        ]
                    }
                ]
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: baseTasks.SourceTableDataExtractConfigInsert,
                        override.SprocParams: [
                            {
                                SourceTableDataExtractConfigInsert.SourceDataset.value: "transient",
                                SourceTableDataExtractConfigInsert.SourceTable.value: "target_datasembly_store_price_mv",
                                SourceTableDataExtractConfigInsert.ColumnName.value: "ingest_date"
                            }
                        ]
                    }
                ]
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: baseTasks.CustomerDatasemblyDeltaTemp,
                        override.SprocParams: [{
                            CustomerDatasemblyDeltaTemp.DestinationTable.value: "target_datasembly_delta_temp",
                            CustomerDatasemblyDeltaTemp.SourceTable.value: "target_datasembly_store_price"
                        }]
                    }
                ]
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: baseTasks.DataQualityChecksRun,
                        override.SprocParams: [
                            {
                                DataQualityChecksRun.RecordKey.value: "7330425509085566455,4308625763946225238,1907540935093837293"
                            }
                        ]
                    }
                ]
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: baseTasks.SrcToEcommCatalogUpcMappingTable,
                        override.SprocParams: [{
                            SrcToEcommCatalogUpcMappingTable.SourceTable.value: "target_datasembly_delta_temp",
                            SrcToEcommCatalogUpcMappingTable.UpcColumnName.value: "upc",
                            SrcToEcommCatalogUpcMappingTable.RpcColumnName.value: "rpc_column_name",
                            SrcToEcommCatalogUpcMappingTable.ProductTitleColumnName.value: "product_title_column"
                        }]
                    }
                ]
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: baseTasks.CustomerProcessedZero,
                        override.SprocParams: [{
                            CustomerProcessedZero.SourceTable.value: "target_datasembly_delta_temp",
                            CustomerProcessedZero.DestinationTable.value: "target_datasembly_processed_zero",
                            CustomerProcessedZero.SourceFeedName.value: "TARGET_DATASEMBLY"
                        }]
                    }
                ]
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: baseTasks.DistributionFact,
                        override.SprocParams: [{
                            DistributionFact.DestinationTable.value: "target",
                            DistributionFact.SourceTable.value: "target"
                        }]
                    }
                ]
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: baseTasks.DistributionAvailabilityJoinedE2Open,
                        override.SprocParams: [{
                            DistributionAvailabilityJoinedE2Open.DestinationTable.value: "target",
                            DistributionAvailabilityJoinedE2Open.SourceTable.value: "target",
                            DistributionAvailabilityJoinedE2Open.IntermediateTable.value: "target"
                        }]
                    }
                ]
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: baseTasks.DistributionAvailabilitySmoothed,
                        override.SprocParams: [{
                            DistributionAvailabilitySmoothed.SourceTable.value: "target",
                            DistributionAvailabilitySmoothed.DestinationTable.value: "target"
                        }]
                    }
                ]
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: baseTasks.DistributionAvailabilityWithUpc,
                        override.SprocParams: [{
                            DistributionAvailabilityWithUpc.DestinationTable.value: "target",
                            DistributionAvailabilityWithUpc.SourceTable.value: "target"
                        }]
                    }
                ]
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: baseTasks.DistributionAvailabilitySubcatgAggFact,
                        override.SprocParams: [{
                            DistributionAvailabilitySubcatgAggFact.SourceTable.value: "target",
                            DistributionAvailabilitySubcatgAggFact.DestinationTable.value: "target"
                        }]
                    }
                ]
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: baseTasks.EcomDataReleaseControlInsert,
                        override.SprocParams: [{
                            EcomDataReleaseControlInsert.SourceTable.value: "target_distribution_availability_subcatg_agg_fact",
                            EcomDataReleaseControlInsert.SourceCustomerName.value: "TARGET_DISTRIBUTION_AVAILABILITY",
                            EcomDataReleaseControlInsert.SourceFeedName.value:"TARGET_DISTRIBUTION_AVAILABILITY_SUBCATG_AGG_FACT"
                        }]
                    }
                ]
            }
        },
        # {
        #     modelingStep.Step: {
        #         modelingStep.Category: category.Base,
        #         modelingStep.Overrides: [
        #             {
        #                 override.Task: baseTasks.UpcConversionsE2Open,
        #                 override.SprocParams: [{
        #                     UpcConversionsE2Open.SourceTable.value: "target",
        #                     UpcConversionsE2Open.IntermediateTable.value: "target",
        #                     UpcConversionsE2Open.DestinationFeedName.value: "target",
        #                     UpcConversionsE2Open.DestinationTable.value: "target"
        #                 }]
        #             }
        #         ]
        #     }
        # },
        # {
        #     modelingStep.Step: {
        #         modelingStep.Category: category.Base,
        #         modelingStep.Overrides: [
        #             {
        #                 override.Task: baseTasks.NewProductTracker,
        #                 override.SprocParams: [{
        #                     NewProductTracker.SourceTable.value: "target",
        #                     NewProductTracker.DestinationTable.value: "ecom_target"
        #                 }]
        #             }
        #         ]
        #     }
        # },
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: gssTableIngestionTasks.DataExtractConfigUpdate,
                        override.SprocParams: [
                            {
                                DataExtractConfigUpdate.SourceTable.value: "target_datasembly_store_price_mv"
                            }
                        ]
                    }
                ]
            }
        }
    ]
}
