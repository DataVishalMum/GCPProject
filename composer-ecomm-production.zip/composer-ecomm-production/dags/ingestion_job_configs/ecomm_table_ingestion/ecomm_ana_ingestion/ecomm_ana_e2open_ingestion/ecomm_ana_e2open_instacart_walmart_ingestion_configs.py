from dags.frameworks.dynamic.utils.available_base_task_params import *
from dags.frameworks.dynamic.utils.available_tasks import (GssTask, AaTask, BaseTask, GcsFileLoadTask, GssTableIngestionTask)
from dags.frameworks.dynamic.utils.classes.attributes import Attribute
from dags.frameworks.dynamic.utils.classes.categories import Category
from dags.frameworks.dynamic.utils.classes.dag_configs import DagConfig
from dags.frameworks.dynamic.utils.classes.dag_modeling_steps import (DagModelingStep, StepOverride)
from dags.frameworks.dynamic.utils.classes.task_config import TaskConfig
from dags.frameworks.dynamic.utils.classes.transformations import Transform
from dags.frameworks.dynamic.utils.classes.data_types import DataType
from dags.frameworks.dynamic.utils.classes.parameters import Parameter
from dags.frameworks.dynamic.utils.classes.file_load_strategy import FileLoadStrategy

dag = DagConfig()
config = TaskConfig()
attribute = Attribute()
transform = Transform()
dataType = DataType()
modelingStep = DagModelingStep()
override = StepOverride()
category = Category()
gcsTasks = GcsFileLoadTask()
gssTasks = GssTask()
gssTableIngestionTasks = GssTableIngestionTask()
aaTasks = AaTask()
baseTasks = BaseTask()
param = Parameter()
fileloadstrategy = FileLoadStrategy()

# noinspection PyInterpreter
configuration = {
    dag.title: {
        dag.ScheduleInterval: "0 4 * * THU",
        dag.DagName: "ecomm_ana_e2open_instacart_walmart_ingestion",
        dag.CustomerName: "walmart_opd",
        dag.FeedName: "instacart_walmart_opd",
        dag.TagsStringArray: ["ecomm", "ana", "e2open", "instacart_walmart_opd"],
        dag.IsPublicFlag: True
    },
    dag.ModelingSteps: [
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: baseTasks.SourceTableDataExtractConfigInsert,
                        override.SprocParams: [
                            {
                                SourceTableDataExtractConfigInsert.SourceDataset.value: "transient",
                                SourceTableDataExtractConfigInsert.SourceTable.value: "walmart_opd_instacart_datasembly_store_price_mv",
                                SourceTableDataExtractConfigInsert.ColumnName.value: "ingest_date"
                            }
                        ]
                    }
                ]
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: baseTasks.CustomerDatasemblyDeltaTemp,
                        override.SprocParams: [{
                            CustomerDatasemblyDeltaTemp.DestinationTable.value: "walmart_opd_instacart_datasembly_delta_temp",
                            CustomerDatasemblyDeltaTemp.SourceTable.value: "walmart_opd_instacart_datasembly_store_price"
                        }]
                    }
                ]
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: baseTasks.DataQualityChecksRun,
                        override.SprocParams: [
                            {
                                DataQualityChecksRun.RecordKey.value: "5216507834396529689,6534433812959245709,838147075831862673"
                            }
                        ]
                    }
                ]
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: baseTasks.SrcToEcommCatalogUpcMappingTable,
                        override.SprocParams: [{
                            SrcToEcommCatalogUpcMappingTable.SourceTable.value: "walmart_opd_instacart_datasembly_delta_temp",
                            SrcToEcommCatalogUpcMappingTable.UpcColumnName.value: "upc",
                            SrcToEcommCatalogUpcMappingTable.RpcColumnName.value: "rpc_column_name",
                            SrcToEcommCatalogUpcMappingTable.ProductTitleColumnName.value: "product_title_column"
                        }]
                    }
                ]
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: baseTasks.CustomerProcessedZero,
                        override.SprocParams: [{
                            CustomerProcessedZero.SourceTable.value: "walmart_opd_instacart_datasembly_delta_temp",
                            CustomerProcessedZero.DestinationTable.value: "walmart_opd_instacart_datasembly_processed_zero",
                            CustomerProcessedZero.SourceFeedName.value: "WALMART_OPD_DATASEMBLY"
                        }]
                    }
                ]
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: baseTasks.DistributionFact,
                        override.SprocParams: [{
                            DistributionFact.DestinationTable.value: "walmart_opd_instacart",
                            DistributionFact.SourceTable.value: "walmart_opd_instacart"
                        }]
                    }
                ]
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: baseTasks.DistributionAvailabilityJoinedE2Open,
                        override.SprocParams: [{
                            DistributionAvailabilityJoinedE2Open.DestinationTable.value: "walmart_opd_instacart",
                            DistributionAvailabilityJoinedE2Open.SourceTable.value: "walmart_opd_instacart",
                            DistributionAvailabilityJoinedE2Open.IntermediateTable.value: "walmart_opd_instacart"
                        }]
                    }
                ]
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: baseTasks.DistributionAvailabilitySmoothed,
                        override.SprocParams: [{
                            DistributionAvailabilitySmoothed.SourceTable.value: "walmart_opd_instacart",
                            DistributionAvailabilitySmoothed.DestinationTable.value: "walmart_opd_instacart"
                        }]
                    }
                ]
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: baseTasks.DistributionAvailabilityWithUpc,
                        override.SprocParams: [{
                            DistributionAvailabilityWithUpc.DestinationTable.value: "walmart_opd_instacart",
                            DistributionAvailabilityWithUpc.SourceTable.value: "walmart_opd_instacart"
                        }]
                    }
                ]
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: baseTasks.DistributionAvailabilitySubcatgAggFact,
                        override.SprocParams: [{
                            DistributionAvailabilitySubcatgAggFact.SourceTable.value: "walmart_opd_instacart",
                            DistributionAvailabilitySubcatgAggFact.DestinationTable.value: "walmart_opd_instacart"
                        }]
                    }
                ]
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: baseTasks.EcomDataReleaseControlInsert,
                        override.SprocParams: [{
                            EcomDataReleaseControlInsert.SourceTable.value: "walmart_opd_instacart_distribution_availability_subcatg_agg_fact",
                            EcomDataReleaseControlInsert.SourceCustomerName.value: "WALMART_OPD_INSTACART_DISTRIBUTION_AVAILABILITY",
                            EcomDataReleaseControlInsert.SourceFeedName.value:"WALMART_OPD_INSTACART_DISTRIBUTION_AVAILABILITY_SUBCATG_AGG_FACT"
                        }]
                    }
                ]
            }
        },
        # {
        #     modelingStep.Step: {
        #         modelingStep.Category: category.Base,
        #         modelingStep.Overrides: [
        #             {
        #                 override.Task: baseTasks.UpcConversionsE2Open,
        #                 override.SprocParams: [{
        #                     UpcConversionsE2Open.SourceTable.value: "walmart_opd_instacart",
        #                     UpcConversionsE2Open.IntermediateTable.value: "walmart_opd",
        #                     UpcConversionsE2Open.DestinationFeedName.value: "walmart_opd_instacart",
        #                     UpcConversionsE2Open.DestinationTable.value: "walmart_opd_instacart"
        #                 }]
        #             }
        #         ]
        #     }
        # },
        # {
        #     modelingStep.Step: {
        #         modelingStep.Category: category.Base,
        #         modelingStep.Overrides: [
        #             {
        #                 override.Task: baseTasks.NewProductTracker,
        #                 override.SprocParams: [{
        #                     NewProductTracker.SourceTable.value: "walmart_opd_instacart",
        #                     NewProductTracker.DestinationTable.value: "ecom_walmart_opd_instacart"
        #                 }]
        #             }
        #         ]
        #     }
        # },
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: gssTableIngestionTasks.DataExtractConfigUpdate,
                        override.SprocParams: [
                            {
                                DataExtractConfigUpdate.SourceTable.value: "walmart_opd_instacart_datasembly_store_price_mv"
                            }
                        ]
                    }
                ]
            }
        }
    ]
}
