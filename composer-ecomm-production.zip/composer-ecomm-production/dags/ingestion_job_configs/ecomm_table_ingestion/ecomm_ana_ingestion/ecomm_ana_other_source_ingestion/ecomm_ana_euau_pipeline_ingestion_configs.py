from dags.frameworks.dynamic.utils.available_base_task_params import *
from dags.frameworks.dynamic.utils.available_tasks import (GssTask, AaTask, BaseTask, GcsFileLoadTask, GssTableIngestionTask)
from dags.frameworks.dynamic.utils.classes.attributes import Attribute
from dags.frameworks.dynamic.utils.classes.categories import Category
from dags.frameworks.dynamic.utils.classes.dag_configs import DagConfig
from dags.frameworks.dynamic.utils.classes.dag_modeling_steps import (DagModelingStep, StepOverride)
from dags.frameworks.dynamic.utils.classes.task_config import TaskConfig
from dags.frameworks.dynamic.utils.classes.transformations import Transform
from dags.frameworks.dynamic.utils.classes.data_types import DataType
from dags.frameworks.dynamic.utils.classes.parameters import Parameter
from dags.frameworks.dynamic.utils.classes.file_load_strategy import FileLoadStrategy

dag = DagConfig()
config = TaskConfig()
attribute = Attribute()
transform = Transform()
dataType = DataType()
modelingStep = DagModelingStep()
override = StepOverride()
category = Category()
gcsTasks = GcsFileLoadTask()
gssTasks = GssTask()
gssTableIngestionTasks = GssTableIngestionTask()
aaTasks = AaTask()
baseTasks = BaseTask()
param = Parameter()
fileloadstrategy = FileLoadStrategy()

# noinspection PyInterpreter
configuration = {
    dag.title: {
        dag.ScheduleInterval: "0 10 * * WED",
        dag.DagName: "ecomm_ana_euau_ingestion",
        dag.CustomerName: "",
        dag.FeedName: "ana_source",
        dag.TagsStringArray: ["ecomm", "ana", "data_impact", "gcstobq"],
        dag.IsPublicFlag: True
    },
    dag.ModelingSteps: [
        {
            modelingStep.Step: {
                modelingStep.Category: category.UserDefined,
                config.TaskName: "trunc_load_customer_map",
                config.TaskDescription: "trunc_load_customer_map",
                config.BigQueryOperator: "BigQueryExecuteQueryOperator",
                config.BigQueryConnId: "bigquery_ecomm_dlf_data",
                config.DestinationProjectVariable: "ecomm-dlf-data",
                config.SqlOrScriptPath: "ecomm_sproc_ana_euau_customer",
                config.IsStoredProcFlag: True,
                "properties": {
                    config.SprocParams: []
                }    
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.UserDefined,
                config.TaskName: "build_availability_report",
                config.TaskDescription: "build_availability_report",
                config.BigQueryOperator: "BigQueryExecuteQueryOperator",
                config.BigQueryConnId: "bigquery_ecomm_dlf_data",
                config.DestinationProjectVariable: "ecomm-dlf-data",
                config.SqlOrScriptPath: "ecomm_sproc_ana_euau_availability_report",
                config.IsStoredProcFlag: True,
                "properties": {
                    config.SprocParams: []
                }    
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.UserDefined,
                config.TaskName: "build_assortment_report",
                config.TaskDescription: "build_assortment_report",
                config.BigQueryOperator: "BigQueryExecuteQueryOperator",
                config.BigQueryConnId: "bigquery_ecomm_dlf_data",
                config.DestinationProjectVariable: "ecomm-dlf-data",
                config.SqlOrScriptPath: "ecomm_sproc_ana_euau_assortment_report",
                config.IsStoredProcFlag: True,
                "properties": {
                    config.SprocParams: []
                }    
            }
        }
    ]
}

