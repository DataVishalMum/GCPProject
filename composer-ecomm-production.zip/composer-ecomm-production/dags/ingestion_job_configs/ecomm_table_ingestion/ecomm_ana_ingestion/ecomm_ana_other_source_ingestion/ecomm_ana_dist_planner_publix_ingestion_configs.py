from dags.frameworks.dynamic.utils.available_base_task_params import *
from dags.frameworks.dynamic.utils.available_tasks import (GssTask, AaTask, BaseTask, GcsFileLoadTask, GssTableIngestionTask)
from dags.frameworks.dynamic.utils.classes.attributes import Attribute
from dags.frameworks.dynamic.utils.classes.categories import Category
from dags.frameworks.dynamic.utils.classes.dag_configs import DagConfig
from dags.frameworks.dynamic.utils.classes.dag_modeling_steps import (DagModelingStep, StepOverride)
from dags.frameworks.dynamic.utils.classes.task_config import TaskConfig
from dags.frameworks.dynamic.utils.classes.transformations import Transform
from dags.frameworks.dynamic.utils.classes.data_types import DataType
from dags.frameworks.dynamic.utils.classes.parameters import Parameter
from dags.frameworks.dynamic.utils.classes.file_load_strategy import FileLoadStrategy

dag = DagConfig()
config = TaskConfig()
attribute = Attribute()
transform = Transform()
dataType = DataType()
modelingStep = DagModelingStep()
override = StepOverride()
category = Category()
gcsTasks = GcsFileLoadTask()
gssTasks = GssTask()
gssTableIngestionTasks = GssTableIngestionTask()
aaTasks = AaTask()
baseTasks = BaseTask()
param = Parameter()
fileloadstrategy = FileLoadStrategy()

# noinspection PyInterpreter
configuration = {
    dag.title: {
        dag.ScheduleInterval: "0 10 * * WED",
        dag.DagName: "ecomm_ana_dist_planner_publix_ingestion",
        dag.CustomerName: "PUBLIX_INSTACART_DATASEMBLY",
        dag.FeedName: "PUBLIX_INSTACART_DATASEMBLY",
        dag.TagsStringArray: ["ecomm", "ana", "dist_planner", "publix"],
        dag.IsPublicFlag: True
    },
    dag.ModelingSteps: [
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: baseTasks.DistPlannerTemp,
                        override.SprocParams: [{}]
                    }
                ]
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: baseTasks.DistPlannerProcessedOne,
                        override.SprocParams: [{}]
                    }
                ]
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: baseTasks.SourceTableDataExtractConfigInsert,
                        override.SprocParams: [
                            {
                                SourceTableDataExtractConfigInsert.SourceDataset.value: "transient",
                                SourceTableDataExtractConfigInsert.SourceTable.value: "publix_instacart_datasembly_store_price_mv",
                                SourceTableDataExtractConfigInsert.ColumnName.value: "ingest_date"
                            }
                        ]
                    }
                ]
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: baseTasks.CustomerDatasemblyDeltaTemp,
                        override.SprocParams: [{
                            CustomerDatasemblyDeltaTemp.DestinationTable.value: "publix_instacart_datasembly_delta_temp",
                            CustomerDatasemblyDeltaTemp.SourceCustomerName.value: "INSTACART_PUBLIX",
                            CustomerDatasemblyDeltaTemp.SourceTable.value: "publix_instacart_datasembly_store_price"
                        }]
                    }
                ]
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: baseTasks.DataQualityChecksRun,
                        override.SprocParams: [
                            {
                                DataQualityChecksRun.RecordKey.value: "3612706581343204499,5777529028716021800,6437411900868999975"
                            }
                        ]
                    }
                ]
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: baseTasks.SrcToEcommCatalogUpcMappingTable,
                        override.SprocParams: [{
                            SrcToEcommCatalogUpcMappingTable.SourceTable.value: "publix_instacart_datasembly_delta_temp",
                            SrcToEcommCatalogUpcMappingTable.UpcColumnName.value: "upc",
                            SrcToEcommCatalogUpcMappingTable.RpcColumnName.value: "rpc_column_name",
                            SrcToEcommCatalogUpcMappingTable.ProductTitleColumnName.value: "product_title_column"
                        }]
                    }
                ]
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: baseTasks.CustomerProcessedZero,
                        override.SprocParams: [{
                            CustomerProcessedZero.SourceTable.value: "publix_instacart_datasembly_delta_temp",
                            CustomerProcessedZero.DestinationTable.value: "publix_instacart_datasembly_processed_zero"
                        }]
                    }
                ]
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: baseTasks.DistributionFact,
                        override.SprocParams: [{
                            DistributionFact.DestinationTable.value: "publix_instacart",
                            DistributionFact.SourceTable.value: "publix_instacart"
                        }]
                    }
                ]
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: baseTasks.SourceTableDataExtractConfigInsert,
                        override.SprocParams: [
                            {
                                SourceTableDataExtractConfigInsert.SourceDataset.value: "processed",
                                SourceTableDataExtractConfigInsert.SourceTable.value: "publix_instacart_datasembly_fact",
                                SourceTableDataExtractConfigInsert.ColumnName.value: "modified_datetime"
                            }
                        ]
                    }
                ]
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: baseTasks.SourceTableDataExtractConfigInsert,
                        override.SprocParams: [
                            {
                                SourceTableDataExtractConfigInsert.SourceDataset.value: "processed",
                                SourceTableDataExtractConfigInsert.SourceTable.value: "publix_instacart_dist_planner_fact",
                                SourceTableDataExtractConfigInsert.ColumnName.value: "modified_datetime"
                            }
                        ]
                    }
                ]
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: baseTasks.DistributionAvailabilityJoinedPublix,
                        override.SprocParams: [{
                            DistributionAvailabilityJoined.DestinationTable.value: "publix_instacart",
                            DistributionAvailabilityJoined.SourceTable.value: "publix_instacart",
                            DistributionAvailabilityJoined.IntermediateTable.value: "publix_instacart"
                        }]
                    }
                ]
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: gssTableIngestionTasks.DataExtractConfigUpdate,
                        override.SprocParams: [
                            {
                                DataExtractConfigUpdate.SourceTable.value: "publix_instacart_datasembly_fact"
                            }
                        ]
                    }
                ]
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: gssTableIngestionTasks.DataExtractConfigUpdate,
                        override.SprocParams: [
                            {
                                DataExtractConfigUpdate.SourceTable.value: "publix_instacart_dist_planner_fact"
                            }
                        ]
                    }
                ]
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: baseTasks.SourceTableDataExtractConfigInsert,
                        override.SprocParams: [
                            {
                                SourceTableDataExtractConfigInsert.SourceDataset.value: "processed",
                                SourceTableDataExtractConfigInsert.SourceTable.value: "publix_instacart_distribution_availability_joined_fact",
                                SourceTableDataExtractConfigInsert.ColumnName.value: "modified_datetime"
                            }
                        ]
                    }
                ]
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: baseTasks.DistributionAvailabilitySmoothedPublix,
                        override.SprocParams: [{
                            DistributionAvailabilitySmoothed.SourceTable.value: "publix_instacart",
                            DistributionAvailabilitySmoothed.DestinationTable.value: "publix_instacart"
                        }]
                    }
                ]
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: gssTableIngestionTasks.DataExtractConfigUpdate,
                        override.SprocParams: [
                            {
                                DataExtractConfigUpdate.SourceTable.value: "publix_instacart_distribution_availability_joined_fact"
                            }
                        ]
                    }
                ]
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: baseTasks.SourceTableDataExtractConfigInsert,
                        override.SprocParams: [
                            {
                                SourceTableDataExtractConfigInsert.SourceDataset.value: "processed",
                                SourceTableDataExtractConfigInsert.SourceTable.value: "publix_instacart_distribution_availability_smoothed_fact",
                                SourceTableDataExtractConfigInsert.ColumnName.value: "modified_datetime"
                            }
                        ]
                    }
                ]
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: baseTasks.DistributionAvailabilityWithUpcPublix,
                        override.SprocParams: [{
                            DistributionAvailabilityWithUpc.DestinationTable.value: "publix_instacart",
                            DistributionAvailabilityWithUpc.SourceTable.value: "publix_instacart"
                        }]
                    }
                ]
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: gssTableIngestionTasks.DataExtractConfigUpdate,
                        override.SprocParams: [
                            {
                                DataExtractConfigUpdate.SourceTable.value: "publix_instacart_distribution_availability_smoothed_fact"
                            }
                        ]
                    }
                ]
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: baseTasks.DistributionAvailabilitySubcatgAggFact,
                        override.SprocParams: [{
                            DistributionAvailabilitySubcatgAggFact.SourceTable.value: "publix_instacart",
                            DistributionAvailabilitySubcatgAggFact.DestinationTable.value: "publix_instacart"
                        }]
                    }
                ]
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: baseTasks.EcomDataReleaseControlInsert,
                        override.SprocParams: [{
                            EcomDataReleaseControlInsert.SourceTable.value: "publix_instacart_distribution_availability_subcatg_agg_fact",
                            EcomDataReleaseControlInsert.SourceCustomerName.value: "PUBLIX_INSTACART_DISTRIBUTION_AVAILABILITY",
                            EcomDataReleaseControlInsert.SourceFeedName.value:"PUBLIX_INSTACART_DISTRIBUTION_AVAILABILITY_SUBCATG_AGG_FACT"
                        }]
                    }
                ]
            }
        },
        # {
        #     modelingStep.Step: {
        #         modelingStep.Category: category.Base,
        #         modelingStep.Overrides: [
        #             {
        #                 override.Task: baseTasks.UpcConversionsDnaOnly,
        #                 override.SprocParams: [{
        #                     UpcConversionsDnaOnly.SourceTable.value: "publix_instacart",
        #                     UpcConversionsDnaOnly.IntermediateTable.value: "publix_instacart",
        #                     UpcConversionsDnaOnly.DestinationFeedName.value: "publix_instacart",
        #                     UpcConversionsDnaOnly.DestinationTable.value: "publix_instacart"
        #                 }]
        #             }
        #         ]
        #     }
        # },
        # {
        #     modelingStep.Step: {
        #         modelingStep.Category: category.Base,
        #         modelingStep.Overrides: [
        #             {
        #                 override.Task: baseTasks.NewProductTracker,
        #                 override.SprocParams: [{
        #                     NewProductTracker.SourceTable.value: "publix_instacart",
        #                     NewProductTracker.DestinationTable.value: "ecom_publix_instacart"
        #                 }]
        #             }
        #         ]
        #     }
        # },
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: gssTableIngestionTasks.DataExtractConfigUpdate,
                        override.SprocParams: [
                            {
                                DataExtractConfigUpdate.SourceTable.value: "publix_instacart_datasembly_store_price_mv"
                            }
                        ]
                    }
                ]
            }
        }
    ]
}
