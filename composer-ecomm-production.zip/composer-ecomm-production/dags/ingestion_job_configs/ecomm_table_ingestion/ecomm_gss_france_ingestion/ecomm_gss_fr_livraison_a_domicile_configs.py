from dags.frameworks.dynamic.utils.available_base_task_params import *
from dags.frameworks.dynamic.utils.available_tasks import (GssTask, AaTask, BaseTask, GcsFileLoadTask, GssTableIngestionTask)
from dags.frameworks.dynamic.utils.classes.attributes import Attribute
from dags.frameworks.dynamic.utils.classes.categories import Category
from dags.frameworks.dynamic.utils.classes.dag_configs import DagConfig
from dags.frameworks.dynamic.utils.classes.dag_modeling_steps import (DagModelingStep, StepOverride)
from dags.frameworks.dynamic.utils.classes.task_config import TaskConfig
from dags.frameworks.dynamic.utils.classes.transformations import Transform
from dags.frameworks.dynamic.utils.classes.data_types import DataType
from dags.frameworks.dynamic.utils.classes.parameters import Parameter
from dags.frameworks.dynamic.utils.classes.file_load_strategy import FileLoadStrategy

dag = DagConfig()
config = TaskConfig()
attribute = Attribute()
transform = Transform()
dataType = DataType()
modelingStep = DagModelingStep()
override = StepOverride()
category = Category()
gcsTasks = GcsFileLoadTask()
gssTasks = GssTask()
gssTableIngestionTasks = GssTableIngestionTask()
aaTasks = AaTask()
baseTasks = BaseTask()
param = Parameter()
fileloadstrategy = FileLoadStrategy()

# noinspection PyInterpreter
configuration = {
    dag.title: {
        dag.ScheduleInterval: "0 11 16 * *",
        dag.DagName: "ecomm_gss_fr_livraison_a_domicile_ingestion",
        dag.CustomerName: "livraison_a_domicile",
        dag.FeedName: "livraison_a_domicile",
        dag.TagsStringArray: ["ecomm", "gss", "fr", "livraison_a_domicile"],
        dag.IsPublicFlag: False
    },
    dag.ModelingSteps: [
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: baseTasks.SourceTableDataExtractConfigInsert,
                        override.SprocParams: [
                            {
                                SourceTableDataExtractConfigInsert.SourceDataset.value: "processed",
                                SourceTableDataExtractConfigInsert.SourceTable.value: "livraison_a_domicile_weekly_agg_fact",
                                SourceTableDataExtractConfigInsert.ColumnName.value: "fiscal_week_begin_dt"
                            }
                        ]
                    }
                ]
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: baseTasks.NielsenDeltaTempFrance,
                        override.SprocParams: [
                            {
                                # NielsenDeltaTempFrance.SourceFeedName.value: "AUCHAN_DRIVE",
                                NielsenDeltaTempFrance.RecordKey.value: "2950556790993483714"
                            }
                        ]
                    }
                ]
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: baseTasks.DataQualityChecksRun,
                        override.SprocParams: [
                            {
                                DataQualityChecksRun.RecordKey.value: "8837503571500881151"
                            }
                        ]
                    }
                ]
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.GssTableIngestion,
                modelingStep.Overrides: [
                    {
                        override.Task: gssTableIngestionTasks.DimSourceToEnterpriseUpcXref,
                        override.SprocParams: [{}]
                    },
                    {
                        override.Task: gssTableIngestionTasks.CustomerProcessedZero,
                        override.SprocParams: [{}]
                    },
                    {
                        override.Task: gssTableIngestionTasks.ProductNarTemp,
                        override.SprocParams: [{}]
                    },
                    {
                        override.Task: baseTasks.NielsenProductNarTemp,
                        override.SprocParams: [{}]
                    },
                    {
                        override.Task: gssTableIngestionTasks.ConsolidateProductNarTemp,
                        override.SprocParams: [{}]
                    },
                    {
                        override.Task: gssTableIngestionTasks.XrefGlobalBrand,
                        override.SprocParams: [{}]
                    },
                    {
                        override.Task: gssTableIngestionTasks.XrefGlobalCategory,
                        override.SprocParams: [{}]
                    },
                    {
                        override.Task: gssTableIngestionTasks.XrefOverride,
                        override.SprocParams: [{}]
                    },
                    {
                        override.Task: gssTableIngestionTasks.ConsolidateXrefTemp,
                        override.SprocParams: [{}]
                    },
                    {
                        override.Task: gssTableIngestionTasks.DerivedXrefInfoTemp,
                        override.SprocParams: [{}]
                    },
                    {
                        override.Task: gssTableIngestionTasks.CustomerFactNar,
                        override.SprocParams: [{}]
                    },
                    {
                        override.Task: baseTasks.DataQualityChecksRun,
                        override.SprocParams: [{
                            DataQualityChecksRun.RecordKey.value: "6766183795873708211"
                        }]
                    },
                    {
                        override.Task: gssTableIngestionTasks.CustomerWeeklyAggFact,
                        override.SprocParams: [{}]
                    },
                    {
                        override.Task: gssTableIngestionTasks.EcomDataReleaseControlInsert,
                        override.SprocParams: [{}]
                    },
                    {
                        override.Task: gssTableIngestionTasks.DataExtractConfigUpdate,
                        override.SprocParams: [
                            {
                                DataExtractConfigUpdate.SourceTable.value: "livraison_a_domicile_weekly_agg_fact"
                            }
                        ]
                    }
                ]
            }
        },
    ]
}
