from dags.frameworks.dynamic.utils.available_base_task_params import *
from dags.frameworks.dynamic.utils.available_tasks import (GssTask, AaTask, BaseTask, GcsFileLoadTask, GssTableIngestionTask)
from dags.frameworks.dynamic.utils.classes.attributes import Attribute
from dags.frameworks.dynamic.utils.classes.categories import Category
from dags.frameworks.dynamic.utils.classes.dag_configs import DagConfig
from dags.frameworks.dynamic.utils.classes.dag_modeling_steps import (DagModelingStep, StepOverride)
from dags.frameworks.dynamic.utils.classes.task_config import TaskConfig
from dags.frameworks.dynamic.utils.classes.transformations import Transform
from dags.frameworks.dynamic.utils.classes.data_types import DataType
from dags.frameworks.dynamic.utils.classes.parameters import Parameter
from dags.frameworks.dynamic.utils.classes.file_load_strategy import FileLoadStrategy


dag = DagConfig()
config = TaskConfig()
attribute = Attribute()
transform = Transform()
dataType = DataType()
modelingStep = DagModelingStep()
override = StepOverride()
category = Category()
gcsTasks = GcsFileLoadTask()
gssTasks = GssTask()
gssTableIngestionTasks = GssTableIngestionTask()
aaTasks = AaTask()
baseTasks = BaseTask()
param = Parameter()
fileloadstrategy = FileLoadStrategy()

# noinspection PyInterpreter
configuration = {
    dag.title: {
        dag.ScheduleInterval: "0 12 30 * *",
        dag.DagName: "ecomm_gss_fr_leclerc_ingestion",
        dag.CustomerName: "leclerc",
        dag.FeedName: "leclerc",
        dag.TagsStringArray: ["ecomm", "gss", "fr", "leclerc"],
        dag.IsPublicFlag: False
    },
    dag.ModelingSteps: [
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: baseTasks.SourceTableDataExtractConfigInsert,
                        override.SprocParams: [
                            {
                                SourceTableDataExtractConfigInsert.SourceDataset.value: "processed",
                                SourceTableDataExtractConfigInsert.SourceTable.value: "leclerc_weekly_agg_fact",
                                SourceTableDataExtractConfigInsert.ColumnName.value: "fiscal_week_begin_dt"
                            }
                        ]
                    }
                ]
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.UserDefined,
                config.TaskName: "leclerc_delta_temp",
                config.TaskDescription: "load_data_from_neilsen_source_to_delta_temp",
                config.BigQueryOperator: "BigQueryExecuteQueryOperator",
                config.BigQueryConnId: "bigquery_ecomm_dlf_data",
                config.DestinationProjectVariable: "ecomm-dlf-data",
                config.SqlOrScriptPath: "ecomm_sproc_gss_fr_leclerc_delta_temp",
                config.IsStoredProcFlag: True,
                "properties": {
                    config.SprocParams: [
                        {
                            attribute.Name: param.SourceProject,
                            attribute.Value: "ecomm-dlf-data",
                            attribute.IsInferredFlag: True,
                            attribute.DataTransformationType: transform.UseAsIs,
                            attribute.DataType: dataType.String
                        },
                        {
                            attribute.Name: param.SourceDataset,
                            attribute.Value: "intlhub",
                            attribute.IsInferredFlag: True,
                            attribute.DataTransformationType: transform.UseAsIs,
                            attribute.DataType: dataType.String
                        },
                        {
                            attribute.Name: param.SourceTable,
                            attribute.Value: "coopelec_euau_channel_store_sales_fact",
                            attribute.IsInferredFlag: True,
                            attribute.DataTransformationType: transform.UseAsIs,
                            attribute.DataType: dataType.String
                        },
                        {
                            attribute.Name: param.SourceLookupTable,
                            attribute.Value: "leclerc_weekly_agg_fact",
                            attribute.IsInferredFlag: True,
                            attribute.DataTransformationType: transform.UseAsIs,
                            attribute.DataType: dataType.String
                        },
                        {
                            attribute.Name: param.IntermediateProject,
                            attribute.Value: "ecomm-edw",
                            attribute.IsInferredFlag: True,
                            attribute.DataTransformationType: transform.UseAsIs,
                            attribute.DataType: dataType.String
                        },
                        {
                            attribute.Name: param.IntermediateDataset,
                            attribute.Value: "syndicated_data",
                            attribute.IsInferredFlag: True,
                            attribute.DataTransformationType: transform.UseAsIs,
                            attribute.DataType: dataType.String
                        },
                        {
                            attribute.Name: param.IntermediateTable,
                            attribute.Value: "dim_nielsen_pos_fr_product",
                            attribute.IsInferredFlag: True,
                            attribute.DataTransformationType: transform.UseAsIs,
                            attribute.DataType: dataType.String
                        },
                        {
                            attribute.Name: param.DestinationDataset,
                            attribute.Value: "transient",
                            attribute.IsInferredFlag: True,
                            attribute.DataTransformationType: transform.UseAsIs,
                            attribute.DataType: dataType.String
                        },
                        {
                            attribute.Name: param.DestinationTable,
                            attribute.Value: "leclerc_delta_temp",
                            attribute.IsInferredFlag: True,
                            attribute.DataTransformationType: transform.UseAsIs,
                            attribute.DataType: dataType.String
                        },
                        {
                            attribute.Name: param.SourceCustomerName,
                            attribute.Value: "leclerc",
                            attribute.IsInferredFlag: True,
                            attribute.DataTransformationType: transform.UseAsIs,
                            attribute.DataType: dataType.String
                        },
                        {
                            attribute.Name: param.SourceFeedName,
                            attribute.Value: "leclerc",
                            attribute.IsInferredFlag: True,
                            attribute.DataTransformationType: transform.UseAsIs,
                            attribute.DataType: dataType.String
                        }
                    ]
                }
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: baseTasks.DataQualityChecksRun,
                        override.SprocParams: [
                            {
                                DataQualityChecksRun.RecordKey.value: "5780050931272424359,8765378395919419679,2877480007850722756,2392889804791216082"
                            }
                        ]
                    }
                ]
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.GssTableIngestion,
                modelingStep.Overrides: [
                    {
                        override.Task: gssTableIngestionTasks.DimSourceToEnterpriseUpcXref,
                        override.SprocParams: [{}]
                    },
                    {
                        override.Task: gssTableIngestionTasks.CustomerProcessedZero,
                        override.SprocParams: [{}]
                    },
                    {
                        override.Task: gssTableIngestionTasks.ProductNarTemp,
                        override.SprocParams: [{}]
                    },
                    {
                        override.Task: baseTasks.NielsenProductNarTemp,
                        override.SprocParams: [{}]
                    },
                    {
                        override.Task: gssTableIngestionTasks.ConsolidateProductNarTemp,
                        override.SprocParams: [{}]
                    },
                    {
                        override.Task: gssTableIngestionTasks.XrefGlobalBrand,
                        override.SprocParams: [{}]
                    },
                    {
                        override.Task: gssTableIngestionTasks.XrefGlobalCategory,
                        override.SprocParams: [{}]
                    },
                    {
                        override.Task: gssTableIngestionTasks.XrefOverride,
                        override.SprocParams: [{}]
                    },
                    {
                        override.Task: gssTableIngestionTasks.ConsolidateXrefTemp,
                        override.SprocParams: [{}]
                    },
                    {
                        override.Task: gssTableIngestionTasks.DerivedXrefInfoTemp,
                        override.SprocParams: [{}]
                    },
                    {
                        override.Task: gssTableIngestionTasks.CustomerFactNar,
                        override.SprocParams: [{}]
                    },
                    {
                        override.Task: baseTasks.DataQualityChecksRun,
                        override.SprocParams: [{
                            DataQualityChecksRun.RecordKey.value: "3702835932760195688"
                        }]
                    },
                    {
                        override.Task: gssTableIngestionTasks.CustomerWeeklyAggFact,
                        override.SprocParams: [{}]
                    },
                    {
                        override.Task: gssTableIngestionTasks.EcomDataReleaseControlInsert,
                        override.SprocParams: [{}]
                    },
                    {
                        override.Task: gssTableIngestionTasks.DataExtractConfigUpdate,
                        override.SprocParams: [
                            {
                                DataExtractConfigUpdate.SourceTable.value: "leclerc_weekly_agg_fact"
                            }
                        ]
                    }
                ]
            }
        },
    ]
}
