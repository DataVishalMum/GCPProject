from dags.frameworks.dynamic.utils.available_base_task_params import *
from dags.frameworks.dynamic.utils.available_tasks import (GssTask, AaTask, BaseTask, GcsFileLoadTask, GssTableIngestionTask)
from dags.frameworks.dynamic.utils.classes.attributes import Attribute
from dags.frameworks.dynamic.utils.classes.categories import Category
from dags.frameworks.dynamic.utils.classes.dag_configs import DagConfig
from dags.frameworks.dynamic.utils.classes.dag_modeling_steps import (DagModelingStep, StepOverride)
from dags.frameworks.dynamic.utils.classes.task_config import TaskConfig
from dags.frameworks.dynamic.utils.classes.transformations import Transform
from dags.frameworks.dynamic.utils.classes.data_types import DataType
from dags.frameworks.dynamic.utils.classes.parameters import Parameter
from dags.frameworks.dynamic.utils.classes.file_load_strategy import FileLoadStrategy

dag = DagConfig()
config = TaskConfig()
attribute = Attribute()
transform = Transform()
dataType = DataType()
modelingStep = DagModelingStep()
override = StepOverride()
category = Category()
gcsTasks = GcsFileLoadTask()
gssTasks = GssTask()
gssTableIngestionTasks = GssTableIngestionTask()
aaTasks = AaTask()
baseTasks = BaseTask()
param = Parameter()
fileloadstrategy = FileLoadStrategy()

# noinspection PyInterpreter
configuration = {
    dag.title: {
        dag.ScheduleInterval: "None",
        dag.DagName: "ecomm_common_customer_info",
        dag.CustomerName: "ecomm_common_customer_info",
        dag.FeedName: "ecomm_common_customer_info",
        dag.TagsStringArray: ["ecomm", "common", "data_access", "customer_info"],
        dag.IsPublicFlag: False
    },
    dag.ModelingSteps: [
        {
            modelingStep.Step: {
                modelingStep.Category: category.UserDefined,
                config.TaskName: "refresh_customer_info",
                config.TaskDescription: "refresh_customer_info_table",
                config.BigQueryOperator: "BigQueryExecuteQueryOperator",
                config.BigQueryConnId: "bigquery_ecomm_dlf_data",
                config.DestinationProjectVariable: "ecomm-dlf-data",
                config.SqlOrScriptPath: "ecomm_sproc_common_customer_info",
                config.IsStoredProcFlag: True,
                "properties": {
                    config.SprocParams: [
                        {
                            attribute.Name: param.SourceProject,
                            attribute.Value: "ecomm-dlf-data",
                            attribute.IsInferredFlag: True,
                            attribute.DataTransformationType: transform.UseAsIs,
                            attribute.DataType: dataType.String
                        },
                        {
                            attribute.Name: param.IntermediateProject,
                            attribute.Value: "ecomm-edw",
                            attribute.IsInferredFlag: True,
                            attribute.DataTransformationType: transform.UseAsIs,
                            attribute.DataType: dataType.String
                        },
                        {
                            attribute.Name: param.DestinationProject,
                            attribute.Value: "ecomm-analytics",
                            attribute.IsInferredFlag: True,
                            attribute.DataTransformationType: transform.UseAsIs,
                            attribute.DataType: dataType.String
                        }
                    ]
                }
            }
        }
    ]
}
