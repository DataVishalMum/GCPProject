from dags.frameworks.dynamic.utils.available_base_task_params import *

from dags.frameworks.dynamic.utils.available_tasks import (GssTask, AaTask, BaseTask, GcsFileLoadTask, EuauTask,GssTableIngestionTask)
from dags.frameworks.dynamic.utils.classes.attributes import Attribute
from dags.frameworks.dynamic.utils.classes.categories import Category
from dags.frameworks.dynamic.utils.classes.dag_configs import DagConfig
from dags.frameworks.dynamic.utils.classes.dag_modeling_steps import (DagModelingStep, StepOverride)
from dags.frameworks.dynamic.utils.classes.task_config import TaskConfig
from dags.frameworks.dynamic.utils.classes.transformations import Transform
from dags.frameworks.dynamic.utils.classes.data_types import DataType
from dags.frameworks.dynamic.utils.classes.parameters import Parameter
from dags.frameworks.dynamic.utils.classes.file_load_strategy import FileLoadStrategy

dag = DagConfig()
config = TaskConfig()
attribute = Attribute()
transform = Transform()
dataType = DataType()
modelingStep = DagModelingStep()
override = StepOverride()
category = Category()
gcsTasks = GcsFileLoadTask()
gssTasks = GssTask()
gssTableIngestionTasks = GssTableIngestionTask()
euauTasks = EuauTask() 
aaTasks = AaTask()
baseTasks = BaseTask()
param = Parameter()
fileloadstrategy = FileLoadStrategy()

# noinspection PyInterpreter

configuration = {
    dag.title: {
        dag.ScheduleInterval: "0 10 14 * *",
        dag.DagName: "ecomm_gss_euau_asda_ingestion",
        dag.CustomerName: "asda",
        dag.FeedName: "asda",
        dag.TagsStringArray: ["ecomm", "gss", "euau", "asda"],
        dag.IsPublicFlag: True
    },
    dag.ModelingSteps: [
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: baseTasks.SourceTableDataExtractConfigInsert,
                        override.SprocParams: [
                            {
                                SourceTableDataExtractConfigInsert.SourceDataset.value: "processed",
                                SourceTableDataExtractConfigInsert.SourceTable.value: "asda_weekly_agg_fact",
                                SourceTableDataExtractConfigInsert.ColumnName.value: "fiscal_week_begin_dt"
                            }
                        ]
                    }
                ]
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.UserDefined,
                config.TaskName: "asda_delta_temp",
                config.TaskDescription: "load_data_from_neilsen_source_to_delta_temp",
                config.BigQueryOperator: "BigQueryExecuteQueryOperator",
                config.BigQueryConnId: "bigquery_ecomm_dlf_data",
                config.DestinationProjectVariable: "ecomm-dlf-data",
                config.SqlOrScriptPath: "ecomm_sproc_gss_euau_asda_delta_temp",
                config.IsStoredProcFlag: True,
                "properties": {
                    config.SprocParams: [
                        {
                            attribute.Name: param.SourceProject,
                            attribute.Value: "ecomm-edw-prd",
                            attribute.IsInferredFlag: True,
                            attribute.DataTransformationType: transform.UseAsIs,
                            attribute.DataType: dataType.String
                        },
                        {
                            attribute.Name: param.SourceDataset,
                            attribute.Value: "syndicated_data",
                            attribute.IsInferredFlag: True,
                            attribute.DataTransformationType: transform.UseAsIs,
                            attribute.DataType: dataType.String
                        },
                        {
                            attribute.Name: param.DestinationProject,
                            attribute.Value: "ecomm-dlf-data",
                            attribute.IsInferredFlag: True,
                            attribute.DataTransformationType: transform.UseAsIs,
                            attribute.DataType: dataType.String
                        },
                        {
                            attribute.Name: param.DestinationDataset,
                            attribute.Value: "transient",
                            attribute.IsInferredFlag: True,
                            attribute.DataTransformationType: transform.UseAsIs,
                            attribute.DataType: dataType.String
                        },
                        {
                            attribute.Name: param.DestinationTable,
                            attribute.Value: "asda_delta_temp",
                            attribute.IsInferredFlag: True,
                            attribute.DataTransformationType: transform.UseAsIs,
                            attribute.DataType: dataType.String
                        },
                        {
                            attribute.Name: param.SourceLookupTable,
                            attribute.Value: "asda_weekly_agg_fact",
                            attribute.IsInferredFlag: True,
                            attribute.DataTransformationType: transform.UseAsIs,
                            attribute.DataType: dataType.String
                        },
                        {
                            attribute.Name: param.SourceCustomerName,
                            attribute.Value: "asda",
                            attribute.IsInferredFlag: True,
                            attribute.DataTransformationType: transform.UseAsIs,
                            attribute.DataType: dataType.String
                        },
                        {
                            attribute.Name: param.SourceFeedName,
                            attribute.Value: "asda",
                            attribute.IsInferredFlag: True,
                            attribute.DataTransformationType: transform.UseAsIs,
                            attribute.DataType: dataType.String
                        }
                    ]
                }
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: baseTasks.DataQualityChecksRun,
                        override.SprocParams: [
                            {
                                DataQualityChecksRun.RecordKey.value: "7347047847400641052"
                            }
                        ]
                    }
                ]
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.Euau,
                modelingStep.Overrides: [
                    {
                        override.Task: euauTasks.DimSourceToEnterpriseUpcXref,
                        override.SprocParams: [{}]
                    },
                    {
                        override.Task: euauTasks.CustomerProcessedZero,
                        override.SprocParams: [{}]
                    },
                    {
                        override.Task: euauTasks.ConsolidateProductEuauTemp,
                        override.SprocParams: [{}]
                    },
                    {
                        override.Task: euauTasks.XrefGlobalBrand,
                        override.SprocParams: [{}]
                    },
                    {
                        override.Task: euauTasks.XrefGlobalCategory,
                        override.SprocParams: [{}]
                    },
                    {
                        override.Task: euauTasks.XrefOverride,
                        override.SprocParams: [{}]
                    },
                    {
                        override.Task: euauTasks.ConsolidateXrefTemp,
                        override.SprocParams: [{}]
                    },
                    {
                        override.Task: euauTasks.DerivedXrefInfoTemp,
                        override.SprocParams: [{}]
                    },
                    {
                        override.Task: euauTasks.CustomerFactEuau,
                        override.SprocParams: [{}]
                    },
                    {
                        override.Task: baseTasks.DataQualityChecksRun,
                        override.SprocParams: [{
                            DataQualityChecksRun.RecordKey.value: "331316163361192775"
                        }]
                    },
                    {
                        override.Task: euauTasks.CustomerWeeklyAggFact,
                        override.SprocParams: [{}]
                    },
                    {
                        override.Task: euauTasks.DataExtractConfigUpdate,
                        override.SprocParams: [{
                            DataExtractConfigUpdate.SourceTable.value: "asda_weekly_agg_fact"
                        }]
                    }
                ]
            }
        },
    ]
}
