from dags.frameworks.dynamic.utils.available_base_task_params import *
from dags.frameworks.dynamic.utils.available_tasks import (GssTask, AaTask, BaseTask, GcsFileLoadTask, GssTableIngestionTask)
from dags.frameworks.dynamic.utils.classes.attributes import Attribute
from dags.frameworks.dynamic.utils.classes.categories import Category
from dags.frameworks.dynamic.utils.classes.dag_configs import DagConfig
from dags.frameworks.dynamic.utils.classes.dag_modeling_steps import (DagModelingStep, StepOverride)
from dags.frameworks.dynamic.utils.classes.task_config import TaskConfig
from dags.frameworks.dynamic.utils.classes.transformations import Transform
from dags.frameworks.dynamic.utils.classes.data_types import DataType
from dags.frameworks.dynamic.utils.classes.parameters import Parameter
from dags.frameworks.dynamic.utils.classes.file_load_strategy import FileLoadStrategy

dag = DagConfig()
config = TaskConfig()
attribute = Attribute()
transform = Transform()
dataType = DataType()
modelingStep = DagModelingStep()
override = StepOverride()
category = Category()
gcsTasks = GcsFileLoadTask()
gssTasks = GssTask()
gssTableIngestionTasks = GssTableIngestionTask()
aaTasks = AaTask()
baseTasks = BaseTask()
param = Parameter()
fileloadstrategy = FileLoadStrategy()

# noinspection PyInterpreter

configuration = {
    dag.title: {
        dag.ScheduleInterval: "30 23 * * TUE",
        dag.DagName: "ecomm_gss_blue_target_ingestion",
        dag.CustomerName: "target_blue",
        dag.FeedName: "target_blue",
        dag.TagsStringArray: ["ecomm", "gss", "blue", "target_blue"],
        dag.IsPublicFlag: True
    },
    dag.ModelingSteps: [
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: baseTasks.SourceTableDataExtractConfigInsert,
                        override.SprocParams: [
                            {
                                SourceTableDataExtractConfigInsert.SourceDataset.value: "processed",
                                SourceTableDataExtractConfigInsert.SourceTable.value: "target_blue_weekly_agg_fact",
                                SourceTableDataExtractConfigInsert.ColumnName.value: "fiscal_week_begin_dt"
                            }
                        ]
                    }
                ]
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: baseTasks.NielsenDeltaTempBlue,
                        override.SprocParams: [
                            {
                                NielsenDeltaTempBlue.RecordKey.value: "3996521846265137638"
                            }
                        ]
                    }
                ]
            }
        },
        # {
        #     modelingStep.Step: {
        #         modelingStep.Category: category.Base,
        #         modelingStep.Overrides: [
        #             {
        #                 override.Task: baseTasks.DataQualityChecksRun,
        #                 override.SprocParams: [
        #                     {
        #                         DataQualityChecksRun.RecordKey.value: "4812696670765860602,4464153942849665098,8392270895237042741,7001129981870280240,6693558358791398082"
        #                     }
        #                 ]
        #             }
        #         ]
        #     }
        # },
        {
            modelingStep.Step: {
                modelingStep.Category: category.GssTableIngestion,
                modelingStep.Overrides: [
                    {
                        override.Task: gssTasks.SrcToEcommCatalogUpcMappingTable,
                        override.SprocParams: [{
                            SrcToEcommCatalogUpcMappingTable.UpcColumnName.value: "upc",
                            SrcToEcommCatalogUpcMappingTable.ProductTitleColumnName.value: "source_item_name"
                        }]
                    },
                    {
                        override.Task: gssTableIngestionTasks.CustomerProcessedZero,
                        override.SprocParams: [{}]
                    },
                   {
                        override.Task: gssTasks.GssNarCustomerFact,
                        override.SprocParams: [{
                            GssNarCustomerFact.UpcColumnName.value: "upc",
                            GssNarCustomerFact.ProductTitleColumnName.value: "source_item_name"
                        }]
                    },
                    # {
                    #     override.Task: baseTasks.DataQualityChecksRun,
                    #     override.SprocParams: [{
                    #         DataQualityChecksRun.RecordKey.value: "8812513394131265738,5587994186949157915,1875720060920387636"
                    #     }]
                    # },
                    {
                        override.Task: gssTableIngestionTasks.CustomerWeeklyAggFact,
                        override.SprocParams: [{}]
                    },
                    {
                        override.Task: gssTableIngestionTasks.EcomDataReleaseControlInsert,
                        override.SprocParams: [{}]
                    },
                    {
                        override.Task: gssTableIngestionTasks.DataExtractConfigUpdate,
                        override.SprocParams: [{
                            DataExtractConfigUpdate.SourceTable.value: "target_blue_weekly_agg_fact"
                        }]
                    }
                ]
            }
        },
    ]
}
