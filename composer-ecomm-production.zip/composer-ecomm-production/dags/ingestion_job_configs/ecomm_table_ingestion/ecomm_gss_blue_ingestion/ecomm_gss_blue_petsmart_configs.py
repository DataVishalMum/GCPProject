from dags.frameworks.dynamic.utils.available_base_task_params import *
from dags.frameworks.dynamic.utils.available_tasks import (GssTask, AaTask, BaseTask, GcsFileLoadTask, GssTableIngestionTask)
from dags.frameworks.dynamic.utils.classes.attributes import Attribute
from dags.frameworks.dynamic.utils.classes.categories import Category
from dags.frameworks.dynamic.utils.classes.dag_configs import DagConfig
from dags.frameworks.dynamic.utils.classes.dag_modeling_steps import (DagModelingStep, StepOverride)
from dags.frameworks.dynamic.utils.classes.task_config import TaskConfig
from dags.frameworks.dynamic.utils.classes.transformations import Transform
from dags.frameworks.dynamic.utils.classes.data_types import DataType
from dags.frameworks.dynamic.utils.classes.parameters import Parameter
from dags.frameworks.dynamic.utils.classes.file_load_strategy import FileLoadStrategy

dag = DagConfig()
config = TaskConfig()
attribute = Attribute()
transform = Transform()
dataType = DataType()
modelingStep = DagModelingStep()
override = StepOverride()
category = Category()
gcsTasks = GcsFileLoadTask()
gssTasks = GssTask()
gssTableIngestionTasks = GssTableIngestionTask()
aaTasks = AaTask()
baseTasks = BaseTask()
param = Parameter()
fileloadstrategy = FileLoadStrategy()

# noinspection PyInterpreter
configuration = {
    dag.title: {
        dag.ScheduleInterval: "0 23 * * TUE",
        dag.DagName: "ecomm_gss_blue_petsmart_ingestion",
        dag.CustomerName: "petsmart",
        dag.FeedName: "petsmart",
        dag.TagsStringArray: ["ecomm", "gss", "nar", "petsmart"],
        dag.IsPublicFlag: True
    },
    dag.ModelingSteps: [
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: baseTasks.SourceTableDataExtractConfigInsert,
                        override.SprocParams: [
                            {
                                SourceTableDataExtractConfigInsert.SourceDataset.value: "processed",
                                SourceTableDataExtractConfigInsert.SourceTable.value: "petsmart_weekly_agg_fact",
                                SourceTableDataExtractConfigInsert.ColumnName.value: "fiscal_week_begin_dt"
                            }
                        ]
                    }
                ]
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: baseTasks.NielsenDeltaTempBlue,
                        override.SprocParams: [
                            {
                                NielsenDeltaTempBlue.RecordKey.value: "5043550806204428235"
                            }
                        ]
                    }
                ]
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.GssTableIngestion,
                modelingStep.Overrides: [
                    {
                        override.Task: gssTableIngestionTasks.DimSourceToEnterpriseUpcXref,
                        override.SprocParams: [{}]
                    },
                    {
                        override.Task: gssTableIngestionTasks.CustomerProcessedZero,
                        override.SprocParams: [{}]
                    },
                    {
                        override.Task: gssTableIngestionTasks.ProductNarTemp,
                        override.SprocParams: [{}]
                    },
                    {
                        override.Task: baseTasks.NielsenProductNarTemp,
                        override.SprocParams: [{}]
                    },
                    {
                        override.Task: gssTableIngestionTasks.ConsolidateProductNarTemp,
                        override.SprocParams: [{}]
                    },
                    {
                        override.Task: gssTableIngestionTasks.XrefGlobalBrand,
                        override.SprocParams: [
                            {
                                XrefGlobalBrand.SourceFeedName.value: "feed_name"
                            }
                        ]
                    },
                    {
                        override.Task: gssTableIngestionTasks.XrefGlobalCategory,
                        override.SprocParams: [
                            {
                                XrefGlobalCategory.SourceFeedName.value: "feed_name"
                            }
                        ]
                    },
                    {
                        override.Task: gssTableIngestionTasks.XrefOverride,
                        override.SprocParams: [
                            {
                                XrefOverride.SourceFeedName.value: "feed_name"
                            }
                        ]
                    },
                    {
                        override.Task: gssTableIngestionTasks.ConsolidateXrefTemp,
                        override.SprocParams: [{}]
                    },
                    {
                        override.Task: gssTableIngestionTasks.DerivedXrefInfoTemp,
                        override.SprocParams: [{}]
                    },
                    {
                        override.Task: gssTableIngestionTasks.CustomerFactNar,
                        override.SprocParams: [{}]
                    },
                    {
                        override.Task: gssTableIngestionTasks.CustomerWeeklyAggFact,
                        override.SprocParams: [{}]
                    },
                    {
                        override.Task: gssTableIngestionTasks.EcomDataReleaseControlInsert,
                        override.SprocParams: [{}]
                    },
                    {
                        override.Task: gssTableIngestionTasks.DataExtractConfigUpdate,
                        override.SprocParams: [{
                            DataExtractConfigUpdate.SourceTable.value: "petsmart_weekly_agg_fact"
                        }]
                    }
                ]
            }
        },
    ]
}
