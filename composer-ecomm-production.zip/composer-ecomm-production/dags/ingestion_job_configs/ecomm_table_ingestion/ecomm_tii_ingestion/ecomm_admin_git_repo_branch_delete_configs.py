from dags.frameworks.dynamic.utils.available_base_task_params import *
from dags.frameworks.dynamic.utils.available_tasks import (GssTask, AaTask, BaseTask, GcsFileLoadTask, GssTableIngestionTask)
from dags.frameworks.dynamic.utils.classes.attributes import Attribute
from dags.frameworks.dynamic.utils.classes.categories import Category
from dags.frameworks.dynamic.utils.classes.dag_configs import DagConfig
from dags.frameworks.dynamic.utils.classes.dag_modeling_steps import (DagModelingStep, StepOverride)
from dags.frameworks.dynamic.utils.classes.task_config import TaskConfig
from dags.frameworks.dynamic.utils.classes.transformations import Transform
from dags.frameworks.dynamic.utils.classes.data_types import DataType
from dags.frameworks.dynamic.utils.classes.parameters import Parameter
from dags.frameworks.dynamic.utils.classes.file_load_strategy import FileLoadStrategy

dag = DagConfig()
config = TaskConfig()
attribute = Attribute()
transform = Transform()
dataType = DataType()
modelingStep = DagModelingStep()
override = StepOverride()
category = Category()
gcsTasks = GcsFileLoadTask()
gssTasks = GssTask()
gssTableIngestionTasks = GssTableIngestionTask()
aaTasks = AaTask()
baseTasks = BaseTask()
param = Parameter()
fileloadstrategy = FileLoadStrategy()

# noinspection PyInterpreter
configuration = {
    dag.title: {
        dag.ScheduleInterval: "None",
        dag.DagName: "ecomm_admin_git_repo_branch_delete",
        dag.CustomerName: "git_repo_branch_delete",
        dag.FeedName: "git_repo_branch_delete",
        dag.TagsStringArray: ["ecomm", "admin", "tii", "git", "branch_delete"],
        dag.IsPublicFlag: False
    },
    dag.ModelingSteps: [
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: baseTasks.RepoBranchDelete,
                        override.SprocParams: [
                            {
                                RepoBranchDelete.OrganizationName.value: "generalmills",
                                RepoBranchDelete.GitProjectId.value: "36d74a66-68b1-4df2-b552-be8f6b8f523b",
                                RepoBranchDelete.RepositoryId.value: "cf7a316d-480f-4e1e-a643-02ffa7469b93",
                                RepoBranchDelete.Threshold.value: "200"
                            }
                        ]
                    }
                ]
            }
        }
    ]
}
