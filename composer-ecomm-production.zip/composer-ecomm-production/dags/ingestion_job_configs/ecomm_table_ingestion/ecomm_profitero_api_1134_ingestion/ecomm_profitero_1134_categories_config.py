from dags.frameworks.dynamic.utils.available_base_task_params import *
from dags.frameworks.dynamic.utils.available_tasks import (GssTask, AaTask, BaseTask)
from dags.frameworks.dynamic.utils.classes.attributes import Attribute
from dags.frameworks.dynamic.utils.classes.categories import Category
from dags.frameworks.dynamic.utils.classes.dag_configs import DagConfig
from dags.frameworks.dynamic.utils.classes.dag_modeling_steps import (DagModelingStep, StepOverride)
from dags.frameworks.dynamic.utils.classes.task_config import TaskConfig
from dags.frameworks.dynamic.utils.classes.transformations import Transform
from dags.frameworks.dynamic.utils.classes.data_types import DataType

dag = DagConfig()
config = TaskConfig()
attribute = Attribute()
transform = Transform()
dataType = DataType()
modelingStep = DagModelingStep()
override = StepOverride()
category = Category()
gssTasks = GssTask()
aaTasks = AaTask()
baseTasks = BaseTask()

configuration = {
    dag.title: {
        dag.ScheduleInterval: "0 10 * * WED",
        dag.DagName: "ecomm_profitero_1134_categories",
        dag.CustomerName: "profitero_1134_categories",
        dag.FeedName: "profitero_1134_categories",
        dag.TagsStringArray: ["ecomm", "profitero_1134",  "profitero_1134_categories"]
    },
    dag.ModelingSteps: [
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: baseTasks.ProfiteroApiDataExtractConfigInsert,
                        override.SprocParams: [
                            {
                                ProfiteroApiDataExtractConfigInsert.SourceDataset.value: "profitero_1134",
                                ProfiteroApiDataExtractConfigInsert.SourceTable.value: "categories",
                                ProfiteroApiDataExtractConfigInsert.ColumnName.value: "updated_at"
                            }
                        ]
                    }
                ]
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: baseTasks.BuildApiProcessedTable,
                        override.SprocParams: [
                            {
                                BuildApiProcessedTable.SourceDataset.value: "profitero_1134",
                                BuildApiProcessedTable.SourceTable.value: "categories",
                                BuildApiProcessedTable.DestinationTable.value: "customer_name",
                            }
                        ]
                    }
                ]
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: baseTasks.DataExtractConfigUpdate,
                        override.SprocParams: [
                            {
                                BuildApiProcessedTable.SourceTable.value: "customer_name"
                            }
                        ]
                    }
                ]
            }
        }
    ]
}
