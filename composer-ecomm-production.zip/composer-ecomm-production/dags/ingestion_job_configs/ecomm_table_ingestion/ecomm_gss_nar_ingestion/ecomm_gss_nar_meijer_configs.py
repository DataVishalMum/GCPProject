from dags.frameworks.dynamic.utils.available_base_task_params import *
from dags.frameworks.dynamic.utils.available_tasks import (GssTask, AaTask, BaseTask, GcsFileLoadTask, GssTableIngestionTask)
from dags.frameworks.dynamic.utils.classes.attributes import Attribute
from dags.frameworks.dynamic.utils.classes.categories import Category
from dags.frameworks.dynamic.utils.classes.dag_configs import DagConfig
from dags.frameworks.dynamic.utils.classes.dag_modeling_steps import (DagModelingStep, StepOverride)
from dags.frameworks.dynamic.utils.classes.task_config import TaskConfig
from dags.frameworks.dynamic.utils.classes.transformations import Transform
from dags.frameworks.dynamic.utils.classes.data_types import DataType
from dags.frameworks.dynamic.utils.classes.parameters import Parameter
from dags.frameworks.dynamic.utils.classes.file_load_strategy import FileLoadStrategy

dag = DagConfig()
config = TaskConfig()
attribute = Attribute()
transform = Transform()
dataType = DataType()
modelingStep = DagModelingStep()
override = StepOverride()
category = Category()
gcsTasks = GcsFileLoadTask()
gssTasks = GssTask()
gssTableIngestionTasks = GssTableIngestionTask()
aaTasks = AaTask()
baseTasks = BaseTask()
param = Parameter()
fileloadstrategy = FileLoadStrategy()

# noinspection PyInterpreter
configuration = {
    dag.title: {
        dag.ScheduleInterval: " 0 22 * * TUE",
        dag.DagName: "ecomm_gss_nar_meijer_ingestion",
        dag.CustomerName: "meijer",
        dag.FeedName: "meijer",
        dag.TagsStringArray: ["ecomm", "gss", "nar", "meijer"],
        dag.IsPublicFlag: False
    },
    dag.ModelingSteps: [
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: baseTasks.SourceTableDataExtractConfigInsert,
                        override.SprocParams: [
                            {
                                SourceTableDataExtractConfigInsert.SourceDataset.value: "processed",
                                SourceTableDataExtractConfigInsert.SourceTable.value: "meijer_weekly_agg_fact",
                                SourceTableDataExtractConfigInsert.ColumnName.value: "fiscal_week_begin_dt"
                            }
                        ]
                    }
                ]
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: baseTasks.NielsenDeltaTempNar,
                        override.SprocParams: [
                            {
                                NielsenDeltaTempNar.RecordKey.value: "594518442618705303"
                            }
                        ]
                    }
                ]
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: baseTasks.DataQualityChecksRun,
                        override.SprocParams: [
                            {
                                DataQualityChecksRun.RecordKey.value: "8510532543682435761"
                            }
                        ]
                    }
                ]
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.GssTableIngestion,
                modelingStep.Overrides: [
                    {
                        override.Task: gssTableIngestionTasks.SrcToEcommCatalogUpcMappingTable,
                        override.SprocParams: [{
                            SrcToEcommCatalogUpcMappingTable.UpcColumnName.value: "upc_cd",
                            SrcToEcommCatalogUpcMappingTable.ProductTitleColumnName.value: "source_item_name"
                        }]
                    },
                    {
                        override.Task: gssTableIngestionTasks.CustomerProcessedZero,
                        override.SprocParams: [{}]
                    },
                    {
                        override.Task: gssTableIngestionTasks.GssNarCustomerFact,
                        override.SprocParams: [{
                            GssNarCustomerFact.UpcColumnName.value: "upc_cd",
                            GssNarCustomerFact.ProductTitleColumnName.value: "source_item_name"
                        }]
                    },
                    {
                        override.Task: baseTasks.DataQualityChecksRun,
                        override.SprocParams: [{
                            DataQualityChecksRun.RecordKey.value: "1180654431878133354"
                        }]
                    },
                    
                    {
                        override.Task: gssTableIngestionTasks.CustomerWeeklyAggFact,
                        override.SprocParams: [{}]
                    },
                    {
                        override.Task: gssTableIngestionTasks.EcomDataReleaseControlInsert,
                        override.SprocParams: [{}]
                    },
                    {
                        override.Task: gssTableIngestionTasks.DataExtractConfigUpdate,
                        override.SprocParams: [
                            {
                                DataExtractConfigUpdate.SourceTable.value: "meijer_weekly_agg_fact"
                            }
                        ]
                    }
                ]
            }
        },
    ]
}
