from dags.frameworks.dynamic.utils.available_base_task_params import *
from dags.frameworks.dynamic.utils.available_tasks import (GssTask, AaTask, BaseTask, GcsFileLoadTask, GssTableIngestionTask)
from dags.frameworks.dynamic.utils.classes.attributes import Attribute
from dags.frameworks.dynamic.utils.classes.categories import Category
from dags.frameworks.dynamic.utils.classes.dag_configs import DagConfig
from dags.frameworks.dynamic.utils.classes.dag_modeling_steps import (DagModelingStep, StepOverride)
from dags.frameworks.dynamic.utils.classes.task_config import TaskConfig
from dags.frameworks.dynamic.utils.classes.transformations import Transform
from dags.frameworks.dynamic.utils.classes.data_types import DataType
from dags.frameworks.dynamic.utils.classes.parameters import Parameter
from dags.frameworks.dynamic.utils.classes.file_load_strategy import FileLoadStrategy

dag = DagConfig()
config = TaskConfig()
attribute = Attribute()
transform = Transform()
dataType = DataType()
modelingStep = DagModelingStep()
override = StepOverride()
category = Category()
gcsTasks = GcsFileLoadTask()
gssTasks = GssTask()
gssTableIngestionTasks = GssTableIngestionTask()
aaTasks = AaTask()
baseTasks = BaseTask()
param = Parameter()
fileloadstrategy = FileLoadStrategy()

# noinspection PyInterpreter
configuration = {
    dag.title: {
        dag.ScheduleInterval: "0 10 * * WED",
        dag.DagName: "ecomm_gss_nar_hub_copy_table",
        dag.CustomerName: "nar_hub_hierarchy",
        dag.FeedName: "nar_hub_hierarchy",
        dag.TagsStringArray: ["ecomm", "gss", "nar", "nar_hub_hierarchy"],
        dag.IsPublicFlag: False
    },
    dag.ModelingSteps: [
        {
            modelingStep.Step: {
                modelingStep.Category: category.UserDefined,
                config.TaskName: "copy_nar_hub_table",
                config.TaskDescription: "copy_nar_hub_table",
                config.BigQueryOperator: "BigQueryExecuteQueryOperator",
                config.BigQueryConnId: "bigquery_ecomm_dlf_data",
                config.DestinationProjectVariable: "ecomm-dlf-data",
                config.SqlOrScriptPath: "ecomm_sproc_nar_hub_hierarchy_copy_table",
                config.IsStoredProcFlag: True,
                "properties": {
                    config.SprocParams: [
                        {
                            attribute.Name: param.SourceProject,
                            attribute.Value: "ecomm-dlf-data",
                            attribute.IsInferredFlag: True,
                            attribute.DataTransformationType: transform.UseAsIs,
                            attribute.DataType: dataType.String
                        },
                        {
                            attribute.Name: param.DestinationDataset,
                            attribute.Value: "transient",
                            attribute.IsInferredFlag: True,
                            attribute.DataTransformationType: transform.UseAsIs,
                            attribute.DataType: dataType.String
                        },
                        {
                            attribute.Name: param.DestinationTable,
                            attribute.Value: "narhub_product_hierarchy_raw_levels ",
                            attribute.IsInferredFlag: True,
                            attribute.DataTransformationType: transform.UseAsIs,
                            attribute.DataType: dataType.String
                        },
                        {
                            attribute.Name: param.IntermediateProject,
                            attribute.Value: "ecomm-edw",
                            attribute.IsInferredFlag: True,
                            attribute.DataTransformationType: transform.UseAsIs,
                            attribute.DataType: dataType.String
                        },
                        {
                            attribute.Name: param.IntermediateDataset,
                            attribute.Value: "syndicated_nielsen",
                            attribute.IsInferredFlag: True,
                            attribute.DataTransformationType: transform.UseAsIs,
                            attribute.DataType: dataType.String
                        },
                        {
                            attribute.Name: param.SourceCustomerName,
                            attribute.Value: "nar_hub_hierarchy",
                            attribute.IsInferredFlag: True,
                            attribute.DataTransformationType: transform.UseAsIs,
                            attribute.DataType: dataType.String
                        },
                        {
                            attribute.Name: param.SourceFeedName,
                            attribute.Value: "nar_hub_hierarchy",
                            attribute.IsInferredFlag: True,
                            attribute.DataTransformationType: transform.UseAsIs,
                            attribute.DataType: dataType.String
                        }
                    ]
                }
            }
        },
    ]
}