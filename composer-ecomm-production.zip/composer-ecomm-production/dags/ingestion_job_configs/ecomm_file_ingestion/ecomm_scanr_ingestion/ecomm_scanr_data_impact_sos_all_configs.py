from dags.frameworks.dynamic.utils.available_base_task_params import *
from dags.frameworks.dynamic.utils.available_tasks import (GssTask, AaTask, BaseTask, GcsFileLoadTask, EuauTask)
from dags.frameworks.dynamic.utils.classes.attributes import Attribute
from dags.frameworks.dynamic.utils.classes.categories import Category
from dags.frameworks.dynamic.utils.classes.dag_configs import DagConfig
from dags.frameworks.dynamic.utils.classes.dag_modeling_steps import (DagModelingStep, StepOverride)
from dags.frameworks.dynamic.utils.classes.task_config import TaskConfig
from dags.frameworks.dynamic.utils.classes.transformations import Transform
from dags.frameworks.dynamic.utils.classes.data_types import DataType
from dags.frameworks.dynamic.utils.classes.parameters import Parameter
from dags.frameworks.dynamic.utils.classes.file_load_strategy import FileLoadStrategy



dag = DagConfig()
config = TaskConfig()
attribute = Attribute()
transform = Transform()
dataType = DataType()
modelingStep = DagModelingStep()
override = StepOverride()
category = Category()
euauTasks = EuauTask()
gcsTasks = GcsFileLoadTask()
gssTasks = GssTask()
aaTasks = AaTask()
baseTasks = BaseTask()
param = Parameter()
fileloadstrategy = FileLoadStrategy()

configuration = {
    dag.title: {
        dag.ScheduleInterval: "0 7 * * 2",
        dag.DagName: "ecomm_scanr_data_impact_sos_euau_all_data_ingestion",
        dag.CustomerName: "data_impact_sos_euau_all",
        dag.FeedName: "data_impact_sos_euau_all",
        dag.TagsStringArray: ["ecomm", "scanr","search","euau"],
        dag.IsPublicFlag: False
    },
    dag.ModelingSteps: [
        {
            modelingStep.Step: {
                modelingStep.Category: category.GcsFileLoad,
                modelingStep.Overrides: [
                    {
                        override.Task: gcsTasks.GcsFileSensor,
                        override.SprocParams: [
                            {
                                GcsFileSensor.DestinationProject.value: "ecomm-dlf-data",
                                GcsFileSensor.FilePath.value: "data_impact_euau_and_others_keyword_search_ranking/landing/",
                                GcsFileSensor.FileName.value: "data_impact_sos_euau_all"
                            }
                        ]
                    },
                    {
                        override.Task: gcsTasks.GcsFileLoadToBigquery,
                        override.SprocParams: [
                            {
                                GcsFileLoadToBigquery.DestinationProject.value: "ecomm-dlf-data",
                                GcsFileLoadToBigquery.DestinationDataset.value: "raw",
                                GcsFileLoadToBigquery.DestinationTable.value: "data_impact_sos_euau_all",
                                GcsFileLoadToBigquery.FilePath.value: "data_impact_euau_and_others_keyword_search_ranking/landing/",
                                GcsFileLoadToBigquery.FileName.value: "data_impact_sos_euau_all",
                                GcsFileLoadToBigquery.FileFieldDelimiter.value: ",",
                                GcsFileLoadToBigquery.FileSkipRows.value: "0",
                                GcsFileLoadToBigquery.FileEncodingType.value: "utf-8",
                                GcsFileLoadToBigquery.FileLoadStrategy.value: fileloadstrategy.Append
                            }
                        ]
                    }
                ]
            }
        },
                 {
                     modelingStep.Step: {
                         modelingStep.Category: category.Base,
                         modelingStep.Overrides: [
                             {
                                 override.Task: baseTasks.DataExtractConfigInsert,
                                 override.SprocParams: [
                                     {
                                         DataExtractConfigInsert.SourceTable.value: "data_impact_sos_euau_all"
                                     }
                                 ]
                             }
                         ]
                     }
                 },
                 {
                     modelingStep.Step: {
                         modelingStep.Category: category.UserDefined,
                         config.TaskName: "data_impact_sos_euau_all_delta_temp",
                         config.TaskDescription: "load_data_into_delta_temp",
                         config.BigQueryOperator: "BigQueryExecuteQueryOperator",
                         config.BigQueryConnId: "bigquery_ecomm_dlf_data",
                         config.DestinationProjectVariable: "ecomm-dlf-data",
                         config.SqlOrScriptPath: "ecomm_sproc_scnr_data_impact_sos_euau_all_delta_temp",
                         config.IsStoredProcFlag: True,
                         "properties": {
                             config.SprocParams: [
                                 {
                                     attribute.Name: param.SourceProject,
                                     attribute.Value: "ecomm-dlf-data",
                                     attribute.IsInferredFlag: True,
                                     attribute.DataTransformationType: transform.UseAsIs,
                                     attribute.DataType: dataType.String
                                 },
                                 {
                                     attribute.Name: param.SourceDataset,
                                     attribute.Value: "raw",
                                     attribute.IsInferredFlag: True,
                                     attribute.DataTransformationType: transform.UseAsIs,
                                     attribute.DataType: dataType.String
                                 },
                                 {
                                     attribute.Name: param.DestinationDataset,
                                     attribute.Value: "transient",
                                     attribute.IsInferredFlag: True,
                                     attribute.DataTransformationType: transform.UseAsIs,
                                     attribute.DataType: dataType.String
                                 },
                                 {
                                     attribute.Name: param.SourceTable,
                                     attribute.Value: "data_impact_sos_euau_all",
                                     attribute.IsInferredFlag: True,
                                     attribute.DataTransformationType: transform.UseAsIs,
                                     attribute.DataType: dataType.String
                                 },
                                 {
                                     attribute.Name: param.SourceFeedName,
                                     attribute.Value: "data_impact_sos_euau_all",
                                     attribute.IsInferredFlag: True,
                                     attribute.DataTransformationType: transform.UseAsIs,
                                     attribute.DataType: dataType.String
                                 }
                             ]
                         }
                     }
                 },
                 {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: baseTasks.DataQualityChecksRun,
                        override.SprocParams: [{
                            DataQualityChecksRun.RecordKey.value: "1332827544490745349,2557787934611768269,5504642350120442951,2313975050374993895,1480980981215298281,4057399563052995962"
                        }]
                    }
                ]
            }
        },
                 {
                     modelingStep.Step: {
                         modelingStep.Category: category.Base,
                         modelingStep.Overrides: [
                             {
                                 override.Task: baseTasks.CustomerProcessedZero,
                                 override.SprocParams: [{}]
                             }

                         ]
                     }
                 },
                          {
                              modelingStep.Step: {
                                  modelingStep.Category: category.UserDefined,
                                  config.TaskName: "data_impact_sos_euau_all_fact",
                                  config.TaskDescription: "load_data_into_fact",
                                  config.BigQueryOperator: "BigQueryExecuteQueryOperator",
                                  config.BigQueryConnId: "bigquery_ecomm_dlf_data",
                                  config.DestinationProjectVariable: "ecomm-dlf-data",
                                  config.SqlOrScriptPath: "ecomm_sproc_scnr_data_impact_sos_euau_all_fact",
                                  config.IsStoredProcFlag: True,
                                  "properties": {
                                      config.SprocParams: [
                                          {
                                              attribute.Name: param.SourceProject,
                                              attribute.Value: "ecomm-dlf-data",
                                              attribute.IsInferredFlag: True,
                                              attribute.DataTransformationType: transform.UseAsIs,
                                              attribute.DataType: dataType.String
                                          },
                                          {
                                              attribute.Name: param.SourceLookupProject,
                                              attribute.Value: "edw-prd-e567f9",
                                              attribute.IsInferredFlag: True,
                                              attribute.DataTransformationType: transform.UseAsIs,
                                              attribute.DataType: dataType.String
                                          },
                                          {
                                              attribute.Name: param.DestinationDataset,
                                              attribute.Value: "processed",
                                              attribute.IsInferredFlag: True,
                                              attribute.DataTransformationType: transform.UseAsIs,
                                              attribute.DataType: dataType.String
                                          },
                                          {
                                              attribute.Name: param.SourceLookupDataset,
                                              attribute.Value: "enterprise",
                                              attribute.IsInferredFlag: True,
                                              attribute.DataTransformationType: transform.UseAsIs,
                                              attribute.DataType: dataType.String
                                          },
                                          {
                                              attribute.Name: param.SourceTable,
                                              attribute.Value: "data_impact_sos_euau_all_processed_zero",
                                              attribute.IsInferredFlag: True,
                                              attribute.DataTransformationType: transform.UseAsIs,
                                              attribute.DataType: dataType.String
                                          },
                                          {
                                              attribute.Name: param.SourceFeedName,
                                              attribute.Value: "data_impact_sos_euau_all",
                                              attribute.IsInferredFlag: True,
                                              attribute.DataTransformationType: transform.UseAsIs,
                                              attribute.DataType: dataType.String
                                          }
                                      ]
                                  }
                              }
                          },
                          {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: baseTasks.DataQualityChecksRun,
                        override.SprocParams: [{
                            DataQualityChecksRun.RecordKey.value: "6061401902005360879"

                        }]
                    }
                ]
            }
        },
                          {
                              modelingStep.Step: {
                                  modelingStep.Category: category.Base,
                                  modelingStep.Overrides: [
                                      {
                                          override.Task: baseTasks.EcomDataReleaseControlInsert,
                                          override.SprocParams: [{
                                              EcomDataReleaseControlInsert.SourceTable.value: "data_impact_sos_euau_all_fact"
                                          }]
                                      },
                                      {
                                          override.Task: baseTasks.DataExtractConfigUpdate,
                                          override.SprocParams: [
                                              {
                                                  DataExtractConfigUpdate.SourceTable.value: "data_impact_sos_euau_all"
                                              }
                                          ]
                                      }
                                  ]
                              }
                                }
                        ]
    }