from dags.frameworks.dynamic.utils.available_base_task_params import *
from dags.frameworks.dynamic.utils.available_tasks import (GssTask, AaTask, BaseTask, GcsFileLoadTask, EuauTask)
from dags.frameworks.dynamic.utils.classes.attributes import Attribute
from dags.frameworks.dynamic.utils.classes.categories import Category
from dags.frameworks.dynamic.utils.classes.dag_configs import DagConfig
from dags.frameworks.dynamic.utils.classes.dag_modeling_steps import (DagModelingStep, StepOverride)
from dags.frameworks.dynamic.utils.classes.task_config import TaskConfig
from dags.frameworks.dynamic.utils.classes.transformations import Transform
from dags.frameworks.dynamic.utils.classes.data_types import DataType
from dags.frameworks.dynamic.utils.classes.parameters import Parameter
from dags.frameworks.dynamic.utils.classes.file_load_strategy import FileLoadStrategy
from dags.frameworks.dynamic.utils.classes.file_delimiters import FileDelimiter

dag = DagConfig()
config = TaskConfig()
attribute = Attribute()
transform = Transform()
dataType = DataType()
modelingStep = DagModelingStep()
override = StepOverride()
category = Category()
euauTasks = EuauTask()
gcsTasks = GcsFileLoadTask()
gssTasks = GssTask()
aaTasks = AaTask()
baseTasks = BaseTask()
param = Parameter()
fileloadstrategy = FileLoadStrategy()
filedelimiter = FileDelimiter()

configuration = {
    dag.title: {
        dag.ScheduleInterval: "None",
        dag.DagName: "ecomm_ana_instacart_publix_instore_data_ingestion",
        dag.CustomerName: "instacart_publix_instore",
        dag.FeedName: "instacart_publix_instore",
        dag.TagsStringArray: ["ecomm", "ana", "instacart", "publix" , "instore"],
        dag.IsPublicFlag: False
    },
    dag.ModelingSteps: [
        {
            modelingStep.Step: {
                modelingStep.Category: category.GcsFileLoad,
                modelingStep.Overrides: [
                    {
                        override.Task: gcsTasks.GcsFileSensor,
                        override.SprocParams: [
                            {
                                GcsFileSensor.DestinationProject.value: "ecomm-dlf-data",
                                GcsFileSensor.FilePath.value: "instacart_publix/landing/",
                                GcsFileSensor.FileName.value: "Publix_ACV"
                            }
                        ]
                    },
                    {
                        override.Task: gcsTasks.GcsFileLoadToBigquery,
                        override.SprocParams: [
                            {
                                GcsFileLoadToBigquery.DestinationProject.value: "ecomm-dlf-data",
                                GcsFileLoadToBigquery.DestinationDataset.value: "raw",
                                GcsFileLoadToBigquery.DestinationTable.value: "instacart_publix_instore",
                                GcsFileLoadToBigquery.FilePath.value: "instacart_publix/landing/",
                                GcsFileLoadToBigquery.FileName.value: "Publix_ACV",
                                GcsFileLoadToBigquery.FileFieldDelimiter.value: filedelimiter.Comma,
                                GcsFileLoadToBigquery.FileSkipRows.value: "0",
                                GcsFileLoadToBigquery.FileLoadStrategy.value: fileloadstrategy.Append
                            }
                        ]
                    }
                ]
            }
        }
    ]
}