from dags.frameworks.dynamic.utils.available_base_task_params import *
from dags.frameworks.dynamic.utils.available_tasks import (GssTask, AaTask, BaseTask, GcsFileLoadTask, EuauTask)
from dags.frameworks.dynamic.utils.classes.attributes import Attribute
from dags.frameworks.dynamic.utils.classes.categories import Category
from dags.frameworks.dynamic.utils.classes.dag_configs import DagConfig
from dags.frameworks.dynamic.utils.classes.dag_modeling_steps import (DagModelingStep, StepOverride)
from dags.frameworks.dynamic.utils.classes.task_config import TaskConfig
from dags.frameworks.dynamic.utils.classes.transformations import Transform
from dags.frameworks.dynamic.utils.classes.data_types import DataType
from dags.frameworks.dynamic.utils.classes.parameters import Parameter
from dags.frameworks.dynamic.utils.classes.file_load_strategy import FileLoadStrategy
from dags.frameworks.dynamic.utils.classes.file_delimiters import FileDelimiter

dag = DagConfig()
config = TaskConfig()
attribute = Attribute()
transform = Transform()
dataType = DataType()
modelingStep = DagModelingStep()
override = StepOverride()
category = Category()
euauTasks = EuauTask()
gcsTasks = GcsFileLoadTask()
gssTasks = GssTask()
aaTasks = AaTask()
baseTasks = BaseTask()
param = Parameter()
fileloadstrategy = FileLoadStrategy()
filedelimiter = FileDelimiter()

configuration = {
    dag.title: {
        dag.ScheduleInterval: "0 22 * * WED",
        dag.DagName: "ecomm_ana_profitero_amazon_com_data_ingestion",
        dag.CustomerName: "profitero_amazon_com_availability",
        dag.FeedName: "profitero_amazon_com_availability",
        dag.TagsStringArray: ["ecomm", "ana", "profitero", "availability", "amazon_com"],
        dag.IsPublicFlag: False
    },
    dag.ModelingSteps: [
        {
            modelingStep.Step: {
                modelingStep.Category: category.GcsFileLoad,
                modelingStep.Overrides: [
                    {
                        override.Task: gcsTasks.GcsFileSensor,
                        override.SprocParams: [
                            {
                                GcsFileSensor.DestinationProject.value: "ecomm-dlf-data",
                                GcsFileSensor.FilePath.value: "profitero_availability/landing/",
                                GcsFileSensor.FileName.value: "profitero_availability"
                            }
                        ]
                    },
                    {
                        override.Task: gcsTasks.GcsFileLoadToBigquery,
                        override.SprocParams: [
                            {
                                GcsFileLoadToBigquery.DestinationProject.value: "ecomm-dlf-data",
                                GcsFileLoadToBigquery.DestinationDataset.value: "raw",
                                GcsFileLoadToBigquery.DestinationTable.value: "profitero_availability",
                                GcsFileLoadToBigquery.FilePath.value: "profitero_availability/landing/",
                                GcsFileLoadToBigquery.FileName.value: "profitero_availability",
                                GcsFileLoadToBigquery.FileFieldDelimiter.value: filedelimiter.Caret,
                                GcsFileLoadToBigquery.FileSkipRows.value: "0",
                                GcsFileLoadToBigquery.FileLoadStrategy.value: fileloadstrategy.Append
                            }
                        ]
                    }
                ]
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: baseTasks.DataExtractConfigInsert,
                        override.SprocParams: [
                            {
                                DataExtractConfigInsert.SourceTable.value: "profitero_availability"
                            }
                        ]
                    }
                ]
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.UserDefined,
                config.TaskName: "profitero_amazon_com_availability_delta_temp",
                config.TaskDescription: "load_data_into_delta_temp",
                config.BigQueryOperator: "BigQueryExecuteQueryOperator",
                config.BigQueryConnId: "bigquery_ecomm_dlf_data",
                config.DestinationProjectVariable: "ecomm-dlf-data",
                config.SqlOrScriptPath: "ecomm_sproc_ana_profitero_availability_delta_temp",
                config.IsStoredProcFlag: True,
                "properties": {
                    config.SprocParams: [
                        {
                            attribute.Name: param.SourceProject,
                            attribute.Value: "ecomm-dlf-data",
                            attribute.IsInferredFlag: True,
                            attribute.DataTransformationType: transform.UseAsIs,
                            attribute.DataType: dataType.String
                        },
                        {
                            attribute.Name: param.SourceDataset,
                            attribute.Value: "raw",
                            attribute.IsInferredFlag: True,
                            attribute.DataTransformationType: transform.UseAsIs,
                            attribute.DataType: dataType.String
                        },
                        {
                            attribute.Name: param.SourceTable,
                            attribute.Value: "profitero_availability",
                            attribute.IsInferredFlag: True,
                            attribute.DataTransformationType: transform.UseAsIs,
                            attribute.DataType: dataType.String
                        },
                        {
                            attribute.Name: param.DestinationDataset,
                            attribute.Value: "transient",
                            attribute.IsInferredFlag: True,
                            attribute.DataTransformationType: transform.UseAsIs,
                            attribute.DataType: dataType.String
                        },
                        {
                            attribute.Name: param.IntermediateDataset,
                            attribute.Value: "processed",
                            attribute.IsInferredFlag: True,
                            attribute.DataTransformationType: transform.UseAsIs,
                            attribute.DataType: dataType.String
                        },
                        {
                            attribute.Name: param.DestinationTable,
                            attribute.Value: "profitero_availability_delta_temp",
                            attribute.IsInferredFlag: True,
                            attribute.DataTransformationType: transform.UseAsIs,
                            attribute.DataType: dataType.String
                        },
                        {
                            attribute.Name: param.SourceFeedName,
                            attribute.Value: "profitero_availability",
                            attribute.IsInferredFlag: True,
                            attribute.DataTransformationType: transform.UseAsIs,
                            attribute.DataType: dataType.String
                        }
                    ]
                }
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: baseTasks.DataExtractConfigUpdate,
                        override.SprocParams: [{
                            DataExtractConfigUpdate.SourceTable.value: "profitero_availability"
                        }]
                    }
                ]
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: baseTasks.CustomerProcessedZero,
                        override.SprocParams: [{
                            CustomerProcessedZero.SourceTable.value: "profitero_availability_delta_temp",
                            CustomerProcessedZero.DestinationTable.value: "profitero_availability_processed_zero",
                            CustomerProcessedZero.SourceFeedName.value: "PROFITERO_AVAILABILITY"
                        }]
                    }
                ]
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: baseTasks.SourceTableDataExtractConfigInsert,
                        override.SprocParams: [
                            {
                                SourceTableDataExtractConfigInsert.SourceDataset.value: "processed",
                                SourceTableDataExtractConfigInsert.SourceTable.value: "amazon_com_profitero_availability_processed_zero",
                                SourceTableDataExtractConfigInsert.ColumnName.value: "report_date"
                            }
                        ]
                    }
                ]
            }
        },
        {

            modelingStep.Step: {
                modelingStep.Category: category.UserDefined,
                config.TaskName: "profitero_amazon_com_distribution_delta_temp",
                config.TaskDescription: "load_data_into_delta_temp",
                config.BigQueryOperator: "BigQueryExecuteQueryOperator",
                config.BigQueryConnId: "bigquery_ecomm_dlf_data",
                config.DestinationProjectVariable: "ecomm-dlf-data",
                config.SqlOrScriptPath: "ecomm_sproc_ana_amazon_profitero_distribution_delta_temp",
                config.IsStoredProcFlag: True,
                "properties": {
                    config.SprocParams: [
                        {
                            attribute.Name: param.SourceProject,
                            attribute.Value: "ecomm-dlf-data",
                            attribute.IsInferredFlag: True,
                            attribute.DataTransformationType: transform.UseAsIs,
                            attribute.DataType: dataType.String
                        },
                        {
                            attribute.Name: param.SourceDataset,
                            attribute.Value: "transient",
                            attribute.IsInferredFlag: True,
                            attribute.DataTransformationType: transform.UseAsIs,
                            attribute.DataType: dataType.String
                        },
                        {
                            attribute.Name: param.DestinationDataset,
                            attribute.Value: "processed",
                            attribute.IsInferredFlag: True,
                            attribute.DataTransformationType: transform.UseAsIs,
                            attribute.DataType: dataType.String
                        },
                        {
                            attribute.Name: param.IntermediateProject,
                            attribute.Value: "ecomm-edw-prd",
                            attribute.IsInferredFlag: True,
                            attribute.DataTransformationType: transform.UseAsIs,
                            attribute.DataType: dataType.String
                        },
                        {
                            attribute.Name: param.IntermediateDataset,
                            attribute.Value: "enterprise",
                            attribute.IsInferredFlag: True,
                            attribute.DataTransformationType: transform.UseAsIs,
                            attribute.DataType: dataType.String
                        },
                        {
                            attribute.Name: param.SourceTable,
                            attribute.Value: "amazon_com_profitero_availability_processed_zero",
                            attribute.IsInferredFlag: True,
                            attribute.DataTransformationType: transform.UseAsIs,
                            attribute.DataType: dataType.String
                        },
                        {
                            attribute.Name: param.DestinationTable,
                            attribute.Value: "amazon_com_profitero_distribution_delta_temp",
                            attribute.IsInferredFlag: True,
                            attribute.DataTransformationType: transform.UseAsIs,
                            attribute.DataType: dataType.String
                        },
                        {
                            attribute.Name: param.SourceFeedName,
                            attribute.Value: "AMAZON_COM",
                            attribute.IsInferredFlag: True,
                            attribute.DataTransformationType: transform.UseAsIs,
                            attribute.DataType: dataType.String
                        }
                    ]
                }
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: baseTasks.DataExtractConfigUpdate,
                        override.SprocParams: [{
                            DataExtractConfigUpdate.SourceTable.value: "amazon_com_profitero_availability_processed_zero"
                        }]
                    }
                ]
            }
        },

        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: baseTasks.SrcToEcommCatalogUpcMappingTable,
                        override.SprocParams: [{
                            SrcToEcommCatalogUpcMappingTable.SourceTable.value: "amazon_com_profitero_distribution_delta_temp",
                            SrcToEcommCatalogUpcMappingTable.UpcColumnName.value: "upc",
                            SrcToEcommCatalogUpcMappingTable.RpcColumnName.value: "rpc_column_name",
                            SrcToEcommCatalogUpcMappingTable.ProductTitleColumnName.value: "product_title_column",
                            SrcToEcommCatalogUpcMappingTable.ColumnName.value: "customer_name"

                        }]
                    }
                ]
            }
        },

        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: baseTasks.CustomerProcessedZero,
                        override.SprocParams: [{
                            CustomerProcessedZero.SourceTable.value: "amazon_com_profitero_distribution_delta_temp",
                            CustomerProcessedZero.DestinationTable.value: "amazon_com_profitero_distribution_processed_zero",
                            CustomerProcessedZero.SourceFeedName.value: "AMAZON_COM_PROFITERO"
                        }]
                    }
                ]
            }
        },

        {
            modelingStep.Step: {
                modelingStep.Category: category.UserDefined,
                config.TaskName: "profitero_amazon_com_distribution_fact",
                config.TaskDescription: "load_data_into_fact",
                config.BigQueryOperator: "BigQueryExecuteQueryOperator",
                config.BigQueryConnId: "bigquery_ecomm_dlf_data",
                config.DestinationProjectVariable: "ecomm-dlf-data",
                config.SqlOrScriptPath: "ecomm_sproc_ana_common_distribution_fact",
                config.IsStoredProcFlag: True,
                "properties": {
                    config.SprocParams: [
                        {
                            attribute.Name: param.SourceProject,
                            attribute.Value: "ecomm-dlf-data",
                            attribute.IsInferredFlag: True,
                            attribute.DataTransformationType: transform.UseAsIs,
                            attribute.DataType: dataType.String
                        },
                        {
                            attribute.Name: param.SourceDataset,
                            attribute.Value: "transient",
                            attribute.IsInferredFlag: True,
                            attribute.DataTransformationType: transform.UseAsIs,
                            attribute.DataType: dataType.String
                        },
                        {
                            attribute.Name: param.DestinationDataset,
                            attribute.Value: "processed",
                            attribute.IsInferredFlag: True,
                            attribute.DataTransformationType: transform.UseAsIs,
                            attribute.DataType: dataType.String
                        },

                        {
                            attribute.Name: param.DestinationTable,
                            attribute.Value: "amazon_com_profitero_distribution_fact",
                            attribute.IsInferredFlag: True,
                            attribute.DataTransformationType: transform.UseAsIs,
                            attribute.DataType: dataType.String
                        },
                        {
                            attribute.Name: param.SourceTable,
                            attribute.Value: "amazon_com_profitero_distribution_processed_zero",
                            attribute.IsInferredFlag: True,
                            attribute.DataTransformationType: transform.UseAsIs,
                            attribute.DataType: dataType.String
                        },

                        {
                            attribute.Name: param.SourceFeedName,
                            attribute.Value: "feed_name",
                            attribute.IsInferredFlag: True,
                            attribute.DataTransformationType: transform.UseAsIs,
                            attribute.DataType: dataType.String
                        }
                    ]
                }
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.UserDefined,
                config.TaskName: "profitero_amazon_com_distribution_availability_with_upc",
                config.TaskDescription: "load_data_into_upc_fact",
                config.BigQueryOperator: "BigQueryExecuteQueryOperator",
                config.BigQueryConnId: "bigquery_ecomm_dlf_data",
                config.DestinationProjectVariable: "ecomm-dlf-data",
                config.SqlOrScriptPath: "ecomm_sproc_ana_pure_player_distribution_availability_with_upc",
                config.IsStoredProcFlag: True,
                "properties": {
                    config.SprocParams: [
                        {
                            attribute.Name: param.SourceProject,
                            attribute.Value: "ecomm-dlf-data",
                            attribute.IsInferredFlag: True,
                            attribute.DataTransformationType: transform.UseAsIs,
                            attribute.DataType: dataType.String
                        },
                        {
                            attribute.Name: param.DestinationDataset,
                            attribute.Value: "processed",
                            attribute.IsInferredFlag: True,
                            attribute.DataTransformationType: transform.UseAsIs,
                            attribute.DataType: dataType.String
                        },
                        {
                            attribute.Name: param.SourceTable,
                            attribute.Value: "amazon_com_profitero_distribution_fact",
                            attribute.IsInferredFlag: True,
                            attribute.DataTransformationType: transform.UseAsIs,
                            attribute.DataType: dataType.String
                        },
                        {
                            attribute.Name: param.DestinationTable,
                            attribute.Value: "amazon_com_distribution_availability_with_upc_fact",
                            attribute.IsInferredFlag: True,
                            attribute.DataTransformationType: transform.UseAsIs,
                            attribute.DataType: dataType.String
                        },
                        {
                            attribute.Name: param.SourceFeedName,
                            attribute.Value: "feed_name",
                            attribute.IsInferredFlag: True,
                            attribute.DataTransformationType: transform.UseAsIs,
                            attribute.DataType: dataType.String
                        }
                    ]
                }
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.UserDefined,
                config.TaskName: "profitero_amazon_com_distribution_subcatg_agg",
                config.TaskDescription: "load_data_into_subcatg_agg",
                config.BigQueryOperator: "BigQueryExecuteQueryOperator",
                config.BigQueryConnId: "bigquery_ecomm_dlf_data",
                config.DestinationProjectVariable: "ecomm-dlf-data",
                config.SqlOrScriptPath: "ecomm_sproc_ana_pure_player_distribution_availability_subcatg_aggregated",
                config.IsStoredProcFlag: True,
                "properties": {
                    config.SprocParams: [
                        {
                            attribute.Name: param.SourceProject,
                            attribute.Value: "ecomm-dlf-data",
                            attribute.IsInferredFlag: True,
                            attribute.DataTransformationType: transform.UseAsIs,
                            attribute.DataType: dataType.String
                        },
                        {
                            attribute.Name: param.DestinationDataset,
                            attribute.Value: "processed",
                            attribute.IsInferredFlag: True,
                            attribute.DataTransformationType: transform.UseAsIs,
                            attribute.DataType: dataType.String
                        },
                        {
                            attribute.Name: param.SourceTable,
                            attribute.Value: "amazon_com_distribution_availability_with_upc_fact",
                            attribute.IsInferredFlag: True,
                            attribute.DataTransformationType: transform.UseAsIs,
                            attribute.DataType: dataType.String
                        },
                        {
                            attribute.Name: param.IntermediateProject,
                            attribute.Value: "edw-prd-e567f9",
                            attribute.IsInferredFlag: True,
                            attribute.DataTransformationType: transform.UseAsIs,
                            attribute.DataType: dataType.String
                        },
                        {
                            attribute.Name: param.IntermediateDataset,
                            attribute.Value: "enterprise",
                            attribute.IsInferredFlag: True,
                            attribute.DataTransformationType: transform.UseAsIs,
                            attribute.DataType: dataType.String
                        },
                        {
                            attribute.Name: param.DestinationTable,
                            attribute.Value: "amazon_com_distribution_availability_subcatg_agg_fact",
                            attribute.IsInferredFlag: True,
                            attribute.DataTransformationType: transform.UseAsIs,
                            attribute.DataType: dataType.String
                        },
                        {
                            attribute.Name: param.SourceFeedName,
                            attribute.Value: "feed_name",
                            attribute.IsInferredFlag: True,
                            attribute.DataTransformationType: transform.UseAsIs,
                            attribute.DataType: dataType.String
                        }
                    ]
                }
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: baseTasks.EcomDataReleaseControlInsert,
                        override.SprocParams: [{
                            EcomDataReleaseControlInsert.SourceTable.value: "amazon_com_distribution_availability_subcatg_agg_fact",
                            EcomDataReleaseControlInsert.SourceCustomerName.value: "AMAZON_COM_DISTRIBUTION_AVAILABILITY",
                            EcomDataReleaseControlInsert.SourceFeedName.value: "AMAZON_COM_DISTRIBUTION_AVAILABILITY_SUBCATG_AGG_FACT"
                        }]
                    }
                ]
            }
        }
    ]
}
