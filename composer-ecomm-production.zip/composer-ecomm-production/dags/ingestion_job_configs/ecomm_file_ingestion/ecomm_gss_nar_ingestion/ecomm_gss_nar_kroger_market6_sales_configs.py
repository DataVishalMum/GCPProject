from dags.frameworks.dynamic.utils.available_base_task_params import *
from dags.frameworks.dynamic.utils.available_tasks import (GssTask, AaTask, BaseTask, GcsFileLoadTask)
from dags.frameworks.dynamic.utils.classes.attributes import Attribute
from dags.frameworks.dynamic.utils.classes.categories import Category
from dags.frameworks.dynamic.utils.classes.dag_configs import DagConfig
from dags.frameworks.dynamic.utils.classes.dag_modeling_steps import (DagModelingStep, StepOverride)
from dags.frameworks.dynamic.utils.classes.task_config import TaskConfig
from dags.frameworks.dynamic.utils.classes.transformations import Transform
from dags.frameworks.dynamic.utils.classes.data_types import DataType
from dags.frameworks.dynamic.utils.classes.parameters import Parameter
from dags.frameworks.dynamic.utils.classes.file_load_strategy import FileLoadStrategy

dag = DagConfig()
config = TaskConfig()
attribute = Attribute()
transform = Transform()
dataType = DataType()
modelingStep = DagModelingStep()
override = StepOverride()
category = Category()
gcsTasks = GcsFileLoadTask()
gssTasks = GssTask()
aaTasks = AaTask()
baseTasks = BaseTask()
param = Parameter()
fileloadstrategy = FileLoadStrategy()


configuration = {
    dag.title: {
        dag.ScheduleInterval: "0 22 * * TUE",
        dag.DagName: "ecomm_gss_nar_kroger_market6_sales_ingestion",
        dag.CustomerName: "kroger",
        dag.FeedName: "kroger",
        dag.TagsStringArray: ["ecomm", "gss", "nar", "kroger_market6_sales"],
        dag.IsPublicFlag: False
    },
    dag.ModelingSteps: [
        {
            modelingStep.Step: {
                modelingStep.Category: category.GcsFileLoad,
                modelingStep.Overrides: [
                    {
                        override.Task: gcsTasks.GcsFileSensor,
                        override.SprocParams: [
                            {
                                GcsFileSensor.DestinationProject.value: "ecomm-dlf-data",
                                GcsFileSensor.FilePath.value: "kroger_mkt6_sales/landing/",
                                GcsFileSensor.FileName.value: "kroger_market6_sales"
                            }
                        ]
                    },
                    {
                        override.Task: gcsTasks.GcsFileLoadToBigquery,
                        override.SprocParams: [
                            {
                                GcsFileLoadToBigquery.DestinationProject.value: "ecomm-dlf-data",
                                GcsFileLoadToBigquery.DestinationDataset.value: "raw",
                                GcsFileLoadToBigquery.DestinationTable.value: "kroger_market6_sales",
                                GcsFileLoadToBigquery.FilePath.value: "kroger_mkt6_sales/landing/",
                                GcsFileLoadToBigquery.FileName.value: "kroger_market6_sales",
                                GcsFileLoadToBigquery.FileFieldDelimiter.value: ",",
                                GcsFileLoadToBigquery.FileSkipRows.value: "0",
                                GcsFileLoadToBigquery.FileEncodingType.value: "utf-8",
                                GcsFileLoadToBigquery.FileLoadStrategy.value: fileloadstrategy.Append
                            }
                        ]
                    }
                ]
            }
        },
    

        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: baseTasks.DataExtractConfigInsert,
                        override.SprocParams: [
                            {
                                DataExtractConfigInsert.SourceTable.value: "kroger_market6_sales"
                            }
                        ]
                    }
                ]
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.UserDefined,
                config.TaskName: "kroger_market6_sales_delta_temp",
                config.TaskDescription: "load_data_into_delta_temp",
                config.BigQueryOperator: "BigQueryExecuteQueryOperator",
                config.BigQueryConnId: "bigquery_ecomm_dlf_data",
                config.DestinationProjectVariable: "ecomm-dlf-data",
                config.SqlOrScriptPath: "ecomm_sproc_gss_nar_kroger_market6_sales_delta_temp",
                config.IsStoredProcFlag: True,
                "properties": {
                    config.SprocParams: [
                        {
                            attribute.Name: param.SourceProject,
                            attribute.Value: "ecomm-dlf-data",
                            attribute.IsInferredFlag: True,
                            attribute.DataTransformationType: transform.UseAsIs,
                            attribute.DataType: dataType.String
                        },
                        {
                            attribute.Name: param.SourceDataset,
                            attribute.Value: "raw",
                            attribute.IsInferredFlag: True,
                            attribute.DataTransformationType: transform.UseAsIs,
                            attribute.DataType: dataType.String
                        },
                        {
                            attribute.Name: param.SourceTable,
                            attribute.Value: "kroger_market6_sales",
                            attribute.IsInferredFlag: True,
                            attribute.DataTransformationType: transform.UseAsIs,
                            attribute.DataType: dataType.String
                        },
						{
                            attribute.Name: param.IntermediateDataset,
                            attribute.Value: "processed",
                            attribute.IsInferredFlag: True,
                            attribute.DataTransformationType: transform.UseAsIs,
                            attribute.DataType: dataType.String
                        },
						{
                            attribute.Name: param.IntermediateTable,
                            attribute.Value: "lkp_kroger_fiscal_calendar",
                            attribute.IsInferredFlag: True,
                            attribute.DataTransformationType: transform.UseAsIs,
                            attribute.DataType: dataType.String
                        },
						
                        {
                            attribute.Name: param.DestinationDataset,
                            attribute.Value: "transient",
                            attribute.IsInferredFlag: True,
                            attribute.DataTransformationType: transform.UseAsIs,
                            attribute.DataType: dataType.String
                        },
                        {
                            attribute.Name: param.DestinationTable,
                            attribute.Value: "kroger_market6_sales_delta_temp",
                            attribute.IsInferredFlag: True,
                            attribute.DataTransformationType: transform.UseAsIs,
                            attribute.DataType: dataType.String
                        },
                        {
                            attribute.Name: param.SourceCustomerName,
                            attribute.Value: "customer_name",
                            attribute.IsInferredFlag: True,
                            attribute.DataTransformationType: transform.UseAsIs,
                            attribute.DataType: dataType.String
                        },
                        {
                            attribute.Name: param.SourceFeedName,
                            attribute.Value: "feed_name",
                            attribute.IsInferredFlag: True,
                            attribute.DataTransformationType: transform.UseAsIs,
                            attribute.DataType: dataType.String
                        }
                    ]
                }
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.Gss,
                modelingStep.Overrides: [
                    {
                        override.Task: gssTasks.SrcToEcommCatalogUpcMappingTable,
                        override.SprocParams: [{
                            SrcToEcommCatalogUpcMappingTable.UpcColumnName.value: "upc",
                            SrcToEcommCatalogUpcMappingTable.ProductTitleColumnName.value: "source_item_name",
			    SrcToEcommCatalogUpcMappingTable.SourceTable.value: "kroger_market6_sales_delta_temp"
                        }]
                    },
                    {
                        override.Task: gssTasks.CustomerProcessedZero,
                        override.SprocParams: [{
			    CustomerProcessedZero.SourceTable.value: "kroger_market6_sales_delta_temp",
		            CustomerProcessedZero.DestinationTable.value: "kroger_market6_sales_processed_zero",
			}]
                    },
                    {
                        override.Task: gssTasks.GssNarCustomerFact,
                        override.SprocParams: [{
                            GssNarCustomerFact.UpcColumnName.value: "upc",
                            GssNarCustomerFact.ProductTitleColumnName.value: "source_item_name",
			    GssNarCustomerFact.DestinationTable.value: "kroger_market6_sales_fact",
			    GssNarCustomerFact.SourceTable.value: "kroger_market6_sales_processed_zero"
                        }]
                    },
                    {
                        override.Task: gssTasks.CustomerWeeklyAggFact,
                        override.SprocParams: [{
			    CustomerWeeklyAggFact.SourceCustomerName.value: "kroger",
			    CustomerWeeklyAggFact.DestinationTable.value: "kroger_market6_sales_weekly_agg_fact",
			    CustomerWeeklyAggFact.SourceTable.value: "kroger_market6_sales_fact"
			}]
                    },
                    {
                        override.Task: gssTasks.EcomDataReleaseControlInsert,
                        override.SprocParams: [{
			EcomDataReleaseControlInsert.SourceTable.value: "kroger_market6_sales_weekly_agg_fact"
			}]
                    },
                    {
                        override.Task: gssTasks.DataExtractConfigUpdate,
                        override.SprocParams: [
                            {
                                DataExtractConfigUpdate.SourceTable.value: "kroger_market6_sales"
                            }
                        ]
                    }
                ]
            }
        }
    ]
}
