from dags.frameworks.dynamic.utils.available_base_task_params import *
from dags.frameworks.dynamic.utils.available_tasks import (GssTask, AaTask, BaseTask, GcsFileLoadTask)
from dags.frameworks.dynamic.utils.classes.attributes import Attribute
from dags.frameworks.dynamic.utils.classes.categories import Category
from dags.frameworks.dynamic.utils.classes.dag_configs import DagConfig
from dags.frameworks.dynamic.utils.classes.dag_modeling_steps import (DagModelingStep, StepOverride)
from dags.frameworks.dynamic.utils.classes.task_config import TaskConfig
from dags.frameworks.dynamic.utils.classes.transformations import Transform
from dags.frameworks.dynamic.utils.classes.data_types import DataType
from dags.frameworks.dynamic.utils.classes.parameters import Parameter
from dags.frameworks.dynamic.utils.classes.file_load_strategy import FileLoadStrategy

dag = DagConfig()
config = TaskConfig()
attribute = Attribute()
transform = Transform()
dataType = DataType()
modelingStep = DagModelingStep()
override = StepOverride()
category = Category()
gcsTasks = GcsFileLoadTask()
gssTasks = GssTask()
aaTasks = AaTask()
baseTasks = BaseTask()
param = Parameter()
fileloadstrategy = FileLoadStrategy()

configuration = {
    dag.title: {
        dag.ScheduleInterval: "0 21 * * TUE",
        dag.DagName: "ecomm_loblaws_data_ingestion",
        dag.CustomerName: "loblaws",
        dag.FeedName: "loblaws",
        dag.TagsStringArray: ["ecomm", "gss", "ca", "loblaws"],
        dag.IsPublicFlag: False
    },
    dag.ModelingSteps: [
        {
            modelingStep.Step: {
                modelingStep.Category: category.GcsFileLoad,
                modelingStep.Overrides: [
                    {
                        override.Task: gcsTasks.GcsFileSensor,
                        override.SprocParams: [
                            {
                                GcsFileSensor.DestinationProject.value: "ecomm-dlf-data",
                                GcsFileSensor.FilePath.value: "loblaws/landing/",
                                GcsFileSensor.FileName.value: "loblaws_sales"
                            }
                        ]
                    },
                    {
                        override.Task: gcsTasks.GcsFileLoadToBigquery,
                        override.SprocParams: [
                            {
                                GcsFileLoadToBigquery.DestinationProject.value: "ecomm-dlf-data",
                                GcsFileLoadToBigquery.DestinationDataset.value: "raw",
                                GcsFileLoadToBigquery.DestinationTable.value: "loblaws_sales",
                                GcsFileLoadToBigquery.FilePath.value: "loblaws/landing/",
                                GcsFileLoadToBigquery.FileName.value: "loblaws_sales",
                                GcsFileLoadToBigquery.FileSkipRows.value: "0",
                                GcsFileLoadToBigquery.FileLoadStrategy.value: fileloadstrategy.Append
                            }
                        ]
                    }
                ]
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: baseTasks.DataExtractConfigInsert,
                        override.SprocParams: [
                            {
                                DataExtractConfigInsert.SourceTable.value: "loblaws_sales"
                            }
                        ]
                    }
                ]
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.UserDefined,
                config.TaskName: "loblaws_delta_temp",
                config.TaskDescription: "load_data_into_delta_temp",
                config.BigQueryOperator: "BigQueryExecuteQueryOperator",
                config.BigQueryConnId: "bigquery_ecomm_dlf_data",
                config.DestinationProjectVariable: "ecomm-dlf-data",
                config.SqlOrScriptPath: "ecomm_sproc_loblaws_delta_temp",
                config.IsStoredProcFlag: True,
                "properties": {
                    config.SprocParams: [
                        {
                            attribute.Name: param.SourceProject,
                            attribute.Value: "ecomm-dlf-data",
                            attribute.IsInferredFlag: True,
                            attribute.DataTransformationType: transform.UseAsIs,
                            attribute.DataType: dataType.String
                        },
                        {
                            attribute.Name: param.SourceDataset,
                            attribute.Value: "raw",
                            attribute.IsInferredFlag: True,
                            attribute.DataTransformationType: transform.UseAsIs,
                            attribute.DataType: dataType.String
                        },
                        {
                            attribute.Name: param.DestinationDataset,
                            attribute.Value: "transient",
                            attribute.IsInferredFlag: True,
                            attribute.DataTransformationType: transform.UseAsIs,
                            attribute.DataType: dataType.String
                        },
                        {
                            attribute.Name: param.SourceTable,
                            attribute.Value: "loblaws_sales",
                            attribute.IsInferredFlag: True,
                            attribute.DataTransformationType: transform.UseAsIs,
                            attribute.DataType: dataType.String
                        },
                        {
                            attribute.Name: param.SourceLookupDataset,
                            attribute.Value: "processed",
                            attribute.IsInferredFlag: True,
                            attribute.DataTransformationType: transform.UseAsIs,
                            attribute.DataType: dataType.String
                        },
                        {
                            attribute.Name: param.SourceLookupTable,
                            attribute.Value: "lkp_loblaws_fiscal_calendar",
                            attribute.IsInferredFlag: True,
                            attribute.DataTransformationType: transform.UseAsIs,
                            attribute.DataType: dataType.String
                        },
                        {
                            attribute.Name: param.DestinationTable,
                            attribute.Value: "loblaws_delta_temp",
                            attribute.IsInferredFlag: True,
                            attribute.DataTransformationType: transform.UseAsIs,
                            attribute.DataType: dataType.String
                        },
                        {
                            attribute.Name: param.SourceCustomerName,
                            attribute.Value: "customer_name",
                            attribute.IsInferredFlag: True,
                            attribute.DataTransformationType: transform.UseAsIs,
                            attribute.DataType: dataType.String
                        },
                        {
                            attribute.Name: param.SourceFeedName,
                            attribute.Value: "feed_name",
                            attribute.IsInferredFlag: True,
                            attribute.DataTransformationType: transform.UseAsIs,
                            attribute.DataType: dataType.String
                        }
                    ]
                }
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.Gss,
                modelingStep.Overrides: [
                    {
                        override.Task: gssTasks.DimSourceToEnterpriseUpcXref,
                        override.SprocParams: [{}]
                    },
                    {
                        override.Task: gssTasks.CustomerProcessedZero,
                        override.SprocParams: [{}]
                    },
                    {
                        override.Task: gssTasks.ProductNarTemp,
                        override.SprocParams: [{}]
                    },
                    {
                        override.Task: gssTasks.NielsenProductNarTemp,
                        override.SprocParams: [{}]
                    },
                    {
                        override.Task: gssTasks.ConsolidateProductNarTemp,
                        override.SprocParams: [{}]
                    },
                    {
                        override.Task: gssTasks.XrefGlobalBrand,
                        override.SprocParams: [{}]
                    },
                    {
                        override.Task: gssTasks.XrefGlobalCategory,
                        override.SprocParams: [{}]
                    },
                    {
                        override.Task: gssTasks.XrefOverride,
                        override.SprocParams: [{}]
                    },
                    {
                        override.Task: gssTasks.ConsolidateXrefTemp,
                        override.SprocParams: [{}]
                    },
                    {
                        override.Task: gssTasks.DerivedXrefInfoTemp,
                        override.SprocParams: [{}]
                    },
                    {
                        override.Task: gssTasks.CustomerFactNar,
                        override.SprocParams: [{}]
                    },
                    {
                        override.Task: gssTasks.CustomerWeeklyAggFact,
                        override.SprocParams: [{}]
                    },
                    {
                        override.Task: gssTasks.EcomDataReleaseControlInsert,
                        override.SprocParams: [{}]
                    },
                    {
                        override.Task: gssTasks.DataExtractConfigUpdate,
                        override.SprocParams: [
                            {
                                DataExtractConfigUpdate.SourceTable.value: "loblaws_sales"
                            }
                        ]
                    }
                ]
            }
        }
    ]
}
