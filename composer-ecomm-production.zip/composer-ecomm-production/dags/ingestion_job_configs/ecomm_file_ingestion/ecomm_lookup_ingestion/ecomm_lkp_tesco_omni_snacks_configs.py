from dags.frameworks.dynamic.utils.available_base_task_params import *
from dags.frameworks.dynamic.utils.available_tasks import (GssTask, AaTask, BaseTask, GcsFileLoadTask)
from dags.frameworks.dynamic.utils.classes.attributes import Attribute
from dags.frameworks.dynamic.utils.classes.categories import Category
from dags.frameworks.dynamic.utils.classes.dag_configs import DagConfig
from dags.frameworks.dynamic.utils.classes.dag_modeling_steps import (DagModelingStep, StepOverride)
from dags.frameworks.dynamic.utils.classes.task_config import TaskConfig
from dags.frameworks.dynamic.utils.classes.transformations import Transform
from dags.frameworks.dynamic.utils.classes.data_types import DataType
from dags.frameworks.dynamic.utils.classes.parameters import Parameter
from dags.frameworks.dynamic.utils.classes.file_load_strategy import FileLoadStrategy

dag = DagConfig()
config = TaskConfig()
attribute = Attribute()
transform = Transform()
dataType = DataType()
modelingStep = DagModelingStep()
override = StepOverride()
category = Category()
gcsTasks = GcsFileLoadTask()
gssTasks = GssTask()
aaTasks = AaTask()
baseTasks = BaseTask()
param = Parameter()
fileloadstrategy = FileLoadStrategy()

configuration = {
    dag.title: {
        dag.ScheduleInterval: "0 10 * * TUE",
        dag.DagName: "ecomm_lkp_tesco_omni_snacks_ingestion",
        dag.CustomerName: "lkp_tesco_omni_snacks",
        dag.FeedName: "lkp_tesco_omni_snacks",
        dag.TagsStringArray: ["ecomm", "gss", "euau", "lkp"],
        dag.IsPublicFlag: True
    },
    dag.ModelingSteps: [
        {
            modelingStep.Step: {
                modelingStep.Category: category.GcsFileLoad,
                modelingStep.Overrides: [
                    {
                        override.Task: gcsTasks.GcsFileSensor,
                        override.SprocParams: [
                            {

                                GcsFileSensor.FilePath.value: "tesco/landing/",
                                GcsFileSensor.DestinationProject.value: "ecomm-dlf-data",
                                GcsFileSensor.FileName.value: "lkp_tpn_ean_tesco_omni_snacks"
                            }
                        ]
                    },
                    {
                        override.Task: gcsTasks.GcsFileLoadToBigquery,
                        override.SprocParams: [
                            {
                                GcsFileLoadToBigquery.DestinationDataset.value: "processed",
                                GcsFileLoadToBigquery.DestinationProject.value: "ecomm-dlf-data",
                                GcsFileLoadToBigquery.DestinationTable.value: "lkp_tpn_ean_tesco_omni_snacks",
                                GcsFileLoadToBigquery.FilePath.value: "tesco/landing/",
                                GcsFileLoadToBigquery.FileName.value: "lkp_tpn_ean_tesco_omni_snacks",
                                GcsFileLoadToBigquery.FileSkipRows.value: "0",
                                GcsFileLoadToBigquery.FileLoadStrategy.value: fileloadstrategy.Overwrite
                            }
                        ]
                    }
                ]
            }
        }
    ]
}
