from dags.frameworks.dynamic.utils.available_base_task_params import *
from dags.frameworks.dynamic.utils.available_tasks import (GssTask, AaTask, BaseTask, GcsFileLoadTask)
from dags.frameworks.dynamic.utils.classes.attributes import Attribute
from dags.frameworks.dynamic.utils.classes.categories import Category
from dags.frameworks.dynamic.utils.classes.dag_configs import DagConfig
from dags.frameworks.dynamic.utils.classes.dag_modeling_steps import (DagModelingStep, StepOverride)
from dags.frameworks.dynamic.utils.classes.task_config import TaskConfig
from dags.frameworks.dynamic.utils.classes.transformations import Transform
from dags.frameworks.dynamic.utils.classes.data_types import DataType
from dags.frameworks.dynamic.utils.classes.parameters import Parameter
from dags.frameworks.dynamic.utils.classes.file_load_strategy import FileLoadStrategy

dag = DagConfig()
config = TaskConfig()
attribute = Attribute()
transform = Transform()
dataType = DataType()
modelingStep = DagModelingStep()
override = StepOverride()
category = Category()
gcsTasks = GcsFileLoadTask()
gssTasks = GssTask()
aaTasks = AaTask()
baseTasks = BaseTask()
param = Parameter()
fileloadstrategy = FileLoadStrategy()

configuration = {
    dag.title: {
        dag.ScheduleInterval: "None",
        dag.DagName: "ecomm_gss_euau_lkp_sainsbury_mapping_ingestion",
        dag.CustomerName: "lkp_sainsbury_mapping",
        dag.FeedName: "lkp_sainsbury_mapping",
        dag.TagsStringArray: ["ecomm", "lkp", "sainsbury", "gss"],
        dag.IsPublicFlag: False
    },
    dag.ModelingSteps: [
        {
            modelingStep.Step: {
                modelingStep.Category: category.GcsFileLoad,
                modelingStep.Overrides: [
                    {
                        override.Task: gcsTasks.GcsFileSensor,
                        override.SprocParams: [
                            {

                                GcsFileSensor.FilePath.value: "lkp/sainsbury/landing/",
                                GcsFileSensor.DestinationProject.value: "ecomm-dlf-data",
                                GcsFileSensor.FileName.value: "lkp_sainsbury_mapping"
                            }
                        ]
                    },
                    {
                        override.Task: gcsTasks.GcsFileLoadToBigquery,
                        override.SprocParams: [
                            {
                                GcsFileLoadToBigquery.DestinationDataset.value: "processed",
                                GcsFileLoadToBigquery.DestinationProject.value: "ecomm-dlf-data",
                                GcsFileLoadToBigquery.DestinationTable.value: "lkp_sainsbury_mapping",
                                GcsFileLoadToBigquery.FilePath.value: "lkp/sainsbury/landing/",
                                GcsFileLoadToBigquery.FileName.value: "lkp_sainsbury_mapping",
                                GcsFileLoadToBigquery.FileSkipRows.value: "0",
                                GcsFileLoadToBigquery.FileEncodingType.value: "utf-8",
                                GcsFileLoadToBigquery.FileLoadStrategy.value: fileloadstrategy.Overwrite
                            }
                        ]
                    }
                ]
            }
        }
    ]
}
