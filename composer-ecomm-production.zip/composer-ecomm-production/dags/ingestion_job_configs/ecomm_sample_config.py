from dags.frameworks.dynamic.utils.available_base_task_params import *
from dags.frameworks.dynamic.utils.available_tasks import (GssTask, AaTask, BaseTask)
from dags.frameworks.dynamic.utils.classes.attributes import Attribute
from dags.frameworks.dynamic.utils.classes.categories import Category
from dags.frameworks.dynamic.utils.classes.dag_configs import DagConfig
from dags.frameworks.dynamic.utils.classes.dag_modeling_steps import (DagModelingStep, StepOverride)
from dags.frameworks.dynamic.utils.classes.task_config import TaskConfig

dag = DagConfig()
config = TaskConfig()
attribute = Attribute()
modelingStep = DagModelingStep()
override = StepOverride()
category = Category()
gssTasks = GssTask()
aaTasks = AaTask()
baseTasks = BaseTask()

configuration = {
    dag.title: {
        dag.ScheduleInterval: "0 10 * * WED",
        dag.DagName: "Some Name",
        dag.CustomerName: "profitero_249_categories",
        dag.FeedName: "profitero_249_categories",
        dag.TagsStringArray: ["tag1", "tag2"]
    },
    dag.ModelingSteps: [
        {
            modelingStep.Step: {
                modelingStep.Category: category.Gss,
                modelingStep.Overrides: [
                    {
                        override.Task: gssTasks.DataExtractConfigUpdate,
                        override.SprocParams: [
                            {
                                DataExtractConfigUpdate.DestinationLookupProject.value: "2nd Override Value"
                            }
                        ]
                    }
                ]
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: baseTasks.DerivedXrefInfoTemp,
                        override.SprocParams: [
                            {
                                DerivedXrefInfoTemp.JobRunId.value: "2nd Override Value"
                            }
                        ]
                    }
                ]
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: baseTasks.DataExtractConfigUpdate,
                        override.SprocParams: [
                            {
                                DerivedXrefInfoTemp.JobRunId.value: "BASE 2nd Override Value"
                            }
                        ]
                    }
                ]
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.Base,
                modelingStep.Overrides: [
                    {
                        override.Task: baseTasks.ProfiteroBuildApiProcessedTable,
                        override.SprocParams: [
                        ]
                    }
                ]
            }
        },
        {
            modelingStep.Step: {
                modelingStep.Category: category.UserDefined,
                config.TaskName: "a_new_table_that_is_being_added",
                config.TaskDescription: "This is a test for a newly added table",
                config.BigQueryOperator: "BigQueryExecuteQueryOperator",
                config.BigQueryConnId: "bigquery_ecomm_dlf_data",
                config.DestinationProjectVariable: "ecomm-dlf-data",
                config.SqlOrScriptPath: "path_to_a_new_script",
                config.IsStoredProcFlag: False,
                config.SprocParams: [
                    {
                        attribute.Name: "some_new_param_name",
                        attribute.Value: "The_value_of_the_new_param"
                    },
                    {
                        attribute.Name: "some_new_param_name2",
                        attribute.Value: "The_value_of_the_new_param2"
                    }
                ]
            }
        }
    ]
}
