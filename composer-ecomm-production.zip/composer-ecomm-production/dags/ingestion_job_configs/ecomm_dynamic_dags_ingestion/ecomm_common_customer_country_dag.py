# Importing python Native Libraries
import datetime
import json
import os
import sys
import ast
from textwrap import dedent

# Fetching path of current file
parent_dir = os.path.dirname(__file__)

# Setting system path till composer-ecomm to import all underlying modules
sys.path.append(parent_dir[:parent_dir.index('composer-ecomm') + len('composer-ecomm')])

# Importing Airflow libraries
import airflow
from airflow.configuration import conf
from airflow.exceptions import AirflowFailException
from airflow.models.variable import Variable
from airflow.operators.dummy_operator import DummyOperator
from airflow.operators.python_operator import PythonOperator
from airflow.models.log import Log
from airflow.utils.db import create_session


# Importing common utils

from dags.common.utils import *
from dags.frameworks.dynamic.utils.dynamic_task_generator import *


ECOMM_DLF_CONN_ID = get_gcp_conn_id("ecomm-dlf-data")
ECOMM_ANALYTICS_CONN_ID = get_gcp_conn_id("ecomm-analytics")
EDW_CONN_ID = get_gcp_conn_id("ecomm-edw")


DAG_ID = "ecomm_common_customer_details_dag"

customer_parent_params_mandatory_values = """
    {
        "is_customer_parent_insert": "bool",
        "customer_parent_id": "str",
        "customer_parent": "str",
        "is_active_fg": "bool"
    }          
"""

customer_account_params_mandatory_values = """
    {
        "is_customer_parent_insert": "bool",
        "customer_account_id": "str",
        "customer_parent_id": "str",
        "country_id": "str",
        "customer_account_name": "str",
        "customer_account_desc": "str",
        "segment": "str",
        "customer_share_flag": "bool",
        "customer_sales_flag": "bool",
        "is_active_flg": "bool"
    }          
"""

customer_parent_params_mandatory_values_json = json.loads(customer_parent_params_mandatory_values)

customer_account_params_mandatory_values_json = json.loads(customer_account_params_mandatory_values)


def validate_param_data_type(param, expected_type):
    try:
        if expected_type == "int":
            int(param)
        elif expected_type == "bool":
            bool(param)
        elif expected_type == "str":
            str(param)
        return True
    except Exception:
        return False


def validate_user_params(**kwargs):

    errors = []

    valid_items = 0

    dag_run_conf_items = {}

    for k, v in kwargs['dag_run'].conf.items():
        dag_run_conf_items[k] = v

    validate_user_permissions(DAG_ID)

    for dr_key, dr_type in (customer_parent_params_mandatory_values_json.items() if str(dag_run_conf_items['is_customer_parent_insert']).lower() == "true" else customer_account_params_mandatory_values_json.items()):
        user_param = {k: v for k, v in dag_run_conf_items.items() if k == dr_key}
        if len(user_param) > 0:
            if validate_param_data_type(user_param[dr_key], dr_type):
                valid_items += 1
            else:
                msg = "Parameter '{}' whose value is '{}' has type of '{}' but is requried type of '{}' ."\
                    .format(dr_key, str(user_param[dr_key]), dr_type, user_param[dr_key])
                errors.append(msg)
        else:
            msg = "Required parameter '{}' of type '{}' is missing.".format(dr_key, dr_type)
            errors.append(msg)

    if errors:
        print("\n ************* VALIDATION OF REQUIRED PARAMS FAILED ************* ")
        raise AirflowFailException("\n ************* ERROR IS {} *************.".format(str(''.join(errors))))
    else:
        print("\n ************* VALIDATION OF REQUIRED PARAMS IS SUCCESSFUL ************* \n")
        return "Success"


def record_insert(**kwargs):

    dag_run_conf_items = {}

    for k, v in kwargs['dag_run'].conf.items():
        dag_run_conf_items[k] = v

    triggered_by = get_user_session(str(kwargs['dag'].dag_id))

    query = ""

    if str(dag_run_conf_items['is_customer_parent_insert']).lower() == "true":
        query += "CALL `{ecomm_dlf_conn_id}`.transient.ecomm_sproc_common_customer_parent_details (" \
                 "'{src_project}','{intermediate_project}','{dest_project}','{customer_parent}',{is_active_fg}," \
                 "'{triggered_by}','{feed_name}','{customer_parent_id}');"\
            .format(ecomm_dlf_conn_id=ECOMM_DLF_CONN_ID,
                    src_project=ECOMM_DLF_CONN_ID,
                    intermediate_project=EDW_CONN_ID,
                    dest_project=ECOMM_ANALYTICS_CONN_ID,
                    customer_parent=dag_run_conf_items['customer_parent'],
                    is_active_fg=dag_run_conf_items['is_active_fg'],
                    triggered_by=triggered_by,
                    feed_name='CUSTOMER_PARENT_DETAILS',
                    customer_parent_id=dag_run_conf_items['customer_parent_id'])

    else:
        query += "CALL `{ecomm_dlf_conn_id}`.transient.ecomm_sproc_common_customer_account_details (" \
                 "'{src_project}','{intermediate_project}','{dest_project}','{customer_parent_id}','{country_id}'," \
                 "'{customer_account_name}','{customer_account_desc}','{segment}',{customer_share_flag}," \
                 "{customer_sales_flag},{is_active_flg},'{triggered_by}','{feed_name}','{customer_account_id}');" \
            .format(ecomm_dlf_conn_id=ECOMM_DLF_CONN_ID,
                    src_project=ECOMM_DLF_CONN_ID,
                    intermediate_project=EDW_CONN_ID,
                    dest_project=ECOMM_ANALYTICS_CONN_ID,
                    customer_parent_id=dag_run_conf_items['customer_parent_id'],
                    country_id=dag_run_conf_items['country_id'],
                    customer_account_name=dag_run_conf_items['customer_account_name'],
                    customer_account_desc=dag_run_conf_items['customer_account_desc'],
                    segment=dag_run_conf_items['segment'],
                    customer_share_flag=dag_run_conf_items['customer_share_flag'],
                    customer_sales_flag=dag_run_conf_items['customer_sales_flag'],
                    is_active_flg=dag_run_conf_items['is_active_flg'],
                    triggered_by=triggered_by,
                    feed_name='CUSTOMER_ACCOUNT_DETAILS',
                    customer_account_id=dag_run_conf_items['customer_account_id'])

    # Construct a BigQuery client object.
    client = bigquery.Client(ECOMM_DLF_CONN_ID)
    job_config = bigquery.QueryJobConfig(use_query_cache=False)

    print("\n *************** RUNNING QUERY {} *************** ".format(str(query)))

    query_job = client.query(query, job_config=job_config)  # Make an API request.

    # Check on the progress by getting the job's updated state. Once the state
    # is `DONE`, the results are ready.

    query_job = client.get_job(
        query_job.job_id, location=query_job.location
    )  # Make an API request.

    query_job.result()

    print("Job {} is currently in state {}".format(query_job.job_id, query_job.state))


with DAG(
        DAG_ID,
        schedule_interval=None,
        default_args=get_default_args(provide_context=True, is_public_flg=True),
        catchup=False,
        orientation='TB',
        default_view='graph',
        max_active_runs=1,
        tags=["ecomm", "common", "customer", "data_access"],
        is_paused_upon_creation=True
) as dag:
    globals()[dag.dag_id] = dag
    dag.doc_md = dedent("""
        #### DAG Summary
        This dag is used to insert / update Customer Parent / Account for Ecomm. <br />
        Based on "is_customer_parent_insert" flag (i.e. True or False) it calls the respective stored proc.<br />
        If "is_customer_parent_insert" flag is True it will lead to insertion / update of Customer Parent in `processed.ecomm_common_customer_parent` table.<br />
        The following parameters are required in the `dag_run.conf` textbox as a json object:
        <ul>
            <li><strong>`is_customer_parent_insert`</strong>: True.</li>
            <li><strong>`customer_parent`</strong>: Name of that customer parent.</li>
            <li><strong>`is_active_fg`</strong>: True.</li>
            <li><strong>`customer_parent_id`</strong>: Integer value which will help to uniquely identify customer parents. This is computed automatically hence it's an optional parameter. In case of any update we need to provide ID.</li>
        </ul>
        
        #### Example Configuration
        
        Below is an example configuration. You can copy the example below and replace the values.<br /><br />
        <pre>
        ```
        {
            "is_customer_parent_insert": "True",
            "customer_parent": "Amazon",
            "is_active_fg": "True",
            "customer_parent_id": ""
        }
        ```
        </pre>
        <br />
        <br />
        If "is_customer_parent_insert" flag is False it will lead to insertion / update of Customer Account in `processed.ecomm_common_customer_account` table.<br />
        The following parameters are required in the `dag_run.conf` textbox as a json object:
        <ul>
            <li><strong>`is_customer_parent_insert`</strong>: False.</li>
            <li><strong>`customer_account_id`</strong>: Integer value which will help to uniquely identify customer account. This is computed automatically hence it's an optional parameter. In case of any update we need to provide ID.</li>
            <li><strong>`customer_parent_id`</strong>: Integer value which will help to map customer account with customer parent.</li>
            <li><strong>`country_id`</strong>: Integer value which will help to map customer account with country.</li>
            <li><strong>`customer_account_name`</strong>: Name of the customer account.</li>
            <li><strong>`customer_account_desc`</strong>: Description of the customer account.</li>
            <li><strong>`segment`</strong>: Name of the segment.</li>
            <li><strong>`customer_share_flag`</strong>: True / False.</li>
            <li><strong>`customer_sales_flag`</strong>: True / False.</li>
            <li><strong>`is_active_flg`</strong>: True / False.</li>
        </ul>
        #### Example Configuration
        Below is an example configuration. You can copy the example below and replace the values.<br /><br />
        <pre>
        ```
        {
            "is_customer_parent_insert": "False",
            "customer_parent_id": "1",
            "country_id": "1",
            "customer_account_name": "Amazon",
            "customer_account_desc": "Amazon.com",
            "segment": "NAR",
            "customer_share_flag": "True",
            "customer_sales_flag": "True",
            "is_active_flg": "True",
            "customer_account_id": ""
        }
        ```
        </pre>
        <br />
        <br />
        `**NOTE: All users cannot insert / update DQ rules. Please create a pull request to get it approved by Kizito Mor, Daniel Bicknell or Pawan Rathod to deploy the same.`
        <br />
    """)

    start_task = DummyOperator(task_id='start', dag=dag)

    validate_params = PythonOperator(
        task_id='validate_user_params',
        provide_context=True,
        python_callable=validate_user_params,
        dag=dag
    )

    record_insert = PythonOperator(
        task_id="customer_parent_insert",
        provide_context=True,
        python_callable=record_insert,
        dag=dag
    )

    # Fetching Airflow logging table_name
    logging_table_name = get_logging_table()

    if logging_table_name:
        # If there is logging table name in airflow environment then use it in end task
        end = PythonOperator(
            task_id='end',
            provide_context=True,
            python_callable=final_status,
            op_kwargs={'logging_table_name': logging_table_name},
            trigger_rule='all_done',
            dag=dag
        )
    else:
        # Else create Dummy end task
        end = DummyOperator(task_id='end', dag=dag)

    start_task >> validate_params >> record_insert >> end
