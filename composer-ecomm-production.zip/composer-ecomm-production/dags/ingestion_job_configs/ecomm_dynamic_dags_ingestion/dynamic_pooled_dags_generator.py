import os
import glob, importlib, pathlib, sys

# Fetching path of current file
parent_dir = os.path.dirname(__file__)

# Setting system path till composer-ecomm to import all underlying modules
sys.path.append(parent_dir[:parent_dir.index('composer-ecomm') + len('composer-ecomm')])

# from dags.frameworks.dynamic.utils.dynamic_task_generator import *
from dags.global_config import DAG_ROOT_DIR

# Importing common utils
from dags.common.utils import *

from airflow import DAG
from airflow.operators.dummy_operator import DummyOperator
from airflow.operators.subdag_operator import SubDagOperator
from airflow.operators.dagrun_operator import TriggerDagRunOperator

# available_common_dag_tasks = create_common_dag_tasks()


# 1. Get all data load configs (from data_load_configs folder):
path = os.path.dirname(DAG_ROOT_DIR + "/ingestion_job_configs/ingestion_job_configs")
# path = os.path.dirname(DAG_ROOT_DIR + "/frameworks/dynamic/dag_configs/data_load_configs/data_load_configs")

for dirname in os.listdir(path=path):
    # 2. Get only those file whose name ends with configs.py from data_load_configs folder:
    sys.path.append('{}/{}'.format(path, dirname))
    py_files = glob.glob(os.path.join('{}/{}'.format(path, dirname), '*configs.py'))

    schedule_interval = None
    tasks_dependency = []

    if 'ecomm_profitero_api' in str(dirname):
        with DAG(dag_id=str("{}_{}".format("pooled", dirname)),
                 schedule_interval=schedule_interval,
                 default_args=get_default_args(provide_context=True, is_public_flg=False),
                 catchup=False,
                 orientation='LR',
                 default_view='graph',
                 max_active_runs=1,
                 tags=["pooled", str(dirname)],
                 is_paused_upon_creation=True) as parent_dag:
            globals()[parent_dag.dag_id] = parent_dag

            start = DummyOperator(task_id='start', dag=parent_dag)

            end = DummyOperator(task_id='end', trigger_rule="all_success", dag=parent_dag)

            for py_file in py_files:
                # 3. Import file as module whose name ends with configs.py under the subfolder for dynamic DAG creation:
                module_name = pathlib.Path(py_file).stem
                module = importlib.import_module(module_name)

                if str(vars(module)['configuration']['dag_config']['schedule_interval']).upper() != 'NONE':
                    schedule_interval = str(vars(module)['configuration']['dag_config']['schedule_interval'])
                print("\n ******************** DAG NAME IS {} ********************".format(vars(module)['configuration']['dag_config']['dag_name']))
                tasks_dependency.append(
                    TriggerDagRunOperator(
                        task_id="trigger_{}".format(str(vars(module)['configuration']['dag_config']['dag_name'])),
                        trigger_dag_id=str(vars(module)['configuration']['dag_config']['dag_name']),
                        wait_for_completion=True
                    )
                )

            for task_dependent in range(0, len(tasks_dependency)):
                start >> tasks_dependency[task_dependent] >> end
