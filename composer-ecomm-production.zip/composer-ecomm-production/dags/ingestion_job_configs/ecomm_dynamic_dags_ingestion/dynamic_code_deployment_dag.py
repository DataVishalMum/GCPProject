# Importing python Native Libraries
import datetime
import json
import requests
import os
import sys
import ast
from textwrap import dedent

# Fetching path of current file
parent_dir = os.path.dirname(__file__)

# Setting system path till composer-ecomm to import all underlying modules
sys.path.append(parent_dir[:parent_dir.index('composer-ecomm') + len('composer-ecomm')])

# Importing Airflow libraries
import airflow
from airflow.configuration import conf
from airflow.exceptions import AirflowFailException
from airflow.operators.dummy_operator import DummyOperator
from airflow.operators.python_operator import PythonOperator
from google.cloud import storage

# Importing common utils
from dags.common.utils import *
from dags.frameworks.dynamic.utils.dynamic_task_generator import *


ECOMM_DLF_CONN_ID = get_gcp_conn_id("ecomm-dlf-data")


def code_deployment(**kwargs):

    validate_user_permissions(str(kwargs['dag'].dag_id))

    storage_client = storage.Client(ECOMM_DLF_CONN_ID)

    for folder_name in str(kwargs['dag_run'].conf['folders_to_deploy']).split(','):

        blobs = storage_client.list_blobs("landing_{}".format(ECOMM_DLF_CONN_ID),
                                          prefix="code_deployment/{}/".format(folder_name),
                                          delimiter='/')
        for blob in blobs:
            if str(blob.name).endswith(".sql"):
                print(blob.name)
                query = str(blob.download_as_text(encoding="utf-8"))

                client = bigquery.Client(ECOMM_DLF_CONN_ID)
                job_config = bigquery.QueryJobConfig(use_query_cache=False)

                print("\n *************** RUNNING QUERY {} *************** ".format(str(query)))

                query_job = client.query(query, job_config=job_config)  # Make an API request.

                # Check on the progress by getting the job's updated state. Once the state
                # is `DONE`, the results are ready.

                query_job = client.get_job(
                    query_job.job_id, location=query_job.location
                )  # Make an API request.

                query_job.result()

                print("Job {} is currently in state {}".format(query_job.job_id, query_job.state))


with DAG(
        "ecomm_code_deployment_dag",
        schedule_interval=None,
        default_args=get_default_args(provide_context=True, is_public_flg=False),
        catchup=False,
        orientation='TB',
        default_view='graph',
        max_active_runs=1,
        tags=["ecomm", "code", "deployment"],
        is_paused_upon_creation=True
) as dag:
    globals()[dag.dag_id] = dag
    dag.doc_md = dedent("""
        #### DAG Summary
        This dag is used to deploy ddl and sproc in BigQuery. <br />
        The following parameters are required in the `dag_run.conf` textbox as a json object:
        <ul>
            <li><strong>`folders_to_deploy`</strong>: List of Folders to deploy </li>
        </ul>
        #### Example Configuration
        Below is an example configuration. You can copy the example below and replace the values.<br /><br />
        <pre>
        ```
        {
            "folders_to_deploy": "ddl/loblaws,sproc/loblaws"
        }
        ```
        </pre>
        <br />
        `**NOTE: All users cannot perform deployments. Please create a pull request to get it approved by Kizito Mor, Daniel Bicknell or Pawan Rathod to deploy the same.` 
        <br /> 
    """)

    start_task = DummyOperator(task_id='start', dag=dag)

    code_deployment = PythonOperator(
        task_id='code_deployment',
        provide_context=True,
        python_callable=code_deployment,
        dag=dag
    )

    # Fetching Airflow logging table_name
    logging_table_name = get_logging_table()

    if logging_table_name:
        # If there is logging table name in airflow environment then use it in end task
        end = PythonOperator(
            task_id='end',
            provide_context=True,
            python_callable=final_status,
            op_kwargs={'logging_table_name': logging_table_name},
            trigger_rule='all_done',
            dag=dag
        )
    else:
        # Else create Dummy end task
        end = DummyOperator(task_id='end', dag=dag)

    start_task >> code_deployment >> end
