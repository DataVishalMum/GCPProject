# Importing python Native Libraries
import datetime
import json
import os
import sys
import ast
from textwrap import dedent

# Fetching path of current file
parent_dir = os.path.dirname(__file__)

# Setting system path till composer-ecomm to import all underlying modules
sys.path.append(parent_dir[:parent_dir.index('composer-ecomm') + len('composer-ecomm')])

# Importing Airflow libraries
import airflow
from airflow.configuration import conf
from airflow.exceptions import AirflowFailException
from airflow.models.variable import Variable
from airflow.operators.dummy_operator import DummyOperator
from airflow.operators.python_operator import PythonOperator
from airflow.models.log import Log
from airflow.utils.db import create_session


# Importing common utils

from dags.common.utils import *
from dags.frameworks.dynamic.utils.dynamic_task_generator import *


ECOMM_DLF_CONN_ID = get_gcp_conn_id("ecomm-dlf-data")

DAG_ID = "ecomm_data_quality_dag"

data_quality_params_mandatory_values = """
    {
        "is_rule_insert": "bool",
        "rule_id": "int",
        "threshold": "int",
        "threshold_is_percent": "bool",
        "customer_name": "str",
        "feed_name": "str",
        "dq_project": "str",
        "dq_dataset": "str",
        "dq_table": "str",
        "dq_column": "str"    
    }          
"""

data_quality_params_total_values = """
    {
        "rule_id": "int",
        "threshold": "int",
        "threshold_is_percent": "bool",
        "customer_name": "str",
        "feed_name": "str",
        "dq_project": "str",
        "dq_dataset": "str",
        "dq_table": "str",
        "dq_column": "str",
        "origin_project": "",
        "origin_dataset": "",
        "origin_table": "",
        "origin_column": ""
    }          
"""

data_quality_rule_mandatory_values = """
    {
        "is_rule_insert": "bool",
        "rule_id": "int",
        "rule_name": "str",
        "query": "str"
    }          
"""


data_quality_params_mandatory_values_json = json.loads(data_quality_params_mandatory_values)

data_quality_params_total_values_json = json.loads(data_quality_params_total_values)

data_quality_rule_mandatory_values_json = json.loads(data_quality_rule_mandatory_values)


def validate_param_data_type(param, expected_type):
    try:
        if expected_type == "int":
            int(param)
        elif expected_type == "bool":
            bool(param)
        elif expected_type == "str":
            str(param)
        return True
    except Exception:
        return False


def validate_user_params(**kwargs):

    errors = []

    valid_items = 0

    dag_run_conf_items = {}

    for k, v in kwargs['dag_run'].conf.items():
        dag_run_conf_items[k] = v

    if str(dag_run_conf_items['is_rule_insert']).lower() == "true":
        validate_user_permissions(DAG_ID)

    for dr_key, dr_type in (data_quality_rule_mandatory_values_json.items() if str(dag_run_conf_items['is_rule_insert']).lower() == "true" else data_quality_params_mandatory_values_json.items()):
        user_param = {k: v for k, v in dag_run_conf_items.items() if k == dr_key}
        if len(user_param) > 0:
            if validate_param_data_type(user_param[dr_key], dr_type):
                valid_items += 1
            else:
                msg = "Parameter '{}' whose value is '{}' has type of '{}' but is requried type of '{}' ."\
                    .format(dr_key, str(user_param[dr_key]), dr_type, user_param[dr_key])
                errors.append(msg)
        else:
            msg = "Required parameter '{}' of type '{}' is missing.".format(dr_key, dr_type)
            errors.append(msg)

    if errors:
        print("\n ************* VALIDATION OF REQUIRED PARAMS FAILED ************* ")
        raise AirflowFailException("\n ************* ERROR IS {} *************.".format(str(''.join(errors))))
    else:
        print("\n ************* VALIDATION OF REQUIRED PARAMS IS SUCCESSFUL ************* \n")
        return "Success"


def data_quality_insert(**kwargs):

    dag_run_conf_items = {}

    for k, v in kwargs['dag_run'].conf.items():
        dag_run_conf_items[k] = v

    query = ""

    if str(dag_run_conf_items['is_rule_insert']).lower() != "true":

        del dag_run_conf_items['is_rule_insert']

        dag_run_conf_items['dq_project'] = get_gcp_conn_id(dag_run_conf_items['dq_project']) \
            if get_gcp_conn_id(dag_run_conf_items['dq_project']) is not None else dag_run_conf_items['dq_project']

        if 'origin_project' in dag_run_conf_items:
            dag_run_conf_items['origin_project'] = get_gcp_conn_id(dag_run_conf_items['origin_project']) \
                if get_gcp_conn_id(dag_run_conf_items['origin_project']) is not None \
                else dag_run_conf_items['origin_project']

        data_quality_params_total_values_json.update(dag_run_conf_items)

        sproc_params = []

        for k, v in data_quality_params_total_values_json.items():
            if k not in ('rule_id', 'threshold', 'threshold_is_percent'):
                sproc_params.append('"{}"'.format(v))
            else:
                sproc_params.append(v)

        query += "CALL `{}`.transient.ecomm_sproc_data_quality_parameter_insert ({});".format(ECOMM_DLF_CONN_ID,
                                                                                              ','.join(sproc_params))

    else:

        del dag_run_conf_items['is_rule_insert']

        dag_run_conf_items['rule_name'] = '"{}"'.format(dag_run_conf_items['rule_name'])
        dag_run_conf_items["query"] = '"""{}"""'.format(dag_run_conf_items["query"])
        dag_run_conf_items['feed_name'] = '"DQ_RULE_INSERT"'

        sproc_params = [v for k, v in dag_run_conf_items.items()]

        query += "CALL `{}`.transient.ecomm_sproc_data_quality_rule_insert ({});".format(ECOMM_DLF_CONN_ID,
                                                                                         ','.join(sproc_params))

    # Construct a BigQuery client object.
    client = bigquery.Client(ECOMM_DLF_CONN_ID)
    job_config = bigquery.QueryJobConfig(use_query_cache=False)

    print("\n *************** RUNNING QUERY {} *************** ".format(str(query)))

    query_job = client.query(query, job_config=job_config)  # Make an API request.

    # Check on the progress by getting the job's updated state. Once the state
    # is `DONE`, the results are ready.

    query_job = client.get_job(
        query_job.job_id, location=query_job.location
    )  # Make an API request.

    query_job.result()

    print("Job {} is currently in state {}".format(query_job.job_id, query_job.state))


with DAG(
        DAG_ID,
        schedule_interval=None,
        default_args=get_default_args(provide_context=True, is_public_flg=True),
        catchup=False,
        orientation='TB',
        default_view='graph',
        max_active_runs=1,
        tags=["ecomm", "dq", "data_quality"],
        is_paused_upon_creation=True
) as dag:
    globals()[dag.dag_id] = dag
    dag.doc_md = dedent("""
        #### DAG Summary
        This dag is used to insert / update DQ rule and parameter. <br />
        Based on "is_rule_insert" flag (i.e. True or False) it calls the respective stored proc.<br />
        If "is_rule_insert" flag is True it will lead to insertion of DQ rule in `processed.data_quality_rules` table.<br />
        The following parameters are required in the `dag_run.conf` textbox as a json object:
        <ul>
            <li><strong>`is_rule_insert`</strong>: True </li>
            <li><strong>`rule_id`</strong>: Integer value which will help to uniquely identify DQ rule</li>
            <li><strong>`rule_name`</strong>: Name of that DQ rule.</li>
            <li><strong>`query`</strong>: DQ query which will help to perform data quality.
            Escape quotes using backward slash (<strong>"&bsol;"</strong>) </li>
        </ul>
        #### Example Configuration
        Below is an example configuration. You can copy the example below and replace the values.<br /><br />
        <pre>
        ```
        {
            "is_rule_insert": "True",
            "rule_id": "1",
            "rule_name": "duplicate_check",
            "query": "with query_to_run as (SELECT DISTINCT cnt , total_cnt FROM (SELECT  COUNT(*) OVER(PARTITION BY \\",dq_column,\\") as cnt, COUNT(*) OVER() as total_cnt FROM `\\",dq_project,\\"`.\\",dq_dataset,\\".\\",dq_table,\\")q)"
        }
        ```
        </pre>
        <br />
        `**NOTE: All users cannot insert / update DQ rules. Please create a pull request to get it approved by Kizito Mor, Daniel Bicknell or Pawan Rathod to deploy the same.`
        <br />
        <br />
        If "is_rule_insert" flag is False it will lead to insertion of DQ parameters in `processed.data_quality_parameters` table .<br />
        The following parameters are required in the `dag_run.conf` textbox as a json object:
        <ul>
            <li><strong>`is_rule_insert`</strong>: False </li>
            <li><strong>`rule_id`</strong>: Integer value which will help to uniquely identify DQ rule</li>
            <li><strong>`threshold`</strong>: Threshold value.</li>
            <li><strong>`threshold_is_percent`</strong>: True is it threshold is in percentage 
            else False for absolute value.</li>
            <li><strong>`customer_name`</strong>: Customer Name for which DQ parameter will be used.</li>
            <li><strong>`feed_name`</strong>: Feed Name for which DQ parameter will be used.</li>
            <li><strong>`dq_project`</strong>: Data Quality table project name.</li>
            <li><strong>`dq_dataset`</strong>: Data Quality table dataset name.</li>
            <li><strong>`dq_table`</strong>: Data Quality table name.</li>
            <li><strong>`dq_column`</strong>: Name of column on which Data Quality is required to perform.</li>
            <li><strong>`origin_project`</strong>: (Optional) Origin Project Name. Only required when you want to 
            perform Data Quality between tables.</li>
            <li><strong>`origin_project`</strong>: (Optional) Origin Project Name. Only required when you want to 
            perform Data Quality between tables.</li>
            <li><strong>`origin_dataset`</strong>: (Optional) Origin Dataset Name. Only required when you want to 
            perform Data Quality between tables.</li>
            <li><strong>`origin_table`</strong>: (Optional) Origin Table Name. Only required when you want to 
            perform Data Quality between tables.</li>
            <li><strong>`origin_column`</strong>: (Optional) Origin Column Name. Only required when you want to 
            perform Data Quality between tables.</li>
        </ul>
        #### Example Configuration
        Below is an example configuration. You can copy the example below and replace the values.<br /><br />
        <pre>
        ```
        {
            "is_rule_insert": "False",
            "rule_id": "1",
            "customer_name": "LOBLAWS",
            "feed_name": "LOBLAWS",
            "threshold": "10",
            "threshold_is_percent": "True",
            "dq_project": "ecomm-dlf-data",
            "dq_dataset": "transient",
            "dq_table": "loblaws_delta_temp",
            "dq_column": "article_number, upc,loblaws_week_start,store_banner"
        }
        ```
        </pre>
        <br />
        <br />
    """)

    start_task = DummyOperator(task_id='start', dag=dag)

    validate_params = PythonOperator(
        task_id='validate_user_params',
        provide_context=True,
        python_callable=validate_user_params,
        dag=dag
    )

    data_quality_insert = PythonOperator(
        task_id="data_quality_insert",
        provide_context=True,
        python_callable=data_quality_insert,
        dag=dag
    )

    # Fetching Airflow logging table_name
    logging_table_name = get_logging_table()

    if logging_table_name:
        # If there is logging table name in airflow environment then use it in end task
        end = PythonOperator(
            task_id='end',
            provide_context=True,
            python_callable=final_status,
            op_kwargs={'logging_table_name': logging_table_name},
            trigger_rule='all_done',
            dag=dag
        )
    else:
        # Else create Dummy end task
        end = DummyOperator(task_id='end', dag=dag)

    start_task >> validate_params >> data_quality_insert >> end
