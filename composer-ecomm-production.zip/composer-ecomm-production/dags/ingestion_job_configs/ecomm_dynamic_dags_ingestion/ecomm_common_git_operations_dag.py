# Importing python Native Libraries
import datetime
import json
import os
import sys
import ast
from textwrap import dedent
import requests, json
import base64
from datetime import datetime

# Fetching path of current file
parent_dir = os.path.dirname(__file__)

# Setting system path till composer-ecomm to import all underlying modules
sys.path.append(parent_dir[:parent_dir.index('composer-ecomm') + len('composer-ecomm')])

# Importing Airflow libraries
import airflow
from airflow.configuration import conf
from airflow.exceptions import AirflowFailException
from airflow.models.variable import Variable
from airflow.operators.dummy_operator import DummyOperator
from airflow.operators.python_operator import PythonOperator
from airflow.models.log import Log
from airflow.utils.db import create_session

# Importing common utils

from dags.common.utils import *
from dags.frameworks.dynamic.utils.dynamic_task_generator import *

DAG_ID = "ecomm_common_git_operations_dag"

git_params_mandatory_values = """
    {
        "organization_name": "str",
        "git_project_name": "str"
    }          
"""

git_params_mandatory_values_json = json.loads(git_params_mandatory_values)


def validate_param_data_type(param, expected_type):
    try:
        if expected_type == "int":
            int(param)
        elif expected_type == "bool":
            bool(param)
        elif expected_type == "str":
            str(param)
        return True
    except Exception:
        return False


def validate_user_params(**kwargs):

    errors = []

    valid_items = 0

    dag_run_conf_items = {}

    for k, v in kwargs['dag_run'].conf.items():
        dag_run_conf_items[k] = v

    for dr_key, dr_type in (git_params_mandatory_values_json.items()):
        user_param = {k: v for k, v in dag_run_conf_items.items() if k == dr_key}
        if len(user_param) > 0:
            if validate_param_data_type(user_param[dr_key], dr_type):
                valid_items += 1
            else:
                msg = "Parameter '{}' whose value is '{}' has type of '{}' but is requried type of '{}' ." \
                    .format(dr_key, str(user_param[dr_key]), dr_type, user_param[dr_key])
                errors.append(msg)
        else:
            msg = "Required parameter '{}' of type '{}' is missing.".format(dr_key, dr_type)
            errors.append(msg)

    if errors:
        print("\n ************* VALIDATION OF REQUIRED PARAMS FAILED ************* ")
        raise AirflowFailException("\n ************* ERROR IS {} *************.".format(str(''.join(errors))))
    else:
        print("\n ************* VALIDATION OF REQUIRED PARAMS IS SUCCESSFUL ************* \n")
        return "Success"


def fetch_result(**kwargs):

    dag_run_conf_items = {}

    for k, v in kwargs['dag_run'].conf.items():
        dag_run_conf_items[k] = v

    result_data = get_repos_id(organization_name=dag_run_conf_items['organization_name'],
                               git_project_name=dag_run_conf_items['git_project_name'])

    print("\n *************** List of all repos id for organization: {organization_name} & project: {git_project_name}"
          " are: *************** ".format(organization_name=str(dag_run_conf_items['organization_name']),
                                          git_project_name=str(dag_run_conf_items['git_project_name'])))

    print(result_data)


with DAG(
        DAG_ID,
        schedule_interval=None,
        default_args=get_default_args(provide_context=True, is_public_flg=True),
        catchup=False,
        orientation='TB',
        default_view='graph',
        max_active_runs=1,
        tags=["ecomm", "common", "git", "repos"],
        is_paused_upon_creation=True
) as dag:
    globals()[dag.dag_id] = dag
    dag.doc_md = dedent("""
        #### DAG Summary
        This dag is used to get all details for Azure DevOps Repos. <br />
        The following parameters are required in the `dag_run.conf` textbox as a json object:
        <ul>
            <li><strong>`organization_name`</strong>: Name of your Organization.</li>
            <li><strong>`git_project_name`</strong>: Project Name.</li>
        </ul>
        
        #### Example Configuration
        
        Below is an example configuration. You can copy the example below and replace the values.<br /><br />
        <pre>
        ```
        {
            "organization_name": "GeneralMills",
            "git_project_name": "eCommerce"
        }
        ```
        </pre>
        <br />
    """)

    start_task = DummyOperator(task_id='start', dag=dag)

    validate_params = PythonOperator(
        task_id='validate_user_params',
        provide_context=True,
        python_callable=validate_user_params,
        dag=dag
    )

    fetch_result = PythonOperator(
        task_id="fetch_result",
        provide_context=True,
        python_callable=fetch_result,
        dag=dag
    )

    # Fetching Airflow logging table_name
    logging_table_name = get_logging_table()

    if logging_table_name:
        # If there is logging table name in airflow environment then use it in end task
        end = PythonOperator(
            task_id='end',
            provide_context=True,
            python_callable=final_status,
            op_kwargs={'logging_table_name': logging_table_name},
            trigger_rule='all_done',
            dag=dag
        )
    else:
        # Else create Dummy end task
        end = DummyOperator(task_id='end', dag=dag)

    start_task >> validate_params >> fetch_result >> end
