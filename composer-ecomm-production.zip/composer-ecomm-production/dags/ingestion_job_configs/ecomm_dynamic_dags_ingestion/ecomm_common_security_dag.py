# Importing python Native Libraries
import datetime
import json
import os
import sys
import ast
from textwrap import dedent

# Fetching path of current file
parent_dir = os.path.dirname(__file__)

# Setting system path till composer-ecomm to import all underlying modules
sys.path.append(parent_dir[:parent_dir.index('composer-ecomm') + len('composer-ecomm')])

# Importing Airflow libraries
import airflow
from airflow.configuration import conf
from airflow.exceptions import AirflowFailException
from airflow.models.variable import Variable
from airflow.operators.dummy_operator import DummyOperator
from airflow.operators.python_operator import PythonOperator
from airflow.models.log import Log
from airflow.utils.db import create_session


# Importing common utils

from dags.common.utils import *
from dags.frameworks.dynamic.utils.dynamic_task_generator import *


ECOMM_DLF_CONN_ID = get_gcp_conn_id("ecomm-dlf-data")
ECOMM_ANALYTICS_CONN_ID = get_gcp_conn_id("ecomm-analytics")
EDW_CONN_ID = get_gcp_conn_id("ecomm-edw")

DAG_ID = "ecomm_common_security_dag"

security_params_mandatory_values = """
    {
        "is_customer_security": "bool",
        "is_group": "bool",
        "security_name": "str",
        "security_desc": "str",
        "is_admin": "bool",
        "global_access": "bool",
        "is_active_flg": "bool",
        "security_id": "str"
    }          
"""

security_params_mandatory_values_json = json.loads(security_params_mandatory_values)

customer_security_params_mandatory_values = """
    {
        "is_customer_security": "bool",
        "security_id": "str",
        "customer_account_id": "str",
        "is_active_flag": "bool"
    }          
"""
customer_security_params_mandatory_values_json = json.loads(customer_security_params_mandatory_values)


def validate_param_data_type(param, expected_type):
    try:
        if expected_type == "int":
            int(param)
        elif expected_type == "bool":
            bool(param)
        elif expected_type == "str":
            str(param)
        return True
    except Exception:
        return False


def validate_user_params(**kwargs):

    errors = []

    valid_items = 0

    dag_run_conf_items = {}

    for k, v in kwargs['dag_run'].conf.items():
        dag_run_conf_items[k] = v

    validate_user_permissions(DAG_ID)

    for dr_key, dr_type in (customer_security_params_mandatory_values_json.items() if str(dag_run_conf_items['is_customer_security']).lower() == "true" else security_params_mandatory_values_json.items()):
        user_param = {k: v for k, v in dag_run_conf_items.items() if k == dr_key}
        if len(user_param) > 0:
            if validate_param_data_type(user_param[dr_key], dr_type):
                valid_items += 1
            else:
                msg = "Parameter '{}' whose value is '{}' has type of '{}' but is requried type of '{}' ."\
                    .format(dr_key, str(user_param[dr_key]), dr_type, user_param[dr_key])
                errors.append(msg)
        else:
            msg = "Required parameter '{}' of type '{}' is missing.".format(dr_key, dr_type)
            errors.append(msg)

    if errors:
        print("\n ************* VALIDATION OF REQUIRED PARAMS FAILED ************* ")
        raise AirflowFailException("\n ************* ERROR IS {} *************.".format(str(''.join(errors))))
    else:
        print("\n ************* VALIDATION OF REQUIRED PARAMS IS SUCCESSFUL ************* \n")
        return "Success"


def record_insert(**kwargs):

    dag_run_conf_items = {}

    for k, v in kwargs['dag_run'].conf.items():
        dag_run_conf_items[k] = v

    triggered_by = get_user_session(str(kwargs['dag'].dag_id))

    query = ""

    if str(dag_run_conf_items['is_customer_security']).lower() == "true":
        query += "CALL `{ecomm_dlf_conn_id}`.transient.ecomm_sproc_common_customer_security (" \
                 "'{src_project}','{intermediate_project}','{dest_project}','{security_id}','{customer_account_id}'," \
                 "{is_active_flag},'{triggered_by}','{feed_name}');" \
            .format(ecomm_dlf_conn_id=ECOMM_DLF_CONN_ID,
                    src_project=ECOMM_DLF_CONN_ID,
                    intermediate_project=EDW_CONN_ID,
                    dest_project=ECOMM_ANALYTICS_CONN_ID,
                    security_id=dag_run_conf_items['security_id'],
                    customer_account_id=dag_run_conf_items['customer_account_id'],
                    is_active_flag=dag_run_conf_items['is_active_flag'],
                    triggered_by=triggered_by,
                    feed_name='CUSTOMER_SECURITY_DETAILS')
    else:
        query += "CALL `{ecomm_dlf_conn_id}`.transient.ecomm_sproc_common_security_details (" \
            "'{src_project}','{intermediate_project}','{dest_project}',{is_group},'{security_name}'," \
            "'{security_desc}',{is_admin},{global_access},{is_active_flg}," \
            "'{triggered_by}','{feed_name}','{security_id}');"\
            .format(ecomm_dlf_conn_id=ECOMM_DLF_CONN_ID,
                    src_project=ECOMM_DLF_CONN_ID,
                    intermediate_project=EDW_CONN_ID,
                    dest_project=ECOMM_ANALYTICS_CONN_ID,
                    is_group=dag_run_conf_items['is_group'],
                    security_name=dag_run_conf_items['security_name'],
                    security_desc=dag_run_conf_items['security_desc'],
                    is_admin=dag_run_conf_items['is_admin'],
                    global_access=dag_run_conf_items['global_access'],
                    is_active_flg=dag_run_conf_items['is_active_flg'],
                    triggered_by=triggered_by,
                    feed_name='AD_SECURITY_DETAILS',
                    security_id=dag_run_conf_items['security_id'])

    # Construct a BigQuery client object.
    client = bigquery.Client(ECOMM_DLF_CONN_ID)
    job_config = bigquery.QueryJobConfig(use_query_cache=False)

    print("\n *************** RUNNING QUERY {} *************** ".format(str(query)))

    query_job = client.query(query, job_config=job_config)  # Make an API request.

    # Check on the progress by getting the job's updated state. Once the state
    # is `DONE`, the results are ready.

    query_job = client.get_job(
        query_job.job_id, location=query_job.location
    )  # Make an API request.

    query_job.result()

    print("Job {} is currently in state {}".format(query_job.job_id, query_job.state))


with DAG(
        DAG_ID,
        schedule_interval=None,
        default_args=get_default_args(provide_context=True, is_public_flg=True),
        catchup=False,
        orientation='TB',
        default_view='graph',
        max_active_runs=1,
        tags=["ecomm", "common", "security", "data_access"],
        is_paused_upon_creation=True
) as dag:
    globals()[dag.dag_id] = dag

    dag.doc_md = dedent("""
        #### DAG Summary
        This dag is used to insert / update AD Security Group / Service Account for Ecomm. <br />
        Based on "is_ad_group" flag (i.e. True or False) it calls the respective stored proc.<br />
        If "is_customer_security" flag is True it will lead to insertion / update of Customer Security Details in `processed.ecomm_common_customer_security` table.<br />
        The following parameters are required in the `dag_run.conf` textbox as a json object:
        <ul>
            <li><strong>`is_customer_security`</strong>: True.</li>
            <li><strong>`security_id`</strong>: Interger value for security id.</li>
            <li><strong>`customer_account_id`</strong>: Interger value for customer account id.</li>
            <li><strong>`is_active_flag`</strong>: True.</li>
        </ul>
        
        #### Example Configuration
        
        Below is an example configuration. You can copy the example below and replace the values.<br /><br />
        <pre>
        ```
        {
            "is_customer_security" : "True",
            "security_id": "1",
            "customer_account_id": "1",
            "is_active_flag": "True"
        }
        ```
        </pre>
        <br />
        <br />

        If "is_customer_security" flag is False it will lead to insertion / update of Security Details in `processed.ecomm_common_security_details` table.<br />
        The following parameters are required in the `dag_run.conf` textbox as a json object:
        <ul>
            <li><strong>`is_customer_security`</strong>: False.</li>
            <li><strong>`is_group`</strong>: True.</li>
            <li><strong>`security_name`</strong>: Name of that AD Security Group.</li>
            <li><strong>`security_desc`</strong>: Description of that AD Security Group.</li>
            <li><strong>`is_admin`</strong>: False.</li>
            <li><strong>`global_access`</strong>: False.</li>
            <li><strong>`is_active_flg`</strong>: True.</li>
            <li><strong>`security_id`</strong>: Integer value which will help to uniquely identify AD Security Group. This is computed automatically hence it's an optional parameter. In case of any update we need to provide ID.</li>
        </ul>
            
        #### Example Configuration
        
        Below is an example configuration. You can copy the example below and replace the values.<br /><br />
        <pre>
        ```
        {
            "is_customer_security" : "False",
            "is_group": "True",
            "security_name": "AD_GROUP_NAME",
            "security_desc": "AD_GROUP_DESC",
            "is_admin": "False",
            "global_access": "False",
            "is_active_flg": "True",
            "security_id": ""
        }
        ```
        </pre>
        <br />
        <br />
        `**NOTE: All users cannot insert / update DQ rules. Please create a pull request to get it approved by Kizito Mor, Daniel Bicknell or Pawan Rathod to deploy the same.`
        <br />
    """)

    start_task = DummyOperator(task_id='start', dag=dag)

    validate_params = PythonOperator(
        task_id='validate_user_params',
        provide_context=True,
        python_callable=validate_user_params,
        dag=dag
    )

    record_insert = PythonOperator(
        task_id="record_insert",
        provide_context=True,
        python_callable=record_insert,
        dag=dag
    )

    # Fetching Airflow logging table_name
    logging_table_name = get_logging_table()

    if logging_table_name:
        # If there is logging table name in airflow environment then use it in end task
        end = PythonOperator(
            task_id='end',
            provide_context=True,
            python_callable=final_status,
            op_kwargs={'logging_table_name': logging_table_name},
            trigger_rule='all_done',
            dag=dag
        )
    else:
        # Else create Dummy end task
        end = DummyOperator(task_id='end', dag=dag)

    start_task >> validate_params >> record_insert >> end
