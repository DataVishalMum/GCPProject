# Importing python Native Libraries
import datetime
import json
import os
import sys
import ast
from textwrap import dedent

# Fetching path of current file
parent_dir = os.path.dirname(__file__)

# Setting system path till composer-ecomm to import all underlying modules
sys.path.append(parent_dir[:parent_dir.index('composer-ecomm') + len('composer-ecomm')])

# Importing Airflow libraries
import airflow
from airflow.configuration import conf
from airflow.exceptions import AirflowFailException
from airflow.models.variable import Variable
from airflow.operators.dummy_operator import DummyOperator
from airflow.operators.python_operator import PythonOperator
from airflow.models.log import Log
from airflow.utils.db import create_session


# Importing common utils

from dags.common.utils import *
from dags.frameworks.dynamic.utils.dynamic_task_generator import *


ECOMM_DLF_CONN_ID = get_gcp_conn_id("ecomm-dlf-data")
ECOMM_ANALYTICS_CONN_ID = get_gcp_conn_id("ecomm-analytics")
EDW_CONN_ID = get_gcp_conn_id("ecomm-edw")

DAG_ID = "ecomm_common_process_historical_upc_mapper"

upc_mapper_mandatory_values = """
    {
        "feed_name": "str",
        "upc_field": "str",
        "rpc_field": "str",
        "product_title_field": "str",
        "customer_name_column": "str",
        "processed_zero_table_name": "str"
    }          
"""

upc_mapper_mandatory_values_json = json.loads(upc_mapper_mandatory_values)


def validate_param_data_type(param, expected_type):
    try:
        if expected_type == "int":
            int(param)
        elif expected_type == "bool":
            bool(param)
        elif expected_type == "str":
            str(param)
        return True
    except Exception:
        return False


def validate_user_params(**kwargs):

    errors = []

    valid_items = 0

    dag_run_conf_items = {}

    for k, v in kwargs['dag_run'].conf.items():
        dag_run_conf_items[k] = v

    for dr_key, dr_type in (upc_mapper_mandatory_values_json.items()):
        user_param = {k: v for k, v in dag_run_conf_items.items() if k == dr_key}
        if len(user_param) > 0:
            if validate_param_data_type(user_param[dr_key], dr_type):
                valid_items += 1
            else:
                msg = "Parameter '{}' whose value is '{}' has type of '{}' but is requried type of '{}' ." \
                    .format(dr_key, str(user_param[dr_key]), dr_type, user_param[dr_key])
                errors.append(msg)
        else:
            msg = "Required parameter '{}' of type '{}' is missing.".format(dr_key, dr_type)
            errors.append(msg)

    if errors:
        print("\n ************* VALIDATION OF REQUIRED PARAMS FAILED ************* ")
        raise AirflowFailException("\n ************* ERROR IS {} *************.".format(str(''.join(errors))))
    else:
        print("\n ************* VALIDATION OF REQUIRED PARAMS IS SUCCESSFUL ************* \n")
        return "Success"


def record_insert(**kwargs):

    dag_run_conf_items = {}

    for k, v in kwargs['dag_run'].conf.items():
        dag_run_conf_items[k] = v

    query = "CALL `{ecomm_dlf_conn_id}`.transient.ecomm_sproc_common_historical_upc_mapper (" \
            "'{dest_project}'," \
            "'{feed_name}'," \
            "'{src_dataset}'," \
            "'{upc_field}'," \
            "'{rpc_field}'," \
            "'{product_title_field}'," \
            "'{customer_name_column}'," \
            "'{processed_zero_table_name}'," \
            "{calculate_check_digit_flg}," \
            "{threshold})" \
        .format(
            ecomm_dlf_conn_id=ECOMM_DLF_CONN_ID,
            dest_project=ECOMM_ANALYTICS_CONN_ID,
            feed_name=dag_run_conf_items['feed_name'],
            src_dataset='transient',
            upc_field=dag_run_conf_items['upc_field'],
            rpc_field=('rpc' if dag_run_conf_items['rpc_field'].strip() == '' else dag_run_conf_items['rpc_field'].strip()),
            product_title_field=dag_run_conf_items['product_title_field'],
            customer_name_column=dag_run_conf_items['customer_name_column'],
            processed_zero_table_name=dag_run_conf_items['processed_zero_table_name'],
            calculate_check_digit_flg='True',
            threshold='0.8'
        )

    # Construct a BigQuery client object.
    client = bigquery.Client(ECOMM_DLF_CONN_ID)
    job_config = bigquery.QueryJobConfig(use_query_cache=False)

    print("\n *************** RUNNING QUERY {} *************** ".format(str(query)))

    query_job = client.query(query, job_config=job_config)  # Make an API request.

    # Check on the progress by getting the job's updated state. Once the state
    # is `DONE`, the results are ready.

    query_job = client.get_job(
        query_job.job_id, location=query_job.location
    )  # Make an API request.

    query_job.result()

    print("Job {} is currently in state {}".format(query_job.job_id, query_job.state))

with DAG(
        DAG_ID,
        schedule_interval=None,
        default_args=get_default_args(provide_context=True, is_public_flg=True),
        catchup=False,
        orientation='TB',
        default_view='graph',
        max_active_runs=1,
        tags=["ecomm", "common", "historical", "upc_mapper"],
        is_paused_upon_creation=True
) as dag:
    globals()[dag.dag_id] = dag
    dag.doc_md = dedent("""
        #### DAG Summary
        This dag is used to process all the historical upc from production into Upc mapper for Ecomm in `transient.ecomm_pipeline_src_to_catalog_upc_mapping_table` and `processed.override_upc` table. <br />
        The following parameters are required in the `dag_run.conf` textbox as a json object:
        <ul>
            <li><strong>`feed_name`</strong>: Ecomm Feed Name.</li>
            <li><strong>`upc_field`</strong>: Upc column name.</li>
            <li><strong>`rpc_field`</strong>: Rpc column name. If there are no rpc column you can leave it blank</li>
            <li><strong>`product_title_field`</strong>: Product title column name.</li>
            <li><strong>`customer_name_column`</strong>: Customer Name column.</li>
            <li><strong>`processed_zero_table_name`</strong>: Processed_zero table name.</li>
        </ul>
        #### Example Configuration
        Below is an example configuration. You can copy the example below and replace the values.<br /><br />
        <pre>
        ```
        {
            "feed_name": "target",
            "upc_field": "upc_cd",
            "rpc_field": "",
            "product_title_field": "source_item_name",
            "customer_name_column": "customer_name",
            "processed_zero_table_name": "target_processed_zero"
        }
        ```
        </pre>
        <br />
    """)

    start_task = DummyOperator(task_id='start', dag=dag)

    validate_params = PythonOperator(
        task_id='validate_user_params',
        provide_context=True,
        python_callable=validate_user_params,
        dag=dag
    )

    record_insert = PythonOperator(
        task_id="upc_mapper_insert",
        provide_context=True,
        python_callable=record_insert,
        dag=dag
    )

    # Fetching Airflow logging table_name
    logging_table_name = get_logging_table()

    if logging_table_name:
        # If there is logging table name in airflow environment then use it in end task
        end = PythonOperator(
            task_id='end',
            provide_context=True,
            python_callable=final_status,
            op_kwargs={'logging_table_name': logging_table_name},
            trigger_rule='all_done',
            dag=dag
        )
    else:
        # Else create Dummy end task
        end = DummyOperator(task_id='end', dag=dag)

    start_task >> validate_params >> record_insert >> end



