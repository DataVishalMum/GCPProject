import os
import sys

parent_dir = os.path.dirname(__file__)
sys.path.append(parent_dir)

from datetime import datetime, timedelta
from airflow.models import DAG
from airflow.operators.python_operator import PythonOperator
from airflow.contrib.operators import bigquery_operator
from airflow.models import Variable
from google.cloud import bigquery
from dag_configs import product_catalog_export_config

ECOMM_COMPOSER = Variable.get('ecomm-composer')
ECOMM_DLF = Variable.get('ecomm-dlf-data')
ECOMM_ANALYTICS = Variable.get('ecomm-analytics')
ECOMM_ANALYTICS_EXPORT_BUCKET = Variable.get('ecomm-analytics-export-bucket')

dml_file_path = "/home/airflow/gcs/dags/composer-ecomm/data_pipeline/dml_scripts/"
dml_folder_name = "common_code/"

BIGQUERY_CONN_ID = "bigquery_ecomm_analytics"

def create_dag(dag_id, export_table, export_dataset, export_bucket_path, export_filename_prefix, dml_file_name, tags):
    today = datetime.now()
    date_time = today.strftime("%Y%m%d_%H%M%S")
    export_filename = export_filename_prefix + date_time + "_*.csv"

    with open("{}{}{}".format(dml_file_path, dml_folder_name, dml_file_name)) as f:
        load_sql_str = f.read()

    default_args = {
        'owner': 'ecomm',
        'start_date': datetime(2021, 1, 1),
        'depends_on_past': False,
        'retries': 1,
        "email": "bb4357a1.genmills.onmicrosoft.com@amer.teams.ms",
        'email_on_retry': False,
        'email_on_failure': True,
        'retry_delay': timedelta(minutes=3),
        'use_legacy_sql': False
    }

    dag = DAG(
        dag_id=dag_id,
        default_args=default_args,
        description=dag_id,
        catchup=False,
        schedule_interval='0 0 21 * *',  # 0:00 AM UTC on the first day of each month
        tags=tags
    )

    def export_table_to_gcs():
        client = bigquery.Client(project=ECOMM_ANALYTICS)

        # Export table to GCS
        destination_uri = ECOMM_ANALYTICS_EXPORT_BUCKET + export_bucket_path + export_filename
        dataset_ref = client.dataset(export_dataset, project=ECOMM_DLF)
        table_ref = dataset_ref.table(export_table)

        extract_job = client.extract_table(
            table_ref,
            destination_uri,
            location='US')
        extract_job.result()  # Waits for job to complete

    with dag:
        data_load_task = bigquery_operator.BigQueryOperator(
            task_id='load_{}_export'.format(export_table.replace("_", "-")),
            sql=load_sql_str,
            gcp_conn_id=BIGQUERY_CONN_ID,
            use_legacy_sql=False,
            params={'ECOMM_DLF': ECOMM_DLF, 'ECOMM_ANALYTICS': ECOMM_ANALYTICS},
            dag=dag)

        export_task = PythonOperator(
            task_id='export_table',
            python_callable=export_table_to_gcs,
            dag=dag,
        )

        data_load_task >> export_task

    return dag

# Loop through the configs dictionary and create the DAGs
for dag_name, config in product_catalog_export_config.configs.items():
    dag = create_dag(**config['config'])
    globals()[dag_name] = dag

