from datetime import datetime, timedelta

# import pymsteams
# from urllib.parse import urlparse

from airflow.models import Variable
from gmi_airflow.common.utils.vault import VaultSettings
from gmi_airflow.sendgrid.error_notification import ErrorNotification
from airflow.configuration import conf
from airflow.models.log import Log
from airflow.utils.db import create_session
from airflow.hooks.mysql_hook import MySqlHook
from airflow.hooks.postgres_hook import PostgresHook
import pymsteams, logging

# Airflow variables
VARIABLE_VAULT_ROLE_ID = "vault_role_id"
VARIABLE_VAULT_MOUNT_ID = "vault_mount_id"
VARIABLE_VAULT_CERT_PATH = "vault_cert_path"
VARIABLE_ECOMM_SUPPORT_EMAIL = "ecomm_support_email"
ECOMM_COMPOSER_CONN_ID = "ecomm-composer"
ECOMM_DLF_CONN_ID = "ecomm-dlf-data"
ECOMM_ANALYTICS_CONN_ID = "ecomm-analytics"
EDW_CONN_ID = "ecomm-edw"
EDW_PRD_CONN_ID = "ecomm-edw-prd"
LOGGING_TABLE = "logging_table"
#DML_FILE_PATH = "/home/airflow/gcs/dags/composer-ecomm/data_pipeline/dml_scripts/"
DML_FILE_PATH = "/home/airflow/gcs/dags/composer-ecomm/data_pipeline/dml_scripts/"
IS_PUBLIC = False
EMAIL_RECIPIENTS = ["daniel.bicknell@genmills.com", "Shubham.Saxena@genmills.com", "pawan.rathod@genmills.com", "krishnamurthy.latchupatula@genmills.com"]
GIT_PAT = Variable.get("ecomm-git")


class GetVaultSettingsFromVariables(VaultSettings):
    """
    A VaultSettings child class to allow for waiting until dag runtime to call
    Variable.get(), instead of DagBag load time.  This is for performance sake of
    DagBag load.
    """

    def __init__(self, role_id_var: str,
                 mount_id_var: str,
                 cert_path_var: str
                 ):
        """
        Constructor, saves off the airflow variable names to use
        """
        self.role_id_var = role_id_var
        self.mount_id_var = mount_id_var
        self.cert_path_var = cert_path_var

    @property
    def role_id(self):
        """get the vault role_id from the variable"""
        return Variable.get(self.role_id_var)

    @property
    def mount_id(self):
        """get the vault mount_id from the variable"""
        return Variable.get(self.mount_id_var)

    @property
    def cert_path(self):
        """get the vault cert_path_var from the variable"""
        return Variable.get(self.cert_path_var)


def get_vault_settings():
    """
    This function is used as a utility function to create a VaultSettings class
    which can be used for vault API calls for the composer DAGs

    :return: Returns the VaultSettings class with the required parameters
    sets to authenticate to Vault and retrieve the secret.
    """

    return GetVaultSettingsFromVariables(
        role_id_var=VARIABLE_VAULT_ROLE_ID,
        mount_id_var=VARIABLE_VAULT_MOUNT_ID,
        cert_path_var=VARIABLE_VAULT_CERT_PATH
    )


def get_gcp_conn_id(project_variable: str) -> object:
    """
    Returns the needed GCP Connection id based on the user provided project variable parameter

    :param project_variable: str
    :return: object
    """
    conn_variables = ["ecomm-composer", "ecomm-dlf-data", "ecomm-analytics", "ecomm-edw-prd", "ecomm-edw"]
    if project_variable in conn_variables:
        return Variable.get(project_variable)
    return None


def get_logging_table():
    """
    Returns the needed Logging Table Name

    """

    logging_table = Variable.get(LOGGING_TABLE)
    if logging_table is not None:
        return logging_table
    return None


def get_admin_user_id():
    """
    Returns list of user_id which are admin

    """
    return ['accounts.google.com:110379546006983209299',
            'accounts.google.com:104417556791937007672',
            'accounts.google.com:114536848864851956525',
            'accounts.google.com:102921257660608472613',
            'accounts.google.com:101545639910506968012']


def get_user_session(dag_id):

    with create_session() as session:
        triggered_by = (
            session.query(Log.owner)
                .filter(Log.dag_id == dag_id, Log.event == "trigger")
                .order_by(Log.dttm.desc())
                .limit(1)
                .scalar()
        )

#     airflow_conn = MySqlHook(mysql_conn_id='airflow_db')
    airflow_conn = PostgresHook(postgres_conn_id='airflow_db')
    sql = "SELECT email FROM ab_user where username='{}'".format(str(triggered_by))
    query = airflow_conn.get_records(sql=sql)

    logging.info("\ *************** USER NAME IS {} ****************** ".format(str(query)))

    triggered_by = str(query[0][0]) if len(query) > 0 else str(triggered_by)
    triggered_by = "scheduler" if str(triggered_by).lower() == "none" else str(triggered_by)

    return triggered_by


def send_teams_message(context):

    environment = get_gcp_conn_id("ecomm-dlf-data")

    if 'dev' in str(environment).lower():
        color_code = "99009a"
    elif 'qa' in str(environment).lower():
        color_code = "0085ff"
    else:
        color_code = "ff4400"

    dag_run = context['dag_run']

    task_id = context['task_instance'].task_id
    dag_execution_date = dag_run.execution_date.strftime('%Y-%m-%dT%H:%M:%S.%f+00:00')

    logs_url = "https://console.cloud.google.com/storage/browser/{url}/{dag_id}/{task_id}/{dag_execution_date}" \
        .format(url=conf.get('logging', 'remote_base_log_folder'),
                dag_id=str(dag_run.dag_id),
                task_id=str(task_id),
                dag_execution_date=str(dag_execution_date).replace("+", "%2B")
                ).replace("gs://", "")

    my_teams_message = pymsteams.connectorcard(
        'https://genmills.webhook.office.com/webhookb2/'
        '4b67d7f4-8802-47b1-8752-ecf82543e5a6@0c33cce8-883c-4ba5-b615-34a6e2b8ff38/IncomingWebhook/'
        '82b1eb628ac54c92bb5961e937da6c97/3fe3ef40-5a53-4d19-9e52-1a0698b63f56',
        verify=False)

    my_teams_message.title("{env}: GCP DLF Composer DAG Failure on {run_date}".format(env=str(environment).upper(),
                                                                                      run_date=dag_execution_date))
    my_teams_message.text(f"DAG <b>{dag_run.dag_id}</b> \n\nFailed on task: `{task_id}`")
    my_teams_message.addLinkButton("View Log", logs_url)
    my_teams_message.color(color_code)

    global IS_PUBLIC
    if IS_PUBLIC:
        my_teams_message.send()
    else:
        global EMAIL_RECIPIENTS
        EMAIL_RECIPIENTS.clear()
        EMAIL_RECIPIENTS.append(get_user_session(str(dag_run.dag_id)))


def ecomm_failure_notification_callback(context):
    """
    A wrapper to the ErrorNotification class and operator so that we can
    wait until runtime to call Variable.get(), to help with DagBag load times
    """

    send_teams_message(context)

    ErrorNotification(
        send_to=EMAIL_RECIPIENTS,
        vault_settings=get_vault_settings(),
    ).send_error_notification(context)


def get_default_args(retries: int = 1, provide_context: bool = False, is_public_flg: bool = False):
    """
    Returns the default args required to create a DAG.
    This also sets the custom Notification implementation with Sendgrid
    and plugs it to the on_failure_callback
    retrieve the API key for sendgrid
    :param provide_context:  if set to true, Airflow will pass a set of
    keyword arguments that can be used in your function. For this
    to work, you need to define **kwargs in your function header.
    :param retries: number of retries default 1
    :return: default_args dictionary
    """
    global IS_PUBLIC
    IS_PUBLIC = is_public_flg
    return {
        "owner": "eComm DLF Team",
        "start_date": datetime(2021, 8, 1),
        "depends_on_past": False,
        "retries": retries,
        "email_on_failure": False,
        "email_on_retry": False,
        "on_failure_callback": ecomm_failure_notification_callback,
        "retry_delay": timedelta(minutes=5),
        "provide_context": provide_context,
    }
