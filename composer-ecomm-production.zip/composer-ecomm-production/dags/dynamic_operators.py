import os
import sys

parent_dir = os.path.dirname(__file__)
sys.path.append(parent_dir)

from airflow.models import Variable

from gmi_airflow.common.utils.vault import VaultSettings

# from airflow.providers.google.cloud.operators.bigquery import bigquery_operator, BigQueryValueCheckOperator
from airflow.contrib.operators.bigquery_check_operator import BigQueryValueCheckOperator
from airflow.contrib.operators.bigquery_operator import BigQueryOperator
from airflow.contrib.operators.kubernetes_pod_operator import KubernetesPodOperator
from kubernetes.client import (
    V1ObjectMeta,
    V1Pod,
    V1PodSpec,
    V1PodSecurityContext,
    V1Container,
    V1SecurityContext,
    V1ResourceRequirements,
)

class DynamicOperators:

    @classmethod
    def kubernetes_pod(cls, dag, config, **kwargs) -> KubernetesPodOperator:
        # Relevant ENV settings can be found here
        # https://dev.azure.com/GeneralMills/SupplyChain/_git/sam-universal-event-processor-batch?path=/src/sam-universal-event-processor-batch/util/settings.py

        return KubernetesPodOperator(
            task_id=config.get('task_id'),
            dag=dag,
            #                                             namespace="default",
            config_file="/home/airflow/composer_kube_config",
            namespace="pod-operator-namespace",
            env_vars=config.get('env_vars'),
            full_pod_spec=V1Pod(
                metadata=V1ObjectMeta(name="sc-sam-pod"),
                spec=V1PodSpec(
                    containers=[
                        V1Container(
                            name="sc-sam-uep-container",
                            image=config.get('docker_image'),
                            security_context=V1SecurityContext(
                                allow_privilege_escalation=False
                            ),
                            image_pull_policy="Always",
                            resources=V1ResourceRequirements(
                                requests={
                                    "cpu": "128m",
                                    "memory": "256Mi",
                                },
                                limits={"cpu": "128m", "memory": "256Mi"},
                            ),
                        )
                    ],
                    security_context=V1PodSecurityContext(
                        run_as_non_root=True, run_as_user=1001, fs_group=1001
                    ),
                ),
            ),
            is_delete_operator_pod=True,
            reattach_on_restart=True,
            get_logs=True,
            log_events_on_failure=True,
            startup_timeout_seconds=300,
        )



    #             task_id=config.get('task_id'),
    #             dag=dag,
    #             gcp_conn_id=None,
    #             namespace="default",
    #             env_vars=config.get('env_vars')
    #             ,
    #             full_pod_spec=V1Pod(
    #                 metadata=V1ObjectMeta(name="sc-sam-pod"),
    #                 spec=V1PodSpec(
    #                     containers=[
    #                         V1Container(
    #                             name="sc-sam-uep-container",
    #                             image=config.get('docker_image'),
    #                             security_context=V1SecurityContext(
    #                                 allow_privilege_escalation=False
    #                             ),
    #                             image_pull_policy="Always",
    #                             resources=V1ResourceRequirements(
    #                                 requests={
    #                                     "cpu": config.get('cpu_resource', "128m"),
    #                                     "memory": config.get('memory_resource', "256Mi"),
    #                                 },
    #                                 limits={"cpu": "128m", "memory": "256Mi"},
    #                             ),
    #                         )
    #                     ],
    #                     security_context=V1PodSecurityContext(
    #                         run_as_non_root=True, run_as_user=1001, fs_group=1001
    #                     ),
    #                 ),
    #             ),
    #             is_delete_operator_pod=True,
    #             reattach_on_restart=True,
    #             get_logs=True,
    #             log_events_on_failure=True,
    #             startup_timeout_seconds=300,
    #         )

    @classmethod
    def data_check(cls, dag, config, **kwargs) -> BigQueryValueCheckOperator:
        # bigquery_conn_id='bq_connection_id'

        return BigQueryValueCheckOperator(
            task_id='{}_{}'.format(kwargs.get('group',''), config['task_id']),
            sql=config['sql'],
            #             trigger_rule=kwargs.get('trigger_rule', 'all_success'),
            gcp_conn_id= config['bigquery_conn_id'],
            params={**config, **kwargs.get('params', {})},
            pass_value=config['pass_value'],
            dag=dag
        )

    #     @classmethod
    #     def bigquery_job(cls, dag, config, **kwargs) -> BigQueryInsertJobOperator:
    #         """
    #         Returns an Airflow Operator BigQueryInsertJobOperator
    #         """
    #
    #         query_config = {
    #             'query': {
    #                 'query': f"""{{% include '{config['sql']}' %}}""",
    #                 'useLegacySql': False,
    #                 'allowLargeResults': False,
    #             },
    #             'createDisposition': config.get('create_disposition'),
    #             'writeDisposition': config.get('write_disposition'),
    #         }
    #
    #         if config.get('run_as_dml', False) == False:
    #             query_config['query']['destinationTable'] = {
    #                 'projectId': Variable.get('ecomm-analytics'),
    #                 'datasetId': config['destination_dataset'],
    #                 'tableId': config['destination_table']
    #             }
    #
    #         return BigQueryInsertJobOperator(
    #             task_id='{}_{}'.format(kwargs.get('group',''), config['task_id']),
    #             configuration=query_config,
    #             params={**config, **kwargs.get('params', {})},
    #             trigger_rule=kwargs.get('trigger_rule', 'all_success'),
    #             dag=dag
    #         )

    #     @classmethod
    #     def bigquery_query(cls, dag, config, **kwargs) -> BigQueryExecuteQueryOperator:
    #         """
    #         Returns an Airflow Operator BigQueryExecuteQueryOperator
    #         """
    #
    #         destination_dataset_table = None if config.get('run_as_dml', False) else f"{config['destination_dataset']}.{config['destination_table']}"
    #         return BigQueryExecuteQueryOperator(
    #             task_id='{}_{}'.format(kwargs.get('group',''), config['task_id']),
    #             sql=config['sql'],
    #             destination_dataset_table=destination_dataset_table,
    #             write_disposition=config.get('write_disposition'),
    #             create_disposition=config.get('create_disposition'),
    #             trigger_rule=kwargs.get('trigger_rule', 'all_success'),
    #             params={**config, **kwargs.get('params', {})},
    #             dag=dag
    #         )

    @classmethod
    def bigquery_job(cls, dag, config, **kwargs) -> BigQueryOperator:
        """
        Returns an Airflow Operator BigQueryOperator
        """
        return BigQueryOperator(
            task_id=f'''{kwargs.get('group','')}_{config['task_id']}''',
            sql=config['sql'],
            gcp_conn_id= config['bigquery_conn_id'],
            allow_large_results=True,
            use_legacy_sql=False,
            params={**config, **kwargs.get('params', {})},
            dag=dag
        )
