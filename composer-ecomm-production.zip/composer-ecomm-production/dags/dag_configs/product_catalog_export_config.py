configs = {
    # 'ecomm_datasembly_product_catalog_export': {
    #     'config': {
    #         'dag_id': 'ecomm_datasembly_product_catalog_export',
    #         'export_table': 'datasembly_product_catalog_export',
    #         'export_dataset': 'processed',
    #         'export_bucket_path': '/datasembly/export/',
    #         'export_filename_prefix': "GMI_datasembly_Product_Export",
    #         'dml_file_name': "trunc_and_load_ecom_datasembly_product_catalog_export.sql",
    #         'tags': ["ecomm", "datasembly", "product_export"]
    #     }
    # },
    'ecomm_profitero_product_content_export': {
        'config': {
            'dag_id': 'ecomm_profitero_product_content_export',
            'export_table': 'profitero_product_catalog_export',
            'export_dataset': 'processed',
            'export_bucket_path': '/profitero/export/',
            'export_filename_prefix': "GMI_Product_Catalog",
            'dml_file_name': "trunc_and_load_ecom_profitero_product_catalog_export_processed.sql",
            'tags': ["ecomm", "profitero", "profitero export"]
        }
    }
}
