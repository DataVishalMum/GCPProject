source_configs = [
    {
        "dag_id": "sales_alert_dag",
        "schedule_interval":'0 12 * * 3',
        "modeling_steps": {
            "extract": [
                {
                    "task_id": "aa_insights",
                    "operation": "bigquery_job",
                    "sql": "sales_alerts/aa_alerts_insight/insert_aa_alerts_insight.sql",
                    "bigquery_conn_id": "bigquery_ecomm_analytics"
                }
            ]
            ,"data_check_insight": [
                {
                    "task_id": "nulls",
                    "pass_value": 0,
                    "operation": "data_check",
                    "sql": "sales_alerts/aa_alerts_insight/data_quality_nulls_aa_alerts_insight.sql",
                    "bigquery_conn_id": "bigquery_ecomm_analytics"
                },
                {
                    "task_id": "unique_keys",
                    "pass_value": 1,
                    "operation": "data_check",
                    "sql": "sales_alerts/aa_alerts_insight/data_quality_unique_keys_aa_alerts_insight.sql",
                    "bigquery_conn_id": "bigquery_ecomm_analytics"
                }
            ]
            ,"data_check_delta": [
                {
                    "task_id": "nulls",
                    "pass_value": 0,
                    "operation": "data_check",
                    "sql": "sales_alerts/aa_alerts_insight_delta/data_quality_nulls_aa_alerts_insight_delta.sql",
                    "bigquery_conn_id": "bigquery_ecomm_analytics"
                },
                {
                    "task_id": "unique_keys",
                    "pass_value": 1,
                    "operation": "data_check",
                    "sql": "sales_alerts/aa_alerts_insight_delta/data_quality_unique_keys_aa_alerts_insight_delta.sql",
                    "bigquery_conn_id": "bigquery_ecomm_analytics"
                }
            ]
            ,"stream": [
                {
                    "task_id": "publish_to_kafka",
                    "operation":"kubernetes_pod",
                    "docker_image": "docker.generalmills.com/docker-local/sam-universal-event-processor-batch:5-5a33979",
                    "env_vars": {
                        "VIEW_NAME": "processed.aa_alerts_insight_delta",
                        "VIEW_PROJECT_ID": "{{ var.value.get('ecomm-analytics') }}",
                        "BIGQUERY_PROJECT_ID": "{{ var.value.get('ecomm-analytics') }}",
                        "KAFKA_TOPIC": "Ecomm.SalesAlert.Opportunity",
                        "KAFKA_BOOTSTRAP_SERVERS": "{{ var.value.get('sales_alert_endpoint','')}}",
                        "VAULT_MOUNT_ID": "{{ var.value.get('vault_mount_id')}}", #the var.value dynamically gets the current env
                        "VAULT_ROLE_ID": "{{ var.value.get('vault_role_id')}}",
                        "VAULT_CONFLUENT_CLOUD_CREDS_PATH": "{{ var.value.get('VAULT_CONFLUENT_CLOUD_CREDS_PATH')}}"
#                         ,"KAFKA_LOCATION":"ON_PREM"
                    }
                }
            ]
            ,"extract_history": [
                {
                    "task_id": "aa_insights_history",
#                     "operation": "bigquery_job",
                    "sql": "sales_alerts/aa_alerts_insight_history/insert_aa_alerts_insight_history.sql",
                    "bigquery_conn_id": "bigquery_ecomm_analytics"
                }
            ]
            ,"data_check_history": [
                {
                    "task_id": "nulls",
                    "operation": "data_check",
                    "pass_value": 0,
                    "sql": "sales_alerts/aa_alerts_insight_history/data_quality_nulls_aa_alerts_insight_history.sql",
                    "bigquery_conn_id": "bigquery_ecomm_analytics"
                },
                {
                    "task_id": "unique_keys",
                    "operation": "data_check",
                    "pass_value": 1,
                    "sql": "sales_alerts/aa_alerts_insight_history/data_quality_unique_keys_aa_alerts_insight_history.sql",
                    "bigquery_conn_id": "bigquery_ecomm_analytics"
                }
            ]
        }
    }
]