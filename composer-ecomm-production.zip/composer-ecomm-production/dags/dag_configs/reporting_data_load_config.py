source_configs = [
    {
        "dag_id": "new_product_tracker",
        "schedule_interval": '0 8 * * 4',  # THR 8:00 AM UTC, 1:30 PM IST, 2:00 AM CST, 3:00 AM CDT


        "modeling_steps": {

            "load": [
                {
                    "task_id": "new_product_tracker_report",
                    "sql": "assortment_and_availability/new_product_tracker_report.sql",
                    "bigquery_conn_id": "bigquery_ecomm_analytics",
                }
            ]
        }
    },
    {
        "dag_id": "ecomm_load_aa_report_output",
        "schedule_interval": '0 8 * * 3',  # WED 8:00 AM UTC, 1:30 PM IST, 2:00 AM CST, 3:00 AM CDT

        "modeling_steps": {
            "Truncate": [
                {
                    "task_id": "stage_table",
                    "sql": "assortment_and_availability/truncate_assortment_availability_stage.sql",
                    "bigquery_conn_id": "bigquery_ecomm_analytics"
                }
            ],
            "load": [
                {
                    "task_id": "amazon_com",
                    "sql": "assortment_and_availability/assortment_availability_sproc.sql",
                    "retailer": "amazon_com",
                    "bigquery_conn_id": "bigquery_ecomm_analytics"
                },
                {
                    "task_id": "target",
                    "sql": "assortment_and_availability/assortment_availability_sproc.sql",
                    "retailer": "target",
                    "bigquery_conn_id": "bigquery_ecomm_analytics"
                },
                {
                    "task_id": "amazon_fresh",
                    "sql": "assortment_and_availability/assortment_availability_sproc.sql",
                    "retailer": "amazon_fresh",
                    "bigquery_conn_id": "bigquery_ecomm_analytics"
                },
                {
                    "task_id": "kroger",
                    "sql": "assortment_and_availability/assortment_availability_sproc.sql",
                    "retailer": "kroger",
                    "bigquery_conn_id": "bigquery_ecomm_analytics"
                },
                {
                    "task_id": "kroger_instacart",
                    "sql": "assortment_and_availability/assortment_availability_sproc.sql",
                    "retailer": "kroger_instacart",
                    "bigquery_conn_id": "bigquery_ecomm_analytics"
                },
                {
                    "task_id": "meijer",
                    "sql": "assortment_and_availability/assortment_availability_sproc.sql",
                    "retailer": "meijer",
                    "bigquery_conn_id": "bigquery_ecomm_analytics"
                },
                {
                    "task_id": "walmart_opd",
                    "sql": "assortment_and_availability/assortment_availability_sproc.sql",
                    "retailer": "walmart_opd",
                    "bigquery_conn_id": "bigquery_ecomm_analytics"
                },
                {
                    "task_id": "walmart_opd_instacart",
                    "sql": "assortment_and_availability/assortment_availability_sproc.sql",
                    "retailer": "walmart_opd_instacart",
                    "bigquery_conn_id": "bigquery_ecomm_analytics"
                },
                {
                    "task_id": "amazon_prime_now",
                    "sql": "assortment_and_availability/assortment_availability_sproc.sql",
                    "retailer": "amazon_prime_now",
                    "bigquery_conn_id": "bigquery_ecomm_analytics"
                },
                {
                    "task_id": "albertsons_safeway",
                    "sql": "assortment_and_availability/assortment_availability_sproc.sql",
                    "retailer": "albertsons_safeway",
                    "bigquery_conn_id": "bigquery_ecomm_analytics"
                },
                {
                    "task_id": "heb",
                    "sql": "assortment_and_availability/assortment_availability_sproc.sql",
                    "retailer": "heb",
                    "bigquery_conn_id": "bigquery_ecomm_analytics"
                },
                {
                    "task_id": "sams_club",
                    "sql": "assortment_and_availability/assortment_availability_sproc.sql",
                    "retailer": "sams_club",
                    "bigquery_conn_id": "bigquery_ecomm_analytics"
                },
                {
                    "task_id": "hannaford",
                    "sql": "assortment_and_availability/assortment_availability_sproc.sql",
                    "retailer": "hannaford",
                    "bigquery_conn_id": "bigquery_ecomm_analytics"
                },
                {
                    "task_id": "food_lion",
                    "sql": "assortment_and_availability/assortment_availability_sproc.sql",
                    "retailer": "food_lion",
                    "bigquery_conn_id": "bigquery_ecomm_analytics"
                },
                {
                    "task_id": "hyvee",
                    "sql": "assortment_and_availability/assortment_availability_sproc.sql",
                    "retailer": "hyvee",
                    "bigquery_conn_id": "bigquery_ecomm_analytics"
                },
                {
                    "task_id": "giant_food",
                    "sql": "assortment_and_availability/assortment_availability_sproc.sql",
                    "retailer": "giant_food",
                    "bigquery_conn_id": "bigquery_ecomm_analytics"
                },
                {
                    "task_id": "shoprite",
                    "sql": "assortment_and_availability/assortment_availability_sproc.sql",
                    "retailer": "shoprite",
                    "bigquery_conn_id": "bigquery_ecomm_analytics"
                },
                {
                    "task_id": "publix_instacart",
                    "sql": "assortment_and_availability/assortment_availability_sproc.sql",
                    "retailer": "publix_instacart",
                    "bigquery_conn_id": "bigquery_ecomm_analytics"
                },
                {
                    "task_id": "giant_co",
                    "sql": "assortment_and_availability/assortment_availability_sproc.sql",
                    "retailer": "giant_co",
                    "bigquery_conn_id": "bigquery_ecomm_analytics"
                },
                {
                    "task_id": "stop_and_shop",
                    "sql": "assortment_and_availability/assortment_availability_sproc.sql",
                    "retailer": "stop_and_shop",
                    "bigquery_conn_id": "bigquery_ecomm_analytics"
                }

            ],
            "enrich": [
                {
                    "task_id": "processed_table",
                    "dataset": "processed",
                    "sql": "assortment_and_availability/assortment_availability_report_output.sql",
                    "bigquery_conn_id": "bigquery_ecomm_analytics"
                },
                {
                    "task_id": "output_table",
                    "dataset": "output",
                    "sql": "assortment_and_availability/assortment_availability_report_output.sql",
                    "bigquery_conn_id": "bigquery_ecomm_analytics"
                }

            ]
        },

    },

    {
        "dag_id": "ecomm_ana_new_upc_conversion_tracker",
        # "schedule_interval": '0 8 * * 3',  # WED 8:00 AM UTC, 1:30 PM IST, 2:00 AM CST, 3:00 AM CDT

        "modeling_steps": {

            "truncate": [
                {
                    "task_id": "stage_table",
                    "sql": "assortment_and_availability/new_conversion_tracker_ana_truncate_step.sql",
                    "bigquery_conn_id": "bigquery_ecomm_analytics"
                }
            ],

            "load": [
                {
                    "task_id": "load",
                    "sql": "assortment_and_availability/create_ecomm_new_conversion_tracker_ana_only_retailers.sql",
                    "bigquery_conn_id": "bigquery_ecomm_analytics"
                }

            ]
        }

    },

    {
        "dag_id": "ecomm_load_ana_blue_report_output",
        "schedule_interval": '0 8 * * 3',  # WED 8:00 AM UTC, 1:30 PM IST, 2:00 AM CST, 3:00 AM CDT

        "modeling_steps": {

            "load": [
                {
                    "task_id": "load_to_output",
                    "sql": "assortment_and_availability/trunc_and_load_assortment_availability_blue_report_output.sql",
                    "destination_dataset": "output",
                    "load_number_days_range": 370,
                    "bigquery_conn_id": "bigquery_ecomm_analytics",
                }
            ]
        },

    },
    {
        "dag_id": "ecomm_load_ecomm_ana_euau_assortment_report_output",
        "schedule_interval": '0 8 * * 3',  # WED 8:00 AM UTC, 1:30 PM IST, 2:00 AM CST, 3:00 AM CDT

        "modeling_steps": {

            "load": [
                {
                    "task_id": "load_to_output",
                    "sql": "assortment_and_availability/trunc_and_load_ecomm_ana_euau_assortment_report_output.sql",
                    "destination_dataset": "output",
                    "load_number_days_range": 370,
                    "bigquery_conn_id": "bigquery_ecomm_analytics",
                }
            ]
        },

    },
    {
        "dag_id": "ecomm_load_ecomm_ana_euau_availability_report_output",
        "schedule_interval": '0 8 * * 3',  # WED 8:00 AM UTC, 1:30 PM IST, 2:00 AM CST, 3:00 AM CDT

        "modeling_steps": {

            "load": [
                {
                    "task_id": "load_to_output",
                    "sql": "assortment_and_availability/trunc_and_load_ecomm_ana_euau_availability_report_output.sql",
                    "destination_dataset": "output",
                    "load_number_days_range": 370,
                    "bigquery_conn_id": "bigquery_ecomm_analytics",
                }
            ]
        },

    },
    {
        "dag_id": "ecomm_load_upc_conversions_report_output",
        "schedule_interval": '0 8 * * 3',  # WED 8:00 AM UTC, 1:30 PM IST, 2:00 AM CST, 3:00 AM CDT

        "modeling_steps": {

            "load": [
                {
                    "task_id": "load_to_output",
                    "sql": "assortment_and_availability/trunc_and_load_upc_conversions_report_output.sql",
                    "destination_dataset": "output",
                    "load_number_days_range": 370,
                    "bigquery_conn_id": "bigquery_ecomm_analytics",
                }
            ]
        },

    },
    {
        "dag_id": "ecomm_load_gss_blue_sales_share_stage_report_output",
        "schedule_interval": '30 5 * * 3',  # WED 5:30 UTC, 11:00 AM IST, 11:30 PM CST, 12:30 AM CDT

        "modeling_steps": {
            "load": [
                {
                    "task_id": "load_to_output",
                    "sql": "perm/trunc_and_load_sales_share_blue_report_stage_output.sql",

                    "load_number_days_range": 735,
                    "bigquery_conn_id": "bigquery_ecomm_analytics",
                }
            ]
        },

    },
    {
        "dag_id": "ecomm_load_gss_blue_sales_share_report_output",
        "schedule_interval": '0 7 * * 2',  # TUE 7:00 AM UTC, 12:30 PM IST, 1:00 AM CST, 2:00 AM CDT

        "modeling_steps": {
            "load": [
                {
                    "task_id": "load_to_output",
                    "sql": "perm/trunc_and_load_sales_share_blue_report_output.sql",

                    "load_number_days_range": 735,
                    "bigquery_conn_id": "bigquery_ecomm_analytics",
                }
            ]
        },

    },
    {
        "dag_id": "ecomm_load_casefill_na_weekly_processed",
        "schedule_interval": '0 7 * * 7',  # SUN 7:00 AM UTC, 12:30 PM IST, 1:00 AM CST, 2:00 AM CDT

        "modeling_steps": {

            "load": [
                {
                    "task_id": "load_to_processed",
                    "sql": "casefill_na_weekly/trunc_and_load_casefill_na_weekly_processed.sql",
                    "destination_dataset": "processed",
                    "destination_table": "casefill_na_weekly",
                    # "load_number_days_range": 735,
                    "bigquery_conn_id": "bigquery_ecomm_dlf_data",
                }
            ]
        },

    },
    {
        "dag_id": "ecomm_load_keyword_search_share_of_search_report",
        "schedule_interval": '0 8 * * 3',  # WED 8:00 AM UTC, 1:30 PM IST, 2:00 AM CST, 3:00 AM CDT

        "modeling_steps": {

            "load": [
                {
                    "task_id": "load_to_processed",
                    "sql": "scanr/keyword_search/trunc_and_load_keyword_search_share_of_search_report_output.sql",
                    "destination_dataset": "output",
                    "destination_table": "keyword_search_share_of_search_report",
                    "load_number_days_range": 735,
                    "bigquery_conn_id": "bigquery_ecomm_analytics",
                }
            ]
        },

    },
    {
        "dag_id": "ecomm_load_gss_sales_share_ca_report_output",
        "schedule_interval": '0 7 * * 2',  # TUE 7:00 AM UTC, 12:30 PM IST, 1:00 AM CST, 2:00 AM CDT

        "modeling_steps": {

            "load": [
                {
                    "task_id": "load_to_output",
                    "sql": "perm/trunc_and_load_sales_share_ca_report_output.sql",
                    "destination_dataset": "output",
                    "destination_table": "gss_sales_share_ca_nar_report",
                    "load_number_days_range": 735,
                    "bigquery_conn_id": "bigquery_ecomm_analytics",
                }
            ]
        },

    },
    {
        "dag_id": "ecomm_load_gss_sales_share_ca_stage_report_output",
        "schedule_interval": '30 5 * * 3',  # WED 5:30 UTC, 11:00 AM IST, 11:30 PM CST, 12:30 AM CDT

        "modeling_steps": {

            "load": [
                {
                    "task_id": "load_to_output",
                    "sql": "perm/trunc_and_load_sales_share_ca_stage_report_output.sql",
                    "destination_dataset": "output",
                    "load_number_days_range": 735,
                    "bigquery_conn_id": "bigquery_ecomm_analytics",
                }
            ]
        },

    },
    {
        "dag_id": "ecomm_load_gss_sales_share_euau_report_output",
        "schedule_interval": '0 7 * * 2',  # TUE 7:00 AM UTC, 12:30 PM IST, 1:00 AM CST, 2:00 AM CDT

        "modeling_steps": {

            "load": [
                {
                    "task_id": "load_to_output",
                    "sql": "perm/trunc_and_load_sales_share_euau_report_output.sql",
                    "destination_dataset": "output",
                    "load_number_days_range": 735,
                    "bigquery_conn_id": "bigquery_ecomm_analytics",
                }
            ]
        },

    },
    {
        "dag_id": "ecomm_load_gss_sales_share_euau_stage_report_output",
        "schedule_interval": '30 5 * * 3',  # WED 5:30 UTC, 11:00 AM IST, 11:30 PM CST, 12:30 AM CDT

        "modeling_steps": {

            "load": [
                {
                    "task_id": "load_to_output",
                    "sql": "perm/trunc_and_load_sales_share_euau_stage_report_output.sql",
                    "destination_dataset": "output",
                    "load_number_days_range": 735,
                    "bigquery_conn_id": "bigquery_ecomm_analytics",
                }
            ]
        },

    },
    {
        "dag_id": "ecomm_load_gss_sales_share_nar_report_output",
        "schedule_interval": '0 7 * * 2',  # TUE 7:00 AM UTC, 12:30 PM IST, 1:00 AM CST, 2:00 AM CDT

        "modeling_steps": {

            "load": [
                {
                    "task_id": "load_to_output",
                    "sql": "perm/trunc_and_load_sales_share_nar_report_output.sql",
                    "destination_dataset": "output",
                    "load_number_days_range": 735,
                    "bigquery_conn_id": "bigquery_ecomm_analytics",
                }
            ]
        },

    },
    {
        "dag_id": "ecomm_load_gss_sales_share_nar_stage_report_output",
        "schedule_interval": '30 5 * * 3',  # WED 5:30 UTC, 11:00 AM IST, 11:30 PM CST, 12:30 AM CDT

        "modeling_steps": {

            "load": [
                {
                    "task_id": "load_to_output",
                    "sql": "perm/trunc_and_load_sales_share_nar_stage_report_output.sql",
                    "destination_dataset": "output",
                    "load_number_days_range": 735,
                    "bigquery_conn_id": "bigquery_ecomm_analytics",
                }
            ]
        },

    },
    {
        "dag_id": "ecomm_load_blue_ratings_review_report_output",
        "schedule_interval": '0 7 * * 2',  # TUE 7:00 AM UTC, 12:30 PM IST, 1:00 AM CST, 2:00 AM CDT

        "modeling_steps": {
            "load": [
                {
                    "task_id": "load_to_output",
                    "sql": "scanr/ratings_review/blue/trunc_and_load_blue_ratings_review_report_output.sql",
                    "destination_dataset": "output",
                    "destination_table": "",
                    "load_number_days_range": 0,
                    "bigquery_conn_id": "bigquery_ecomm_dlf_data",
                }
            ]
        },
    },
    {
        "dag_id": "ecomm_load_gss_france_sales_share_report_output",
        "schedule_interval": '0 7 * * 2',  # TUE 7:00 AM UTC, 12:30 PM IST, 1:00 AM CST, 2:00 AM CDT

        "modeling_steps": {
            "load": [
                {
                    "task_id": "load_to_output",
                    "sql": "perm/trunc_and_load_sales_share_france_report_output.sql",

                    "load_number_days_range": 735,
                    "bigquery_conn_id": "bigquery_ecomm_analytics",
                }
            ]
        },

    },
    {
        "dag_id": "ecomm_load_gss_france_sales_share_stage_report_output",
        "schedule_interval": '30 5 * * 3',  # WED 5:30 UTC, 11:00 AM IST, 11:30 PM CST, 12:30 AM CDT

        "modeling_steps": {
            "load": [
                {
                    "task_id": "load_to_output",
                    "sql": "perm/trunc_and_load_sales_share_france_stage_report_output.sql",

                    "load_number_days_range": 735,
                    "bigquery_conn_id": "bigquery_ecomm_analytics",
                }
            ]
        },

    },
    {
        "dag_id": "ecomm_load_gss_sainsbury_omni_sales_share_report_output",
        "schedule_interval": '0 7 * * TUE',  # 7:00 AM UTC, 12:30 PM IST, 1:00 AM CST, 2:00 AM CDT

        "modeling_steps": {
            "load": [
                {
                    "task_id": "load_to_output",
                    "sql": "perm/trunc_and_load_sales_share_sainsbury_omni_report_output.sql",

                    "load_number_days_range": 735,
                    "bigquery_conn_id": "bigquery_ecomm_analytics",
                }
            ]
        },

    },
    {
        "dag_id": "ecomm_load_gss_sainsbury_omni_sales_share_stage_report_output",
        "schedule_interval": '30 5 * * WED',  # 5:30 UTC, 11:00 AM IST, 11:30 PM CST, 12:30 AM CDT

        "modeling_steps": {
            "load": [
                {
                    "task_id": "load_to_output",
                    "sql": "perm/trunc_and_load_sales_share_sainsbury_omni_stage_report_output.sql",

                    "load_number_days_range": 735,
                    "bigquery_conn_id": "bigquery_ecomm_analytics",
                }
            ]
        },

    },
    {
        "dag_id": "ecomm_load_gss_tesco_omni_sales_share_report_output",
        "schedule_interval": '0 7 * * TUE',  # 7:00 AM UTC, 12:30 PM IST, 1:00 AM CST, 2:00 AM CDT

        "modeling_steps": {
            "load": [
                {
                    "task_id": "load_to_output",
                    "sql": "perm/trunc_and_load_sales_share_tesco_omni_report_output.sql",

                    "load_number_days_range": 735,
                    "bigquery_conn_id": "bigquery_ecomm_analytics",
                }
            ]
        },

    },
    {
        "dag_id": "ecomm_load_gss_tesco_omni_sales_share_stage_report_output",
        "schedule_interval": '30 5 * * WED',  # 5:30 UTC, 11:00 AM IST, 11:30 PM CST, 12:30 AM CDT

        "modeling_steps": {
            "load": [
                {
                    "task_id": "load_to_output",
                    "sql": "perm/trunc_and_load_sales_share_tesco_omni_stage_report_output.sql",

                    "load_number_days_range": 735,
                    "bigquery_conn_id": "bigquery_ecomm_analytics",
                }
            ]
        },

    },
    {
        "dag_id": "ecomm_load_gss_leclerc_omni_sales_share_report_output",
        "schedule_interval": '0 7 * * TUE',  # 7:00 AM UTC, 12:30 PM IST, 1:00 AM CST, 2:00 AM CDT ?

        "modeling_steps": {
            "load": [
                {
                    "task_id": "load_to_output",
                    "sql": "perm/trunc_and_load_sales_share_leclerc_omni_report_output.sql",

                    "load_number_days_range": 735,
                    "bigquery_conn_id": "bigquery_ecomm_analytics",
                }
            ]
        },

    },
    {
        "dag_id": "ecomm_load_gss_leclerc_omni_sales_share_stage_report_output",
        "schedule_interval": '30 5 * * WED',  # 5:30 UTC, 11:00 AM IST, 11:30 PM CST, 12:30 AM CDT

        "modeling_steps": {
            "load": [
                {
                    "task_id": "load_to_output",
                    "sql": "perm/trunc_and_load_sales_share_leclerc_omni_stage_report_output.sql",

                    "load_number_days_range": 735,
                    "bigquery_conn_id": "bigquery_ecomm_analytics",
                }
            ]
        },

    },
    {
        "dag_id": "ecomm_load_gss_walmart_luminate_blue_omni_sales_share_report_output",
        "schedule_interval": '0 7 * * TUE',  # 7:00 AM UTC, 12:30 PM IST, 1:00 AM CST, 2:00 AM CDT

        "modeling_steps": {
            "load": [
                {
                    "task_id": "load_to_output",
                    "sql": "perm/trunc_and_load_sales_share_walmart_luminate_pet_omni_report_output.sql",

                    "load_number_days_range": 735,
                    "bigquery_conn_id": "bigquery_ecomm_analytics",
                }
            ]
        },

    },
    {
        "dag_id": "ecomm_load_gss_walmart_luminate_blue_omni_sales_share_stage_report_output",
        "schedule_interval": '30 5 * * THU',  # 5:30 UTC, 11:00 AM IST, 11:30 PM CST, 12:30 AM CDT

        "modeling_steps": {
            "load": [
                {
                    "task_id": "load_to_output",
                    "sql": "perm/trunc_and_load_sales_share_walmart_luminate_pet_omni_stage_report_output.sql",

                    "load_number_days_range": 735,
                    "bigquery_conn_id": "bigquery_ecomm_analytics",
                }
            ]
        },

    },
    {
        "dag_id": "ecomm_load_gss_summary_pet_omni_sales_share_report_output",
        "schedule_interval": '0 7 * * TUE',  # 7:00 AM UTC, 12:30 PM IST, 1:00 AM CST, 2:00 AM CDT

        "modeling_steps": {
            "load": [
                {
                    "task_id": "load_to_output",
                    "sql": "perm/trunc_and_load_sales_share_summary_pet_omni_report_output.sql",

                    "bigquery_conn_id": "bigquery_ecomm_analytics",
                }
            ]
        },

    },
    {
        "dag_id": "ecomm_load_gss_summary_pet_omni_sales_share_stage_report_output",
        "schedule_interval": '0 7 * * TUE',  # 7:00 AM UTC, 12:30 PM IST, 1:00 AM CST, 2:00 AM CDT

        "modeling_steps": {
            "load": [
                {
                    "task_id": "load_to_output",
                    "sql": "perm/trunc_and_load_sales_share_summary_pet_omni_stage_report_output.sql",
                    "load_number_days_range": 735,

                    "bigquery_conn_id": "bigquery_ecomm_analytics",
                }
            ]
        },

    },

    {
        "dag_id": "ecomm_load_gss_instacart_omni_sales_share_report_output",
        "schedule_interval": '0 7 * * TUE',  # 7:00 AM UTC, 12:30 PM IST, 1:00 AM CST, 2:00 AM CDT

        "modeling_steps": {
            "load": [
                {
                    "task_id": "load_to_output",
                    "sql": "perm/trunc_and_load_sales_share_instacart_pet_omni_report_output.sql",
                    "load_number_days_range": 735,

                    "bigquery_conn_id": "bigquery_ecomm_analytics",
                }
            ]
        },

    },

    {
        "dag_id": "ecomm_load_gss_instacart_omni_sales_share_stage_report_output",
        "schedule_interval": '0 7 * * TUE',  # 7:00 AM UTC, 12:30 PM IST, 1:00 AM CST, 2:00 AM CDT

        "modeling_steps": {
            "load": [
                {
                    "task_id": "load_to_output",
                    "sql": "perm/trunc_and_load_sales_share_instacart_pet_omni_stage_report_output.sql",
                    "load_number_days_range": 735,

                    "bigquery_conn_id": "bigquery_ecomm_analytics",
                }
            ]
        },

    },
    {
        "dag_id": "ecomm_load_gss_instacart_omni_sales_share_report_output",
        "schedule_interval": '0 7 * * TUE',  # 7:00 AM UTC, 12:30 PM IST, 1:00 AM CST, 2:00 AM CDT

        "modeling_steps": {
            "load": [
                {
                    "task_id": "load_to_output",
                    "sql": "perm/trunc_and_load_sales_share_instacart_pet_omni_report_output.sql",
                    "load_number_days_range": 735,

                    "bigquery_conn_id": "bigquery_ecomm_analytics",
                }
            ]
        },

    },
    
    {
        "dag_id": "ecomm_load_gss_instacart_omni_sales_share_stage_report_output",
        "schedule_interval": '0 7 * * TUE',  # 7:00 AM UTC, 12:30 PM IST, 1:00 AM CST, 2:00 AM CDT

        "modeling_steps": {
            "load": [
                {
                    "task_id": "load_to_output",
                    "sql": "perm/trunc_and_load_sales_share_instacart_pet_omni_stage_report_output.sql",
                    "load_number_days_range": 735,

                    "bigquery_conn_id": "bigquery_ecomm_analytics",
                }
            ]
        },

    }

    ,
    {
        "dag_id": "ecomm_load_gss_chewy_omni_sales_share_stage_report_output",
        "schedule_interval": '0 7 * * TUE',  # 7:00 AM UTC, 12:30 PM IST, 1:00 AM CST, 2:00 AM CDT

        "modeling_steps": {
            "load": [
                {
                    "task_id": "load_to_output",
                    "sql": "perm/trunc_and_load_sales_share_chewy_pet_omni_stage_report_output.sql",
                    "load_number_days_range": 735,

                    "bigquery_conn_id": "bigquery_ecomm_analytics",
                }
            ]
        },

    }
    ,
    {
        "dag_id": "ecomm_load_gss_chewy_omni_sales_share_report_output",
        "schedule_interval": '0 7 * * TUE',  # 7:00 AM UTC, 12:30 PM IST, 1:00 AM CST, 2:00 AM CDT

        "modeling_steps": {
            "load": [
                {
                    "task_id": "load_to_output",
                    "sql": "perm/trunc_and_load_sales_share_chewy_pet_omni_report_output.sql",
                    "load_number_days_range": 735,

                    "bigquery_conn_id": "bigquery_ecomm_analytics",
                }
            ]
        },

    }
    ,
    {
        "dag_id": "ecomm_load_gss_petsmart_omni_sales_share_stage_report_output",
        "schedule_interval": '0 7 * * TUE',  # 7:00 AM UTC, 12:30 PM IST, 1:00 AM CST, 2:00 AM CDT

        "modeling_steps": {
            "load": [
                {
                    "task_id": "load_to_output",
                    "sql": "perm/trunc_and_load_sales_share_petsmart_pet_omni_stage_report_output.sql",
                    "load_number_days_range": 735,

                    "bigquery_conn_id": "bigquery_ecomm_analytics",
                }
            ]
        },

    }
    ,

    {
        "dag_id": "ecomm_load_to_edw_output",
        "schedule_interval": '0 7 * * TUE',  # 7:00 AM UTC, 12:30 PM IST, 1:00 AM CST, 2:00 AM CDT

        "modeling_steps": {
            "load": [
                {
                    "task_id": "load_to_output",
                    "sql": "perm/trunc_and_load_sales_and_share_release.sql",
                    "bigquery_conn_id": "bigquery_ecomm_analytics",
                }
            ]
        },

    }
    ,
    {
        "dag_id": "ecomm_load_gss_petsmart_omni_sales_share_report_output",
        "schedule_interval": '0 7 * * TUE',  # 7:00 AM UTC, 12:30 PM IST, 1:00 AM CST, 2:00 AM CDT

        "modeling_steps": {
            "load": [
                {
                    "task_id": "load_to_output",
                    "sql": "perm/trunc_and_load_sales_share_petsmart_pet_omni_report_output.sql",
                    "load_number_days_range": 735,

                    "bigquery_conn_id": "bigquery_ecomm_analytics",
                }
            ]
        },
    },
    {
        "dag_id": "ecomm_load_gss_asda_omni_sales_share_report_output",
        "schedule_interval": '0 20 15 * *',  # 7:00 AM UTC, 12:30 PM IST, 1:00 AM CST, 2:00 AM CDT

        "modeling_steps": {
            "load": [
                {
                    "task_id": "load_to_output",
                    "sql": "perm/trunc_and_load_sales_share_asda_omni_report_output.sql",

                    "load_number_days_range": 735,
                    "bigquery_conn_id": "bigquery_ecomm_analytics",
                }
            ]
        },

    },
    {
        "dag_id": "ecomm_load_gss_asda_omni_sales_share_stage_report_output",
        "schedule_interval": '0 23 14 * *',  # 5:30 UTC, 11:00 AM IST, 11:30 PM CST, 12:30 AM CDT

        "modeling_steps": {
            "load": [
                {
                    "task_id": "load_to_output",
                    "sql": "perm/trunc_and_load_sales_share_asda_omni_stage_report_output.sql",

                    "load_number_days_range": 735,
                    "bigquery_conn_id": "bigquery_ecomm_analytics",
                }
            ]
        },

    }
]
