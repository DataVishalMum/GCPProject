source_configs = [

    # common_code
    {
        "dag_id": "ecomm_load_ecom_product_catalog_processed",
        "schedule_interval": '0 10 * * 3',

        "modeling_steps": {
            "load": [
                {
                    "task_id": "load_to_processed",
                    "sql": "common_code/trunc_and_load_ecom_product_catalog_processed.sql",
                    "destination_dataset": "processed",
                    "destination_table": "ecom_product_catalog",
                    # "bigquery_conn_id": "bigquery_ecomm_dlf_data",
                    "bigquery_conn_id": "bigquery_ecomm_analytics",
                    # "validation": []
                }
            ]
        },
    },
    {
        "dag_id": "ecomm_load_ecom_product_catalog_processed_v3",
        "schedule_interval": '0 10 * * WED',

        "modeling_steps": {
            "load": [
                {
                    "task_id": "load_to_processed",
                    "sql": "common_code/poc_storecodes_trunc_and_load_ecom_product_catalog_processed_v3.sql",
                    "destination_dataset": "processed",
                    "destination_table": "ecom_product_catalog",
                    # "bigquery_conn_id": "bigquery_ecomm_dlf_data",
                    "bigquery_conn_id": "bigquery_ecomm_analytics",
                    # "validation": []
                }
            ]
        },

    },
    {
        "dag_id": "ecomm_load_ecom_retailer_product_codes",
        "schedule_interval": '0 10 * * WED',

        "modeling_steps": {
            "load": [
                {
                    "task_id": "load_to_processed",
                    "sql": "common_code/trunc_and_load_ecomm_retailer_product_codes.sql",
                    "destination_dataset": "processed",
                    "destination_table": "ecom_product_catalog",
                    # "bigquery_conn_id": "bigquery_ecomm_dlf_data",
                    "bigquery_conn_id": "bigquery_ecomm_analytics",
                    # "validation": []
                }
            ]
        },

    },


    
]
