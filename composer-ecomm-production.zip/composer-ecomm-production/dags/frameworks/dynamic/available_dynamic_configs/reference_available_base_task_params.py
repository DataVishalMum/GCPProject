# **** THIS IS AN AUTO GENERATED FILE FOR USE AS REFERENCE FOR CONFIGURATION ****
# ************* GENERATED ON 2023-03-06 at 01:04:01 PM *************

from enum import Enum


class BqToBqCopyTable(Enum):
	BqConnectionId = "bq_connection_id"
	SourceProject = "source_project"
	SourceDataset = "source_dataset"
	SourceTable = "source_table"
	DestinationProject = "destination_project"
	DestinationDataset = "destination_dataset"
	DestinationTable = "destination_table"
	SourceFeedName = "source_feed_name"


class BuildApiProcessedTable(Enum):
	SourceProject = "source_project"
	DestinationProject = "destination_project"
	SourceDataset = "source_dataset"
	IntermediateDataset = "intermediate_dataset"
	DestinationDataset = "destination_dataset"
	SourceTable = "source_table"
	DestinationTable = "destination_table"
	SourceCustomerName = "source_customer_name"
	SourceFeedName = "source_feed_name"


class BuildProcessedTable(Enum):
	SourceProject = "source_project"
	IntermediateDataset = "intermediate_dataset"
	DestinationDataset = "destination_dataset"
	SourceTable = "source_table"
	DestinationTable = "destination_table"
	SourceFeedName = "source_feed_name"


class CommonModalityCalculation(Enum):
	SourceProject = "source_project"
	SourceDataset = "source_dataset"
	SourceTable = "source_table"
	IntermediateTable = "intermediate_table"
	DestinationTable = "destination_table"
	SourceCustomerName = "source_customer_name"
	SourceFeedName = "source_feed_name"


class CustomerDatasemblyDeltaTemp(Enum):
	DestinationProject = "destination_project"
	DestinationDataset = "destination_dataset"
	SourceCustomerName = "source_customer_name"
	DestinationTable = "destination_table"
	SourceTable = "source_table"
	SourceFeedName = "source_feed_name"


class ConsolidateProductEuauTemp(Enum):
	SourceProject = "source_project"
	SourceDataset = "source_dataset"
	SourceLookupDataset = "source_lookup_dataset"
	DestinationTable = "destination_table"
	SourceTable = "source_table"
	IntermediateTable = "intermediate_table"
	XrefTable = "xref_table"
	SourceCustomerName = "source_customer_name"
	SourceFeedName = "source_feed_name"


class ConsolidateProductNarTemp(Enum):
	SourceProject = "source_project"
	SourceDataset = "source_dataset"
	SourceLookupDataset = "source_lookup_dataset"
	DestinationTable = "destination_table"
	SourceTable = "source_table"
	IntermediateTable = "intermediate_table"
	XrefTable = "xref_table"
	SourceCustomerName = "source_customer_name"
	SourceFeedName = "source_feed_name"


class ConsolidateXrefTemp(Enum):
	SourceProject = "source_project"
	SourceDataset = "source_dataset"
	DestinationTable = "destination_table"
	SourceTable = "source_table"
	SourceCustomerName = "source_customer_name"
	SourceFeedName = "source_feed_name"


class CustomerFactNar(Enum):
	SourceProject = "source_project"
	SourceLookupProject = "source_lookup_project"
	SourceDataset = "source_dataset"
	SourceLookupDataset = "source_lookup_dataset"
	DestinationDataset = "destination_dataset"
	DestinationTable = "destination_table"
	SourceTable = "source_table"
	XrefTable = "xref_table"
	SourceCustomerName = "source_customer_name"
	SourceFeedName = "source_feed_name"


class CustomerFactEuau(Enum):
	SourceProject = "source_project"
	SourceLookupProject = "source_lookup_project"
	SourceDataset = "source_dataset"
	SourceLookupDataset = "source_lookup_dataset"
	DestinationDataset = "destination_dataset"
	DestinationTable = "destination_table"
	SourceTable = "source_table"
	XrefTable = "xref_table"
	SourceCustomerName = "source_customer_name"
	SourceFeedName = "source_feed_name"


class CustomerProcessedZero(Enum):
	SourceProject = "source_project"
	SourceDataset = "source_dataset"
	SourceTable = "source_table"
	DestinationTable = "destination_table"
	SourceFeedName = "source_feed_name"
	DestinationDataset = "destination_dataset"
	SourceLookupProject = "source_lookup_project"
	SourceLookupDataset = "source_lookup_dataset"


class CustomerWeeklyAggFact(Enum):
	SourceProject = "source_project"
	SourceDataset = "source_dataset"
	DestinationDataset = "destination_dataset"
	SourceLookupProject = "source_lookup_project"
	SourceLookupDataset = "source_lookup_dataset"
	SourceTable = "source_table"
	DestinationTable = "destination_table"
	XrefTable = "xref_table"
	SourceCustomerName = "source_customer_name"
	SourceFeedName = "source_feed_name"


class DataExtractConfigInsert(Enum):
	SourceProject = "source_project"
	SourceDataset = "source_dataset"
	IntermediateDataset = "intermediate_dataset"
	SourceTable = "source_table"
	SourceFeedName = "source_feed_name"


class DataExtractConfigUpdate(Enum):
	SourceProject = "source_project"
	SourceDataset = "source_dataset"
	SourceTable = "source_table"
	SourceFeedName = "source_feed_name"


class DeleteObjectsFromGcs(Enum):
	DestinationProject = "destination_project"
	FileBucketName = "file_bucket_name"
	FilePath = "file_path"
	FileName = "file_name"


class DerivedXrefInfoTemp(Enum):
	SourceProject = "source_project"
	SourceDataset = "source_dataset"
	XrefTable = "xref_table"
	SourceTable = "source_table"
	DestinationTable = "destination_table"
	SourceCustomerName = "source_customer_name"
	SourceFeedName = "source_feed_name"
	DestinationDataset = "destination_dataset"


class DimSourceToEnterpriseUpcXref(Enum):
	SourceProject = "source_project"
	SourceDataset = "source_dataset"
	DestinationDataset = "destination_dataset"
	SourceLookupProject = "source_lookup_project"
	SourceLookupDataset = "source_lookup_dataset"
	SourceCustomerName = "source_customer_name"
	SourceTable = "source_table"
	DestinationTable = "destination_table"
	SourceFeedName = "source_feed_name"


class DistPlannerDeltaTemp(Enum):
	DestinationProject = "destination_project"
	IntermediateProject = "intermediate_project"
	IntermediateDataset = "intermediate_dataset"
	DestinationDataset = "destination_dataset"
	DestinationTable = "destination_table"
	SourceFeedName = "source_feed_name"


class DistPlannerDeltaTempArchive(Enum):
	DestinationProject = "destination_project"
	IntermediateProject = "intermediate_project"
	IntermediateDataset = "intermediate_dataset"
	DestinationDataset = "destination_dataset"
	DestinationTable = "destination_table"
	SourceFeedName = "source_feed_name"


class DistPlannerTemp(Enum):
	DestinationProject = "destination_project"
	DestinationDataset = "destination_dataset"
	DestinationTable = "destination_table"
	SourceDataset = "source_dataset"
	SourceTable = "source_table"
	IntermediateProject = "intermediate_project"
	IntermediateDataset = "intermediate_dataset"
	IntermediateTable = "intermediate_table"
	SourceFeedName = "source_feed_name"


class DistPlannerProcessedOne(Enum):
	DestinationProject = "destination_project"
	SourceDataset = "source_dataset"
	SourceTable = "source_table"
	DestinationDataset = "destination_dataset"
	IntermediateTable = "intermediate_table"
	DestinationTable = "destination_table"
	SourceFeedName = "source_feed_name"


class DistributionAvailabilityJoined(Enum):
	SourceProject = "source_project"
	SourceTable = "source_table"
	IntermediateProject = "intermediate_project"
	IntermediateDataset = "intermediate_dataset"
	IntermediateTable = "intermediate_table"
	DestinationDataset = "destination_dataset"
	DestinationTable = "destination_table"
	SourceFeedName = "source_feed_name"


class DistributionAvailabilityJoinedE2Open(Enum):
	SourceProject = "source_project"
	SourceTable = "source_table"
	IntermediateProject = "intermediate_project"
	IntermediateDataset = "intermediate_dataset"
	IntermediateTable = "intermediate_table"
	DestinationDataset = "destination_dataset"
	DestinationTable = "destination_table"
	SourceFeedName = "source_feed_name"


class DistributionAvailabilityJoinedPublix(Enum):
	SourceProject = "source_project"
	SourceDataset = "source_dataset"
	DestinationDataset = "destination_dataset"
	IntermediateProject = "intermediate_project"
	IntermediateDataset = "intermediate_dataset"
	DestinationTable = "destination_table"
	SourceTable = "source_table"
	IntermediateTable = "intermediate_table"
	SourceFeedName = "source_feed_name"


class DistributionAvailabilitySmoothed(Enum):
	SourceProject = "source_project"
	SourceTable = "source_table"
	IntermediateProject = "intermediate_project"
	IntermediateDataset = "intermediate_dataset"
	IntermediateTable = "intermediate_table"
	DestinationDataset = "destination_dataset"
	DestinationTable = "destination_table"
	SourceFeedName = "source_feed_name"


class DistributionAvailabilitySmoothedPublix(Enum):
	SourceProject = "source_project"
	SourceDataset = "source_dataset"
	DestinationDataset = "destination_dataset"
	IntermediateProject = "intermediate_project"
	IntermediateDataset = "intermediate_dataset"
	SourceTable = "source_table"
	DestinationTable = "destination_table"
	SourceFeedName = "source_feed_name"


class DistributionAvailabilitySubcatgAggFact(Enum):
	SourceProject = "source_project"
	SourceDataset = "source_dataset"
	SourceTable = "source_table"
	IntermediateProject = "intermediate_project"
	IntermediateDataset = "intermediate_dataset"
	DestinationDataset = "destination_dataset"
	DestinationTable = "destination_table"
	SourceFeedName = "source_feed_name"


class DistributionAvailabilityWithUpc(Enum):
	SourceProject = "source_project"
	SourceTable = "source_table"
	SourceLookupTable = "source_lookup_table"
	DestinationDataset = "destination_dataset"
	DestinationTable = "destination_table"
	SourceFeedName = "source_feed_name"


class DistributionAvailabilityWithUpcPublix(Enum):
	SourceProject = "source_project"
	SourceLookupDataset = "source_lookup_dataset"
	SourceDataset = "source_dataset"
	DestinationDataset = "destination_dataset"
	DestinationTable = "destination_table"
	SourceTable = "source_table"
	SourceFeedName = "source_feed_name"


class DistributionFact(Enum):
	SourceProject = "source_project"
	SourceDataset = "source_dataset"
	DestinationDataset = "destination_dataset"
	DestinationTable = "destination_table"
	SourceTable = "source_table"
	SourceFeedName = "source_feed_name"


class DistributionFactE2Open(Enum):
	SourceProject = "source_project"
	SourceDataset = "source_dataset"
	DestinationDataset = "destination_dataset"
	DestinationTable = "destination_table"
	SourceTable = "source_table"
	SourceFeedName = "source_feed_name"


class DistributionTargetWeeklyAggFact(Enum):
	DestinationProject = "destination_project"
	DestinationDataset = "destination_dataset"
	SourceTable = "source_table"
	DestinationTable = "destination_table"
	SourceFeedName = "source_feed_name"


class DistributionWeeklyAggFact(Enum):
	DestinationProject = "destination_project"
	DestinationDataset = "destination_dataset"
	SourceTable = "source_table"
	DestinationTable = "destination_table"
	SourceFeedName = "source_feed_name"


class DataQualityChecksRun(Enum):
	SourceProject = "source_project"
	DestinationProject = "destination_project"
	RecordKey = "record_key"
	SourceFeedName = "source_feed_name"


class E2OpenDeltaTemp(Enum):
	DestinationProject = "destination_project"
	DestinationDataset = "destination_dataset"
	SourceProject = "source_project"
	IntermediateProject = "intermediate_project"
	SourceDataset = "source_dataset"
	IntermediateDataset = "intermediate_dataset"
	SourceTable = "source_table"
	DestinationTable = "destination_table"
	SourceFeedName = "source_feed_name"


class E2OpenTargetDeltaTemp(Enum):
	DestinationProject = "destination_project"
	DestinationDataset = "destination_dataset"
	SourceProject = "source_project"
	IntermediateProject = "intermediate_project"
	SourceDataset = "source_dataset"
	IntermediateDataset = "intermediate_dataset"
	SourceTable = "source_table"
	DestinationTable = "destination_table"
	SourceFeedName = "source_feed_name"


class EcomDataReleaseControlInsert(Enum):
	SourceProject = "source_project"
	DestinationDataset = "destination_dataset"
	SourceDataset = "source_dataset"
	SourceTable = "source_table"
	SourceCustomerName = "source_customer_name"
	SourceFeedName = "source_feed_name"


class GcsFileLoadToBigquery(Enum):
	DestinationProject = "destination_project"
	DestinationDataset = "destination_dataset"
	DestinationTable = "destination_table"
	FileBucketName = "file_bucket_name"
	FilePath = "file_path"
	FileName = "file_name"
	FileType = "file_type"
	FileFieldDelimiter = "file_field_delimiter"
	FileLoadStrategy = "file_load_strategy"
	FileSkipRows = "file_skip_rows"
	FileEncodingType = "file_encoding_type"


class GcsFileSensor(Enum):
	DestinationProject = "destination_project"
	DestinationDataset = "destination_dataset"
	DestinationTable = "destination_table"
	FileBucketName = "file_bucket_name"
	FilePath = "file_path"
	FileName = "file_name"
	FileType = "file_type"
	FileFieldDelimiter = "file_field_delimiter"
	FileLoadStrategy = "file_load_strategy"
	FileCheckerTimeout = "file_checker_timeout"
	FileCheckInterval = "file_check_interval"


class GssNarCustomerFact(Enum):
	SourceProject = "source_project"
	SourceLookupProject = "source_lookup_project"
	SourceDataset = "source_dataset"
	SourceLookupDataset = "source_lookup_dataset"
	DestinationDataset = "destination_dataset"
	DestinationTable = "destination_table"
	SourceTable = "source_table"
	UpcColumnName = "upc_column_name"
	RpcColumnName = "rpc_column_name"
	ProductTitleColumnName = "product_title_column_name"
	SourceCustomerName = "source_customer_name"
	SourceFeedName = "source_feed_name"


class KeywordSearchStandardizedDataLookup(Enum):
	DestinationProject = "destination_project"
	DestinationDataset = "destination_dataset"
	SourceDataset = "source_dataset"
	IntermediateProject = "intermediate_project"
	IntermediateDataset = "intermediate_dataset"
	SourceTable = "source_table"
	SourceFeedName = "source_feed_name"


class NarCustomerEnrichment(Enum):
	SourceProject = "source_project"
	SourceDataset = "source_dataset"
	SourceTable = "source_table"
	IntermediateTable = "intermediate_table"
	SourceLookupDataset = "source_lookup_dataset"
	DestinationDataset = "destination_dataset"
	DestinationTable = "destination_table"
	DomaninName = "domanin_name"
	DomaninOverrideDate = "domanin_override_date"
	SourceCustomerName = "source_customer_name"
	SourceFeedName = "source_feed_name"


class NewProductTracker(Enum):
	SourceProject = "source_project"
	SourceDataset = "source_dataset"
	DestinationDataset = "destination_dataset"
	IntermediateProject = "intermediate_project"
	IntermediateDataset = "intermediate_dataset"
	DestinationLookupProject = "destination_lookup_project"
	DestinationLookupTable = "destination_lookup_table"
	DestinationLookupDataset = "destination_lookup_dataset"
	SourceTable = "source_table"
	DestinationTable = "destination_table"
	SourceFeedName = "source_feed_name"


class NielsenDeltaTempBlue(Enum):
	DestinationProject = "destination_project"
	DestinationDataset = "destination_dataset"
	SourceProject = "source_project"
	SourceDataset = "source_dataset"
	SourceFeedName = "source_feed_name"
	FeedGrain = "feed_grain"
	RecordKey = "record_key"


class NielsenDeltaTempEuau(Enum):
	DestinationProject = "destination_project"
	DestinationDataset = "destination_dataset"
	SourceProject = "source_project"
	SourceDataset = "source_dataset"
	SourceFeedName = "source_feed_name"
	FeedGrain = "feed_grain"
	RecordKey = "record_key"


class NielsenDeltaTempFrance(Enum):
	DestinationProject = "destination_project"
	DestinationDataset = "destination_dataset"
	SourceProject = "source_project"
	SourceDataset = "source_dataset"
	SourceFeedName = "source_feed_name"
	FeedGrain = "feed_grain"
	RecordKey = "record_key"


class NielsenDeltaTempNar(Enum):
	DestinationProject = "destination_project"
	DestinationDataset = "destination_dataset"
	SourceProject = "source_project"
	SourceDataset = "source_dataset"
	SourceFeedName = "source_feed_name"
	FeedGrain = "feed_grain"
	RecordKey = "record_key"


class NielsenIriDeltaTemp(Enum):
	DestinationProject = "destination_project"
	DestinationDataset = "destination_dataset"
	SourceProject = "source_project"
	SourceDataset = "source_dataset"
	SourceCustomerName = "source_customer_name"
	SourceTable = "source_table"
	DestinationTable = "destination_table"
	SourceFeedName = "source_feed_name"


class NielsenIriProcessedOne(Enum):
	SourceProject = "source_project"
	SourceDataset = "source_dataset"
	SourceTable = "source_table"
	DestinationDataset = "destination_dataset"
	DestinationTable = "destination_table"
	SourceFeedName = "source_feed_name"


class NielsenIriTemp(Enum):
	SourceProject = "source_project"
	SourceDataset = "source_dataset"
	SourceTable = "source_table"
	IntermediateProject = "intermediate_project"
	IntermediateDataset = "intermediate_dataset"
	SourceLookupProject = "source_lookup_project"
	SourceLookupDataset = "source_lookup_dataset"
	DestinationProject = "destination_project"
	DestinationDataset = "destination_dataset"
	DestinationTable = "destination_table"
	SourceFeedName = "source_feed_name"


class NielsenProductCaTemp(Enum):
	SourceProject = "source_project"
	SourceDataset = "source_dataset"
	XrefDataset = "xref_dataset"
	DestinationTable = "destination_table"
	SourceLookupProject = "source_lookup_project"
	SourceLookupDataset = "source_lookup_dataset"
	SourceCustomerName = "source_customer_name"
	SourceFeedName = "source_feed_name"


class NielsenProductEuauTemp(Enum):
	SourceProject = "source_project"
	SourceDataset = "source_dataset"
	DestinationTable = "destination_table"
	SourceTable = "source_table"
	SourceLookupProject = "source_lookup_project"
	SourceLookupDataset = "source_lookup_dataset"
	SourceLookupTable = "source_lookup_table"
	SourceFeedName = "source_feed_name"


class NielsenProductNarNsTemp(Enum):
	SourceProject = "source_project"
	SourceDataset = "source_dataset"
	XrefDataset = "xref_dataset"
	DestinationTable = "destination_table"
	SourceLookupProject = "source_lookup_project"
	SourceLookupDataset = "source_lookup_dataset"
	SourceCustomerName = "source_customer_name"
	SourceFeedName = "source_feed_name"


class NielsenProductNarTemp(Enum):
	SourceProject = "source_project"
	SourceDataset = "source_dataset"
	XrefDataset = "xref_dataset"
	DestinationTable = "destination_table"
	SourceLookupProject = "source_lookup_project"
	SourceLookupDataset = "source_lookup_dataset"
	SourceCustomerName = "source_customer_name"
	SourceFeedName = "source_feed_name"


class ProductEnrichment(Enum):
	DestinationProject = "destination_project"
	DestinationDataset = "destination_dataset"
	DestinationTable = "destination_table"
	SourceFeedName = "source_feed_name"


class ProductIntlTemp(Enum):
	SourceProject = "source_project"
	DestinationDataset = "destination_dataset"
	SourceDataset = "source_dataset"
	SourceLookupProject = "source_lookup_project"
	SourceLookupDataset = "source_lookup_dataset"
	SourceTable = "source_table"
	DestinationTable = "destination_table"
	XrefTable = "xref_table"
	SourceLookupTable = "source_lookup_table"
	SourceCustomerName = "source_customer_name"
	SourceFeedName = "source_feed_name"


class ProductNarTemp(Enum):
	SourceProject = "source_project"
	DestinationDataset = "destination_dataset"
	XrefDataset = "xref_dataset"
	SourceLookupProject = "source_lookup_project"
	SourceLookupDataset = "source_lookup_dataset"
	SourceCustomerName = "source_customer_name"
	DestinationTable = "destination_table"
	SourceFeedName = "source_feed_name"


class ProfiteroApiDataExtractConfigInsert(Enum):
	DestinationProject = "destination_project"
	DestinationDataset = "destination_dataset"
	SourceProject = "source_project"
	SourceDataset = "source_dataset"
	SourceTable = "source_table"
	ColumnName = "column_name"
	SourceFeedName = "source_feed_name"


class RepoBranchDelete(Enum):
	OrganizationName = "organization_name"
	GitProjectId = "git_project_id"
	RepositoryId = "repository_id"
	Threshold = "threshold"


class SourceTableDataExtractConfigInsert(Enum):
	DestinationProject = "destination_project"
	DestinationDataset = "destination_dataset"
	SourceProject = "source_project"
	SourceDataset = "source_dataset"
	SourceTable = "source_table"
	ColumnName = "column_name"
	SourceFeedName = "source_feed_name"


class SrcToEcommCatalogUpcMappingTable(Enum):
	DestinationProject = "destination_project"
	SourceFeedName = "source_feed_name"
	SourceDataset = "source_dataset"
	SourceTable = "source_table"
	UpcColumnName = "upc_column_name"
	RpcColumnName = "rpc_column_name"
	ProductTitleColumnName = "product_title_column_name"
	ColumnName = "column_name"
	UpcCheckDigitFlg = "upc_check_digit_flg"
	Threshold = "threshold"


class UnpivotPivot(Enum):
	SourceProject = "source_project"
	DestinationDataset = "destination_dataset"
	SourceDataset = "source_dataset"
	SourceTable = "source_table"
	DestinationTable = "destination_table"
	PivotColName = "pivot_col_name"
	PivotColValue = "pivot_col_value"
	ColumnName = "column_name"
	ColumnsPositionToSkipInPivot = "columns_position_to_skip_in_pivot"
	ColumnsNameToSkipInPivot = "columns_name_to_skip_in_pivot"
	SourceFeedName = "source_feed_name"


class UpcConversionProcessAna(Enum):
	SourceProject = "source_project"
	SourceDataset = "source_dataset"
	IntermediateDataset = "intermediate_dataset"
	IntermediateTable = "intermediate_table"
	SourceTable = "source_table"
	DestinationTable = "destination_table"
	SourceFeedName = "source_feed_name"


class UpcConversionProcessE2Open(Enum):
	SourceProject = "source_project"
	SourceDataset = "source_dataset"
	IntermediateDataset = "intermediate_dataset"
	IntermediateTable = "intermediate_table"
	SourceTable = "source_table"
	DestinationTable = "destination_table"
	SourceFeedName = "source_feed_name"


class UpcConversionsDnaOnly(Enum):
	SourceProject = "source_project"
	DestinationLookupProject = "destination_lookup_project"
	IntermediateProject = "intermediate_project"
	DestinationDataset = "destination_dataset"
	DestinationLookupTable = "destination_lookup_table"
	IntermediateDataset = "intermediate_dataset"
	SourceTable = "source_table"
	IntermediateTable = "intermediate_table"
	DestinationFeedName = "destination_feed_name"
	DestinationTable = "destination_table"
	SourceFeedName = "source_feed_name"


class UpcConversionsE2Open(Enum):
	SourceProject = "source_project"
	IntermediateProject = "intermediate_project"
	DestinationDataset = "destination_dataset"
	IntermediateDataset = "intermediate_dataset"
	SourceTable = "source_table"
	IntermediateTable = "intermediate_table"
	DestinationFeedName = "destination_feed_name"
	DestinationTable = "destination_table"
	SourceFeedName = "source_feed_name"


class XrefGlobalBrand(Enum):
	SourceFeedName = "source_feed_name"


class XrefGlobalCategory(Enum):
	SourceFeedName = "source_feed_name"


class XrefOverride(Enum):
	SourceFeedName = "source_feed_name"


