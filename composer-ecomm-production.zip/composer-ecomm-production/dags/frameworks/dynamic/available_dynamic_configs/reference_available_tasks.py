# **** THIS IS AN AUTO GENERATED FILE FOR USE AS REFERENCE FOR CONFIGURATION ****
# ************* GENERATED ON 2023-03-06 at 01:04:01 PM *************


class BaseTask:
	def __init__(self):
		self.__bq_to_bq_copy_table = "bq_to_bq_copy_table"
		self.__build_api_processed_table = "build_api_processed_table"
		self.__build_processed_table = "build_processed_table"
		self.__common_modality_calculation = "common_modality_calculation"
		self.__customer_datasembly_delta_temp = "customer_datasembly_delta_temp"
		self.__consolidate_product_euau_temp = "consolidate_product_euau_temp"
		self.__consolidate_product_nar_temp = "consolidate_product_nar_temp"
		self.__consolidate_xref_temp = "consolidate_xref_temp"
		self.__customer_fact_nar = "customer_fact_nar"
		self.__customer_fact_euau = "customer_fact_euau"
		self.__customer_processed_zero = "customer_processed_zero"
		self.__customer_weekly_agg_fact = "customer_weekly_agg_fact"
		self.__data_extract_config_insert = "data_extract_config_insert"
		self.__data_extract_config_update = "data_extract_config_update"
		self.__delete_objects_from_gcs = "delete_objects_from_gcs"
		self.__derived_xref_info_temp = "derived_xref_info_temp"
		self.__dim_source_to_enterprise_upc_xref = "dim_source_to_enterprise_upc_xref"
		self.__dist_planner_delta_temp = "dist_planner_delta_temp"
		self.__dist_planner_delta_temp_archive = "dist_planner_delta_temp_archive"
		self.__dist_planner_temp = "dist_planner_temp"
		self.__dist_planner_processed_one = "dist_planner_processed_one"
		self.__distribution_availability_joined = "distribution_availability_joined"
		self.__distribution_availability_joined_e2open = "distribution_availability_joined_e2open"
		self.__distribution_availability_joined_publix = "distribution_availability_joined_publix"
		self.__distribution_availability_smoothed = "distribution_availability_smoothed"
		self.__distribution_availability_smoothed_publix = "distribution_availability_smoothed_publix"
		self.__distribution_availability_subcatg_agg_fact = "distribution_availability_subcatg_agg_fact"
		self.__distribution_availability_with_upc = "distribution_availability_with_upc"
		self.__distribution_availability_with_upc_publix = "distribution_availability_with_upc_publix"
		self.__distribution_fact = "distribution_fact"
		self.__distribution_fact_e2open = "distribution_fact_e2open"
		self.__distribution_target_weekly_agg_fact = "distribution_target_weekly_agg_fact"
		self.__distribution_weekly_agg_fact = "distribution_weekly_agg_fact"
		self.__data_quality_checks_run = "data_quality_checks_run"
		self.__e2open_delta_temp = "e2open_delta_temp"
		self.__e2open_target_delta_temp = "e2open_target_delta_temp"
		self.__ecom_data_release_control_insert = "ecom_data_release_control_insert"
		self.__gcs_file_load_to_bigquery = "gcs_file_load_to_bigquery"
		self.__gcs_file_sensor = "gcs_file_sensor"
		self.__gss_nar_customer_fact = "gss_nar_customer_fact"
		self.__keyword_search_standardized_data_lookup = "keyword_search_standardized_data_lookup"
		self.__nar_customer_enrichment = "nar_customer_enrichment"
		self.__new_product_tracker = "new_product_tracker"
		self.__nielsen_delta_temp_blue = "nielsen_delta_temp_blue"
		self.__nielsen_delta_temp_euau = "nielsen_delta_temp_euau"
		self.__nielsen_delta_temp_france = "nielsen_delta_temp_france"
		self.__nielsen_delta_temp_nar = "nielsen_delta_temp_nar"
		self.__nielsen_iri_delta_temp = "nielsen_iri_delta_temp"
		self.__nielsen_iri_processed_one = "nielsen_iri_processed_one"
		self.__nielsen_iri_temp = "nielsen_iri_temp"
		self.__nielsen_product_ca_temp = "nielsen_product_ca_temp"
		self.__nielsen_product_euau_temp = "nielsen_product_euau_temp"
		self.__nielsen_product_nar_ns_temp = "nielsen_product_nar_ns_temp"
		self.__nielsen_product_nar_temp = "nielsen_product_nar_temp"
		self.__product_enrichment = "product_enrichment"
		self.__product_intl_temp = "product_intl_temp"
		self.__product_nar_temp = "product_nar_temp"
		self.__profitero_api_data_extract_config_insert = "profitero_api_data_extract_config_insert"
		self.__repo_branch_delete = "repo_branch_delete"
		self.__source_table_data_extract_config_insert = "source_table_data_extract_config_insert"
		self.__src_to_ecomm_catalog_upc_mapping_table = "src_to_ecomm_catalog_upc_mapping_table"
		self.__unpivot_pivot = "unpivot_pivot"
		self.__upc_conversion_process_ana = "upc_conversion_process_ana"
		self.__upc_conversion_process_e2open = "upc_conversion_process_e2open"
		self.__upc_conversions_dna_only = "upc_conversions_dna_only"
		self.__upc_conversions_e2open = "upc_conversions_e2open"
		self.__xref_global_brand = "xref_global_brand"
		self.__xref_global_category = "xref_global_category"
		self.__xref_override = "xref_override"

	@property
	def BqToBqCopyTable(self):
		""" Name (Class: BaseTask) """
		return self.__bq_to_bq_copy_table

	@BqToBqCopyTable.setter
	def BqToBqCopyTable(self, value):
		self.__bq_to_bq_copy_table = value

	@property
	def BuildApiProcessedTable(self):
		""" Name (Class: BaseTask) """
		return self.__build_api_processed_table

	@BuildApiProcessedTable.setter
	def BuildApiProcessedTable(self, value):
		self.__build_api_processed_table = value

	@property
	def BuildProcessedTable(self):
		""" Name (Class: BaseTask) """
		return self.__build_processed_table

	@BuildProcessedTable.setter
	def BuildProcessedTable(self, value):
		self.__build_processed_table = value

	@property
	def CommonModalityCalculation(self):
		""" Name (Class: BaseTask) """
		return self.__common_modality_calculation

	@CommonModalityCalculation.setter
	def CommonModalityCalculation(self, value):
		self.__common_modality_calculation = value

	@property
	def CustomerDatasemblyDeltaTemp(self):
		""" Name (Class: BaseTask) """
		return self.__customer_datasembly_delta_temp

	@CustomerDatasemblyDeltaTemp.setter
	def CustomerDatasemblyDeltaTemp(self, value):
		self.__customer_datasembly_delta_temp = value

	@property
	def ConsolidateProductEuauTemp(self):
		""" Name (Class: BaseTask) """
		return self.__consolidate_product_euau_temp

	@ConsolidateProductEuauTemp.setter
	def ConsolidateProductEuauTemp(self, value):
		self.__consolidate_product_euau_temp = value

	@property
	def ConsolidateProductNarTemp(self):
		""" Name (Class: BaseTask) """
		return self.__consolidate_product_nar_temp

	@ConsolidateProductNarTemp.setter
	def ConsolidateProductNarTemp(self, value):
		self.__consolidate_product_nar_temp = value

	@property
	def ConsolidateXrefTemp(self):
		""" Name (Class: BaseTask) """
		return self.__consolidate_xref_temp

	@ConsolidateXrefTemp.setter
	def ConsolidateXrefTemp(self, value):
		self.__consolidate_xref_temp = value

	@property
	def CustomerFactNar(self):
		""" Name (Class: BaseTask) """
		return self.__customer_fact_nar

	@CustomerFactNar.setter
	def CustomerFactNar(self, value):
		self.__customer_fact_nar = value

	@property
	def CustomerFactEuau(self):
		""" Name (Class: BaseTask) """
		return self.__customer_fact_euau

	@CustomerFactEuau.setter
	def CustomerFactEuau(self, value):
		self.__customer_fact_euau = value

	@property
	def CustomerProcessedZero(self):
		""" Name (Class: BaseTask) """
		return self.__customer_processed_zero

	@CustomerProcessedZero.setter
	def CustomerProcessedZero(self, value):
		self.__customer_processed_zero = value

	@property
	def CustomerWeeklyAggFact(self):
		""" Name (Class: BaseTask) """
		return self.__customer_weekly_agg_fact

	@CustomerWeeklyAggFact.setter
	def CustomerWeeklyAggFact(self, value):
		self.__customer_weekly_agg_fact = value

	@property
	def DataExtractConfigInsert(self):
		""" Name (Class: BaseTask) """
		return self.__data_extract_config_insert

	@DataExtractConfigInsert.setter
	def DataExtractConfigInsert(self, value):
		self.__data_extract_config_insert = value

	@property
	def DataExtractConfigUpdate(self):
		""" Name (Class: BaseTask) """
		return self.__data_extract_config_update

	@DataExtractConfigUpdate.setter
	def DataExtractConfigUpdate(self, value):
		self.__data_extract_config_update = value

	@property
	def DeleteObjectsFromGcs(self):
		""" Name (Class: BaseTask) """
		return self.__delete_objects_from_gcs

	@DeleteObjectsFromGcs.setter
	def DeleteObjectsFromGcs(self, value):
		self.__delete_objects_from_gcs = value

	@property
	def DerivedXrefInfoTemp(self):
		""" Name (Class: BaseTask) """
		return self.__derived_xref_info_temp

	@DerivedXrefInfoTemp.setter
	def DerivedXrefInfoTemp(self, value):
		self.__derived_xref_info_temp = value

	@property
	def DimSourceToEnterpriseUpcXref(self):
		""" Name (Class: BaseTask) """
		return self.__dim_source_to_enterprise_upc_xref

	@DimSourceToEnterpriseUpcXref.setter
	def DimSourceToEnterpriseUpcXref(self, value):
		self.__dim_source_to_enterprise_upc_xref = value

	@property
	def DistPlannerDeltaTemp(self):
		""" Name (Class: BaseTask) """
		return self.__dist_planner_delta_temp

	@DistPlannerDeltaTemp.setter
	def DistPlannerDeltaTemp(self, value):
		self.__dist_planner_delta_temp = value

	@property
	def DistPlannerDeltaTempArchive(self):
		""" Name (Class: BaseTask) """
		return self.__dist_planner_delta_temp_archive

	@DistPlannerDeltaTempArchive.setter
	def DistPlannerDeltaTempArchive(self, value):
		self.__dist_planner_delta_temp_archive = value

	@property
	def DistPlannerTemp(self):
		""" Name (Class: BaseTask) """
		return self.__dist_planner_temp

	@DistPlannerTemp.setter
	def DistPlannerTemp(self, value):
		self.__dist_planner_temp = value

	@property
	def DistPlannerProcessedOne(self):
		""" Name (Class: BaseTask) """
		return self.__dist_planner_processed_one

	@DistPlannerProcessedOne.setter
	def DistPlannerProcessedOne(self, value):
		self.__dist_planner_processed_one = value

	@property
	def DistributionAvailabilityJoined(self):
		""" Name (Class: BaseTask) """
		return self.__distribution_availability_joined

	@DistributionAvailabilityJoined.setter
	def DistributionAvailabilityJoined(self, value):
		self.__distribution_availability_joined = value

	@property
	def DistributionAvailabilityJoinedE2Open(self):
		""" Name (Class: BaseTask) """
		return self.__distribution_availability_joined_e2open

	@DistributionAvailabilityJoinedE2Open.setter
	def DistributionAvailabilityJoinedE2Open(self, value):
		self.__distribution_availability_joined_e2open = value

	@property
	def DistributionAvailabilityJoinedPublix(self):
		""" Name (Class: BaseTask) """
		return self.__distribution_availability_joined_publix

	@DistributionAvailabilityJoinedPublix.setter
	def DistributionAvailabilityJoinedPublix(self, value):
		self.__distribution_availability_joined_publix = value

	@property
	def DistributionAvailabilitySmoothed(self):
		""" Name (Class: BaseTask) """
		return self.__distribution_availability_smoothed

	@DistributionAvailabilitySmoothed.setter
	def DistributionAvailabilitySmoothed(self, value):
		self.__distribution_availability_smoothed = value

	@property
	def DistributionAvailabilitySmoothedPublix(self):
		""" Name (Class: BaseTask) """
		return self.__distribution_availability_smoothed_publix

	@DistributionAvailabilitySmoothedPublix.setter
	def DistributionAvailabilitySmoothedPublix(self, value):
		self.__distribution_availability_smoothed_publix = value

	@property
	def DistributionAvailabilitySubcatgAggFact(self):
		""" Name (Class: BaseTask) """
		return self.__distribution_availability_subcatg_agg_fact

	@DistributionAvailabilitySubcatgAggFact.setter
	def DistributionAvailabilitySubcatgAggFact(self, value):
		self.__distribution_availability_subcatg_agg_fact = value

	@property
	def DistributionAvailabilityWithUpc(self):
		""" Name (Class: BaseTask) """
		return self.__distribution_availability_with_upc

	@DistributionAvailabilityWithUpc.setter
	def DistributionAvailabilityWithUpc(self, value):
		self.__distribution_availability_with_upc = value

	@property
	def DistributionAvailabilityWithUpcPublix(self):
		""" Name (Class: BaseTask) """
		return self.__distribution_availability_with_upc_publix

	@DistributionAvailabilityWithUpcPublix.setter
	def DistributionAvailabilityWithUpcPublix(self, value):
		self.__distribution_availability_with_upc_publix = value

	@property
	def DistributionFact(self):
		""" Name (Class: BaseTask) """
		return self.__distribution_fact

	@DistributionFact.setter
	def DistributionFact(self, value):
		self.__distribution_fact = value

	@property
	def DistributionFactE2Open(self):
		""" Name (Class: BaseTask) """
		return self.__distribution_fact_e2open

	@DistributionFactE2Open.setter
	def DistributionFactE2Open(self, value):
		self.__distribution_fact_e2open = value

	@property
	def DistributionTargetWeeklyAggFact(self):
		""" Name (Class: BaseTask) """
		return self.__distribution_target_weekly_agg_fact

	@DistributionTargetWeeklyAggFact.setter
	def DistributionTargetWeeklyAggFact(self, value):
		self.__distribution_target_weekly_agg_fact = value

	@property
	def DistributionWeeklyAggFact(self):
		""" Name (Class: BaseTask) """
		return self.__distribution_weekly_agg_fact

	@DistributionWeeklyAggFact.setter
	def DistributionWeeklyAggFact(self, value):
		self.__distribution_weekly_agg_fact = value

	@property
	def DataQualityChecksRun(self):
		""" Name (Class: BaseTask) """
		return self.__data_quality_checks_run

	@DataQualityChecksRun.setter
	def DataQualityChecksRun(self, value):
		self.__data_quality_checks_run = value

	@property
	def E2OpenDeltaTemp(self):
		""" Name (Class: BaseTask) """
		return self.__e2open_delta_temp

	@E2OpenDeltaTemp.setter
	def E2OpenDeltaTemp(self, value):
		self.__e2open_delta_temp = value

	@property
	def E2OpenTargetDeltaTemp(self):
		""" Name (Class: BaseTask) """
		return self.__e2open_target_delta_temp

	@E2OpenTargetDeltaTemp.setter
	def E2OpenTargetDeltaTemp(self, value):
		self.__e2open_target_delta_temp = value

	@property
	def EcomDataReleaseControlInsert(self):
		""" Name (Class: BaseTask) """
		return self.__ecom_data_release_control_insert

	@EcomDataReleaseControlInsert.setter
	def EcomDataReleaseControlInsert(self, value):
		self.__ecom_data_release_control_insert = value

	@property
	def GcsFileLoadToBigquery(self):
		""" Name (Class: BaseTask) """
		return self.__gcs_file_load_to_bigquery

	@GcsFileLoadToBigquery.setter
	def GcsFileLoadToBigquery(self, value):
		self.__gcs_file_load_to_bigquery = value

	@property
	def GcsFileSensor(self):
		""" Name (Class: BaseTask) """
		return self.__gcs_file_sensor

	@GcsFileSensor.setter
	def GcsFileSensor(self, value):
		self.__gcs_file_sensor = value

	@property
	def GssNarCustomerFact(self):
		""" Name (Class: BaseTask) """
		return self.__gss_nar_customer_fact

	@GssNarCustomerFact.setter
	def GssNarCustomerFact(self, value):
		self.__gss_nar_customer_fact = value

	@property
	def KeywordSearchStandardizedDataLookup(self):
		""" Name (Class: BaseTask) """
		return self.__keyword_search_standardized_data_lookup

	@KeywordSearchStandardizedDataLookup.setter
	def KeywordSearchStandardizedDataLookup(self, value):
		self.__keyword_search_standardized_data_lookup = value

	@property
	def NarCustomerEnrichment(self):
		""" Name (Class: BaseTask) """
		return self.__nar_customer_enrichment

	@NarCustomerEnrichment.setter
	def NarCustomerEnrichment(self, value):
		self.__nar_customer_enrichment = value

	@property
	def NewProductTracker(self):
		""" Name (Class: BaseTask) """
		return self.__new_product_tracker

	@NewProductTracker.setter
	def NewProductTracker(self, value):
		self.__new_product_tracker = value

	@property
	def NielsenDeltaTempBlue(self):
		""" Name (Class: BaseTask) """
		return self.__nielsen_delta_temp_blue

	@NielsenDeltaTempBlue.setter
	def NielsenDeltaTempBlue(self, value):
		self.__nielsen_delta_temp_blue = value

	@property
	def NielsenDeltaTempEuau(self):
		""" Name (Class: BaseTask) """
		return self.__nielsen_delta_temp_euau

	@NielsenDeltaTempEuau.setter
	def NielsenDeltaTempEuau(self, value):
		self.__nielsen_delta_temp_euau = value

	@property
	def NielsenDeltaTempFrance(self):
		""" Name (Class: BaseTask) """
		return self.__nielsen_delta_temp_france

	@NielsenDeltaTempFrance.setter
	def NielsenDeltaTempFrance(self, value):
		self.__nielsen_delta_temp_france = value

	@property
	def NielsenDeltaTempNar(self):
		""" Name (Class: BaseTask) """
		return self.__nielsen_delta_temp_nar

	@NielsenDeltaTempNar.setter
	def NielsenDeltaTempNar(self, value):
		self.__nielsen_delta_temp_nar = value

	@property
	def NielsenIriDeltaTemp(self):
		""" Name (Class: BaseTask) """
		return self.__nielsen_iri_delta_temp

	@NielsenIriDeltaTemp.setter
	def NielsenIriDeltaTemp(self, value):
		self.__nielsen_iri_delta_temp = value

	@property
	def NielsenIriProcessedOne(self):
		""" Name (Class: BaseTask) """
		return self.__nielsen_iri_processed_one

	@NielsenIriProcessedOne.setter
	def NielsenIriProcessedOne(self, value):
		self.__nielsen_iri_processed_one = value

	@property
	def NielsenIriTemp(self):
		""" Name (Class: BaseTask) """
		return self.__nielsen_iri_temp

	@NielsenIriTemp.setter
	def NielsenIriTemp(self, value):
		self.__nielsen_iri_temp = value

	@property
	def NielsenProductCaTemp(self):
		""" Name (Class: BaseTask) """
		return self.__nielsen_product_ca_temp

	@NielsenProductCaTemp.setter
	def NielsenProductCaTemp(self, value):
		self.__nielsen_product_ca_temp = value

	@property
	def NielsenProductEuauTemp(self):
		""" Name (Class: BaseTask) """
		return self.__nielsen_product_euau_temp

	@NielsenProductEuauTemp.setter
	def NielsenProductEuauTemp(self, value):
		self.__nielsen_product_euau_temp = value

	@property
	def NielsenProductNarNsTemp(self):
		""" Name (Class: BaseTask) """
		return self.__nielsen_product_nar_ns_temp

	@NielsenProductNarNsTemp.setter
	def NielsenProductNarNsTemp(self, value):
		self.__nielsen_product_nar_ns_temp = value

	@property
	def NielsenProductNarTemp(self):
		""" Name (Class: BaseTask) """
		return self.__nielsen_product_nar_temp

	@NielsenProductNarTemp.setter
	def NielsenProductNarTemp(self, value):
		self.__nielsen_product_nar_temp = value

	@property
	def ProductEnrichment(self):
		""" Name (Class: BaseTask) """
		return self.__product_enrichment

	@ProductEnrichment.setter
	def ProductEnrichment(self, value):
		self.__product_enrichment = value

	@property
	def ProductIntlTemp(self):
		""" Name (Class: BaseTask) """
		return self.__product_intl_temp

	@ProductIntlTemp.setter
	def ProductIntlTemp(self, value):
		self.__product_intl_temp = value

	@property
	def ProductNarTemp(self):
		""" Name (Class: BaseTask) """
		return self.__product_nar_temp

	@ProductNarTemp.setter
	def ProductNarTemp(self, value):
		self.__product_nar_temp = value

	@property
	def ProfiteroApiDataExtractConfigInsert(self):
		""" Name (Class: BaseTask) """
		return self.__profitero_api_data_extract_config_insert

	@ProfiteroApiDataExtractConfigInsert.setter
	def ProfiteroApiDataExtractConfigInsert(self, value):
		self.__profitero_api_data_extract_config_insert = value

	@property
	def RepoBranchDelete(self):
		""" Name (Class: BaseTask) """
		return self.__repo_branch_delete

	@RepoBranchDelete.setter
	def RepoBranchDelete(self, value):
		self.__repo_branch_delete = value

	@property
	def SourceTableDataExtractConfigInsert(self):
		""" Name (Class: BaseTask) """
		return self.__source_table_data_extract_config_insert

	@SourceTableDataExtractConfigInsert.setter
	def SourceTableDataExtractConfigInsert(self, value):
		self.__source_table_data_extract_config_insert = value

	@property
	def SrcToEcommCatalogUpcMappingTable(self):
		""" Name (Class: BaseTask) """
		return self.__src_to_ecomm_catalog_upc_mapping_table

	@SrcToEcommCatalogUpcMappingTable.setter
	def SrcToEcommCatalogUpcMappingTable(self, value):
		self.__src_to_ecomm_catalog_upc_mapping_table = value

	@property
	def UnpivotPivot(self):
		""" Name (Class: BaseTask) """
		return self.__unpivot_pivot

	@UnpivotPivot.setter
	def UnpivotPivot(self, value):
		self.__unpivot_pivot = value

	@property
	def UpcConversionProcessAna(self):
		""" Name (Class: BaseTask) """
		return self.__upc_conversion_process_ana

	@UpcConversionProcessAna.setter
	def UpcConversionProcessAna(self, value):
		self.__upc_conversion_process_ana = value

	@property
	def UpcConversionProcessE2Open(self):
		""" Name (Class: BaseTask) """
		return self.__upc_conversion_process_e2open

	@UpcConversionProcessE2Open.setter
	def UpcConversionProcessE2Open(self, value):
		self.__upc_conversion_process_e2open = value

	@property
	def UpcConversionsDnaOnly(self):
		""" Name (Class: BaseTask) """
		return self.__upc_conversions_dna_only

	@UpcConversionsDnaOnly.setter
	def UpcConversionsDnaOnly(self, value):
		self.__upc_conversions_dna_only = value

	@property
	def UpcConversionsE2Open(self):
		""" Name (Class: BaseTask) """
		return self.__upc_conversions_e2open

	@UpcConversionsE2Open.setter
	def UpcConversionsE2Open(self, value):
		self.__upc_conversions_e2open = value

	@property
	def XrefGlobalBrand(self):
		""" Name (Class: BaseTask) """
		return self.__xref_global_brand

	@XrefGlobalBrand.setter
	def XrefGlobalBrand(self, value):
		self.__xref_global_brand = value

	@property
	def XrefGlobalCategory(self):
		""" Name (Class: BaseTask) """
		return self.__xref_global_category

	@XrefGlobalCategory.setter
	def XrefGlobalCategory(self, value):
		self.__xref_global_category = value

	@property
	def XrefOverride(self):
		""" Name (Class: BaseTask) """
		return self.__xref_override

	@XrefOverride.setter
	def XrefOverride(self, value):
		self.__xref_override = value


class GssTask:
	def __init__(self):
		self.__dim_source_to_enterprise_upc_xref = "dim_source_to_enterprise_upc_xref"
		self.__src_to_ecomm_catalog_upc_mapping_table = "src_to_ecomm_catalog_upc_mapping_table"
		self.__customer_processed_zero = "customer_processed_zero"
		self.__gss_nar_customer_fact = "gss_nar_customer_fact"
		self.__product_nar_temp = "product_nar_temp"
		self.__nielsen_product_ca_temp = "nielsen_product_ca_temp"
		self.__nielsen_product_nar_temp = "nielsen_product_nar_temp"
		self.__consolidate_product_nar_temp = "consolidate_product_nar_temp"
		self.__xref_global_brand = "xref_global_brand"
		self.__xref_global_category = "xref_global_category"
		self.__xref_override = "xref_override"
		self.__consolidate_xref_temp = "consolidate_xref_temp"
		self.__derived_xref_info_temp = "derived_xref_info_temp"
		self.__customer_fact_nar = "customer_fact_nar"
		self.__customer_weekly_agg_fact = "customer_weekly_agg_fact"
		self.__ecom_data_release_control_insert = "ecom_data_release_control_insert"
		self.__data_extract_config_update = "data_extract_config_update"

	@property
	def DimSourceToEnterpriseUpcXref(self):
		""" Name (Class: GssTask) """
		return self.__dim_source_to_enterprise_upc_xref

	@DimSourceToEnterpriseUpcXref.setter
	def DimSourceToEnterpriseUpcXref(self, value):
		self.__dim_source_to_enterprise_upc_xref = value

	@property
	def SrcToEcommCatalogUpcMappingTable(self):
		""" Name (Class: GssTask) """
		return self.__src_to_ecomm_catalog_upc_mapping_table

	@SrcToEcommCatalogUpcMappingTable.setter
	def SrcToEcommCatalogUpcMappingTable(self, value):
		self.__src_to_ecomm_catalog_upc_mapping_table = value

	@property
	def CustomerProcessedZero(self):
		""" Name (Class: GssTask) """
		return self.__customer_processed_zero

	@CustomerProcessedZero.setter
	def CustomerProcessedZero(self, value):
		self.__customer_processed_zero = value

	@property
	def GssNarCustomerFact(self):
		""" Name (Class: GssTask) """
		return self.__gss_nar_customer_fact

	@GssNarCustomerFact.setter
	def GssNarCustomerFact(self, value):
		self.__gss_nar_customer_fact = value

	@property
	def ProductNarTemp(self):
		""" Name (Class: GssTask) """
		return self.__product_nar_temp

	@ProductNarTemp.setter
	def ProductNarTemp(self, value):
		self.__product_nar_temp = value

	@property
	def NielsenProductCaTemp(self):
		""" Name (Class: GssTask) """
		return self.__nielsen_product_ca_temp

	@NielsenProductCaTemp.setter
	def NielsenProductCaTemp(self, value):
		self.__nielsen_product_ca_temp = value

	@property
	def NielsenProductNarTemp(self):
		""" Name (Class: GssTask) """
		return self.__nielsen_product_nar_temp

	@NielsenProductNarTemp.setter
	def NielsenProductNarTemp(self, value):
		self.__nielsen_product_nar_temp = value

	@property
	def ConsolidateProductNarTemp(self):
		""" Name (Class: GssTask) """
		return self.__consolidate_product_nar_temp

	@ConsolidateProductNarTemp.setter
	def ConsolidateProductNarTemp(self, value):
		self.__consolidate_product_nar_temp = value

	@property
	def XrefGlobalBrand(self):
		""" Name (Class: GssTask) """
		return self.__xref_global_brand

	@XrefGlobalBrand.setter
	def XrefGlobalBrand(self, value):
		self.__xref_global_brand = value

	@property
	def XrefGlobalCategory(self):
		""" Name (Class: GssTask) """
		return self.__xref_global_category

	@XrefGlobalCategory.setter
	def XrefGlobalCategory(self, value):
		self.__xref_global_category = value

	@property
	def XrefOverride(self):
		""" Name (Class: GssTask) """
		return self.__xref_override

	@XrefOverride.setter
	def XrefOverride(self, value):
		self.__xref_override = value

	@property
	def ConsolidateXrefTemp(self):
		""" Name (Class: GssTask) """
		return self.__consolidate_xref_temp

	@ConsolidateXrefTemp.setter
	def ConsolidateXrefTemp(self, value):
		self.__consolidate_xref_temp = value

	@property
	def DerivedXrefInfoTemp(self):
		""" Name (Class: GssTask) """
		return self.__derived_xref_info_temp

	@DerivedXrefInfoTemp.setter
	def DerivedXrefInfoTemp(self, value):
		self.__derived_xref_info_temp = value

	@property
	def CustomerFactNar(self):
		""" Name (Class: GssTask) """
		return self.__customer_fact_nar

	@CustomerFactNar.setter
	def CustomerFactNar(self, value):
		self.__customer_fact_nar = value

	@property
	def CustomerWeeklyAggFact(self):
		""" Name (Class: GssTask) """
		return self.__customer_weekly_agg_fact

	@CustomerWeeklyAggFact.setter
	def CustomerWeeklyAggFact(self, value):
		self.__customer_weekly_agg_fact = value

	@property
	def EcomDataReleaseControlInsert(self):
		""" Name (Class: GssTask) """
		return self.__ecom_data_release_control_insert

	@EcomDataReleaseControlInsert.setter
	def EcomDataReleaseControlInsert(self, value):
		self.__ecom_data_release_control_insert = value

	@property
	def DataExtractConfigUpdate(self):
		""" Name (Class: GssTask) """
		return self.__data_extract_config_update

	@DataExtractConfigUpdate.setter
	def DataExtractConfigUpdate(self, value):
		self.__data_extract_config_update = value


class EuauTask:
	def __init__(self):
		self.__dim_source_to_enterprise_upc_xref = "dim_source_to_enterprise_upc_xref"
		self.__customer_processed_zero = "customer_processed_zero"
		self.__product_intl_temp = "product_intl_temp"
		self.__nielsen_product_euau_temp = "nielsen_product_euau_temp"
		self.__consolidate_product_euau_temp = "consolidate_product_euau_temp"
		self.__xref_global_brand = "xref_global_brand"
		self.__xref_global_category = "xref_global_category"
		self.__xref_override = "xref_override"
		self.__consolidate_xref_temp = "consolidate_xref_temp"
		self.__derived_xref_info_temp = "derived_xref_info_temp"
		self.__customer_fact_euau = "customer_fact_euau"
		self.__data_quality_checks_run = "data_quality_checks_run"
		self.__customer_weekly_agg_fact = "customer_weekly_agg_fact"
		self.__ecom_data_release_control_insert = "ecom_data_release_control_insert"
		self.__data_extract_config_update = "data_extract_config_update"

	@property
	def DimSourceToEnterpriseUpcXref(self):
		""" Name (Class: EuauTask) """
		return self.__dim_source_to_enterprise_upc_xref

	@DimSourceToEnterpriseUpcXref.setter
	def DimSourceToEnterpriseUpcXref(self, value):
		self.__dim_source_to_enterprise_upc_xref = value

	@property
	def CustomerProcessedZero(self):
		""" Name (Class: EuauTask) """
		return self.__customer_processed_zero

	@CustomerProcessedZero.setter
	def CustomerProcessedZero(self, value):
		self.__customer_processed_zero = value

	@property
	def ProductIntlTemp(self):
		""" Name (Class: EuauTask) """
		return self.__product_intl_temp

	@ProductIntlTemp.setter
	def ProductIntlTemp(self, value):
		self.__product_intl_temp = value

	@property
	def NielsenProductEuauTemp(self):
		""" Name (Class: EuauTask) """
		return self.__nielsen_product_euau_temp

	@NielsenProductEuauTemp.setter
	def NielsenProductEuauTemp(self, value):
		self.__nielsen_product_euau_temp = value

	@property
	def ConsolidateProductEuauTemp(self):
		""" Name (Class: EuauTask) """
		return self.__consolidate_product_euau_temp

	@ConsolidateProductEuauTemp.setter
	def ConsolidateProductEuauTemp(self, value):
		self.__consolidate_product_euau_temp = value

	@property
	def XrefGlobalBrand(self):
		""" Name (Class: EuauTask) """
		return self.__xref_global_brand

	@XrefGlobalBrand.setter
	def XrefGlobalBrand(self, value):
		self.__xref_global_brand = value

	@property
	def XrefGlobalCategory(self):
		""" Name (Class: EuauTask) """
		return self.__xref_global_category

	@XrefGlobalCategory.setter
	def XrefGlobalCategory(self, value):
		self.__xref_global_category = value

	@property
	def XrefOverride(self):
		""" Name (Class: EuauTask) """
		return self.__xref_override

	@XrefOverride.setter
	def XrefOverride(self, value):
		self.__xref_override = value

	@property
	def ConsolidateXrefTemp(self):
		""" Name (Class: EuauTask) """
		return self.__consolidate_xref_temp

	@ConsolidateXrefTemp.setter
	def ConsolidateXrefTemp(self, value):
		self.__consolidate_xref_temp = value

	@property
	def DerivedXrefInfoTemp(self):
		""" Name (Class: EuauTask) """
		return self.__derived_xref_info_temp

	@DerivedXrefInfoTemp.setter
	def DerivedXrefInfoTemp(self, value):
		self.__derived_xref_info_temp = value

	@property
	def CustomerFactEuau(self):
		""" Name (Class: EuauTask) """
		return self.__customer_fact_euau

	@CustomerFactEuau.setter
	def CustomerFactEuau(self, value):
		self.__customer_fact_euau = value

	@property
	def DataQualityChecksRun(self):
		""" Name (Class: EuauTask) """
		return self.__data_quality_checks_run

	@DataQualityChecksRun.setter
	def DataQualityChecksRun(self, value):
		self.__data_quality_checks_run = value

	@property
	def CustomerWeeklyAggFact(self):
		""" Name (Class: EuauTask) """
		return self.__customer_weekly_agg_fact

	@CustomerWeeklyAggFact.setter
	def CustomerWeeklyAggFact(self, value):
		self.__customer_weekly_agg_fact = value

	@property
	def EcomDataReleaseControlInsert(self):
		""" Name (Class: EuauTask) """
		return self.__ecom_data_release_control_insert

	@EcomDataReleaseControlInsert.setter
	def EcomDataReleaseControlInsert(self, value):
		self.__ecom_data_release_control_insert = value

	@property
	def DataExtractConfigUpdate(self):
		""" Name (Class: EuauTask) """
		return self.__data_extract_config_update

	@DataExtractConfigUpdate.setter
	def DataExtractConfigUpdate(self, value):
		self.__data_extract_config_update = value


class AaTask:
	def __init__(self):
		self.__build_api_processed_table = "build_api_processed_table"
		self.__data_extract_config_update = "data_extract_config_update"

	@property
	def BuildApiProcessedTable(self):
		""" Name (Class: AaTask) """
		return self.__build_api_processed_table

	@BuildApiProcessedTable.setter
	def BuildApiProcessedTable(self, value):
		self.__build_api_processed_table = value

	@property
	def DataExtractConfigUpdate(self):
		""" Name (Class: AaTask) """
		return self.__data_extract_config_update

	@DataExtractConfigUpdate.setter
	def DataExtractConfigUpdate(self, value):
		self.__data_extract_config_update = value


class GcsFileLoadTask:
	def __init__(self):
		self.__gcs_file_sensor = "gcs_file_sensor"
		self.__gcs_file_load_to_bigquery = "gcs_file_load_to_bigquery"

	@property
	def GcsFileSensor(self):
		""" Name (Class: GcsFileLoadTask) """
		return self.__gcs_file_sensor

	@GcsFileSensor.setter
	def GcsFileSensor(self, value):
		self.__gcs_file_sensor = value

	@property
	def GcsFileLoadToBigquery(self):
		""" Name (Class: GcsFileLoadTask) """
		return self.__gcs_file_load_to_bigquery

	@GcsFileLoadToBigquery.setter
	def GcsFileLoadToBigquery(self, value):
		self.__gcs_file_load_to_bigquery = value


class GssTableIngestionTask:
	def __init__(self):
		self.__dim_source_to_enterprise_upc_xref = "dim_source_to_enterprise_upc_xref"
		self.__src_to_ecomm_catalog_upc_mapping_table = "src_to_ecomm_catalog_upc_mapping_table"
		self.__customer_processed_zero = "customer_processed_zero"
		self.__gss_nar_customer_fact = "gss_nar_customer_fact"
		self.__product_nar_temp = "product_nar_temp"
		self.__nielsen_product_nar_temp = "nielsen_product_nar_temp"
		self.__consolidate_product_nar_temp = "consolidate_product_nar_temp"
		self.__xref_global_brand = "xref_global_brand"
		self.__xref_global_category = "xref_global_category"
		self.__xref_override = "xref_override"
		self.__consolidate_xref_temp = "consolidate_xref_temp"
		self.__derived_xref_info_temp = "derived_xref_info_temp"
		self.__customer_fact_nar = "customer_fact_nar"
		self.__data_quality_checks_run = "data_quality_checks_run"
		self.__customer_weekly_agg_fact = "customer_weekly_agg_fact"
		self.__ecom_data_release_control_insert = "ecom_data_release_control_insert"
		self.__data_extract_config_update = "data_extract_config_update"

	@property
	def DimSourceToEnterpriseUpcXref(self):
		""" Name (Class: GssTableIngestionTask) """
		return self.__dim_source_to_enterprise_upc_xref

	@DimSourceToEnterpriseUpcXref.setter
	def DimSourceToEnterpriseUpcXref(self, value):
		self.__dim_source_to_enterprise_upc_xref = value

	@property
	def SrcToEcommCatalogUpcMappingTable(self):
		""" Name (Class: GssTableIngestionTask) """
		return self.__src_to_ecomm_catalog_upc_mapping_table

	@SrcToEcommCatalogUpcMappingTable.setter
	def SrcToEcommCatalogUpcMappingTable(self, value):
		self.__src_to_ecomm_catalog_upc_mapping_table = value

	@property
	def CustomerProcessedZero(self):
		""" Name (Class: GssTableIngestionTask) """
		return self.__customer_processed_zero

	@CustomerProcessedZero.setter
	def CustomerProcessedZero(self, value):
		self.__customer_processed_zero = value

	@property
	def GssNarCustomerFact(self):
		""" Name (Class: GssTableIngestionTask) """
		return self.__gss_nar_customer_fact

	@GssNarCustomerFact.setter
	def GssNarCustomerFact(self, value):
		self.__gss_nar_customer_fact = value

	@property
	def ProductNarTemp(self):
		""" Name (Class: GssTableIngestionTask) """
		return self.__product_nar_temp

	@ProductNarTemp.setter
	def ProductNarTemp(self, value):
		self.__product_nar_temp = value

	@property
	def NielsenProductNarTemp(self):
		""" Name (Class: GssTableIngestionTask) """
		return self.__nielsen_product_nar_temp

	@NielsenProductNarTemp.setter
	def NielsenProductNarTemp(self, value):
		self.__nielsen_product_nar_temp = value

	@property
	def ConsolidateProductNarTemp(self):
		""" Name (Class: GssTableIngestionTask) """
		return self.__consolidate_product_nar_temp

	@ConsolidateProductNarTemp.setter
	def ConsolidateProductNarTemp(self, value):
		self.__consolidate_product_nar_temp = value

	@property
	def XrefGlobalBrand(self):
		""" Name (Class: GssTableIngestionTask) """
		return self.__xref_global_brand

	@XrefGlobalBrand.setter
	def XrefGlobalBrand(self, value):
		self.__xref_global_brand = value

	@property
	def XrefGlobalCategory(self):
		""" Name (Class: GssTableIngestionTask) """
		return self.__xref_global_category

	@XrefGlobalCategory.setter
	def XrefGlobalCategory(self, value):
		self.__xref_global_category = value

	@property
	def XrefOverride(self):
		""" Name (Class: GssTableIngestionTask) """
		return self.__xref_override

	@XrefOverride.setter
	def XrefOverride(self, value):
		self.__xref_override = value

	@property
	def ConsolidateXrefTemp(self):
		""" Name (Class: GssTableIngestionTask) """
		return self.__consolidate_xref_temp

	@ConsolidateXrefTemp.setter
	def ConsolidateXrefTemp(self, value):
		self.__consolidate_xref_temp = value

	@property
	def DerivedXrefInfoTemp(self):
		""" Name (Class: GssTableIngestionTask) """
		return self.__derived_xref_info_temp

	@DerivedXrefInfoTemp.setter
	def DerivedXrefInfoTemp(self, value):
		self.__derived_xref_info_temp = value

	@property
	def CustomerFactNar(self):
		""" Name (Class: GssTableIngestionTask) """
		return self.__customer_fact_nar

	@CustomerFactNar.setter
	def CustomerFactNar(self, value):
		self.__customer_fact_nar = value

	@property
	def DataQualityChecksRun(self):
		""" Name (Class: GssTableIngestionTask) """
		return self.__data_quality_checks_run

	@DataQualityChecksRun.setter
	def DataQualityChecksRun(self, value):
		self.__data_quality_checks_run = value

	@property
	def CustomerWeeklyAggFact(self):
		""" Name (Class: GssTableIngestionTask) """
		return self.__customer_weekly_agg_fact

	@CustomerWeeklyAggFact.setter
	def CustomerWeeklyAggFact(self, value):
		self.__customer_weekly_agg_fact = value

	@property
	def EcomDataReleaseControlInsert(self):
		""" Name (Class: GssTableIngestionTask) """
		return self.__ecom_data_release_control_insert

	@EcomDataReleaseControlInsert.setter
	def EcomDataReleaseControlInsert(self, value):
		self.__ecom_data_release_control_insert = value

	@property
	def DataExtractConfigUpdate(self):
		""" Name (Class: GssTableIngestionTask) """
		return self.__data_extract_config_update

	@DataExtractConfigUpdate.setter
	def DataExtractConfigUpdate(self, value):
		self.__data_extract_config_update = value

