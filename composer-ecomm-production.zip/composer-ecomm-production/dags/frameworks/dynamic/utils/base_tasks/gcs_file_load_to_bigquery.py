from dags.frameworks.dynamic.utils.classes.attributes import Attribute
from dags.frameworks.dynamic.utils.classes.data_types import DataType
from dags.frameworks.dynamic.utils.classes.parameters import Parameter
from dags.frameworks.dynamic.utils.classes.task_config import TaskConfig
from dags.frameworks.dynamic.utils.classes.transformations import Transform
from dags.frameworks.dynamic.utils.classes.file_types import FileType
from dags.frameworks.dynamic.utils.classes.file_delimiters import FileDelimiter

config = TaskConfig()
transform = Transform()
dataType = DataType()
param = Parameter()
attribute = Attribute()
fileType = FileType()
fileDelimiter = FileDelimiter()

load = {
    config.TaskName: "gcs_file_load_to_bigquery",
    config.TaskDescription: "load_file_to_bigquery",
    config.BigQueryOperator: "GCSFileLoad",
    config.BigQueryConnId: "bigquery_ecomm_dlf_data",
    config.DestinationProjectVariable: "ecomm-dlf-data",
    config.SqlOrScriptPath: "",
    config.IsStoredProcFlag: True,
    config.SprocParams: [
        {
            attribute.Name: param.DestinationProject,
            attribute.Value: "ecomm-dlf-data",
            attribute.IsInferredFlag: True,
            attribute.DataTransformationType: transform.UseAsIs,
            attribute.DataType: dataType.Int
        },
        {
            attribute.Name: param.DestinationDataset,
            attribute.Value: "raw",
            attribute.IsInferredFlag: True,
            attribute.DataTransformationType: transform.UseAsIs,
            attribute.DataType: dataType.Int
        },
        {
            attribute.Name: param.DestinationTable,
            attribute.Value: "file_load_table_name",
            attribute.IsInferredFlag: True,
            attribute.DataTransformationType: transform.UseAsIs,
            attribute.DataType: dataType.Int
        },
        {
            attribute.Name: param.FileBucketName,
            attribute.Value: "landing",
            attribute.IsInferredFlag: True,
            attribute.DataTransformationType: transform.UseAsIs,
            attribute.DataType: dataType.Int
        },
        {
            attribute.Name: param.FilePath,
            attribute.Value: "",
            attribute.IsInferredFlag: True,
            attribute.DataTransformationType: transform.UseAsIs,
            attribute.DataType: dataType.Int
        },
        {
            attribute.Name: param.FileName,
            attribute.Value: "",
            attribute.IsInferredFlag: True,
            attribute.DataTransformationType: transform.UseAsIs,
            attribute.DataType: dataType.Int
        },
        {
            attribute.Name: param.FileType,
            attribute.Value: fileType.Csv,
            attribute.IsInferredFlag: True,
            attribute.DataTransformationType: transform.UseAsIs,
            attribute.DataType: dataType.Int
        },
        {
            attribute.Name: param.FileFieldDelimiter,
            attribute.Value: fileDelimiter.Comma,
            attribute.IsInferredFlag: True,
            attribute.DataTransformationType: transform.UseAsIs,
            attribute.DataType: dataType.Int
        },
        {
            attribute.Name: param.FileLoadStrategy,
            attribute.Value: "append",
            attribute.IsInferredFlag: True,
            attribute.DataTransformationType: transform.UseAsIs,
            attribute.DataType: dataType.Int
        },
        {
            attribute.Name: param.FileSkipRows,
            attribute.Value: "0",
            attribute.IsInferredFlag: True,
            attribute.DataTransformationType: transform.UseAsIs,
            attribute.DataType: dataType.Int
        },
        {
            attribute.Name: param.FileEncodingType,
            attribute.Value: "unicode_escape",
            attribute.IsInferredFlag: True,
            attribute.DataTransformationType: transform.UseAsIs,
            attribute.DataType: dataType.Int
        },
    ]
}
