from dags.frameworks.dynamic.utils.classes.attributes import Attribute
from dags.frameworks.dynamic.utils.classes.data_types import DataType
from dags.frameworks.dynamic.utils.classes.parameters import Parameter
from dags.frameworks.dynamic.utils.classes.task_config import TaskConfig
from dags.frameworks.dynamic.utils.classes.transformations import Transform

config = TaskConfig()
transform = Transform()
dataType = DataType()
param = Parameter()
attribute = Attribute()

load = {
  config.TaskName: "upc_conversions_e2open",
  config.TaskDescription: "insert_into_distribution_availability_upc_conversions",
  config.BigQueryOperator: "BigQueryExecuteQueryOperator",
  config.BigQueryConnId: "bigquery_ecomm_dlf_data",
  config.DestinationProjectVariable: "ecomm-dlf-data",
  config.SqlOrScriptPath: "ecomm_sproc_ana_e2open_upc_conversions",
  config.IsStoredProcFlag: True,
  config.SprocParams: [
    {
      attribute.Name: param.SourceProject,
      attribute.Value: "ecomm-dlf-data",
      attribute.IsInferredFlag: True,
      attribute.DataTransformationType:  transform.UseAsIs,
      attribute.DataType: dataType.String
    },
    {
      attribute.Name: param.IntermediateProject,
      attribute.Value: "edw-prd-e567f9",
      attribute.IsInferredFlag: True,
      attribute.DataTransformationType: transform.UseAsIs,
      attribute.DataType: dataType.String
    },
    {
      attribute.Name: param.DestinationDataset,
      attribute.Value: "processed",
      attribute.IsInferredFlag: True,
      attribute.DataTransformationType: transform.UseAsIs,
      attribute.DataType: dataType.String
    },
    {
      attribute.Name: param.IntermediateDataset,
      attribute.Value: "enterprise",
      attribute.IsInferredFlag: True,
      attribute.DataTransformationType: transform.UseAsIs,
      attribute.DataType: dataType.String
    },
    {
      attribute.Name: param.SourceTable,
      attribute.Value: "distribution_availability_with_upc_fact",
      attribute.IsInferredFlag: True,
      attribute.DataTransformationType: transform.UseAsPrefix,
      attribute.DataType: dataType.String
    },
    {
      attribute.Name: param.IntermediateTable,
      attribute.Value: "weekly_agg_fact",
      attribute.IsInferredFlag: True,
      attribute.DataTransformationType: transform.UseAsPrefix,
      attribute.DataType: dataType.String
    },
    {
      attribute.Name: param.DestinationFeedName,
      attribute.Value: "DISTRIBUTION_AVAILABILITY_SUBCATG_AGG_FACT",
      attribute.IsInferredFlag: True,
      attribute.DataTransformationType: transform.UseAsPrefix,
      attribute.DataType: dataType.String
    },
    {
      attribute.Name: param.DestinationTable,
      attribute.Value: "distribution_availability_upc_conversions",
      attribute.IsInferredFlag: True,
      attribute.DataTransformationType: transform.UseAsPrefix,
      attribute.DataType: dataType.String
    },
    {
      attribute.Name: param.SourceFeedName,
      attribute.Value: "feed_name",
      attribute.IsInferredFlag: True,
      attribute.DataTransformationType: transform.UseAsIs,
      attribute.DataType: dataType.String
    }
  ]
}