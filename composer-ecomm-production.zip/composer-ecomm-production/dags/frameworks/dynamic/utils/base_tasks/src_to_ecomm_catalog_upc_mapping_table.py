from dags.frameworks.dynamic.utils.classes.attributes import Attribute
from dags.frameworks.dynamic.utils.classes.data_types import DataType
from dags.frameworks.dynamic.utils.classes.parameters import Parameter
from dags.frameworks.dynamic.utils.classes.task_config import TaskConfig
from dags.frameworks.dynamic.utils.classes.transformations import Transform

config = TaskConfig()
transform = Transform()
dataType = DataType()
param = Parameter()
attribute = Attribute()

load = {
  config.TaskName: "src_to_ecomm_catalog_upc_mapping_table",
  config.TaskDescription: "src_to_ecomm_catalog_upc_mapping_table",
  config.BigQueryOperator: "BigQueryExecuteQueryOperator",
  config.BigQueryConnId: "bigquery_ecomm_dlf_data",
  config.DestinationProjectVariable: "ecomm-dlf-data",
  config.SqlOrScriptPath: "ecomm_sproc_src_to_ecomm_catalog_upc_mapping_table",
  config.IsStoredProcFlag: True,
  config.SprocParams: [
    {
      attribute.Name: param.DestinationProject,
      attribute.Value: "ecomm-analytics",
      attribute.IsInferredFlag: True,
      attribute.DataTransformationType: transform.UseAsIs,
      attribute.DataType: dataType.String
    },
    {
      attribute.Name: param.SourceFeedName,
      attribute.Value: "feed_name",
      attribute.IsInferredFlag: True,
      attribute.DataTransformationType: transform.UseAsIs,
      attribute.DataType: dataType.String
    },
    {
      attribute.Name: param.SourceDataset,
      attribute.Value: "transient",
      attribute.IsInferredFlag: True,
      attribute.DataTransformationType:  transform.UseAsIs,
      attribute.DataType: dataType.String
    },
    {
      attribute.Name: param.SourceTable,
      attribute.Value: "feed_name_delta_temp",
      attribute.IsInferredFlag: True,
      attribute.DataTransformationType:  transform.UseAsIs,
      attribute.DataType: dataType.String
    },
    {
      attribute.Name: param.UpcColumnName,
      attribute.Value: "upc",
      attribute.IsInferredFlag: True,
      attribute.DataTransformationType: transform.UseAsIs,
      attribute.DataType: dataType.String
    },
    {
      attribute.Name: param.RpcColumnName,
      attribute.Value: "rpc",
      attribute.IsInferredFlag: True,
      attribute.DataTransformationType:  transform.UseAsIs,
      attribute.DataType: dataType.String
    },
    {
      attribute.Name: param.ProductTitleColumnName,
      attribute.Value: "source_item_name",
      attribute.IsInferredFlag: True,
      attribute.DataTransformationType: transform.UseAsIs,
      attribute.DataType: dataType.String
    },
    {
      attribute.Name: param.ColumnName,
      attribute.Value: "customer_name",
      attribute.IsInferredFlag: False,
      attribute.DataTransformationType: transform.UseAsIs,
      attribute.DataType: dataType.String
    },
    {
      attribute.Name: param.UpcCheckDigitFlag,
      attribute.Value: "True",
      attribute.IsInferredFlag: True,
      attribute.DataTransformationType: transform.UseAsIs,
      attribute.DataType: dataType.Bool
    },
    {
      attribute.Name: param.Threshold,
      attribute.Value: "0.8",
      attribute.IsInferredFlag: True,
      attribute.DataTransformationType: transform.UseAsIs,
      attribute.DataType: dataType.Float
    }
  ]
}