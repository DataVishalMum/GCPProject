from dags.frameworks.dynamic.utils.classes.attributes import Attribute
from dags.frameworks.dynamic.utils.classes.data_types import DataType
from dags.frameworks.dynamic.utils.classes.parameters import Parameter
from dags.frameworks.dynamic.utils.classes.task_config import TaskConfig
from dags.frameworks.dynamic.utils.classes.transformations import Transform

config = TaskConfig()
transform = Transform()
dataType = DataType()
param = Parameter()
attribute = Attribute()

load = {
    config.TaskName: "dist_planner_delta_temp_archive",
    config.TaskDescription: "Pull data from dist_planner to dlf",
    config.BigQueryOperator: "BigQueryExecuteQueryOperator",
    config.BigQueryConnId: "bigquery_ecomm_dlf_data",
    config.DestinationProjectVariable: "ecomm-dlf-data",
    config.SqlOrScriptPath: "ecomm_sproc_ana_dist_planner_delta_temp_archive",
    config.IsStoredProcFlag: True,
    config.SprocParams: [
        {
            attribute.Name: param.DestinationProject,
            attribute.Value: "ecomm-dlf-data",
            attribute.IsInferredFlag: True,
            attribute.DataTransformationType: transform.UseAsIs,
            attribute.DataType: dataType.String
        },
        {
            attribute.Name: param.IntermediateProject,
            attribute.Value: "edw-prd-e567f9",
            attribute.IsInferredFlag: True,
            attribute.DataTransformationType: transform.UseAsIs,
            attribute.DataType: dataType.String
        },
        {
            attribute.Name: param.IntermediateDataset,
            attribute.Value: "sales_ops",
            attribute.IsInferredFlag: True,
            attribute.DataTransformationType: transform.UseAsIs,
            attribute.DataType: dataType.String
        },
        {
            attribute.Name: param.DestinationDataset,
            attribute.Value: "transient",
            attribute.IsInferredFlag: True,
            attribute.DataTransformationType: transform.UseAsIs,
            attribute.DataType: dataType.String
        },
        {
            attribute.Name: param.DestinationTable,
            attribute.Value: "publix_instacart_dist_planner_delta_temp_archive",
            attribute.IsInferredFlag: True,
            attribute.DataTransformationType: transform.UseAsIs,
            attribute.DataType: dataType.String
        },
        {
            attribute.Name: param.SourceFeedName,
            attribute.Value: "feed_name",
            attribute.IsInferredFlag: True,
            attribute.DataTransformationType: transform.UseAsIs,
            attribute.DataType: dataType.String
        }
    ]
}
