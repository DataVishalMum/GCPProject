from dags.frameworks.dynamic.utils.classes.attributes import Attribute
from dags.frameworks.dynamic.utils.classes.data_types import DataType
from dags.frameworks.dynamic.utils.classes.parameters import Parameter
from dags.frameworks.dynamic.utils.classes.task_config import TaskConfig
from dags.frameworks.dynamic.utils.classes.transformations import Transform

config = TaskConfig()
transform = Transform()
dataType = DataType()
param = Parameter()
attribute = Attribute()

load = {
  config.TaskName: "nielsen_delta_temp_france",
  config.TaskDescription: "insert_into_nielsen_france_delta_temp_tables",
  config.BigQueryOperator: "BigQueryExecuteQueryOperator",
  config.BigQueryConnId: "bigquery_ecomm_dlf_data",
  config.DestinationProjectVariable: "ecomm-dlf-data",
  config.SqlOrScriptPath: "ecomm_sproc_nielsen_delta_temp_france",
  config.IsStoredProcFlag: True,
  config.SprocParams: [
    {
      attribute.Name: param.DestinationProject,
      attribute.Value: "ecomm-dlf-data",
      attribute.IsInferredFlag: True,
      attribute.DataTransformationType: transform.UseAsIs,
      attribute.DataType: dataType.String
    },
    {
      attribute.Name: param.DestinationDataset,
      attribute.Value: "transient",
      attribute.IsInferredFlag: True,
      attribute.DataTransformationType:  transform.UseAsIs,
      attribute.DataType: dataType.String
    },
    {
      attribute.Name: param.SourceProject,
      attribute.Value: "ecomm-edw-prd",
      attribute.IsInferredFlag: True,
      attribute.DataTransformationType: transform.UseAsIs,
      attribute.DataType: dataType.String
    },
    {
      attribute.Name: param.SourceDataset,
      attribute.Value: "syndicated_data",
      attribute.IsInferredFlag: True,
      attribute.DataTransformationType: transform.UseAsIs,
      attribute.DataType: dataType.String
    },
    {
      attribute.Name: param.SourceFeedName,
      attribute.Value: "feed_name",
      attribute.IsInferredFlag: True,
      attribute.DataTransformationType: transform.UseAsIs,
      attribute.DataType: dataType.String
    },
    {
      attribute.Name: param.FeedGrain,
      attribute.Value: "WEEK",
      attribute.IsInferredFlag: True,
      attribute.DataTransformationType: transform.UseAsIs,
      attribute.DataType: dataType.String
    },
    {
      attribute.Name: param.RecordKey,
      attribute.Value: "999999",
      attribute.IsInferredFlag: True,
      attribute.DataTransformationType:  transform.UseAsIs,
      attribute.DataType: dataType.Int
    }
  ]
}