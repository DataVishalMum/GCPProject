from dags.frameworks.dynamic.utils.classes.attributes import Attribute
from dags.frameworks.dynamic.utils.classes.data_types import DataType
from dags.frameworks.dynamic.utils.classes.parameters import Parameter
from dags.frameworks.dynamic.utils.classes.task_config import TaskConfig
from dags.frameworks.dynamic.utils.classes.transformations import Transform

config = TaskConfig()
transform = Transform()
dataType = DataType()
param = Parameter()
attribute = Attribute()

load = {
    config.TaskName: "gcs_file_sensor",
    config.TaskDescription: "streaming_check_for_file_availability",
    config.BigQueryOperator: "GoogleCloudStoragePrefixSensor",
    config.BigQueryConnId: "bigquery_ecomm_dlf_data",
    config.DestinationProjectVariable: "ecomm-dlf-data",
    config.SqlOrScriptPath: "",
    config.IsStoredProcFlag: True,
    config.SprocParams: [
        {
            attribute.Name: param.DestinationProject,
            attribute.Value: "ecomm-dlf-data",
            attribute.IsInferredFlag: True,
            attribute.DataTransformationType: transform.UseAsIs,
            attribute.DataType: dataType.Int
        },
        {
            attribute.Name: param.DestinationDataset,
            attribute.Value: "",
            attribute.IsInferredFlag: True,
            attribute.DataTransformationType: transform.UseAsIs,
            attribute.DataType: dataType.Int
        },
        {
            attribute.Name: param.DestinationTable,
            attribute.Value: "",
            attribute.IsInferredFlag: True,
            attribute.DataTransformationType: transform.UseAsIs,
            attribute.DataType: dataType.Int
        },
        {
            attribute.Name: param.FileBucketName,
            attribute.Value: "landing",
            attribute.IsInferredFlag: True,
            attribute.DataTransformationType: transform.UseAsIs,
            attribute.DataType: dataType.Int
        },
        {
            attribute.Name: param.FilePath,
            attribute.Value: "",
            attribute.IsInferredFlag: True,
            attribute.DataTransformationType: transform.UseAsIs,
            attribute.DataType: dataType.Int
        },
        {
            attribute.Name: param.FileName,
            attribute.Value: "",
            attribute.IsInferredFlag: True,
            attribute.DataTransformationType: transform.UseAsIs,
            attribute.DataType: dataType.Int
        },
        {
            attribute.Name: param.FileType,
            attribute.Value: "CSV",
            attribute.IsInferredFlag: True,
            attribute.DataTransformationType: transform.UseAsIs,
            attribute.DataType: dataType.Int
        },
        {
            attribute.Name: param.FileFieldDelimiter,
            attribute.Value: ",",
            attribute.IsInferredFlag: True,
            attribute.DataTransformationType: transform.UseAsIs,
            attribute.DataType: dataType.Int
        },
        {
            attribute.Name: param.FileLoadStrategy,
            attribute.Value: "append",
            attribute.IsInferredFlag: True,
            attribute.DataTransformationType: transform.UseAsIs,
            attribute.DataType: dataType.Int
        },
        {
            attribute.Name: param.FileCheckerTimeout,
            attribute.Value: "3600",
            attribute.IsInferredFlag: True,
            attribute.DataTransformationType: transform.UseAsIs,
            attribute.DataType: dataType.Int
        },
        {
            attribute.Name: param.FileCheckInterval,
            attribute.Value: "900",
            attribute.IsInferredFlag: True,
            attribute.DataTransformationType: transform.UseAsIs,
            attribute.DataType: dataType.Int
        },
    ]
}
