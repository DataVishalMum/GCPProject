from dags.frameworks.dynamic.utils.classes.attributes import Attribute
from dags.frameworks.dynamic.utils.classes.data_types import DataType
from dags.frameworks.dynamic.utils.classes.parameters import Parameter
from dags.frameworks.dynamic.utils.classes.task_config import TaskConfig
from dags.frameworks.dynamic.utils.classes.transformations import Transform

config = TaskConfig()
transform = Transform()
dataType = DataType()
param = Parameter()
attribute = Attribute()

load = {
  config.TaskName: "product_enrichment",
  config.TaskDescription: "insert_into_customer_enrichment",
  config.BigQueryOperator: "BigQueryExecuteQueryOperator",
  config.BigQueryConnId: "bigquery_ecomm_dlf_data",
  config.DestinationProjectVariable: "ecomm-dlf-data",
  config.SqlOrScriptPath: "ecomm_commnon_sproc_product_enrichment",
  config.IsStoredProcFlag: True,
  config.SprocParams: [
    {
      attribute.Name: param.DestinationProject,
      attribute.Value: "ecomm-dlf-data",
      attribute.IsInferredFlag: True,
      attribute.DataTransformationType:  transform.UseAsIs,
      attribute.DataType: dataType.String
    },
    {
      attribute.Name: param.DestinationDataset,
      attribute.Value: "transient",
      attribute.IsInferredFlag: True,
      attribute.DataTransformationType:  transform.UseAsIs,
      attribute.DataType: dataType.String
    },
    {
      attribute.Name: param.DestinationTable,
      attribute.Value: "ecomm_common_product_enrichment",
      attribute.IsInferredFlag: True,
      attribute.DataTransformationType:  transform.UseAsIs,
      attribute.DataType: dataType.String
    },
    {
      attribute.Name: param.SourceFeedName,
      attribute.Value: "feed_name",
      attribute.IsInferredFlag: True,
      attribute.DataTransformationType: transform.UseAsIs,
      attribute.DataType: dataType.String
    }
  ]
}