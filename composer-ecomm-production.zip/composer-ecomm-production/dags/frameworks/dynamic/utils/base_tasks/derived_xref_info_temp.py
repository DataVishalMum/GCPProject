from dags.frameworks.dynamic.utils.classes.attributes import Attribute
from dags.frameworks.dynamic.utils.classes.data_types import DataType
from dags.frameworks.dynamic.utils.classes.parameters import Parameter
from dags.frameworks.dynamic.utils.classes.task_config import TaskConfig
from dags.frameworks.dynamic.utils.classes.transformations import Transform

config = TaskConfig()
transform = Transform()
dataType = DataType()
param = Parameter()
attribute = Attribute()

load = {
  config.TaskName: "derived_xref_info_temp",
  config.TaskDescription: "load_data_into_derived_xref_info",
  config.BigQueryOperator: "BigQueryExecuteQueryOperator",
  config.BigQueryConnId: "bigquery_ecomm_dlf_data",
  config.DestinationProjectVariable: "ecomm-dlf-data",
  config.SqlOrScriptPath: "ecomm_sproc_derived_xref_info_temp",
  config.IsStoredProcFlag: True,
  config.SprocParams: [
    {
      attribute.Name: param.SourceProject,
      attribute.Value: "ecomm-dlf-data",
      attribute.IsInferredFlag: True,
      attribute.DataTransformationType:  transform.UseAsIs,
      attribute.DataType: dataType.String
    },
    {
      attribute.Name: param.SourceDataset,
      attribute.Value: "transient",
      attribute.IsInferredFlag: True,
      attribute.DataTransformationType: transform.UseAsIs,
      attribute.DataType: dataType.String
    },
    {
      attribute.Name: param.XrefTable,
      attribute.Value: "feed_name_consolidate_xref_temp",
      attribute.IsInferredFlag: True,
      attribute.DataTransformationType: transform.UseAsIs,
      attribute.DataType: dataType.String
    },
    {
      attribute.Name: param.SourceTable,
      attribute.Value: "feed_name_consolidate_product_temp",
      attribute.IsInferredFlag: True,
      attribute.DataTransformationType: transform.UseAsIs,
      attribute.DataType: dataType.String
    },
    {
      attribute.Name: param.DestinationTable,
      attribute.Value: "feed_name_derived_xref_info_temp",
      attribute.IsInferredFlag: True,
      attribute.DataTransformationType: transform.UseAsIs,
      attribute.DataType: dataType.String
    },
    {
      attribute.Name: param.SourceCustomerName,
      attribute.Value: "customer_name",
      attribute.IsInferredFlag: True,
      attribute.DataTransformationType: transform.UseAsIs,
      attribute.DataType: dataType.String
    },
    {
      attribute.Name: param.SourceFeedName,
      attribute.Value: "feed_name",
      attribute.IsInferredFlag: True,
      attribute.DataTransformationType: transform.UseAsIs,
      attribute.DataType: dataType.String
    },
    {
      attribute.Name: param.DestinationDataset,
      attribute.Value: "processed",
      attribute.IsInferredFlag: True,
      attribute.DataTransformationType: transform.UseAsIs,
      attribute.DataType: dataType.String
    }
  ]
}