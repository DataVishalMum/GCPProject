from dags.frameworks.dynamic.utils.classes.attributes import Attribute
from dags.frameworks.dynamic.utils.classes.data_types import DataType
from dags.frameworks.dynamic.utils.classes.parameters import Parameter
from dags.frameworks.dynamic.utils.classes.task_config import TaskConfig
from dags.frameworks.dynamic.utils.classes.transformations import Transform

config = TaskConfig()
transform = Transform()
dataType = DataType()
param = Parameter()
attribute = Attribute()

load = {
    config.TaskName: "profitero_api_data_extract_config_insert",
    config.TaskDescription: "Pull data from Profitero dataset to dlf",
    config.BigQueryOperator: "BigQueryExecuteQueryOperator",
    config.BigQueryConnId: "bigquery_ecomm_dlf_data",
    config.DestinationProjectVariable: "ecomm-dlf-data",
    config.SqlOrScriptPath: "ecomm_sproc_profitero_api_data_extract_config_insert",
    config.IsStoredProcFlag: True,
    config.SprocParams: [
        {
            attribute.Name: param.DestinationProject,
            attribute.Value: "ecomm-dlf-data",
            attribute.IsInferredFlag: True,
            attribute.DataTransformationType: transform.UseAsIs,
            attribute.DataType: dataType.String
        },
        {
            attribute.Name: param.DestinationDataset,
            attribute.Value: "transient",
            attribute.IsInferredFlag: True,
            attribute.DataTransformationType: transform.UseAsIs,
            attribute.DataType: dataType.String
        },
        {
            attribute.Name: param.SourceProject,
            attribute.Value: "ecomm-dlf-data",
            attribute.IsInferredFlag: True,
            attribute.DataTransformationType: transform.UseAsIs,
            attribute.DataType: dataType.String
        },
        {
            attribute.Name: param.SourceDataset,
            attribute.Value: "src_dataset",
            attribute.IsInferredFlag: True,
            attribute.DataTransformationType: transform.UseAsIs,
            attribute.DataType: dataType.String
        },
        {
            attribute.Name: param.SourceTable,
            attribute.Value: "src_table",
            attribute.IsInferredFlag: True,
            attribute.DataTransformationType: transform.UseAsIs,
            attribute.DataType: dataType.String
        },
        {
            attribute.Name: param.ColumnName,
            attribute.Value: "date_column_name",
            attribute.IsInferredFlag: True,
            attribute.DataTransformationType: transform.UseAsIs,
            attribute.DataType: dataType.String
        },
        {
            attribute.Name: param.SourceFeedName,
            attribute.Value: "feed_name",
            attribute.IsInferredFlag: True,
            attribute.DataTransformationType: transform.UseAsIs,
            attribute.DataType: dataType.String
        }
    ]
}
