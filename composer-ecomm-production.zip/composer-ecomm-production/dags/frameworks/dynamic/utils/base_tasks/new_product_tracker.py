from dags.frameworks.dynamic.utils.classes.attributes import Attribute
from dags.frameworks.dynamic.utils.classes.data_types import DataType
from dags.frameworks.dynamic.utils.classes.parameters import Parameter
from dags.frameworks.dynamic.utils.classes.task_config import TaskConfig
from dags.frameworks.dynamic.utils.classes.transformations import Transform

config = TaskConfig()
transform = Transform()
dataType = DataType()
param = Parameter()
attribute = Attribute()

load = {
  config.TaskName: "new_product_tracker",
  config.TaskDescription: "insert_into_new_product_tracker",
  config.BigQueryOperator: "BigQueryExecuteQueryOperator",
  config.BigQueryConnId: "bigquery_ecomm_dlf_data",
  config.DestinationProjectVariable: "ecomm-dlf-data",
  config.SqlOrScriptPath: "ecomm_sproc_ana_common_new_product_tracker",
  config.IsStoredProcFlag: True,
  config.SprocParams: [
    {
      attribute.Name: param.SourceProject,
      attribute.Value: "ecomm-dlf-data",
      attribute.IsInferredFlag: True,
      attribute.DataTransformationType:  transform.UseAsIs,
      attribute.DataType: dataType.String
    },
    {
      attribute.Name: param.SourceDataset,
      attribute.Value: "transient",
      attribute.IsInferredFlag: True,
      attribute.DataTransformationType: transform.UseAsIs,
      attribute.DataType: dataType.String
    },
    {
      attribute.Name: param.DestinationDataset,
      attribute.Value: "processed",
      attribute.IsInferredFlag: True,
      attribute.DataTransformationType: transform.UseAsIs,
      attribute.DataType: dataType.String
    },
    {
      attribute.Name: param.IntermediateProject,
      attribute.Value: "edw-prd-e567f9",
      attribute.IsInferredFlag: True,
      attribute.DataTransformationType: transform.UseAsIs,
      attribute.DataType: dataType.String
    },
    {
      attribute.Name: param.IntermediateDataset,
      attribute.Value: "enterprise",
      attribute.IsInferredFlag: True,
      attribute.DataTransformationType: transform.UseAsIs,
      attribute.DataType: dataType.String
    },
    {
      attribute.Name: param.DestinationLookupProject,
      attribute.Value: "shareddata-prd-cb5872",
      attribute.IsInferredFlag: True,
      attribute.DataTransformationType: transform.UseAsIs,
      attribute.DataType: dataType.String
    },
    {
      attribute.Name: param.DestinationLookupTable,
      attribute.Value: "sales_ecomm_global_sales_and_share",
      attribute.IsInferredFlag: True,
      attribute.DataTransformationType: transform.UseAsIs,
      attribute.DataType: dataType.String
    },
    {
      attribute.Name: param.DestinationLookupDataset,
      attribute.Value: "shared_data_sales",
      attribute.IsInferredFlag: True,
      attribute.DataTransformationType: transform.UseAsIs,
      attribute.DataType: dataType.String
    },
    {
      attribute.Name: param.SourceTable,
      attribute.Value: "distribution_availability_with_upc_fact",
      attribute.IsInferredFlag: True,
      attribute.DataTransformationType: transform.UseAsPrefix,
      attribute.DataType: dataType.String
    },
    {
      attribute.Name: param.DestinationTable,
      attribute.Value: "new_product_tracker",
      attribute.IsInferredFlag: True,
      attribute.DataTransformationType: transform.UseAsPrefix,
      attribute.DataType: dataType.String
    },
    {
      attribute.Name: param.SourceFeedName,
      attribute.Value: "feed_name",
      attribute.IsInferredFlag: True,
      attribute.DataTransformationType: transform.UseAsIs,
      attribute.DataType: dataType.String
    }
  ]
}