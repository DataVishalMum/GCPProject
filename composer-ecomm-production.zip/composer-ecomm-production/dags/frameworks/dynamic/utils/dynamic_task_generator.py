# All Framework Imports
import copy
import datetime
import pkg_resources
import subprocess
from datetime import timedelta
import os, sys, pandas, logging, re, time
import shutil
from pathlib import Path
import requests, json
import base64

# Fetching path of current file
parent_dir = os.path.dirname(__file__)

# Setting system path till composer-ecomm to import all underlying modules
#krishna composer migration - s
#sys.path.append(parent_dir[:parent_dir.index('ecomm-composer') + len('composer-ecomm')])
sys.path.append(parent_dir[:parent_dir.index('composer-ecomm') + len('composer-ecomm')])
#krishna composer migration - e

# All Framework Imports
from dags.frameworks.dynamic.utils.base_tasks import load_base_task_configs
from dags.frameworks.dynamic.utils.classes.attributes import Attribute
from dags.frameworks.dynamic.utils.classes.categories import Category
from dags.frameworks.dynamic.utils.classes.common_task_configs import CommonTaskConfig
from dags.frameworks.dynamic.utils.classes.parameters import Parameter
from dags.frameworks.dynamic.utils.classes.task_config import TaskConfig
from dags.frameworks.dynamic.utils.common_tasks import load_common_task_configs
from dags.common.utils import *
from dags.global_config import DAG_ROOT_DIR

# Importing Airflow UTILS

from google.cloud import bigquery
from airflow.providers.google.cloud.operators.bigquery import BigQueryExecuteQueryOperator
from airflow.configuration import conf
from airflow import DAG
from airflow.operators.dummy_operator import DummyOperator
from airflow.contrib.sensors.gcs_sensor import GoogleCloudStoragePrefixSensor
from airflow.exceptions import AirflowFailException
from airflow.operators.python_operator import PythonOperator
from airflow.contrib.operators.gcs_delete_operator import GoogleCloudStorageDeleteOperator
from google.cloud import storage
from airflow.models.log import Log
from airflow.utils.db import create_session
from airflow.providers.google.cloud.transfers.bigquery_to_bigquery import BigQueryToBigQueryOperator
from airflow.hooks.mysql_hook import MySqlHook


attributeCls: Attribute = Attribute()
taskConfigCls = TaskConfig()
param = Parameter()
categoryCls = Category()
commonConfigCls = CommonTaskConfig()
# utils_folder =  os.path.dirname(Path(__file__).resolve())
# backup_folder = Path().resolve().parent
utils_folder = os.path.join(DAG_ROOT_DIR, "frameworks/dynamic/utils")
backup_folder = os.path.join(DAG_ROOT_DIR, "frameworks/dynamic")
formatted_time_stamp = datetime.now().strftime("%Y-%m-%d at %I:%M:%S %p")
dry_run_list = []
html_display_task_list = []

ECOMM_COMPOSER_CONN_ID = get_gcp_conn_id(ECOMM_COMPOSER_CONN_ID)
ECOMM_DLF_CONN_ID = get_gcp_conn_id(ECOMM_DLF_CONN_ID)
ECOMM_ANALYTICS_CONN_ID = get_gcp_conn_id(ECOMM_ANALYTICS_CONN_ID)
EDW_CONN_ID = get_gcp_conn_id(EDW_CONN_ID)
EDW_PRD_CONN_ID = get_gcp_conn_id(EDW_PRD_CONN_ID)

file_load_counts = 0

# Creating bigquery connection to perform dry run
dry_run_bq_conn = bigquery.Client(ECOMM_DLF_CONN_ID)
dry_run_job_config = bigquery.QueryJobConfig(dry_run=True, use_query_cache=False)

# Azure Repos Constants

authorization = str(base64.b64encode(bytes(':'+GIT_PAT, 'ascii')), 'ascii')

headers = {
    'Accept': 'application/json',
    'Authorization': 'Basic '+authorization
}


def message(text: str, color=None):
    """Prints message in status color error (red), success (green), warning (yellow)

    :param text: str
    :param color: str
    """
    if color == "error":
        print('\033[31m', text, '\033[0m', sep='')
    elif color == "success":
        print('\033[32m', text, '\033[0m', sep='')
    elif color == "warning":
        print('\033[33m', text, '\033[0m', sep='')
    else:
        print(text)


def to_title(text: str) -> str:
    """ Returns string with InitailCaps
    :param text: str
    :return: str
    """
    return text.title().replace("_", "")


class Task:
    """ Core object in eComm dag definition """

    def __init__(self, task_name, bq_operator, bq_conn_id, **task_properties):
        self.task_name = "_".join(task_name.split())
        self.big_query_operator = bq_operator
        self.big_query_conn_id = bq_conn_id
        self.properties = task_properties


class Dag:
    """ Final Dag Definition """

    def __init__(self, dag_id, schedule_interval, create_sub_dags, dag_tasks):
        self.dag_id = "_".join(dag_id.lower().split())
        self.schedule_interval = schedule_interval
        self.create_sub_dags = create_sub_dags
        self.dag_tasks = dag_tasks


class CommonTask:
    """ A container task that can contain other tasks """
    def __init__(self, ct_title, ct_category, ct_tasks, **common_task_properties):
        self.title = ct_title
        self.category = ct_category
        self.position = common_task_properties.get('position', 1)
        self.is_base_task = common_task_properties.get('is_base_task', True)
        self.doc_md = common_task_properties.get('doc_md', '"category":"{c}", "tasks": "{t}"'.
                                                 format(c=ct_category, t=ct_title))
        self.tasks = ct_tasks


def create_file(file_name: str, file_text: str):
    """ Backs up file and creates new file

    :rtype: none
    :param file_name: str
    :param file_text: str
    :return: None
    """
    # First do back up
    back_ups_folder = os.path.join(backup_folder, "available_dynamic_configs")
    back_up_file_name = f"reference_{file_name}"
    if utils_folder is not None:
        original_file_path = os.path.join(utils_folder, file_name)
        if not os.path.exists(back_ups_folder):
            os.makedirs(back_ups_folder, exist_ok=True)
        existing_file = Path(original_file_path)
        if existing_file.is_file():
            back_up_file_path = os.path.join(back_ups_folder, back_up_file_name)
            shutil.copyfile(original_file_path, back_up_file_path)

        # Create file
        base_params_file = open(original_file_path, "w")
        base_params_file.write(file_text)
        base_params_file.close()


def get_json_key_value(lookup_string: str, json_data: list) -> object:
    """ Helper function to check if key exists in object

    :param lookup_string: str
    :type json_data: list
    """
    return json_data[lookup_string] if lookup_string in json_data else None


def create_generic_classes(class_items: list) -> str:
    """ Returns auto generated python class as string
    :param class_items: list
    :return: str
    """
    class_info = f"# **** THIS IS AN AUTO GENERATED FILE FOR USE AS REFERENCE FOR CONFIGURATION ****\n# " \
        f"************* GENERATED ON {formatted_time_stamp} *************\n"
    class_definitions = ""
    for item_group in class_items:
        if "category" in item_group:
            category = item_group["category"]
            class_category = next(filter(lambda b: b["category"] == category, class_items), None)
            if class_category is not None:
                class_name = to_title(f"{category}_task")
                class_title = f"\n\nclass {class_name}:\n\tdef __init__(self):\n"
                class_properties = ""
                class_decorators = ""
                if "items" in item_group:
                    for class_item in class_category["items"]:
                        attr_name = to_title(class_item)
                        attr_value = class_item
                        class_properties += f'\t\tself.__{attr_value} = "{attr_value}"\n'
                        class_decorators += f'\n\t@property\n\tdef {attr_name}(self):\n\t\t""" Name (Class: {class_name}) """\n\t\t' \
                                            f'return self.__{attr_value}\n\n\t@{attr_name}.setter\n\t' \
                                            f'def {attr_name}(self, value):\n\t\tself.__{attr_value} = value\n'
                class_definitions += f"{class_title}{class_properties}{class_decorators}"
    if len(class_definitions) > 0:
        return f"{class_info}{class_definitions}\n"
    else:
        return None
    return None


def create_base_task_params(created_base_tasks: list):
    all_base_task_params = []
    all_base_task_with_params = []
    for base_task in created_base_tasks:
        base_task_params = []
        base_task_with_params = []
        if taskConfigCls.SprocParams in base_task.properties:
            bt_params = base_task.properties[taskConfigCls.SprocParams]
            if len(bt_params) > 0:
                for sproc_param_item in bt_params:
                    check_param = next(
                        filter(lambda attr: attr[1] == sproc_param_item[attributeCls.Name], vars(param).items()), None)
                    available_params = next(
                        filter(lambda attr: attr[1] == sproc_param_item[attributeCls.Name], vars(param).items()), None)
                    as_list = list(available_params)
                    as_list[1] = sproc_param_item['value']
                    available_params = tuple(as_list)
                    if check_param is not None:
                        base_task_params.append(check_param[1])
                    if available_params is not None:
                        base_task_with_params.append({str(available_params[0].split("Parameter")[1]): str(available_params[1])})
            if len(base_task_params) > 0:
                all_base_task_params.append({"category": base_task.task_name, "items": base_task_params})
            if len(base_task_with_params) > 0:
                all_base_task_with_params.append({"category": base_task.task_name, "items": base_task_with_params})
    if len(all_base_task_params) > 0:
        create_enums("available_base_task_params.py", all_base_task_params)
    if len(all_base_task_with_params) > 0:
        create_enums("available_base_task_with_params.py", all_base_task_with_params)


def create_enums(enum_file_name: str, enum_items_list: list):
    """ Creates a parameters file with Enums using a list of tasks

    """
    enum_text = f"# **** THIS IS AN AUTO GENERATED FILE FOR USE AS REFERENCE FOR CONFIGURATION ****\n# " \
                f"************* GENERATED ON {formatted_time_stamp} *************\n\nfrom enum import Enum\n\n\n"
    all_enum_file_text = ""
    for enum_items in enum_items_list:
        unique_items = []
        if "items" in enum_items:
            for enum_item_to_create in enum_items["items"]:
                if enum_item_to_create not in unique_items:
                    enum_item = f'\t{to_title(enum_item_to_create)} = "{enum_item_to_create}"\n' \
                        if enum_file_name != "available_base_task_with_params.py" \
                        else \
                        f'\t{to_title(next(iter(enum_item_to_create)))} = "{list(enum_item_to_create.values())[0]}"\n'
                    unique_items.append(enum_item)
            if len(unique_items) > 0:
                base_task_enum = f'class { to_title(enum_items["category"])}(Enum):\n'
                base_task_enum += f'{"".join(unique_items)}\n\n'
                all_enum_file_text += base_task_enum
    if len(all_enum_file_text) > 0:
        enum_text += all_enum_file_text
        create_file(enum_file_name, enum_text)


def create_base_tasks() -> list:
    """ Creates base tasks that drive all tasks using task configs.
    :rtype: Task
    :returns: list
    """

    created_base_tasks = []
    base_task_configs = load_base_task_configs.load()
    for base_task_config_counter, base_task_config in enumerate(base_task_configs, start=1):
        copied_config = copy.copy(base_task_config)
        keys_to_remove = [taskConfigCls.TaskName, taskConfigCls.BigQueryConnId, taskConfigCls.BigQueryOperator]
        tn = base_task_config.get(taskConfigCls.TaskName, f"invalid_base_task_{str(base_task_config_counter)}")
        bqc = base_task_config.get(taskConfigCls.BigQueryConnId, None)
        bqo = base_task_config.get(taskConfigCls.BigQueryOperator, "BigQueryOperator")

        if all(v is not None for v in [tn, bqc, bqo]):
            [copied_config.pop(key) for key in keys_to_remove]
            copied_config["doc_md"] = "This is a base task. You can use it as-is or modify the parameters as needed."
            created_task = Task(tn, bqo, bqc, **copied_config)
            assert isinstance(created_task, Task)
            created_base_tasks.append(created_task)
            message(f"Base Task {created_task.task_name} created successfully.", "success")
        else:
            name_str = "" if tn is None else f" for {tn}"
            message(f"Base task not created{name_str}. The fields: '{taskConfigCls.TaskName}', "
                    f"'{taskConfigCls.BigQueryConnId}' and '{taskConfigCls.BigQueryOperator}' "
                    f"are all required. Please verify these fields are present on all base tasks", "error")
    return created_base_tasks


def create_common_dag_tasks() -> list:
    """ Creates tasks that will be used in the dag configuration.
    Also creates available_base_tasks.py class file and available_base_task_params.py enum file

    :rtype: CommonTask
    :return: list
    """
    available_common_tasks = []
    class_items_new = []

    # Create Base tasks. This is the foundation for everything
    available_base_tasks = create_base_tasks()
    # Create Base tasks As Common Task Group
    common_base_tasks_desc = "These are all the available base tasks. You can run any task as-is or " \
                             "override the associated parameters with other values."
    base_task_names = [b.task_name for b in available_base_tasks]
    common_base_tasks_doc_md = f'{{ "category":"{categoryCls.Base}","' \
                               f'desc": "{common_base_tasks_desc}","tasks": {base_task_names} }}'
    common_base_tasks = CommonTask(f"{categoryCls.Base}_tasks", categoryCls.Base, available_base_tasks,
                                   **{"position": 1, "is_base_task": True, "doc_md": common_base_tasks_doc_md})
    class_items_new.append({"category": categoryCls.Base, "items": base_task_names})
    available_common_tasks.append(common_base_tasks)

    # Now do Common Config Tasks using config files
    common_configs = load_common_task_configs.load()
    for common_config_counter, common_config in enumerate(common_configs, start=1):
        if categoryCls.title in common_config:
            common_config_tasks = []
            common_config_tasks_doc_md_str = []
            common_config_category = common_config[categoryCls.title]
            common_config_desc = common_config[commonConfigCls.Description]
            common_config_generated_id = f"{common_config_category}_common_task_group"
            if commonConfigCls.Tasks in common_config:
                for common_ct_counter, common_config_task in enumerate(common_config[commonConfigCls.Tasks], start=1):
                    common_config_task_id = common_config_task[commonConfigCls.Task]
                    base_task = next(filter(lambda b: b.task_name == common_config_task_id, available_base_tasks), None)
                    if base_task is None:
                        error_msg = "** ERROR **: in 'create_common_dag_tasks' method. Task with name '{task_id}'" \
                                    " not found. Please make sure this task exists in the list or create a" \
                                    " 'user-defined' task.".format(task_id=common_config_task_id)
                        message(error_msg, "error")
                    else:
                        common_config_tasks_doc_md_str.append(f"`{common_config_task_id}`")
                        copied_base_task = copy.copy(base_task)
                        assert isinstance(copied_base_task, Task)
                        if taskConfigCls.SprocParams in copied_base_task.properties:
                            copied_params = copied_base_task.properties[taskConfigCls.SprocParams]
                            if commonConfigCls.TaskOverrides in common_config_task and len(copied_params) > 0:
                                overrides = common_config_task[commonConfigCls.TaskOverrides]
                                # Use Common Overrides to update values
                                for param_key in overrides:
                                    matched = next(filter(
                                        lambda p: p[attributeCls.Name] == param_key, copied_params), None)
                                    if matched is not None:
                                        matched[attributeCls.Value] = overrides[param_key]
                                    else:
                                        message(f"{param_key} is not a valid override and has been ignored", "warning")

                            task_doc_md = f'{{"params": {copied_params}}}'
                            child_domain_task = CommonTask(copied_base_task.task_name,
                                                           common_config_category, copied_base_task,
                                                           **{"position": common_ct_counter,
                                                              "is_base_task": False, "doc_md": task_doc_md})
                            common_config_tasks.append(child_domain_task)

                category_domain_doc_md = f'{{ "category":"{common_config_category}","desc": "{common_config_desc}",' \
                    f'"tasks": {common_config_tasks_doc_md_str} }}'
                category_domain_task = CommonTask(common_config_generated_id,
                                                  common_config_category, common_config_tasks,
                                                  **{"position": common_config_counter, "is_base_task": False,
                                                     "doc_md": category_domain_doc_md})
                common_task_names = [g.title for g in common_config_tasks]
                class_items_new.append({"category": common_config_category, "items": common_task_names})
                available_common_tasks.append(category_domain_task)

    # Create new class and Enum files after everything runs
    # This is needed so newly added base_tasks can be available for use
    # This is done last so that we don't override any files we may need before code complete
    if len(class_items_new) > 0:
        tasks_class_text = create_generic_classes(class_items_new)
        create_file("available_tasks.py", tasks_class_text)
        create_base_task_params(available_base_tasks)
    return available_common_tasks


def override_params_value(common_tasks_value, config_tasks_value, big_query_operator):
    # If if there is override required for tasks
    if config_tasks_value:
        # Fetching list of all common tasks for overriding
        for common_config in common_tasks_value:
            # Fetching list of all overriding tasks details
            for configs in config_tasks_value:
                # Validating the override position
                if common_config['data_transformation_type'] == '_prefix':
                    # If overwriting value is same as global variable then prepend value with global variable value
                    # One of the scenario is when we want to overwrite ecomm-dlf-data with
                    # respective environment project name
                    if configs.get(common_config['name']) is not None:
                        override_value = globals()[configs.get(common_config['name'])] \
                            if configs.get(common_config['name']) in globals() and common_config['is_inferred_flag'] \
                            else configs.get(common_config['name'])
                        common_config['value'] = "{}_{}".format(override_value, common_config['value'])
                    else:
                        override_value = globals()[common_config['value']] \
                            if common_config['value'] in globals() and common_config['is_inferred_flag'] \
                            else common_config['value']
                        common_config['value'] = "{}_{}".format(override_value, common_config['value'])
                elif common_config['data_transformation_type'] == 'suffix_':
                    # If overwriting value is same as global variable then append value with global variable value
                    # One of the scenario is when we want to overwrite ecomm-dlf-data with
                    # respective environment project name
                    if configs.get(common_config['name']) is not None:
                        override_value = globals()[configs.get(common_config['name'])] \
                            if configs.get(common_config['name']) in globals() and common_config['is_inferred_flag'] \
                            else configs.get(common_config['name'])
                        common_config['value'] = "{}_{}".format(common_config['value'], override_value)
                    else:
                        override_value = globals()[common_config['value']] \
                            if common_config['value'] in globals() and common_config['is_inferred_flag'] \
                            else common_config['value']
                        common_config['value'] = "{}_{}".format(common_config['value'], override_value)
                else:
                    # If overwriting value is same as global variable then replace value with global variable value
                    # One of the scenario is when we want to overwrite ecomm-dlf-data with
                    # respective environment project name
                    if configs.get(common_config['name']) is not None:
                        override_value = globals()[configs.get(common_config['name'])] \
                            if configs.get(common_config['name']) in globals() and common_config['is_inferred_flag'] \
                            else configs.get(common_config['name'])
                        common_config['value'] = override_value
                    else:
                        override_value = globals()[common_config['value']] \
                            if common_config['value'] in globals() and common_config['is_inferred_flag'] \
                            else common_config['value']
                        common_config['value'] = user_defined_overrides(override_value) \
                            if common_config['is_inferred_flag'] else override_value

    if big_query_operator == "BigQueryExecuteQueryOperator":
        return generate_sproc(common_tasks_value)
    else:
        return generate_file_load_params(common_tasks_value)


def validate_user_permissions(dag_id):
    with create_session() as session:
        triggered_by = (
            session.query(Log.owner)
                .filter(Log.dag_id == dag_id, Log.event == "trigger")
                .order_by(Log.dttm.desc())
                .limit(1)
                .scalar()
        )
    if triggered_by not in get_admin_user_id():
        raise AirflowFailException("\n ************************** You don't have permission to run this DAG."
                                   " Please Adhere to the process mentioned in DAG Doc for insertion or contact your Admin"
                                   "************************** ")


def generate_sproc(params):
    # This is used to cast sproc_parameters into respective data_type
    sproc_params = []
    for vals in params:
        if vals['data_type'] not in ['int', 'float','bool']:
            vals['value'] = "'{}'".format(vals['value'])
        sproc_params.append(vals['value'])
    return ' , '.join(sproc_params)


def generate_file_load_params(params):
    # This returns dictionary for GCS File Load parameters
    new_dict = {}
    for vals in params:
        new_dict[vals['name']] = vals['value']
    return new_dict


def user_defined_overrides(sproc_params):
    # This function helps to replace project_name for user_defined task:
    return sproc_params \
        .replace("'ecomm-composer'", "'{}'".format(ECOMM_COMPOSER_CONN_ID)) \
        .replace("'ecomm-dlf-data'", "'{}'".format(ECOMM_DLF_CONN_ID)) \
        .replace("'ecomm-analytics'", "'{}'".format(ECOMM_ANALYTICS_CONN_ID)) \
        .replace("'ecomm-edw'", "'{}'".format(EDW_CONN_ID)) \
        .replace("'ecomm-edw-prd'", "'{}'".format(EDW_PRD_CONN_ID))\
        .replace("customer_name", "{}".format(globals()['customer_name'])) \
        .replace("feed_name", "{}".format(globals()['feed_name']))


def get_task_list(tasks_val, category, config_overrides_val, customer_name, feed_name, task_counter, dag):
    # Creating deepcopy of task to avoid overwriting of base tasks
    tasks = copy.deepcopy(tasks_val)
    config_overrides = copy.deepcopy(config_overrides_val)

    # Creating global variables to use across dags
    globals()['customer_name'] = customer_name
    globals()['feed_name'] = feed_name
    globals()['ecomm-composer'] = ECOMM_COMPOSER_CONN_ID
    globals()['ecomm-dlf-data'] = ECOMM_DLF_CONN_ID
    globals()['ecomm-analytics'] = ECOMM_ANALYTICS_CONN_ID
    globals()['ecomm-edw'] = EDW_CONN_ID
    globals()['ecomm-edw-prd'] = EDW_PRD_CONN_ID

    sproc_params = None

    # Checking if there is override for any config
    if config_overrides:
        for override in config_overrides:
            # If override task is same as config tasks then only override values
            if override['task'] == tasks['task_name']:
                sproc_params = override_params_value(tasks['properties']['sproc_params'], override['sproc_params'],
                                                     tasks['big_query_operator'])
    else:
        sproc_params = override_params_value(tasks['properties']['sproc_params'], [], tasks['big_query_operator'])

    if tasks['big_query_operator'] == "BigQueryExecuteQueryOperator":
        if category != "user_defined":
            is_sproc_flag = tasks['properties']['is_stored_proc_flag']
            sql_or_script_path = tasks['properties']['sql_or_script_path']
            sproc_params = sproc_params
        else:
            is_sproc_flag = tasks['is_stored_proc_flag']
            sql_or_script_path = tasks['sql_or_script_path']
            sproc_params = user_defined_overrides(sproc_params)

        if is_sproc_flag:
            # If it is a sproc then prepending sproc_params with sproc name and CALL functionality
            sql = "CALL transient.{sproc_name}({sproc_params})" \
                .format(sproc_name=sql_or_script_path,
                        sproc_params=sproc_params)
        else:
            # Running SQL script
            sql = "{DML_PATH}{FILE_NAME}"\
                .format(DML_PATH=DML_FILE_PATH, FILE_NAME=sql_or_script_path)

        # Appending list of sproc for performing dry run to validate them before running the actual.
        dry_run_list.append(
            {'task_id': "dry_run_{category}_{task_name}_{task_counter}".format(category=category,
                                                                               task_name=tasks['task_name'],
                                                                               task_counter=task_counter),
             'sql': str(sql)}
        )

        retries = 0 if 'dq' in str(tasks['task_name']) else 1

        html_display_task_list.append(
            {
                'Task_Name': "{category}_{task_name}_{task_counter}".format(category=category,
                                                                                    task_name=tasks['task_name'],
                                                                                    task_counter=task_counter),
                'Task_Value': str(sql)
             }
        )

        return BigQueryExecuteQueryOperator(
            task_id="{category}_{task_name}_{task_counter}".format(category=category,
                                                                   task_name=tasks['task_name'],
                                                                   task_counter=task_counter),
            #bigquery_conn_id=tasks['big_query_conn_id'],
            gcp_conn_id=tasks['big_query_conn_id'],
            sql=sql,
            use_legacy_sql=False,
            retries=retries,
            dag=dag
        )
    elif tasks['big_query_operator'] == "GoogleCloudStoragePrefixSensor":
        global file_load_counts
        file_load_counts = file_load_counts + 1

        html_display_task_list.append(
            {
                'Task_Name': "{task_name}_{task_counter}".format(task_name=tasks['task_name'],
                                                                 task_counter=task_counter),
                'Task_Value': [
                    {
                        "bucket": "{bucket_name}_{destination_project}".format(
                                                            bucket_name=sproc_params['file_bucket_name'],
                                                            destination_project=sproc_params['destination_project']),
                        'prefix':'{file_path}{file_name}'.format(file_path=sproc_params['file_path'],
                                                                 file_name=sproc_params['file_name']),
                        'poke_interval':sproc_params['file_check_interval'],
                        'timeout':sproc_params['file_checker_timeout'],
                        'soft_fail':'False'
                    }
                 ]
            }
        )
        
        return GoogleCloudStoragePrefixSensor(
            task_id="{task_name}_{task_counter}".format(task_name=tasks['task_name'],
                                                        task_counter=task_counter),
            bucket="{bucket_name}_{destination_project}".format(
                bucket_name=sproc_params['file_bucket_name'],
                destination_project=sproc_params['destination_project']),
            prefix='{file_path}{file_name}'.format(file_path=sproc_params['file_path'],
                                                   file_name=sproc_params['file_name']),
            poke_interval=int(sproc_params['file_check_interval']),
            timeout=int(sproc_params['file_checker_timeout']),
            soft_fail=False,
            retries=0,
            dag=dag
        )
    elif tasks['big_query_operator'] == "GCSFileLoad":

        html_display_task_list.append(
            {
                'Task_Name': "{task_name}_{task_counter}".format(task_name=tasks['task_name'],
                                                                 task_counter=task_counter),
                'Task_Value': [
                    {
                        'destination_project': sproc_params['destination_project'],
                        'destination_dataset': sproc_params['destination_dataset'],
                        'destination_table': sproc_params['destination_table'],
                        'file_bucket_name': "{bucket_name}_{destination_project}".format(
                            bucket_name=sproc_params['file_bucket_name'],
                            destination_project=sproc_params['destination_project']),
                        'file_path': sproc_params['file_path'],
                        'file_name': sproc_params['file_name'],
                        'file_type': sproc_params['file_type'],
                        'file_encoding_type': sproc_params['file_encoding_type'],
                        'file_field_delimiter': sproc_params['file_field_delimiter'],
                        'file_load_strategy': sproc_params['file_load_strategy'],
                        'file_skip_rows': sproc_params['file_skip_rows']
                    }
                ]
            }
        )

        return PythonOperator(
            task_id="{task_name}_{task_counter}".format(task_name=tasks['task_name'],
                                                        task_counter=task_counter),
            provide_context=True,
            python_callable=file_load_to_bigquery,
            op_kwargs={'destination_project': sproc_params['destination_project'],
                       'destination_dataset': sproc_params['destination_dataset'],
                       'destination_table': sproc_params['destination_table'],
                       'file_bucket_name': "{bucket_name}_{destination_project}".format(
                           bucket_name=sproc_params['file_bucket_name'],
                           destination_project=sproc_params['destination_project']),
                       'file_path': sproc_params['file_path'],
                       'file_name': sproc_params['file_name'],
                       'file_type': sproc_params['file_type'],
                       'file_encoding_type': sproc_params['file_encoding_type'],
                       'file_field_delimiter': sproc_params['file_field_delimiter'],
                       'file_load_strategy': sproc_params['file_load_strategy'],
                       'file_skip_rows': sproc_params['file_skip_rows']
                       },
            trigger_rule='all_success',
            retries=0,
            dag=dag
        )
    elif tasks['big_query_operator'] == "GoogleCloudStorageDeleteOperator":

        html_display_task_list.append(
            {
                'Task_Name': "{task_name}_{task_counter}".format(task_name=tasks['task_name'],
                                                                 task_counter=task_counter),
                'Task_Value': [
                    {
                        'bucket_name':"{bucket_name}_{destination_project}".format(
                            bucket_name=sproc_params['file_bucket_name'],
                            destination_project=sproc_params['destination_project']),
                        'prefix':'{file_path}{file_name}'.format(file_path=sproc_params['file_path'],
                                                                 file_name=sproc_params['file_name'])
                    }
                ]
            }
        )

        return GoogleCloudStorageDeleteOperator(
            task_id="{task_name}_{task_counter}".format(task_name=tasks['task_name'],
                                                        task_counter=task_counter),
            bucket_name="{bucket_name}_{destination_project}".format(
                bucket_name=sproc_params['file_bucket_name'],
                destination_project=sproc_params['destination_project']),
            prefix='{file_path}{file_name}'.format(file_path=sproc_params['file_path'],
                                                   file_name=sproc_params['file_name']),
            retries=0,
            dag=dag
        )
    elif tasks['big_query_operator'] == "AzureReposBranchDeleteOperator":

        html_display_task_list.append(
            {
                'Task_Name': "{task_name}_{task_counter}".format(task_name=tasks['task_name'],
                                                                 task_counter=task_counter),
                'Task_Value': [
                    {
                        'organization_name': sproc_params['organization_name'],
                        'git_project_id':sproc_params['git_project_id'],
                        'repository_id':sproc_params['repository_id'],
                        'threshold':sproc_params['threshold']
                    }
                ]
            }
        )

        return PythonOperator(
            task_id="{task_name}_{task_counter}".format(task_name=tasks['task_name'],
                                                        task_counter=task_counter),
            provide_context=True,
            python_callable=delete_repo_branch,
            op_kwargs={'organization_name': sproc_params['organization_name'],
                       'git_project_id': sproc_params['git_project_id'],
                       'repository_id': sproc_params['repository_id'],
                       'threshold': sproc_params['threshold']
                       },
            retries=0,
            dag=dag
        )

    elif tasks['big_query_operator'] == "BigQueryToBigQueryOperator":

        html_display_task_list.append(
            {
                'Task_Name': "{task_name}_{task_counter}".format(task_name=tasks['task_name'],
                                                                 task_counter=task_counter),
                'Task_Value': [
                    {
                        'gcp_conn_id': tasks['big_query_conn_id'],
                        'source_project_dataset_tables':"{source_project}.{source_dataset}.{source_table}"
                            .format(
                                    source_project=sproc_params['source_project'],
                                    source_dataset=sproc_params['source_dataset'],
                                    source_table=sproc_params['source_table']
                                ).replace("'", ""),
                        'destination_project_dataset_table':"{destination_project}.{destination_dataset}"
                                                            ".{destination_table}"
                            .format(destination_project=sproc_params['destination_project'],
                                    destination_dataset=sproc_params['destination_dataset'],
                                    destination_table=sproc_params['destination_table']).replace("'", ""),
                        'write_disposition':'WRITE_TRUNCATE',
                        'create_disposition':'CREATE_IF_NEEDED'
                    }
                ]
            }
        )

        return BigQueryToBigQueryOperator(
            task_id="{task_name}_{task_counter}".format(task_name=tasks['task_name'],
                                                        task_counter=task_counter),
            gcp_conn_id=tasks['big_query_conn_id'],
            source_project_dataset_tables="{source_project}.{source_dataset}.{source_table}"
                                                         .format(source_project=sproc_params['source_project'],
                                                                 source_dataset=sproc_params['source_dataset'],
                                                                 source_table=sproc_params['source_table'])
                                                         .replace("'", ""),
            destination_project_dataset_table="{destination_project}.{destination_dataset}.{destination_table}"
                         .format(destination_project=sproc_params['destination_project'],
                                 destination_dataset=sproc_params['destination_dataset'],
                                 destination_table=sproc_params['destination_table']).replace("'", ""),
            write_disposition='WRITE_TRUNCATE',
            create_disposition='CREATE_IF_NEEDED',
            retries=0,
            dag=dag
        )
    return None


# Creating sub_dags for dry_run tasks
def create_sub_dag(parent_dag_id,
                   sub_dag_id,
                   schedule_interval,
                   default_args):
    with DAG('{}.{}'.format(parent_dag_id, sub_dag_id),
             schedule_interval=schedule_interval,
             default_args=default_args,
             catchup=False,
             orientation='LR',
             default_view='graph',
             is_paused_upon_creation=True) as sub_dag:
        globals()[sub_dag.dag_id] = sub_dag
        dry_run_task_dependency = []
        for dt_counter, dag_task in enumerate(dry_run_list, start=1):
            dry_run_task_dependency.append(
                PythonOperator(
                    task_id="{task_name}".format(task_name=dag_task['task_id']),
                    provide_context=True,
                    python_callable=validation_task_creation,
                    op_kwargs={'sql': dag_task['sql']},
                    retries=2,
                    dag=sub_dag)
            )

        start = DummyOperator(task_id='start', dag=sub_dag)
        end = DummyOperator(task_id='end', dag=sub_dag)
        if len(dry_run_task_dependency) == 0:
            start >> end
        elif len(dry_run_task_dependency) == 1:
            start >> dry_run_task_dependency[0] >> end
        else:
            for i in range(0, len(dry_run_task_dependency)):
                start >> dry_run_task_dependency[i] >> end
                # if i not in [0]:
                #     prev_task = dry_run_task_dependency[i - 1]
                #     next_task = dry_run_task_dependency[i]
                #     prev_task.set_downstream(next_task)
    dry_run_list.clear()
    global file_load_counts
    file_load_counts = 0
    return sub_dag


def validation_task_creation(**kwargs):
    query = kwargs['sql']

    # Creating bigquery connection to perform dry run
    # bq_conn = bigquery.Client(ECOMM_DLF_CONN_ID)
    # job_config = bigquery.QueryJobConfig(dry_run=True, use_query_cache=False)

    try:
        # A dry run query completes immediately.
        dry_run_job = dry_run_bq_conn.query(query, job_config=dry_run_job_config,)
        logging.info("\n************** DAG RUN FEEDBACK START ****************")
        logging.info("\n Dry Run Successful for query {}.".format(query))
        logging.info("*************** DAG RUN FEEDBACK END ***************\n")
    except Exception as excep:
        raise AirflowFailException("\n Dry Run failed for query {} due to error {}.".format(query, str(excep)))


def updating_report_tables():
    dag_run_report_query = "CALL transient.ecomm_sproc_admin_dag_run_report ('{SRC_PROJECT}', 'processed', " \
                           "'ecomm_admin_dag_run_logs', '{DEST_PROJECT}', 'output', 'ecomm_admin_dag_run_report'," \
                           " 'ecomm_admin_dag_run_report');".format(SRC_PROJECT=ECOMM_DLF_CONN_ID,
                                                                    DEST_PROJECT=ECOMM_ANALYTICS_CONN_ID)

    dag_run_report_job = dry_run_bq_conn.query(dag_run_report_query)


# Logging Dag run status to Bigquery Table
def final_status(**kwargs):

    dag_details_list = []

    triggered_by = get_user_session(str(kwargs['dag'].dag_id))

    # Getting stats of all tasks in current dag
    for task_instance in kwargs['dag_run'].get_task_instances():

        dag_details_dict = {}

        dag_details_dict['dag_id'] = str(kwargs['dag'].dag_id)

        dag_details_dict['task_id'] = str(task_instance.task_id)

        dag_details_dict['dag_execution_date'] = str(kwargs['dag_run'].execution_date)

        # If task_instance task is same as current task then end date will be current timestamp & it happens
        # only for end task
        dag_details_dict['task_execution_date'] = task_instance.end_date.strftime('%Y-%m-%dT%H:%M:%S+00:00') \
            if task_instance.task_id != kwargs['task_instance'].task_id and task_instance.end_date is not None \
            else datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%S+00:00')

        # If task_instance task is same as current task then task status will be success & it only happens for end task
        dag_details_dict['task_status'] = str(task_instance.current_state()).lower() \
            if task_instance.task_id != kwargs['task_instance'].task_id else 'success'

        # Fetching tasks log path
        dag_details_dict['logs_path'] = "https://console.cloud.google.com/storage/browser/{url}/{dag_id}/" \
                                        "{task_id}/{dag_execution_date}". \
            format(url=conf.get('logging', 'remote_base_log_folder'),
                   dag_id=str(kwargs['dag'].dag_id),
                   task_id=str(task_instance.task_id),
                   dag_execution_date=str(kwargs['dag_run'].execution_date.strftime('%Y-%m-%dT%H:%M:%S.%f+00:00'))
                   .replace("+", "%2B")).replace("gs://", "")

        # Fetching dag path
        dag_details_dict['dag_url'] = "{base_url}/graph?dag_id={dag_id}"\
            .format(base_url=conf.get('webserver', 'base_url'),
                    dag_id=str(kwargs['dag'].dag_id))

        # User who ran the dag
        dag_details_dict['triggered_by'] = triggered_by

        dag_details_list.append(dag_details_dict)

    # Creating an Empty pandas Dataframe
    airflow_metadata_df = pandas.DataFrame()

    # Appending dataframe with each task details fetched for current dag
    for dag_details in dag_details_list:
        airflow_metadata_df = airflow_metadata_df.append(dag_details, ignore_index=True)

    client = bigquery.Client(ECOMM_DLF_CONN_ID)

    # Casting dag_execution_date & task_execution_date to pandas datetime
    airflow_metadata_df['dag_execution_date'] = pandas.to_datetime(airflow_metadata_df['dag_execution_date'])

    airflow_metadata_df['task_execution_date'] = pandas.to_datetime(airflow_metadata_df['task_execution_date'])

    status = set(airflow_metadata_df['task_status'].str.contains("failed"))

    if True in status:
        airflow_metadata_df['dag_status'] = str("failed")
    else:
        airflow_metadata_df['dag_status'] = str("success")

    airflow_metadata_df = airflow_metadata_df[['dag_id', 'task_id', 'dag_execution_date', 'dag_status',
                                               'task_execution_date', 'task_status', 'logs_path', 'dag_url',
                                               'triggered_by']]

    # Creating Job Config to load Dataframe into bigquery
    job_config = bigquery.LoadJobConfig(write_disposition=bigquery.WriteDisposition.WRITE_APPEND)

    # Load Dataframe into bigquery table
    job = client.load_table_from_dataframe(airflow_metadata_df, kwargs['logging_table_name'], job_config=job_config)
    job.result()
    logging.info("\n************ LOGS INSERTED INTO BIGQUERY TABLE: {logging_table_name} SUCCESSFULLY ************"
                 .format(logging_table_name=kwargs['logging_table_name']))

    status = set(airflow_metadata_df['dag_status'].str.contains("failed"))
    updating_report_tables()
    if True in status:
        raise AirflowFailException("\n DAG execution Failed .")


# Validating if gcs_file_load modules are available on host. if not then install it.
def validating_gcs_load_required_modules():
    required_modules = {'fsspec', 'gcsfs'}
    installed_modules = {pkg.key for pkg in pkg_resources.working_set}
    missing_modules = required_modules - installed_modules
    logging.info("\n************ MISSING MODULES ARE : {} ************".format(str(missing_modules)))
    if missing_modules:
        for module_name in missing_modules:
            logging.info("\n****************** ADDING PACKAGE : {} *************************"
                  .format(module_name.strip()))
            logging.info(subprocess.check_output([sys.executable, "-m", "pip", "install", module_name.strip()]))
        time.sleep(60)
        help("modules")
        return "\n****************** ALL DEPENDENCY PACKAGES ARE ADDED *************************"
    else:
        return "\n****************** NO DEPENDENCIES TO INSTALL *************************"


# Refining column_name to remove special characters
def column_name_refinement(column_name):
    # replacing all special characters with underscore
    column_name = re.sub('\W+', ' ', column_name.encode('ascii', 'ignore').decode('ascii'))
    # replacing multiple underscore with single
    column_name = re.sub('\s+', '_', column_name.strip())
    # validating if column_name starts with alpha letter or underscore and if not prepending underscore to column_name
    column_name = "_{}".format(column_name) if not (column_name[0].isalpha() or column_name[0] == "_") else column_name
    return column_name.lower()


# Loading file to bigquery from GCS bucket
def file_load_to_bigquery(**kwargs):

    # Validating if GCS File Sensor status is sucessful and not skipped or failed
    for task_instance in kwargs['dag_run'].get_task_instances():
        if str(task_instance.current_state()).lower() != 'success' and \
                'gcs_file_sensor' in str(task_instance.task_id).lower():
            raise AirflowFailException("\n************** GCS File Sensor Timeout due to {file_name}*.csv missing ****************"
                            .format(file_name=kwargs['file_name']))
        elif task_instance.task_id != kwargs['task_instance'].task_id:
            break

    logging.info(validating_gcs_load_required_modules())

    client = bigquery.Client(ECOMM_DLF_CONN_ID)

    table_name = "{dataset_name}.{table_name}".format(
        dataset_name=kwargs['destination_dataset'],
        table_name=kwargs['destination_table']
    )

    logging.info('\n ********** RAW TABLE NAME ************')
    logging.info(table_name)

    # If load_strategy is not append then it will be truncate load
    write_disposition = bigquery.WriteDisposition.WRITE_APPEND \
        if str(kwargs['file_load_strategy']).lower() == 'append' else bigquery.WriteDisposition.WRITE_TRUNCATE

    try:
        client.get_table("{project_name}.{table_name}".format(project_name=ECOMM_DLF_CONN_ID,
                                                              table_name=table_name))
    except Exception as ex:
        logging.info("\n *********** Table {project_name}.{table_name} is not found. Creating a new Table ***********"
                     .format(project_name=ECOMM_DLF_CONN_ID,
                             table_name=table_name))
        write_disposition = bigquery.WriteDisposition.WRITE_TRUNCATE

    logging.info('\n ********** List Files in GCS **********')

    storage_client = storage.Client(ECOMM_DLF_CONN_ID)

    logging.info("\n *********** Reading Files from Bucket {bucket_name} in file path {file_path} ***********"
                 .format(bucket_name=kwargs['file_bucket_name'],
                         file_path=kwargs['file_path']))

    blobs = storage_client.list_blobs(kwargs['file_bucket_name'], prefix=kwargs['file_path'], delimiter='/')

    new_view_query = []
    file_counter = 0
    validate_required_file_counts = 0

    sorted_blobs_list = {}

    for blob in blobs:
        sorted_blobs_list[blob.name] = datetime.fromtimestamp(blob.generation/(10**6))

    sorted_blobs_list = sorted(sorted_blobs_list.items(), key=lambda x: x[1])

    for blob in sorted_blobs_list:
        if kwargs['file_name'] in blob[0] and kwargs['file_type'] in blob[0]:

            if file_counter > 0:
                write_disposition = bigquery.WriteDisposition.WRITE_APPEND

            file_counter += 1
            uri = "gs://{bucket_name}/{file_path}".format(bucket_name=kwargs['file_bucket_name'],
                                                          file_path=blob[0])

            logging.info('\n ********** Processing File {filename} **********'.format(filename=uri))

            # Loading data into DataFrame from CSV present in GCS bucket
            load_file_to_dataframe = pandas.read_csv(uri,
                                                     dtype=str,
                                                     sep=kwargs['file_field_delimiter'],
                                                     encoding=kwargs['file_encoding_type'],
                                                     skiprows=int(kwargs['file_skip_rows']),
                                                     escapechar='\\').fillna("").astype(str)

            # Refining column_names to matching bigquery table criteria
            load_file_to_dataframe.columns = [column_name_refinement(cols) for cols in load_file_to_dataframe.columns]

            # Appending dataframe with ingest_date column whose value is current_timestamp
            load_file_to_dataframe['ingest_date'] = pandas.to_datetime(datetime.now())

            # Listing all column_names in Dataframe which is loaded from CSV file
            logging.info("\n ********** Dataframe Schema **********")
            logging.info(load_file_to_dataframe.info())

            # Creating job_config based on inputs provided i.e. append, overwrite or file_drift , autodetect schema etc.
            job_config = bigquery.LoadJobConfig(
                write_disposition=write_disposition,
                autodetect=True,
                allow_quoted_newlines=True,
                time_partitioning=bigquery.TimePartitioning(
                    type_=bigquery.TimePartitioningType.DAY,
                    field="ingest_date",  # Name of the column to use for partitioning.
                    expiration_ms=31536000000,  # 365 days.
                ),
            )

            new_table_name = ""

            # Checking file_load_strategy
            if str(kwargs['file_load_strategy']).lower() == "schema_drift":
                # Overwrting provided table_name with new_table_name with pattern as <table_name>_<job_id>_<file_count>
                # E.g. Provided Table_Name : table_name
                #      New Table_Name : table_name_132342_1
                new_table_name = "{table_name}_{job_id}_{file_counter}".format(table_name=table_name,
                                                                               job_id=kwargs['task_instance'].job_id,
                                                                               file_counter=str(file_counter))

                # Loading Dataframe to Biguery table
                load_job = client.load_table_from_dataframe(load_file_to_dataframe,
                                                            new_table_name,
                                                            job_config=job_config)
                load_job.result()

                logging.info("\n********** SETTING TABLE EXPIRY DETAILS *******************")

                set_new_table_name_expiry = client.get_table("{new_table_name}"
                                                             .format(new_table_name=new_table_name))
                # set table to expire 182 days (i.e 6 months) from now
                expiration = datetime.now() + timedelta(days=182)
                set_new_table_name_expiry.expires = expiration
                updated_policy = client.update_table(set_new_table_name_expiry, ["expires"])

                # Creating select statement of new table for updating the view
                new_view_query.append("SELECT * FROM {table_name}".format(table_name=new_table_name))
            else:
                new_table_name = table_name
                # Loading Dataframe into table based on load_stategy i.e. append or overwrite
                load_job = client.load_table_from_dataframe(load_file_to_dataframe, table_name, job_config=job_config)

            # Wait for the job to complete.
            load_job.result()

            logging.info("\n************** FILE LOADED IN TABLE {new_table_name} ****************"
                         .format(new_table_name=new_table_name))

            # Fetching file details from GCS bucket to archive the file
            source_bucket = storage_client.get_bucket(kwargs['file_bucket_name'])
            source_blob = source_bucket.blob(blob[0])
            destination_bucket = storage_client.get_bucket(kwargs['file_bucket_name'])
            new_blob_name = blob[0].replace('/landing/', '/archive/')

            logging.info("\n************** ARCHIVING FILE {} ****************".format(blob[0]))

            logging.info("\n********* Type of blob.name is : {} *********".format(type(blob[0])))

            # copy to new destination
            new_blob = source_bucket.copy_blob(
                source_blob, destination_bucket, new_blob_name)

            # delete blob at source
            source_blob.delete()

            logging.info("\n************** FILE {source_blob} ARCHIVED AT {new_blob} ****************"
                  .format(source_blob=source_blob, new_blob=new_blob))

    # Creating / Updating Views for Schema_Drift Tables
    if str(kwargs['file_load_strategy']).lower() == "schema_drift":
        try:
            # Fetch already existing view name
            view = client.get_table("{table_name}".format(table_name=table_name))
            # Get list of all previous run tables from view definition
            for query_details in str(view.view_query).upper().split("UNION ALL"):
                logging.info("\n********* OLD TABLE NAME IS : {new_table_name} *********"
                             .format(new_table_name=str(query_details.split("FROM")[1]).lower().strip()))
                set_new_table_name_expiry = client.get_table("{new_table_name}"
                                                             .format(new_table_name=str(query_details.split("FROM")[1])
                                                                     .lower().strip()))
                # set table to expire 30 days (i.e 1 months) from now
                expiration = datetime.now() + timedelta(days=30)
                set_new_table_name_expiry.expires = expiration
                updated_policy = client.update_table(set_new_table_name_expiry, ["expires"])

            # Join all current run table query using UNION ALL
            view.view_query = ' UNION ALL '.join(new_view_query)

            # Make an API request to update the query property of the view.
            view = client.update_table(view, ["view_query"])
            logging.info("Updated View {table_type}: {reference}".format(table_type=view.table_type,
                                                                         reference=str(view.reference)))
        except Exception as e:
            logging.info("\n*************** FAILED TO UPDATE VIEW {error} HENCE CREATING NEW VIEW ***************"
                         .format(error=str(e)))

            logging.info("\n*************** Creating View for {table_name} ***************"
                         .format(table_name=table_name))

            # If the view is does not exists then Create a New View
            job = client.query('CREATE OR REPLACE VIEW {table_name} AS {query} ;'
                               .format(table_name=table_name,
                                       query=' UNION ALL '.join(new_view_query)))
            job.result()
            logging.info("\n*************** Created View {table_name} Successfully ***************"
                         .format(table_name=table_name))


def create_html_element(html_tag, string):
    return '<{open_tag} style="padding:5px 10px;border-bottom: 1px solid #ddd">{text}</{close_tag}>' \
        .format(open_tag=html_tag, text=string, close_tag=html_tag)


def create_html_list_with_table(table_data, is_generic=True):

    # 1. Considering it as generic tasks by default and assigning column names:
    col1_name = "Task Name"
    col2_name = "Parameter List"

    # 2. Create table configurations and decorators:
    # html_li = '<li style="padding: 5px 0;">'
    html_li = ''
    html_table = '<table id="table_name" style="width:100%;border-collapse:collapse">'
    html_thead = '<thead><tr><th scope="col" style="padding:5px 10px;border-bottom: 1px solid #ddd">{col1_name}</th>' \
                 '<th scope="col" style="padding:5px 10px;border-bottom: 1px solid #ddd">{col2_name}</th>' \
                 '</tr></thead>'.format(col1_name=col1_name, col2_name=col2_name)
    html_table += html_thead
    html_tbody = "<tbody>"

    # 3. For each tasks in task list add table rows and return table:
    for tr_counter, tasks in enumerate(table_data, start=1):
        row_color = '#dddddd' if (tr_counter % 2) == 0 else 'none'
        html_tr = '<tr style="padding:5px 10px; background-color:{row_color}">'.format(row_color=row_color)
        col1 = tasks['Task_Name']
        col2 = tasks['Task_Value']
        html_tr += create_html_element("td", col1)
        html_tr += create_html_element("td", col2)
        html_tr += "</tr>"
        html_tbody += html_tr
    html_tbody += "</tbody>"
    html_table += html_tbody
    html_table += "</table></li>"
    html_li += html_table
    return html_li


def get_all_available_tasks():
    # html_ul = '<ul style="list-style-type: none;padding: 0;margin: 0;">'
    html_ul = ''
    html_li_generic_tasks = create_html_list_with_table(html_display_task_list)
    html_ul += html_li_generic_tasks
    # html_ul += "</ul>"

    html_ul = "<html>  <body> <div id='btnDagDetails' style='font-size:18px;color:blue'>" \
              "<span style='cursor: pointer; margin-bottom : 2px; padding:2px'>View Detail<span></div> " \
              "<div id='dagDetailTableWrapper' style='display: none;'>" + \
              html_ul + "</div> </body> <script> let showHide = document.getElementById('btnDagDetails');" \
                        "showHide.addEventListener('click', toggleDagDetail); " \
                        "function toggleDagDetail() " \
                        "{ let myTable = document.getElementById('dagDetailTableWrapper'); " \
                        "if(myTable.style.display == 'none') " \
                        "{ myTable.style.display = 'block'; showHide.textContent = 'Hide Detail'; }" \
                        "else{ myTable.style.display = 'none'; showHide.textContent = 'View Detail'; " \
                        "} } </script> </html>"

    html_display_task_list.clear()
    return html_ul


# Get Azure Repos ID
def get_repos_id(organization_name, git_project_name):
    url = "https://dev.azure.com/{organization}/{project}/_apis/git/repositories?api-version=6.0"\
        .format(organization=organization_name,
                project=git_project_name)

    response = requests.get(url=url, headers=headers)

    reponse_data = json.loads(response.text)

    project_details = {}

    all_repository_details = []

    repo_details = {}

    for details in reponse_data["value"]:
        repo_details["repository_id"] = details["id"]
        repo_details["repository_name"] = details["name"]
        repo_details["repository_url"] = details["url"]
        project_details["project_id"] = details["project"]["id"]
        project_details["project_name"] = details["project"]["name"]
        project_details["project_url"] = details["project"]["url"]
        all_repository_details.append(copy.deepcopy(repo_details))

    project_details["repository_details"] = all_repository_details

    return project_details


# Delete Azure Repository Branches
def delete_repo_branch(**kwargs):

    url = "https://dev.azure.com/{organization}/{git_project_id}/_apis/git/repositories/{repository_id}/"\
        .format(organization=kwargs['organization_name'],
                git_project_id=kwargs['git_project_id'],
                repository_id=kwargs['repository_id'])

    list_url_data = "{}{}".format(url, "stats/branches?api-version=6.1-preview.1")

    delete_url = "{}{}".format(url, "refs?api-version=6.1")

    get_branch_details = requests.get(url=list_url_data, headers=headers)

    branch_data = json.loads(get_branch_details.text)

    for details in branch_data.get('value'):
        old_object_id = details.get('commit').get('commitId')
        branch_name = details.get('name')
        branch_date = datetime.strptime(str(details.get('commit').get('author').get('date')).upper()
                                        .split('T')[0], '%Y-%m-%d')
        date_diff = datetime.today() - branch_date
        if date_diff.days > int(kwargs['threshold']):
            post_data = [
                {
                    "name": "refs/heads/{branch_name}".format(branch_name=branch_name),
                    "oldobjectid": "{old_object_id}".format(old_object_id=old_object_id),
                    "newobjectid": "0000000000000000000000000000000000000000"
                }
            ]
            print("Deleting branch : {branch_name} which is {days} days older".format(branch_name=branch_name,
                                                                                      days=str(date_diff.days)))
            x = requests.post(delete_url, headers=headers, json=post_data)
            print(x.text)
    return "Success"

