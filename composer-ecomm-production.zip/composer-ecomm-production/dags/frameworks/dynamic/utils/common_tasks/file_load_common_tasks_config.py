from dags.frameworks.dynamic.utils.available_base_task_params import *
from dags.frameworks.dynamic.utils.available_tasks import BaseTask
from dags.frameworks.dynamic.utils.classes.categories import Category
from dags.frameworks.dynamic.utils.classes.common_task_configs import CommonTaskConfig

category = Category()
config = CommonTaskConfig()
baseTask = BaseTask()

configuration = {
    config.Category: category.GcsFileLoad,
    config.Description: "Load File From GCS to Bigquery",
    config.Tasks: [
        {
            config.Task: baseTask.GcsFileSensor,

        },
        {
            config.Task: baseTask.GcsFileLoadToBigquery,
        }
    ]
}
