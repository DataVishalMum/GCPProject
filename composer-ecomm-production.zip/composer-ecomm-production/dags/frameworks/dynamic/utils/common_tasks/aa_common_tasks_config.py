from dags.frameworks.dynamic.utils.available_base_task_params import *
from dags.frameworks.dynamic.utils.available_tasks import BaseTask
from dags.frameworks.dynamic.utils.classes.categories import Category
from dags.frameworks.dynamic.utils.classes.common_task_configs import CommonTaskConfig
from dags.frameworks.dynamic.utils.classes.file_types import FileType

category = Category()
config = CommonTaskConfig()
baseTask = BaseTask()
fileType = FileType()

configuration = {
    config.Category: category.AssortmentAndAvailability,
    config.Description: "Some description about AA common task",
    config.Tasks: [
        {
            config.Task: baseTask.BuildApiProcessedTable,
        },
        {
            config.Task: baseTask.DataExtractConfigUpdate
        }
    ]
}
