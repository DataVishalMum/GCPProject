from dags.frameworks.dynamic.utils.common_tasks import aa_common_tasks_config, euau_ingestion_common_tasks_config ,gss_common_tasks_config, file_load_common_tasks_config, gss_table_ingestion_common_tasks_config


def load():
    configs = [
        gss_common_tasks_config.configuration,
        euau_ingestion_common_tasks_config.configuration,
        aa_common_tasks_config.configuration,
        file_load_common_tasks_config.configuration,
        gss_table_ingestion_common_tasks_config.configuration
    ]
    return configs
