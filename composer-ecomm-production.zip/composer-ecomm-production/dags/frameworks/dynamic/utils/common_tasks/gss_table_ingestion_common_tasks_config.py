from dags.frameworks.dynamic.utils.available_base_task_params import *
from dags.frameworks.dynamic.utils.available_tasks import BaseTask
from dags.frameworks.dynamic.utils.classes.categories import Category
from dags.frameworks.dynamic.utils.classes.common_task_configs import CommonTaskConfig

category = Category()
config = CommonTaskConfig()
baseTask = BaseTask()

configuration = {
    config.Category: category.GssTableIngestion,
    config.Description: "Global Sales and Share List of most frequently used tasks in sequence for table ingestion",
    config.Tasks: [
        {
            config.Task: baseTask.DimSourceToEnterpriseUpcXref
        },
        {
            config.Task: baseTask.SrcToEcommCatalogUpcMappingTable
        },
        {
            config.Task: baseTask.CustomerProcessedZero
        },
        {
            config.Task: baseTask.GssNarCustomerFact
        },
        {
            config.Task: baseTask.ProductNarTemp
        },
        {
            config.Task: baseTask.NielsenProductNarTemp
        },
        {
            config.Task: baseTask.ConsolidateProductNarTemp
        },
        {
            config.Task: baseTask.XrefGlobalBrand
        },
        {
            config.Task: baseTask.XrefGlobalCategory
        },
        {
            config.Task: baseTask.XrefOverride
        },
        {
            config.Task: baseTask.ConsolidateXrefTemp
        },
        {
            config.Task: baseTask.DerivedXrefInfoTemp
        },
        {
            config.Task: baseTask.CustomerFactNar
        },
        {
            config.Task: baseTask.DataQualityChecksRun
        },
        {
            config.Task: baseTask.CustomerWeeklyAggFact
        },
        {
            config.Task: baseTask.EcomDataReleaseControlInsert
        },
        {
            config.Task: baseTask.DataExtractConfigUpdate
        }
    ]
}
