import os
import glob, importlib, pathlib, sys
from textwrap import dedent

# Fetching path of current file
parent_dir = os.path.dirname(__file__)

# Setting system path till composer-ecomm to import all underlying modules
#krishna composer migration - s
#sys.path.append(parent_dir[:parent_dir.index('ecomm-composer') + len('composer-ecomm')])
sys.path.append(parent_dir[:parent_dir.index('composer-ecomm') + len('composer-ecomm')])
#krishna composer migration - e

from dags.frameworks.dynamic.utils.dynamic_task_generator import *
from dags.global_config import DAG_ROOT_DIR

# Importing common utils
from dags.common.utils import *

from airflow import DAG
from airflow.operators.dummy_operator import DummyOperator
from airflow.operators.subdag_operator import SubDagOperator


available_common_dag_tasks = create_common_dag_tasks()


# 1. Get all data load configs (from data_load_configs folder):
base_path = os.path.dirname(DAG_ROOT_DIR + "/ingestion_job_configs/ingestion_job_configs")

for (dir_path, dir_names, file_names) in os.walk(base_path):
    # 2. Get only those file whose name ends with configs.py from data_load_configs folder:
    sys.path.append(dir_path)
    py_files = glob.glob(os.path.join(dir_path, '*configs.py'))
    if len(py_files) > 0:
        for py_file in py_files:
            if "ingestion_job_configs" in py_file:
                # 3. Import file as module whose name ends with configs.py under the subfolder for dynamic DAG creation:
                module_name = pathlib.Path(py_file).stem
                module = importlib.import_module(module_name)
                # 4. Get dag configurations from the config file & from the list of common_task using
                # common function (i.e. utils.get_dag_configs):

                tasks_dependency = []
                schedule_interval = None
                try:
                    if (str(vars(module)['configuration']['dag_config']['schedule_interval']).upper() != 'NONE'
                            and ('prd' in get_gcp_conn_id(ECOMM_DLF_CONN_ID))):
                        schedule_interval = str(vars(module)['configuration']['dag_config']['schedule_interval'])

                    # 5. Create dag using the dag configuration:
                    with DAG(dag_id=str(vars(module)['configuration']['dag_config']['dag_name']),
                             schedule_interval=schedule_interval,
                             default_args=get_default_args(
                                 provide_context=True,
                                 is_public_flg=str(vars(module)['configuration']
                                                   ['dag_config']
                                                   ['is_public_flag']
                                                   )
                             ),
                             catchup=False,
                             orientation='TB',
                             default_view='graph',
                             max_active_runs=1,
                             tags=vars(module)['configuration']['dag_config']['tags'],
                             is_paused_upon_creation=True) as parent_dag:
                        globals()[parent_dag.dag_id] = parent_dag
                        for task_counter, steps in enumerate(vars(module)['configuration']['modeling_steps'], start=1):
                            if str(steps['step']['category']) == 'user_defined':
                                tasks_dependency.append(
                                    get_task_list(steps['step'],
                                                  str(steps['step']['category']),
                                                  [],
                                                  vars(module)['configuration']['dag_config']
                                                  ['customer_name'],
                                                  vars(module)['configuration']['dag_config']
                                                  ['feed_name'],
                                                  task_counter,
                                                  parent_dag))
                            else:
                                common_tasks = [dt for dt in available_common_dag_tasks if (dt.category == steps['step']['category'])]
                                for item in common_tasks:
                                    assert isinstance(item, CommonTask)
                                    all_common_tasks_val = [vars(vars(items)['tasks'])['task_name'] for items in item.tasks
                                                            if str(steps['step']['category']) != 'base']
                                    override_task_val = [step["task"] for step in steps['step']['overrides']]
                                    not_processed_task = [item for item in override_task_val if item not in all_common_tasks_val]
                                    for items in item.tasks:
                                        for overrides in steps['step']['overrides']:
                                            if str(steps['step']['category']) == 'base':
                                                if overrides['task'] == vars(items)['task_name']:
                                                    tasks_dependency.append(
                                                        get_task_list(vars(items), str(steps['step']['category']),
                                                                      steps['step']['overrides'],
                                                                      vars(module)['configuration']['dag_config']
                                                                      ['customer_name'],
                                                                      vars(module)['configuration']['dag_config']
                                                                      ['feed_name'],
                                                                      task_counter,
                                                                      parent_dag))
                                                    break
                                            else:
                                                if vars(vars(items)['tasks'])['task_name'] == overrides['task']:
                                                    tasks_dependency.append(
                                                        get_task_list(vars(vars(items)['tasks']), str(steps['step']['category']),
                                                                      steps['step']['overrides'],
                                                                      vars(module)['configuration']['dag_config']
                                                                      ['customer_name'],
                                                                      vars(module)['configuration']['dag_config']
                                                                      ['feed_name'],
                                                                      task_counter,
                                                                      parent_dag))
                                                    break
                                                elif overrides['task'] in not_processed_task:
                                                    base_tasks_val = [dt for dt in available_common_dag_tasks
                                                                      if (dt.category == "base")]
                                                    base_items_val = [items for item in base_tasks_val for items in item.tasks]
                                                    for tasks in base_items_val:
                                                        if overrides['task'] in vars(tasks)['task_name']:
                                                            tasks_dependency.append(
                                                                get_task_list(vars(tasks), str(steps['step']['category']),
                                                                              steps['step']['overrides'],
                                                                              vars(module)['configuration']['dag_config']
                                                                              ['customer_name'],
                                                                              vars(module)['configuration']['dag_config']
                                                                              ['feed_name'],
                                                                              task_counter,
                                                                              parent_dag))
                                                    not_processed_task.remove(overrides['task'])
                        # 6. Creating Dummy start task
                        start = DummyOperator(task_id='start', dag=parent_dag)

                        # 7. Fetching Airflow logging table_name
                        logging_table_name = get_logging_table()

                        if logging_table_name:
                            # 8. If there is logging table name in airflow environment then use it in end task
                            end = PythonOperator(
                                task_id='end',
                                provide_context=True,
                                python_callable=final_status,
                                op_kwargs={'logging_table_name': logging_table_name},
                                trigger_rule='all_done',
                                dag=parent_dag
                            )
                        else:
                            # 8. Else create Dummy end task
                            end = DummyOperator(task_id='end', dag=parent_dag)

                        # 9. Merging all dry_run task as a subdag
                        sub_dag_task = SubDagOperator(task_id='dry_run_validation',
                                                      subdag=create_sub_dag(parent_dag.dag_id,
                                                                            'dry_run_validation',
                                                                            parent_dag.schedule_interval,
                                                                            get_default_args(provide_context=True,
                                                                                             is_public_flg=str(vars(module)['configuration']
                                                                                                               ['dag_config']
                                                                                                               ['is_public_flag']
                                                                                                               ))),
                                                      dag=parent_dag)

                        get_dag_info = get_all_available_tasks()

                        dag_readme = "#### DAG Summary " + '\n' + \
                                     "This dag is used to process `" + \
                                     str(str(vars(module)['configuration']['dag_config']['dag_name'])) + \
                                     "` data load. <br /> "

                        parent_dag.doc_md = dedent(dag_readme + get_dag_info)

                        if len(tasks_dependency) == 1:
                            start >> sub_dag_task >> tasks_dependency[0] >> end
                        else:
                            # 10. Create task dependency in Dag for all the tasks list:
                            start >> sub_dag_task >> tasks_dependency[0]
                            for task_dependent in range(0, len(tasks_dependency)):
                                if task_dependent not in [0]:
                                    prev_task = tasks_dependency[task_dependent - 1]
                                    next_task = tasks_dependency[task_dependent]
                                    prev_task.set_downstream(next_task)
                            tasks_dependency[len(tasks_dependency)-1].set_downstream(end)
                except KeyError as e:
                    print(e, module_name)
