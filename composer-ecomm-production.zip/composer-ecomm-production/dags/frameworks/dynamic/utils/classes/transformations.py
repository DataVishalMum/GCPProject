class Transform:
    def __init__(self):
        super().__init__()
        self.__use_as_is = "none"
        self.__use_as_prefix = "_prefix"
        self.__use_as_suffix = "suffix_"

    @property
    def title(self):
        return "transform"

    @property
    def UseAsIs(self):
        """ UseAsIs (Class: Transform) """
        return self.__use_as_is

    @UseAsIs.setter
    def UseAsIs(self, value):
        self.__use_as_is = value

    @property
    def UseAsPrefix(self):
        """ UseAsPrefix (Class: Transform) """
        return self.__use_as_prefix

    @UseAsPrefix.setter
    def UseAsPrefix(self, value):
        self.__use_as_prefix = value

    @property
    def UseAsSuffix(self):
        """ UseAsSuffix (Class: Transform) """
        return self.__use_as_suffix

    @UseAsSuffix.setter
    def UseAsSuffix(self, value):
        self.__use_as_suffix = value
