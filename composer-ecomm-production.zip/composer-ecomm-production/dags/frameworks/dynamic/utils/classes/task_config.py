class TaskConfig:
    def __init__(self):
        super().__init__()
        self.__big_query_conn_id = "big_query_conn_id"
        self.__big_query_operator = "big_query_operator"
        self.__destination_project_variable = "destination_project_variable"
        self.__destination_dataset = "destination_dataset"
        self.__destination_table = "destination_table"
        self.__sql_or_script_path = "sql_or_script_path"
        self.__is_stored_proc_flag = "is_stored_proc_flag"
        self.__custom_scripts_flag = "custom_scripts_flag"
        self.__custom_scripts_params = "custom_scripts_params"
        self.__sproc_params = "sproc_params"
        self.__task_description = "task_description"
        self.__task_name = "task_name"

    @property
    def title(self):
        return "task_config"

    @property
    def BigQueryConnId(self):
        """ BigQueryConnId (Class: TaskConfig) """
        return self.__big_query_conn_id

    @BigQueryConnId.setter
    def BigQueryConnId(self, value):
        self.__big_query_conn_id = value

    @property
    def BigQueryOperator(self):
        """ BigQueryOperator (Class: TaskConfig) """
        return self.__big_query_operator

    @BigQueryOperator.setter
    def BigQueryOperator(self, value):
        self.__big_query_operator = value

    @property
    def DestinationProjectVariable(self):
        """ DestinationProjectVariable (Class: TaskConfig) """
        return self.__destination_project_variable

    @DestinationProjectVariable.setter
    def DestinationProjectVariable(self, value):
        self.__destination_project_variable = value

    @property
    def DestinationDataset(self):
        """ DestinationDataset (Class: TaskConfig) """
        return self.__destination_dataset

    @DestinationDataset.setter
    def DestinationDataset(self, value):
        self.__destination_dataset = value

    @property
    def DestinationTable(self):
        """ DestinationTable (Class: TaskConfig) """
        return self.__destination_table

    @DestinationTable.setter
    def DestinationTable(self, value):
        self.__destination_table = value

    @property
    def SqlOrScriptPath(self):
        """ SqlOrScriptPath (Class: TaskConfig) """
        return self.__sql_or_script_path

    @SqlOrScriptPath.setter
    def SqlOrScriptPath(self, value):
        self.__sql_or_script_path = value

    @property
    def IsStoredProcFlag(self):
        """ IsStoredProcFlag (Class: TaskConfig) """
        return self.__is_stored_proc_flag

    @IsStoredProcFlag.setter
    def IsStoredProcFlag(self, value):
        self.__is_stored_proc_flag = value

    @property
    def CustomScriptsFlag(self):
        """ CustomScriptsFlag (Class: TaskConfig) """
        return self.__custom_scripts_flag

    @CustomScriptsFlag.setter
    def CustomScriptsFlag(self, value):
        self.__custom_scripts_flag = value

    @property
    def CustomScriptsParams(self):
        """ CustomScriptsParams (Class: TaskConfig) """
        return self.__custom_scripts_params

    @CustomScriptsParams.setter
    def CustomScriptsParams(self, value):
        self.__custom_scripts_params = value

    @property
    def SprocParams(self):
        """ SprocParams (Class: TaskConfig) """
        return self.__sproc_params

    @SprocParams.setter
    def SprocParams(self, value):
        self.__sproc_params = value

    @property
    def TaskDescription(self):
        """ TaskDescription (Class: TaskConfig) """
        return self.__task_description

    @TaskDescription.setter
    def TaskDescription(self, value):
        self.__task_description = value

    @property
    def TaskName(self):
        """ TaskName (Class: TaskConfig) """
        return self.__task_name

    @TaskName.setter
    def TaskName(self, value):
        self.__task_name = value
