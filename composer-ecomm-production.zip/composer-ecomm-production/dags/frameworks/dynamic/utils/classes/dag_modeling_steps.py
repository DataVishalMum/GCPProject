class DagModelingStep:
    def __init__(self):
        super().__init__()
        self.__step = "step"
        self.__category = "category"
        self.__overrides = "overrides"

    @property
    def title(self):
        return "dag_modeling_step"

    @property
    def Step(self):
        """ Step (Class: DagModelingSteps) """
        return self.__step

    @Step.setter
    def Step(self, value):
        self.__step = value

    @property
    def Category(self):
        """ Category (Class: DagModelingStep) """
        return self.__category

    @Category.setter
    def Category(self, value):
        self.__category = value

    @property
    def Overrides(self):
        """ Overrides (Class: DagModelingStep) """
        return self.__overrides

    @Overrides.setter
    def Overrides(self, value):
        self.__overrides = value


class StepOverride:
    def __init__(self):
        super().__init__()
        self.__task = "task"
        self.__sproc_params = "sproc_params"
        self.__custom_scripts_flag = "custom_scripts_flag"
        self.__custom_scripts_params = "custom_scripts_params"

    @property
    def title(self):
        return "dag_modeling_step_override"

    @property
    def Task(self):
        """ Task (Class: StepOverride) """
        return self.__task

    @Task.setter
    def Task(self, value):
        self.__task = value

    @property
    def SprocParams(self):
        """ SprocParams (Class: StepOverride) """
        return self.__sproc_params

    @SprocParams.setter
    def SprocParams(self, value):
        self.__sproc_params = value

    @property
    def CustomScriptsFlag(self):
        """ CustomScriptsFlag (Class: StepOverride) """
        return self.__custom_scripts_flag

    @CustomScriptsFlag.setter
    def CustomScriptsFlag(self, value):
        self.__custom_scripts_flag = value

    @property
    def CustomScriptsParams(self):
        """ CustomScriptsParams (Class: StepOverride) """
        return self.__custom_scripts_params

    @CustomScriptsParams.setter
    def CustomScriptsParams(self, value):
        self.__custom_scripts_params = value