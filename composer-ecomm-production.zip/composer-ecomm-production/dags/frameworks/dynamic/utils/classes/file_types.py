class FileType:
    def __init__(self):
        super().__init__()
        self.__csv = ".csv"
        self.__txt = ".txt"
        self.__parquet = ".parquet"
        self.__edi = ".edi"
        self.__dat = ".dat"

    @property
    def title(self):
        return "file_type"

    @property
    def Csv(self):
        """ Csv (Class: FileType) """
        return self.__csv

    @Csv.setter
    def Csv(self, value):
        self.__csv = value

    @property
    def Txt(self):
        """ Txt (Class: FileType) """
        return self.__txt

    @Txt.setter
    def Txt(self, value):
        self.__txt = value

    @property
    def Parquet(self):
        """ Parquet (Class: FileType) """
        return self.__parquet

    @Parquet.setter
    def Parquet(self, value):
        self.__parquet = value

    @property
    def Edi(self):
        """ Edi (Class: FileType) """
        return self.__edi

    @Edi.setter
    def Edi(self, value):
        self.__edi = value

    @property
    def Dat(self):
        """ Dat (Class: FileType) """
        return self.__dat

    @Dat.setter
    def Dat(self, value):
        self.__dat = value
