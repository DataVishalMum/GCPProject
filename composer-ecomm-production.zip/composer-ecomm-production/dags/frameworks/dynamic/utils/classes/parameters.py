# noinspection SpellCheckingInspection
class Parameter:
    def __init__(self):
        super().__init__()
        self.__archive_table = "archive_table"
        self.__archive_flag = "archive_flag"
        self.__column_name = "column_name"
        self.__columns_position_to_skip_in_pivot = "columns_position_to_skip_in_pivot"
        self.__columns_name_to_skip_in_pivot = "columns_name_to_skip_in_pivot"
        self.__bq_connection_id = "bq_connection_id"
        self.__destination_customer_name = "destination_customer_name"
        self.__destination_feed_name = "destination_feed_name"
        self.__destination_project = "destination_project"
        self.__destination_dataset = "destination_dataset"
        self.__destination_table = "destination_table"
        self.__destination_lookup_dataset = "destination_lookup_dataset"
        self.__destination_lookup_project = "destination_lookup_project"
        self.__destination_lookup_table = "destination_lookup_table"
        self.__domanin_name = "domanin_name"
        self.__domanin_override_date = "domanin_override_date"
        self.__feed_grain = "feed_grain"
        self.__file_bucket_name = "file_bucket_name"
        self.__file_check_interval = "file_check_interval"
        self.__file_encoding_type = "file_encoding_type"
        self.__file_field_delimiter = "file_field_delimiter"
        self.__file_load_strategy = "file_load_strategy"
        self.__file_name = "file_name"
        self.__file_path = "file_path"
        self.__file_checker_timeout = "file_checker_timeout"
        self.__file_type = "file_type"
        self.__file_skip_rows = "file_skip_rows"
        self.__git_project_id = "git_project_id"
        self.__intermediate_lookup_project = "intermediate_lookup_project"
        self.__intermediate_lookup_dataset = "intermediate_lookup_dataset"
        self.__intermediate_lookup_table = "intermediate_lookup_table"
        self.__intermediate_project = "intermediate_project"
        self.__intermediate_dataset = "intermediate_dataset"
        self.__intermediate_table = "intermediate_table"
        self.__organization_name = "organization_name"
        self.__pivot_col_name = "pivot_col_name"
        self.__pivot_col_value = "pivot_col_value"
        self.__product_title_column_name = "product_title_column_name"
        self.__record_key = "record_key"
        self.__repository_id = "repository_id"
        self.__rpc_column_name = "rpc_column_name"
        self.__source_customer_name = "source_customer_name"
        self.__source_feed_name = "source_feed_name"
        self.__source_project = "source_project"
        self.__source_dataset = "source_dataset"
        self.__source_table = "source_table"
        self.__source_lookup_project = "source_lookup_project"
        self.__source_lookup_dataset = "source_lookup_dataset"
        self.__source_lookup_table = "source_lookup_table"
        self.__source_project = "source_project"
        self.__TARGET_TABLE_LIST = "TARGET_TABLE_LIST"
        self.__threshold = "threshold"
        self.__upc_column_name = "upc_column_name"
        self.__upc_check_digit_flg = "upc_check_digit_flg"
        self.__xref_project = "xref_project"
        self.__xref_dataset = "xref_dataset"
        self.__xref_table = "xref_table"

    @property
    def title(self):
        return "task_param"

    @property
    def ArchiveTable(self):
        """ ArchiveTable (Class: Parameter) """
        return self.__archive_table

    @ArchiveTable.setter
    def ArchiveTable(self, value):
        self.__archive_table = value

    @property
    def ArchiveFlag(self):
        """ ArchiveFlag (Class: Parameter) """
        return self.__archive_flag

    @ArchiveFlag.setter
    def ArchiveFlag(self, value):
        self.__archive_flag = value

    @property
    def ColumnName(self):
        """ ColumnName (Class: Parameter) """
        return self.__column_name

    @ColumnName.setter
    def ColumnName(self, value):
        self.__column_name = value

    @property
    def ColumnPositionToSkipInPivot(self):
        """ ColumnPositionToSkipInPivot (Class: Parameter) """
        return self.__columns_position_to_skip_in_pivot

    @ColumnPositionToSkipInPivot.setter
    def ColumnPositionToSkipInPivot(self, value):
        self.__columns_position_to_skip_in_pivot = value

    @property
    def ColumnNameToSkipInPivot(self):
        """ ColumnNameToSkipInPivot (Class: Parameter) """
        return self.__columns_name_to_skip_in_pivot

    @ColumnNameToSkipInPivot.setter
    def ColumnNameToSkipInPivot(self, value):
        self.__columns_name_to_skip_in_pivot = value

    @property
    def BQConnectionID(self):
        """ BQConnectionID (Class: Parameter) """
        return self.__bq_connection_id

    @BQConnectionID.setter
    def BQConnectionID(self, value):
        self.__bq_connection_id = value

    @property
    def DestinationCustomerName(self):
        """ DestinationCustomerName (Class: Parameter) """
        return self.__destination_customer_name

    @DestinationCustomerName.setter
    def DestinationCustomerName(self, value):
        self.__destination_customer_name = value

    @property
    def DestinationFeedName(self):
        """ DestinationFeedName (Class: Parameter) """
        return self.__destination_feed_name

    @DestinationFeedName.setter
    def DestinationFeedName(self, value):
        self.__destination_feed_name = value

    @property
    def DestinationProject(self):
        """ DestinationProject (Class: Parameter) """
        return self.__destination_project

    @DestinationProject.setter
    def DestinationProject(self, value):
        self.__destination_project = value

    @property
    def DestinationDataset(self):
        """ DestinationDataset (Class: Parameter) """
        return self.__destination_dataset

    @DestinationDataset.setter
    def DestinationDataset(self, value):
        self.__destination_dataset = value

    @property
    def DestinationLookupDataset(self):
        """ DestinationLookupDataset (Class: Parameter) """
        return self.__destination_lookup_dataset

    @DestinationLookupDataset.setter
    def DestinationLookupDataset(self, value):
        self.__destination_lookup_dataset = value

    @property
    def DestinationLookupProject(self):
        """ DestinationLookupProject (Class: Parameter) """
        return self.__destination_lookup_project

    @DestinationLookupProject.setter
    def DestinationLookupProject(self, value):
        self.__destination_lookup_project = value

    @property
    def DestinationLookupTable(self):
        """ DestinationLookupTable (Class: Parameter) """
        return self.__destination_lookup_table

    @DestinationLookupTable.setter
    def DestinationLookupTable(self, value):
        self.__destination_lookup_table = value

    @property
    def DestinationTable(self):
        """ DestinationTable (Class: Parameter) """
        return self.__destination_table

    @DestinationTable.setter
    def DestinationTable(self, value):
        self.__destination_table = value

    @property
    def DomainName(self):
        """ DomainName (Class: Parameter) """
        return self.__domanin_name

    @DomainName.setter
    def DomainName(self, value):
        self.__domanin_name = value

    @property
    def DomainOverrideDate(self):
        """ DomainOverrideDate (Class: Parameter) """
        return self.__domanin_override_date

    @DomainOverrideDate.setter
    def DomainOverrideDate(self, value):
        self.__domanin_override_date = value

    @property
    def FeedGrain(self):
        """ FeedGrain (Class: Parameter) """
        return self.__feed_grain

    @FeedGrain.setter
    def FeedGrain(self, value):
        self.__feed_grain = value

    @property
    def FileBucketName(self):
        """ FileBucketName (Class: Parameter) """
        return self.__file_bucket_name

    @FileBucketName.setter
    def FileBucketName(self, value):
        self.__file_bucket_name = value

    @property
    def FileCheckInterval(self):
        """ FileCheckInterval (Class: Parameter) """
        return self.__file_check_interval

    @FileCheckInterval.setter
    def FileCheckInterval(self, value):
        self.__file_check_interval = value

    @property
    def FileCheckerTimeout(self):
        """ FileCheckerTimeout (Class: Parameter) """
        return self.__file_checker_timeout

    @FileCheckerTimeout.setter
    def FileCheckerTimeout(self, value):
        self.__file_checker_timeout = value

    @property
    def FileEncodingType(self):
        """ FileEncodingType (Class: Parameter) """
        return self.__file_encoding_type

    @FileEncodingType.setter
    def FileEncodingType(self, value):
        self.__file_encoding_type = value

    @property
    def FileFieldDelimiter(self):
        """ FileFieldDelimiter (Class: Parameter) """
        return self.__file_field_delimiter

    @FileFieldDelimiter.setter
    def FileFieldDelimiter(self, value):
        self.__file_field_delimiter = value

    @property
    def FileLoadStrategy(self):
        """ FileLoadStrategy (Class: Parameter) """
        return self.__file_load_strategy

    @FileLoadStrategy.setter
    def FileLoadStrategy(self, value):
        self.__file_load_strategy = value

    @property
    def FileName(self):
        """ FileName (Class: Parameter) """
        return self.__file_name

    @FileName.setter
    def FileName(self, value):
        self.__file_name = value

    @property
    def FilePath(self):
        """ FilePath (Class: Parameter) """
        return self.__file_path

    @FilePath.setter
    def FilePath(self, value):
        self.__file_path = value

    @property
    def FileSkipRows(self):
        """ FileSkipRows (Class: Parameter) """
        return self.__file_skip_rows

    @FileSkipRows.setter
    def FileSkipRows(self, value):
        self.__file_skip_rows = value

    @property
    def FileType(self):
        """ FileType (Class: Parameter) """
        return self.__file_type

    @FileType.setter
    def FileType(self, value):
        self.__file_type = value

    @property
    def GitProjectId(self):
        """ GitProjectId (Class: Parameter) """
        return self.__git_project_id

    @GitProjectId.setter
    def GitProjectId(self, value):
        self.__git_project_id = value

    @property
    def IntermediateDataset(self):
        """ IntermediateDataset (Class: Parameter) """
        return self.__intermediate_dataset

    @IntermediateDataset.setter
    def IntermediateDataset(self, value):
        self.__intermediate_dataset = value

    @property
    def IntermediateLookupDataset(self):
        """ IntermediateLookupDataset (Class: Parameter) """
        return self.__intermediate_lookup_dataset

    @IntermediateLookupDataset.setter
    def IntermediateLookupDataset(self, value):
        self.__intermediate_lookup_dataset = value

    @property
    def IntermediateLookupProject(self):
        """ IntermediateLookupProject (Class: Parameter) """
        return self.__intermediate_lookup_project

    @IntermediateLookupProject.setter
    def IntermediateLookupProject(self, value):
        self.__intermediate_lookup_project = value

    @property
    def IntermediateLookupTable(self):
        """ IntermediateLookupTable (Class: Parameter) """
        return self.__intermediate_lookup_table

    @IntermediateLookupTable.setter
    def IntermediateLookupTable(self, value):
        self.__intermediate_lookup_table = value

    @property
    def IntermediateProject(self):
        """ IntermediateProject (Class: Parameter) """
        return self.__intermediate_project

    @IntermediateProject.setter
    def IntermediateProject(self, value):
        self.__intermediate_project = value

    @property
    def IntermediateTable(self):
        """ IntermediateTable (Class: Parameter) """
        return self.__intermediate_table

    @IntermediateTable.setter
    def IntermediateTable(self, value):
        self.__intermediate_table = value

    @property
    def OrganizationName(self):
        """ OrganizationName (Class: Parameter) """
        return self.__organization_name

    @OrganizationName.setter
    def OrganizationName(self, value):
        self.__organization_name = value

    @property
    def PivotColumnName(self):
        """ PivotColumnName (Class: Parameter) """
        return self.__pivot_col_name

    @PivotColumnName.setter
    def PivotColumnName(self, value):
        self.__pivot_col_name = value

    @property
    def ProductTitleColumnName(self):
        """ ProductTitleColumnName (Class: Parameter) """
        return self.__product_title_column_name

    @ProductTitleColumnName.setter
    def ProductTitleColumnName(self, value):
        self.__product_title_column_name = value

    @property
    def PivotColumnValue(self):
        """ PivotColumnValue (Class: Parameter) """
        return self.__pivot_col_value

    @PivotColumnValue.setter
    def PivotColumnValue(self, value):
        self.__pivot_col_value = value

    @property
    def RecordKey(self):
        """ RecordKey (Class: Parameter) """
        return self.__record_key

    @RecordKey.setter
    def RecordKey(self, value):
        self.__record_key = value

    @property
    def RepositoryID(self):
        """ RepositoryID (Class: Parameter) """
        return self.__repository_id

    @RepositoryID.setter
    def RepositoryID(self, value):
        self.__repository_id = value

    @property
    def RpcColumnName(self):
        """ RpcColumnName (Class: Parameter) """
        return self.__rpc_column_name

    @RpcColumnName.setter
    def RpcColumnName(self, value):
        self.__rpc_column_name = value

    @property
    def SourceCustomerName(self):
        """ SourceCustomerName (Class: Parameter) """
        return self.__source_customer_name

    @SourceCustomerName.setter
    def SourceCustomerName(self, value):
        self.__source_customer_name = value

    @property
    def SourceDataset(self):
        """ SourceDataset (Class: Parameter) """
        return self.__source_dataset

    @SourceDataset.setter
    def SourceDataset(self, value):
        self.__source_dataset = value

    @property
    def SourceFeedName(self):
        """ SourceFeedName (Class: Parameter) """
        return self.__source_feed_name

    @SourceFeedName.setter
    def SourceFeedName(self, value):
        self.__source_feed_name = value

    @property
    def SourceLookupDataset(self):
        """ SourceLookupDataset (Class: Parameter) """
        return self.__source_lookup_dataset

    @SourceLookupDataset.setter
    def SourceLookupDataset(self, value):
        self.__source_lookup_dataset = value

    @property
    def SourceLookupProject(self):
        """ SourceLookupProject (Class: Parameter) """
        return self.__source_lookup_project

    @SourceLookupProject.setter
    def SourceLookupProject(self, value):
        self.__source_lookup_project = value

    @property
    def SourceLookupTable(self):
        """ SourceLookupTable (Class: Parameter) """
        return self.__source_lookup_table

    @SourceLookupTable.setter
    def SourceLookupTable(self, value):
        self.__source_lookup_table = value

    @property
    def SourceProject(self):
        """ SourceProject (Class: Parameter) """
        return self.__source_project

    @SourceProject.setter
    def SourceProject(self, value):
        self.__source_project = value

    @property
    def SourceTable(self):
        """ SourceTable (Class: Parameter) """
        return self.__source_table

    @SourceTable.setter
    def SourceTable(self, value):
        self.__source_table = value

    @property
    def TARGET_TABLE_LIST(self):
        """ SourceTable (Class: Parameter) """
        return self.__TARGET_TABLE_LIST
    @TARGET_TABLE_LIST.setter
    def TARGET_TABLE_LIST(self, value):
        self.__TARGET_TABLE_LIST = value


    @property
    def Threshold(self):
        """ Threshold (Class: Parameter) """
        return self.__threshold

    @Threshold.setter
    def Threshold(self, value):
        self.__threshold = value

    @property
    def UpcCheckDigitFlag(self):
        """ UpcCheckDigitFlag (Class: Parameter) """
        return self.__upc_check_digit_flg

    @UpcCheckDigitFlag.setter
    def UpcCheckDigitFlag(self, value):
        self.__upc_check_digit_flg = value

    @property
    def UpcColumnName(self):
        """ UpcColumnName (Class: Parameter) """
        return self.__upc_column_name

    @UpcColumnName.setter
    def UpcColumnName(self, value):
        self.__upc_column_name = value

    @property
    def XrefDataset(self):
        """ XrefDataset (Class: Parameter) """
        return self.__xref_dataset

    @XrefDataset.setter
    def XrefDataset(self, value):
        self.__xref_dataset = value

    @property
    def XrefProject(self):
        """ XrefProject (Class: Parameter) """
        return self.__xref_project

    @XrefProject.setter
    def XrefProject(self, value):
        self.__xref_project = value

    @property
    def XrefTable(self):
        """ XrefTable (Class: Parameter) """
        return self.__xref_table

    @XrefTable.setter
    def XrefTable(self, value):
        self.__xref_table = value