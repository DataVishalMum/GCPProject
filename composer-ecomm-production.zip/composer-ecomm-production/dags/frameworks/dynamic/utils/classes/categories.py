class Category:
    def __init__(self):
        self.__assortment_and_availability = "aa"
        self.__base = "base"
        self.__euau = "euau"
        self.__gcs_file_load = "gcs_file_load"
        self.__gss = "gss"
        self.__gss_table_ingestion = "gss_table_ingestion"
        self.__performance_management = "pm"
        self.__technology_and_innovation = "tii"
        self.__user_defined = "user_defined"

    @property
    def title(self):
        return "category"

    @property
    def AssortmentAndAvailability(self):
        """ AssortmentAndAvailability (Class: Category) """
        return self.__assortment_and_availability

    @AssortmentAndAvailability.setter
    def AssortmentAndAvailability(self, value):
        self.__assortment_and_availability = value

    @property
    def Base(self):
        """ Base (Class: Category) """
        return self.__base

    @Base.setter
    def Base(self, value):
        self.__base = value

    @property
    def Euau(self):
        """ Euau (Class: Category) """
        return self.__euau

    @Euau.setter
    def Euau(self, value):
        self.__euau = value

    @property
    def GcsFileLoad(self):
        """ GcsFileLoad (Class: Category) """
        return self.__gcs_file_load

    @GcsFileLoad.setter
    def GcsFileLoad(self, value):
        self.__gcs_file_load = value

    @property
    def Gss(self):
        """ Gss (Class: Category) """
        return self.__gss

    @Gss.setter
    def Gss(self, value):
        self.__gss = value

    @property
    def GssTableIngestion(self):
        """ GssTableIngestion (Class: Category) """
        return self.__gss_table_ingestion

    @GssTableIngestion.setter
    def GssTableIngestion(self, value):
        self.__gss_table_ingestion = value

    @property
    def PerformanceManagement(self):
        """ PerformanceManagement (Class: Category) """
        return self.__performance_management

    @PerformanceManagement.setter
    def PerformanceManagement(self, value):
        self.__performance_management = value

    @property
    def TechnologyAndInnovation(self):
        """ TechnologyAndInnovation (Class: Category) """
        return self.__technology_and_innovation

    @TechnologyAndInnovation.setter
    def TechnologyAndInnovation(self, value):
        self.__technology_and_innovation = value

    @property
    def UserDefined(self):
        """ UserDefined (Class: Category) """
        return self.__user_defined

    @UserDefined.setter
    def UserDefined(self, value):
        self.__user_defined = value

