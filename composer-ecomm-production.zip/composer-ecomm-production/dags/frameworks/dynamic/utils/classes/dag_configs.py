class DagConfig:
    def __init__(self):
        super().__init__()
        self.__schedule_interval = "schedule_interval"
        self.__dag_name = "dag_name"
        self.__feed_name = "feed_name"
        self.__customer_name = "customer_name"
        self.__is_public_flag = "is_public_flag"
        self.__tags_string_array = "tags"
        self.__modeling_steps = "modeling_steps"

    @property
    def title(self):
        return "dag_config"

    @property
    def ScheduleInterval(self):
        """ ScheduleInterval (Class: DagConfig) """
        return self.__schedule_interval

    @ScheduleInterval.setter
    def ScheduleInterval(self, value):
        self.__schedule_interval = value

    @property
    def DagName(self):
        """ DagName (Class: DagConfig) """
        return self.__dag_name

    @DagName.setter
    def DagName(self, value):
        self.__dag_name = value

    @property
    def FeedName(self):
        """ FeedName (Class: DagConfig) """
        return self.__feed_name

    @FeedName.setter
    def FeedName(self, value):
        self.__feed_name = value

    @property
    def CustomerName(self):
        """ CustomerName (Class: DagConfig) """
        return self.__customer_name

    @CustomerName.setter
    def CustomerName(self, value):
        self.__customer_name = value

    @property
    def IsPublicFlag(self):
        """ IsPublicFlag (Class: DagConfig) """
        return self.__is_public_flag

    @IsPublicFlag.setter
    def IsPublicFlag(self, value):
        self.__is_public_flag = value

    @property
    def ModelingSteps(self):
        """ ModelingSteps (Class: DagConfig) """
        return self.__modeling_steps

    @ModelingSteps.setter
    def ModelingSteps(self, value):
        self.__modeling_steps = value

    @property
    def TagsStringArray(self):
        """ TagsStringArray (Class: DagConfig) """
        return self.__tags_string_array

    @TagsStringArray.setter
    def TagsStringArray(self, value):
        self.__tags_string_array = value
