class DataType:
    def __init__(self):
        super().__init__()
        self.__bool = "bool"
        self.__int = "int"
        self.__float = "float"
        self.__list_string = "list<string>"
        self.__list_int = "list<int>"
        self.__string = "string"

    @property
    def title(self):
        return "data_type"

    @property
    def Bool(self):
        """ Bool (Class: DataType) """
        return self.__bool

    @Bool.setter
    def Bool(self, value):
        self.__bool = value

    @property
    def Int(self):
        """ Int (Class: DataType) """
        return self.__int

    @Int.setter
    def Int(self, value):
        self.__int = value

    @property
    def Float(self):
        """ Float (Class: DataType) """
        return self.__float

    @Float.setter
    def Float(self, value):
        self.__float = value

    @property
    def ListString(self):
        """ ListString (Class: DataType) """
        return self.__list_string

    @ListString.setter
    def ListString(self, value):
        self.__list_string = value

    @property
    def ListInt(self):
        """ ListInt (Class: DataType) """
        return self.__list_int

    @ListInt.setter
    def ListInt(self, value):
        self.__list_int = value

    @property
    def String(self):
        """ String (Class: DataType) """
        return self.__string

    @String.setter
    def String(self, value):
        self.__string = value
