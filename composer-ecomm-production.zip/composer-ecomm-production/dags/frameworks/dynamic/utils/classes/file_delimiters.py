class FileDelimiter:
    def __init__(self):
        super().__init__()
        self.__caret = "^"
        self.__comma = ","
        self.__pipe = "|"
        self.__tilde = "~"
        self.__tab = "tab"

    @property
    def title(self):
        return "file_delimiter"

    @property
    def Caret(self):
        """ Caret (Class: FileDelimiter) """
        return self.__caret

    @Caret.setter
    def Caret(self, value):
        self.__caret = value

    @property
    def Comma(self):
        """ Comma (Class: FileDelimiter) """
        return self.__comma

    @Comma.setter
    def Comma(self, value):
        self.__comma = value

    @property
    def Pipe(self):
        """ Pipe (Class: FileDelimiter) """
        return self.__pipe

    @Pipe.setter
    def Pipe(self, value):
        self.__pipe = value

    @property
    def Tilde(self):
        """ Tilde (Class: FileDelimiter) """
        return self.__tilde

    @Tilde.setter
    def Tilde(self, value):
        self.__tilde = value

    @property
    def Tab(self):
        """ Tab (Class: FileDelimiter) """
        return self.__tab

    @Tab.setter
    def Tab(self, value):
        self.__tab = value
