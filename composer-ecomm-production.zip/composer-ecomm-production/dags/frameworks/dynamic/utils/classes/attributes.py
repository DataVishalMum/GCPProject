class Attribute:
    def __init__(self):
        super().__init__()
        self.__name = "name"
        self.__value = "value"
        self.__data_type = "data_type"
        self.__data_transformation_type = "data_transformation_type"
        self.__is_inferred_flag = "is_inferred_flag"

    @property
    def title(self):
        return "attribute"

    @property
    def Name(self):
        """ Name (Class: Attribute) """
        return self.__name

    @Name.setter
    def Name(self, value):
        self.__name = value

    @property
    def Value(self):
        """ Value (Class: Attribute) """
        return self.__value

    @Value.setter
    def Value(self, value):
        self.__value = value

    @property
    def DataType(self):
        """ DataType (Class: Attribute) """
        return self.__data_type

    @DataType.setter
    def DataType(self, value):
        self.__data_type = value

    @property
    def DataTransformationType(self):
        """ DataTransformationType (Class: Attribute) """
        return self.__data_transformation_type

    @DataTransformationType.setter
    def DataTransformationType(self, value):
        self.__data_transformation_type = value

    @property
    def IsInferredFlag(self):
        """ IsInferredFlag (Class: Attribute) """
        return self.__is_inferred_flag

    @IsInferredFlag.setter
    def IsInferredFlag(self, value):
        self.__is_inferred_flag = value
