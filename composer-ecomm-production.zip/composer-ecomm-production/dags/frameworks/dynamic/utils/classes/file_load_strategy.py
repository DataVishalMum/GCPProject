class FileLoadStrategy:
    def __init__(self):
        super().__init__()
        self.__append = "append"
        self.__overwrite = "overwrite"
        self.__schema_drift = "schema_drift"

    @property
    def title(self):
        return "file_load_strategy"

    @property
    def Append(self):
        """ Append (Class: FileLoadStrategy) """
        return self.__append

    @Append.setter
    def Append(self, value):
        self.__append = value

    @property
    def Overwrite(self):
        """ Overwrite (Class: FileLoadStrategy) """
        return self.__overwrite

    @Overwrite.setter
    def Overwrite(self, value):
        self.__overwrite = value

    @property
    def SchemaDrift(self):
        """ SchemaDrift (Class: FileLoadStrategy) """
        return self.__schema_drift

    @SchemaDrift.setter
    def SchemaDrift(self, value):
        self.__schema_drift = value

