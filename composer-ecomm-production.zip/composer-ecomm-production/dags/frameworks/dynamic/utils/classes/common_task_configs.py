class CommonTaskConfig:
    def __init__(self):
        super().__init__()
        self.__category = "category"
        self.__description = "description"
        self.__task = "task"
        self.__tasks = "tasks"
        self.__task_overrides = "task_overrides"

    @property
    def title(self):
        return "common_task_config"

    @property
    def Category(self):
        """ Category (Class: CommonTaskConfig) """
        return self.__category

    @Category.setter
    def Category(self, value):
        self.__category = value

    @property
    def Description(self):
        """ Description (Class: CommonTaskConfig) """
        return self.__description

    @Description.setter
    def Description(self, value):
        self.__description = value

    @property
    def Task(self):
        """ Task (Class: CommonTaskConfig) """
        return self.__task

    @Task.setter
    def Task(self, value):
        self.__task = value

    @property
    def Tasks(self):
        """ Tasks (Class: CommonTaskConfig) """
        return self.__tasks

    @Tasks.setter
    def Tasks(self, value):
        self.__tasks = value

    @property
    def TaskOverrides(self):
        """ TaskOverrides (Class: CommonTaskConfig) """
        return self.__task_overrides

    @TaskOverrides.setter
    def TaskOverrides(self, value):
        self.__task_overrides = value
