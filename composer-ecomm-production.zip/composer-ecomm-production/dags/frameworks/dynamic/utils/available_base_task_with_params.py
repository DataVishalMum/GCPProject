# **** THIS IS AN AUTO GENERATED FILE FOR USE AS REFERENCE FOR CONFIGURATION ****
# ************* GENERATED ON 2023-03-06 at 01:04:07 PM *************

from enum import Enum


class BqToBqCopyTable(Enum):
	BqConnectionId = "bigquery_ecomm_dlf_data"
	SourceProject = "ecomm-dlf-data"
	SourceDataset = "source_dataset"
	SourceTable = "source_table"
	DestinationProject = "ecomm-dlf-data"
	DestinationDataset = "destination_dataset"
	DestinationTable = "destination_table"
	SourceFeedName = "feed_name"


class BuildApiProcessedTable(Enum):
	SourceProject = "ecomm-dlf-data"
	DestinationProject = "ecomm-dlf-data"
	SourceDataset = "source_dataset"
	IntermediateDataset = "transient"
	DestinationDataset = "processed"
	SourceTable = "source_table_name"
	DestinationTable = "destination_table_name"
	SourceCustomerName = "customer_name"
	SourceFeedName = "feed_name"


class BuildProcessedTable(Enum):
	SourceProject = "ecomm-dlf-data"
	IntermediateDataset = "transient"
	DestinationDataset = "processed"
	SourceTable = "feed_name_delta_temp"
	DestinationTable = "feed_name"
	SourceFeedName = "feed_name"


class CommonModalityCalculation(Enum):
	SourceProject = "ecomm-dlf-data"
	SourceDataset = "processed"
	SourceTable = "feed_name_weekly_agg_fact"
	IntermediateTable = "customer_name_processed_zero"
	DestinationTable = "ecomm_common_modality_calculation"
	SourceCustomerName = "customer_name"
	SourceFeedName = "feed_name"


class CustomerDatasemblyDeltaTemp(Enum):
	DestinationProject = "ecomm-dlf-data"
	DestinationDataset = "transient"
	SourceCustomerName = "customer_name"
	DestinationTable = "destination_table"
	SourceTable = "source_table"
	SourceFeedName = "feed_name"


class ConsolidateProductEuauTemp(Enum):
	SourceProject = "ecomm-dlf-data"
	SourceDataset = "transient"
	SourceLookupDataset = "processed"
	DestinationTable = "feed_name_consolidate_product_temp"
	SourceTable = "feed_name_processed_zero"
	IntermediateTable = "feed_name_product_temp"
	XrefTable = "feed_name_nielsen_product_temp"
	SourceCustomerName = "customer_name"
	SourceFeedName = "feed_name"


class ConsolidateProductNarTemp(Enum):
	SourceProject = "ecomm-dlf-data"
	SourceDataset = "transient"
	SourceLookupDataset = "processed"
	DestinationTable = "feed_name_consolidate_product_temp"
	SourceTable = "feed_name_processed_zero"
	IntermediateTable = "feed_name_product_temp"
	XrefTable = "feed_name_nielsen_product_temp"
	SourceCustomerName = "customer_name"
	SourceFeedName = "feed_name"


class ConsolidateXrefTemp(Enum):
	SourceProject = "ecomm-dlf-data"
	SourceDataset = "transient"
	DestinationTable = "feed_name_consolidate_xref_temp"
	SourceTable = "feed_name_consolidate_product_temp"
	SourceCustomerName = "customer_name"
	SourceFeedName = "feed_name"


class CustomerFactNar(Enum):
	SourceProject = "ecomm-dlf-data"
	SourceLookupProject = "ecomm-edw"
	SourceDataset = "transient"
	SourceLookupDataset = "enterprise"
	DestinationDataset = "processed"
	DestinationTable = "feed_name_fact"
	SourceTable = "feed_name_processed_zero"
	XrefTable = "feed_name_derived_xref_info_temp"
	SourceCustomerName = "customer_name"
	SourceFeedName = "feed_name"


class CustomerFactEuau(Enum):
	SourceProject = "ecomm-dlf-data"
	SourceLookupProject = "ecomm-edw"
	SourceDataset = "transient"
	SourceLookupDataset = "enterprise"
	DestinationDataset = "processed"
	DestinationTable = "feed_name_fact"
	SourceTable = "feed_name_processed_zero"
	XrefTable = "feed_name_derived_xref_info_temp"
	SourceCustomerName = "customer_name"
	SourceFeedName = "feed_name"


class CustomerProcessedZero(Enum):
	SourceProject = "ecomm-dlf-data"
	SourceDataset = "transient"
	SourceTable = "feed_name_delta_temp"
	DestinationTable = "feed_name_processed_zero"
	SourceFeedName = "feed_name"
	DestinationDataset = "processed"
	SourceLookupProject = "ecomm-edw"
	SourceLookupDataset = "enterprise"


class CustomerWeeklyAggFact(Enum):
	SourceProject = "ecomm-dlf-data"
	SourceDataset = "transient"
	DestinationDataset = "processed"
	SourceLookupProject = "ecomm-edw"
	SourceLookupDataset = "enterprise"
	SourceTable = "feed_name_fact"
	DestinationTable = "feed_name_weekly_agg_fact"
	XrefTable = "gmi_customer_metadata_reference"
	SourceCustomerName = "customer_name"
	SourceFeedName = "feed_name"


class DataExtractConfigInsert(Enum):
	SourceProject = "ecomm-dlf-data"
	SourceDataset = "raw"
	IntermediateDataset = "transient"
	SourceTable = "table_name"
	SourceFeedName = "feed_name"


class DataExtractConfigUpdate(Enum):
	SourceProject = "ecomm-dlf-data"
	SourceDataset = "transient"
	SourceTable = "table_name"
	SourceFeedName = "feed_name"


class DeleteObjectsFromGcs(Enum):
	DestinationProject = "ecomm-dlf-data"
	FileBucketName = ""
	FilePath = ""
	FileName = ""


class DerivedXrefInfoTemp(Enum):
	SourceProject = "ecomm-dlf-data"
	SourceDataset = "transient"
	XrefTable = "feed_name_consolidate_xref_temp"
	SourceTable = "feed_name_consolidate_product_temp"
	DestinationTable = "feed_name_derived_xref_info_temp"
	SourceCustomerName = "customer_name"
	SourceFeedName = "feed_name"
	DestinationDataset = "processed"


class DimSourceToEnterpriseUpcXref(Enum):
	SourceProject = "ecomm-dlf-data"
	SourceDataset = "transient"
	DestinationDataset = "processed"
	SourceLookupProject = "ecomm-edw"
	SourceLookupDataset = "enterprise"
	SourceCustomerName = "customer_name"
	SourceTable = "feed_name_delta_temp"
	DestinationTable = "dim_source_to_enterprise_upc_xref"
	SourceFeedName = "feed_name"


class DistPlannerDeltaTemp(Enum):
	DestinationProject = "ecomm-dlf-data"
	IntermediateProject = "edw-prd-e567f9"
	IntermediateDataset = "sales_ops"
	DestinationDataset = "transient"
	DestinationTable = "publix_instacart_dist_planner_delta_temp"
	SourceFeedName = "feed_name"


class DistPlannerDeltaTempArchive(Enum):
	DestinationProject = "ecomm-dlf-data"
	IntermediateProject = "edw-prd-e567f9"
	IntermediateDataset = "sales_ops"
	DestinationDataset = "transient"
	DestinationTable = "publix_instacart_dist_planner_delta_temp_archive"
	SourceFeedName = "feed_name"


class DistPlannerTemp(Enum):
	DestinationProject = "ecomm-dlf-data"
	DestinationDataset = "transient"
	DestinationTable = "publix_instacart_dist_planner_temp"
	SourceDataset = "raw"
	SourceTable = "instacart_publix_instore"
	IntermediateProject = "edw-prd-e567f9"
	IntermediateDataset = "enterprise"
	IntermediateTable = "dim_product_active"
	SourceFeedName = "feed_name"


class DistPlannerProcessedOne(Enum):
	DestinationProject = "ecomm-dlf-data"
	SourceDataset = "transient"
	SourceTable = "publix_instacart_dist_planner_temp"
	DestinationDataset = "processed"
	IntermediateTable = "dim_upc_conversions_flattened"
	DestinationTable = "publix_instacart_dist_planner_fact"
	SourceFeedName = "feed_name"


class DistributionAvailabilityJoined(Enum):
	SourceProject = "ecomm-dlf-data"
	SourceTable = "datasembly_fact"
	IntermediateProject = "edw-prd-e567f9"
	IntermediateDataset = "enterprise"
	IntermediateTable = "fact"
	DestinationDataset = "processed"
	DestinationTable = "distribution_availability_joined_fact"
	SourceFeedName = "feed_name"


class DistributionAvailabilityJoinedE2Open(Enum):
	SourceProject = "ecomm-dlf-data"
	SourceTable = "datasembly_fact"
	IntermediateProject = "edw-prd-e567f9"
	IntermediateDataset = "enterprise"
	IntermediateTable = "e2open_weekly_agg_fact"
	DestinationDataset = "processed"
	DestinationTable = "distribution_availability_joined_fact"
	SourceFeedName = "feed_name"


class DistributionAvailabilityJoinedPublix(Enum):
	SourceProject = "ecomm-dlf-data"
	SourceDataset = "transient"
	DestinationDataset = "processed"
	IntermediateProject = "edw-prd-e567f9"
	IntermediateDataset = "enterprise"
	DestinationTable = "distribution_availability_joined_fact"
	SourceTable = "datasembly_fact"
	IntermediateTable = "dist_planner_fact"
	SourceFeedName = "feed_name"


class DistributionAvailabilitySmoothed(Enum):
	SourceProject = "ecomm-dlf-data"
	SourceTable = "distribution_availability_joined_fact"
	IntermediateProject = "edw-prd-e567f9"
	IntermediateDataset = "enterprise"
	IntermediateTable = "dim_date"
	DestinationDataset = "processed"
	DestinationTable = "distribution_availability_smoothed_fact"
	SourceFeedName = "feed_name"


class DistributionAvailabilitySmoothedPublix(Enum):
	SourceProject = "ecomm-dlf-data"
	SourceDataset = "transient"
	DestinationDataset = "processed"
	IntermediateProject = "edw-prd-e567f9"
	IntermediateDataset = "enterprise"
	SourceTable = "distribution_availability_joined_fact"
	DestinationTable = "distribution_availability_smoothed_fact"
	SourceFeedName = "feed_name"


class DistributionAvailabilitySubcatgAggFact(Enum):
	SourceProject = "ecomm-dlf-data"
	SourceDataset = "transient"
	SourceTable = "distribution_availability_with_upc_fact"
	IntermediateProject = "edw-prd-e567f9"
	IntermediateDataset = "enterprise"
	DestinationDataset = "processed"
	DestinationTable = "distribution_availability_subcatg_agg_fact"
	SourceFeedName = "feed_name"


class DistributionAvailabilityWithUpc(Enum):
	SourceProject = "ecomm-dlf-data"
	SourceTable = "distribution_availability_smoothed_fact"
	SourceLookupTable = "lkp_customer"
	DestinationDataset = "processed"
	DestinationTable = "distribution_availability_with_upc_fact"
	SourceFeedName = "feed_name"


class DistributionAvailabilityWithUpcPublix(Enum):
	SourceProject = "ecomm-dlf-data"
	SourceLookupDataset = "raw"
	SourceDataset = "transient"
	DestinationDataset = "processed"
	DestinationTable = "distribution_availability_with_upc_fact"
	SourceTable = "distribution_availability_smoothed_fact"
	SourceFeedName = "feed_name"


class DistributionFact(Enum):
	SourceProject = "ecomm-dlf-data"
	SourceDataset = "transient"
	DestinationDataset = "processed"
	DestinationTable = "datasembly_fact"
	SourceTable = "datasembly_processed_zero"
	SourceFeedName = "feed_name"


class DistributionFactE2Open(Enum):
	SourceProject = "ecomm-dlf-data"
	SourceDataset = "transient"
	DestinationDataset = "processed"
	DestinationTable = "e2open_daily_fact"
	SourceTable = "e2open_processed_zero"
	SourceFeedName = "feed_name"


class DistributionTargetWeeklyAggFact(Enum):
	DestinationProject = "ecomm-dlf-data"
	DestinationDataset = "processed"
	SourceTable = "e2open_daily_fact"
	DestinationTable = "e2open_weekly_agg_fact"
	SourceFeedName = "feed_name"


class DistributionWeeklyAggFact(Enum):
	DestinationProject = "ecomm-dlf-data"
	DestinationDataset = "processed"
	SourceTable = "e2open_daily_fact"
	DestinationTable = "e2open_weekly_agg_fact"
	SourceFeedName = "feed_name"


class DataQualityChecksRun(Enum):
	SourceProject = "ecomm-dlf-data"
	DestinationProject = "ecomm-analytics"
	RecordKey = ""
	SourceFeedName = "feed_name"


class E2OpenDeltaTemp(Enum):
	DestinationProject = "ecomm-dlf-data"
	DestinationDataset = "transient"
	SourceProject = "edw-prd-e567f9"
	IntermediateProject = "edw-prd-e567f9"
	SourceDataset = "source_dataset"
	IntermediateDataset = "enterprise"
	SourceTable = "source_table_name"
	DestinationTable = "e2open_delta_temp"
	SourceFeedName = "feed_name"


class E2OpenTargetDeltaTemp(Enum):
	DestinationProject = "ecomm-dlf-data"
	DestinationDataset = "transient"
	SourceProject = "edw-prd-e567f9"
	IntermediateProject = "edw-prd-e567f9"
	SourceDataset = "source_dataset"
	IntermediateDataset = "enterprise"
	SourceTable = "source_table_name"
	DestinationTable = "e2open_delta_temp"
	SourceFeedName = "feed_name"


class EcomDataReleaseControlInsert(Enum):
	SourceProject = "ecomm-dlf-data"
	DestinationDataset = "processed"
	SourceDataset = "processed"
	SourceTable = "feed_name_weekly_agg_fact"
	SourceCustomerName = "customer_name"
	SourceFeedName = "feed_name"


class GcsFileLoadToBigquery(Enum):
	DestinationProject = "ecomm-dlf-data"
	DestinationDataset = "raw"
	DestinationTable = "file_load_table_name"
	FileBucketName = "landing"
	FilePath = ""
	FileName = ""
	FileType = ".csv"
	FileFieldDelimiter = ","
	FileLoadStrategy = "append"
	FileSkipRows = "0"
	FileEncodingType = "unicode_escape"


class GcsFileSensor(Enum):
	DestinationProject = "ecomm-dlf-data"
	DestinationDataset = ""
	DestinationTable = ""
	FileBucketName = "landing"
	FilePath = ""
	FileName = ""
	FileType = "CSV"
	FileFieldDelimiter = ","
	FileLoadStrategy = "append"
	FileCheckerTimeout = "3600"
	FileCheckInterval = "900"


class GssNarCustomerFact(Enum):
	SourceProject = "ecomm-dlf-data"
	SourceLookupProject = "ecomm-edw"
	SourceDataset = "transient"
	SourceLookupDataset = "enterprise"
	DestinationDataset = "processed"
	DestinationTable = "feed_name_fact"
	SourceTable = "feed_name_processed_zero"
	UpcColumnName = "upc_column_name"
	RpcColumnName = "rpc"
	ProductTitleColumnName = "product_title_column_name"
	SourceCustomerName = "customer_name"
	SourceFeedName = "feed_name"


class KeywordSearchStandardizedDataLookup(Enum):
	DestinationProject = "ecomm-dlf-data"
	DestinationDataset = "transient"
	SourceDataset = "raw"
	IntermediateProject = "ecomm-dlf-data"
	IntermediateDataset = "processed"
	SourceTable = "source_tablename"
	SourceFeedName = "feed_name"


class NarCustomerEnrichment(Enum):
	SourceProject = "ecomm-dlf-data"
	SourceDataset = "transient"
	SourceTable = "feed_name_processed_zero"
	IntermediateTable = "ecomm_common_product_enrichment"
	SourceLookupDataset = "processed"
	DestinationDataset = "transient"
	DestinationTable = "feed_name_customer_enrichment_temp"
	DomaninName = "domain_name"
	DomaninOverrideDate = "domain_override_date"
	SourceCustomerName = "customer_name"
	SourceFeedName = "feed_name"


class NewProductTracker(Enum):
	SourceProject = "ecomm-dlf-data"
	SourceDataset = "transient"
	DestinationDataset = "processed"
	IntermediateProject = "edw-prd-e567f9"
	IntermediateDataset = "enterprise"
	DestinationLookupProject = "shareddata-prd-cb5872"
	DestinationLookupTable = "sales_ecomm_global_sales_and_share"
	DestinationLookupDataset = "shared_data_sales"
	SourceTable = "distribution_availability_with_upc_fact"
	DestinationTable = "new_product_tracker"
	SourceFeedName = "feed_name"


class NielsenDeltaTempBlue(Enum):
	DestinationProject = "ecomm-dlf-data"
	DestinationDataset = "transient"
	SourceProject = "ecomm-edw-prd"
	SourceDataset = "syndicated_nielsen"
	SourceFeedName = "feed_name"
	FeedGrain = "WEEK"
	RecordKey = "999999"


class NielsenDeltaTempEuau(Enum):
	DestinationProject = "ecomm-dlf-data"
	DestinationDataset = "transient"
	SourceProject = "ecomm-edw-prd"
	SourceDataset = "syndicated_data"
	SourceFeedName = "feed_name"
	FeedGrain = "WEEK"
	RecordKey = "999999"


class NielsenDeltaTempFrance(Enum):
	DestinationProject = "ecomm-dlf-data"
	DestinationDataset = "transient"
	SourceProject = "ecomm-edw-prd"
	SourceDataset = "syndicated_data"
	SourceFeedName = "feed_name"
	FeedGrain = "WEEK"
	RecordKey = "999999"


class NielsenDeltaTempNar(Enum):
	DestinationProject = "ecomm-dlf-data"
	DestinationDataset = "transient"
	SourceProject = "ecomm-edw-prd"
	SourceDataset = "syndicated_nielsen"
	SourceFeedName = "feed_name"
	FeedGrain = "WEEK"
	RecordKey = "999999"


class NielsenIriDeltaTemp(Enum):
	DestinationProject = "ecomm-dlf-data"
	DestinationDataset = "transient"
	SourceProject = "edw-prd-e567f9"
	SourceDataset = "source_dataset"
	SourceCustomerName = "customer_name"
	SourceTable = "source_table"
	DestinationTable = "destination_table"
	SourceFeedName = "feed_name"


class NielsenIriProcessedOne(Enum):
	SourceProject = "ecomm-dlf-data"
	SourceDataset = "transient"
	SourceTable = "source_table"
	DestinationDataset = "processed"
	DestinationTable = "fact"
	SourceFeedName = "feed_name"


class NielsenIriTemp(Enum):
	SourceProject = "ecomm-dlf-data"
	SourceDataset = "transient"
	SourceTable = "delta_temp"
	IntermediateProject = "ecomm-edw"
	IntermediateDataset = "enterprise"
	SourceLookupProject = "edw-prd-e567f9"
	SourceLookupDataset = "customer_direct"
	DestinationProject = "ecomm-dlf-data"
	DestinationDataset = "transient"
	DestinationTable = "destination_table"
	SourceFeedName = "feed_name"


class NielsenProductCaTemp(Enum):
	SourceProject = "ecomm-dlf-data"
	SourceDataset = "transient"
	XrefDataset = "processed"
	DestinationTable = "feed_name_nielsen_product_temp"
	SourceLookupProject = "ecomm-edw"
	SourceLookupDataset = "syndicated_data"
	SourceCustomerName = "customer_name"
	SourceFeedName = "feed_name"


class NielsenProductEuauTemp(Enum):
	SourceProject = "ecomm-dlf-data"
	SourceDataset = "transient"
	DestinationTable = "feed_name_nielsen_product_temp"
	SourceTable = "feed_name_product_temp"
	SourceLookupProject = "shareddata-prd-cb5872"
	SourceLookupDataset = "shared_data_enterprise"
	SourceLookupTable = "nielsen_dim_product_euau"
	SourceFeedName = "feed_name"


class NielsenProductNarNsTemp(Enum):
	SourceProject = "ecomm-dlf-data"
	SourceDataset = "transient"
	XrefDataset = "processed"
	DestinationTable = "feed_name_nielsen_product_temp"
	SourceLookupProject = "ecomm-edw"
	SourceLookupDataset = "syndicated_nielsen"
	SourceCustomerName = "customer_name"
	SourceFeedName = "feed_name"


class NielsenProductNarTemp(Enum):
	SourceProject = "ecomm-dlf-data"
	SourceDataset = "transient"
	XrefDataset = "processed"
	DestinationTable = "feed_name_nielsen_product_temp"
	SourceLookupProject = "ecomm-edw"
	SourceLookupDataset = "syndicated_nielsen"
	SourceCustomerName = "customer_name"
	SourceFeedName = "feed_name"


class ProductEnrichment(Enum):
	DestinationProject = "ecomm-dlf-data"
	DestinationDataset = "transient"
	DestinationTable = "ecomm_common_product_enrichment"
	SourceFeedName = "feed_name"


class ProductIntlTemp(Enum):
	SourceProject = "ecomm-dlf-data"
	DestinationDataset = "transient"
	SourceDataset = "processed"
	SourceLookupProject = "ecomm-edw"
	SourceLookupDataset = "enterprise"
	SourceTable = "feed_name_processed_zero"
	DestinationTable = "feed_name_product_temp"
	XrefTable = "lkp_table"
	SourceLookupTable = "gmi_customer_metadata_reference"
	SourceCustomerName = "customer_name"
	SourceFeedName = "feed_name"


class ProductNarTemp(Enum):
	SourceProject = "ecomm-dlf-data"
	DestinationDataset = "transient"
	XrefDataset = "processed"
	SourceLookupProject = "ecomm-edw"
	SourceLookupDataset = "enterprise"
	SourceCustomerName = "customer_name"
	DestinationTable = "feed_name_product_temp"
	SourceFeedName = "feed_name"


class ProfiteroApiDataExtractConfigInsert(Enum):
	DestinationProject = "ecomm-dlf-data"
	DestinationDataset = "transient"
	SourceProject = "ecomm-dlf-data"
	SourceDataset = "src_dataset"
	SourceTable = "src_table"
	ColumnName = "date_column_name"
	SourceFeedName = "feed_name"


class RepoBranchDelete(Enum):
	OrganizationName = ""
	GitProjectId = ""
	RepositoryId = ""
	Threshold = "180"


class SourceTableDataExtractConfigInsert(Enum):
	DestinationProject = "ecomm-dlf-data"
	DestinationDataset = "transient"
	SourceProject = "ecomm-dlf-data"
	SourceDataset = "src_dataset"
	SourceTable = "src_table"
	ColumnName = "date_column_name"
	SourceFeedName = "feed_name"


class SrcToEcommCatalogUpcMappingTable(Enum):
	DestinationProject = "ecomm-analytics"
	SourceFeedName = "feed_name"
	SourceDataset = "transient"
	SourceTable = "feed_name_delta_temp"
	UpcColumnName = "upc"
	RpcColumnName = "rpc"
	ProductTitleColumnName = "source_item_name"
	ColumnName = "customer_name"
	UpcCheckDigitFlg = "True"
	Threshold = "0.8"


class UnpivotPivot(Enum):
	SourceProject = "ecomm-dlf-data"
	DestinationDataset = "destination_dataset"
	SourceDataset = "source_dataset"
	SourceTable = "source_table"
	DestinationTable = "destination_table"
	PivotColName = "pivot_column_name"
	PivotColValue = "pivot_column_value"
	ColumnName = "week_begin_dt_value"
	ColumnsPositionToSkipInPivot = "list_of_column_position"
	ColumnsNameToSkipInPivot = "list_of_column_name"
	SourceFeedName = "feed_name"


class UpcConversionProcessAna(Enum):
	SourceProject = "ecomm-dlf-data"
	SourceDataset = "transient"
	IntermediateDataset = "processed"
	IntermediateTable = "dim_upc_conversions_flattened"
	SourceTable = "product_temp"
	DestinationTable = "product_upc_converted"
	SourceFeedName = "feed_name"


class UpcConversionProcessE2Open(Enum):
	SourceProject = "ecomm-dlf-data"
	SourceDataset = "transient"
	IntermediateDataset = "processed"
	IntermediateTable = "dim_upc_conversions_flattened"
	SourceTable = "e2open_product_temp"
	DestinationTable = "e2open_product_upc_converted"
	SourceFeedName = "feed_name"


class UpcConversionsDnaOnly(Enum):
	SourceProject = "ecomm-dlf-data"
	DestinationLookupProject = "shareddata-prd-cb5872"
	IntermediateProject = "edw-prd-e567f9"
	DestinationDataset = "processed"
	DestinationLookupTable = "sales_ecomm_global_sales_and_share"
	IntermediateDataset = "enterprise"
	SourceTable = "distribution_availability_with_upc_fact"
	IntermediateTable = "market6_sales_weekly_agg_fact"
	DestinationFeedName = "DISTRIBUTION_AVAILABILITY_SUBCATG_AGG_FACT"
	DestinationTable = "distribution_availability_upc_conversions"
	SourceFeedName = "feed_name"


class UpcConversionsE2Open(Enum):
	SourceProject = "ecomm-dlf-data"
	IntermediateProject = "edw-prd-e567f9"
	DestinationDataset = "processed"
	IntermediateDataset = "enterprise"
	SourceTable = "distribution_availability_with_upc_fact"
	IntermediateTable = "weekly_agg_fact"
	DestinationFeedName = "DISTRIBUTION_AVAILABILITY_SUBCATG_AGG_FACT"
	DestinationTable = "distribution_availability_upc_conversions"
	SourceFeedName = "feed_name"


class XrefGlobalBrand(Enum):
	SourceFeedName = "feed_name"


class XrefGlobalCategory(Enum):
	SourceFeedName = "feed_name"


class XrefOverride(Enum):
	SourceFeedName = "feed_name"


