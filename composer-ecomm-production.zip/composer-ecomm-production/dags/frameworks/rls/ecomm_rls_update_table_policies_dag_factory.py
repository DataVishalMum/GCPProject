# Importing python Native Libraries
import datetime
import os
import sys
from textwrap import dedent

# Fetching path of current file
parent_dir = os.path.dirname(__file__)

# Setting system path till composer-ecomm to import all underlying modules
#sys.path.append(parent_dir[:parent_dir.index('ecomm-composer') + len('composer-ecomm')])
sys.path.append(parent_dir[:parent_dir.index('composer-ecomm') + len('composer-ecomm')])

# Importing Airflow libraries
import airflow
from airflow.contrib.operators.bigquery_operator import BigQueryOperator
from airflow.models.variable import Variable
from airflow.operators.dummy_operator import DummyOperator

# Importing common utils
from dags.common.utils import (
    get_default_args,
    DML_FILE_PATH
)

# Importing configurations
from dags.frameworks.rls.dag_configs import update_rls_policies_on_ecomm_tables


# Get Environment Specific Variables
ECOMM_COMPOSER = Variable.get('ecomm-composer')
ECOMM_DLF = Variable.get('ecomm-dlf-data')
ECOMM_ANALYTICS = Variable.get('ecomm-analytics')
BIGQUERY_EDW = Variable.get('ecomm-edw')

dag_builder_list = [
    update_rls_policies_on_ecomm_tables.source_configs
    # Add more configs here...
]

# Since we will have a list of lists for dag configs, flatten them to a single list
flattened_dag_list = [config for sublist in dag_builder_list for config in sublist]

for dag_config in flattened_dag_list:

    with airflow.DAG(
            dag_config['dag_id'],
            template_searchpath=[DML_FILE_PATH],
            default_args=get_default_args(provide_context=True),
            start_date=datetime.datetime(2021, 7, 1),
            schedule_interval=dag_config['schedule_interval'],
            catchup=False,
            tags=["rls", "row level security", "ecomm table security"]
    ) as dag:
        globals()[dag.dag_id] = dag

        dag.doc_md = dedent("""
            #### DAG Summary
            This dag uses native BigQuery row level security (rls) to apply security policies on ecomm tables using 
            a combination of the `enterprise.dim_azure_ad_membership_flat` AD table and the `ecomm_customer_data_access` table. <br />  
            
            #### DAG Detail  
            <ul>
              <li>Runs every day at 4 AM.</li>
              <li>Only applies rls to tables (this is a BigQuery restriction).</li>
              <li>Only applies rls to tables that have the `customer_parent` column (eComm restriction).</li>
              <li>Checks if the AD groups are valid and if any invalid groups are found the policies for the invalid AD groups will be removed.</li>
              <li>Applies rls using new/updated entries found in the corresponding `ecomm_customer_data_access` table where the `is_pending_flg` column is `true`.</li>
              <li>The dag can also be run adhoc (after making an entry/entries in the corresponding `ecomm_customer_data_access` table).</li>
              <li>You make an entry in the `ecomm_customer_data_access` table using the dag for the corresponding project (edw or analytics).</li>
            </ul>
        """)

        if 'modeling_steps' in dag_config:

            start_task = DummyOperator(
                task_id="start_task", dag=dag)
            start_task.doc_md = """
                This dummy operator marks the beginning point of a group 
                of modeling/transformation data steps
            """

            end_task = DummyOperator(
                task_id="end_task", dag=dag)
            end_task.doc_md = """
                This dummy operator marks the ending point of a group 
                of modeling/transformation data steps
            """


            task_array=[]
            task_array.append(start_task)


            for loading_group in dag_config['modeling_steps']:

                for data_step in dag_config['modeling_steps'][loading_group]:
                    with open("{}{}".format(DML_FILE_PATH, data_step['sql'])) as f:
                        load_sql_str = f.read()

                    task_array.append(BigQueryOperator(
                        task_id=data_step['task_id'],
                        sql=load_sql_str,
                        #bigquery_conn_id=data_step['bigquery_conn_id'],
                        gcp_conn_id=data_step['bigquery_conn_id'],
                        use_legacy_sql=False,
                        params={**data_step, **{},
                                'DESTINATION_PROJECT': Variable.get(data_step['destination_project_variable']),
                                'TABLE_LIST':"'assortment_availability_report_rls_testing','ecomm_product_catalog_service_data', 'keyword_search_share_of_search_report'",
                                'TARGET_PROJECT':ECOMM_ANALYTICS,
                                'ECOMM_DLF':ECOMM_DLF,
                                },
                        dag=dag))

                    task_array[-2]>>task_array[-1]


            task_array.append(end_task)
            task_array[-2]>>task_array[-1]



                

                
