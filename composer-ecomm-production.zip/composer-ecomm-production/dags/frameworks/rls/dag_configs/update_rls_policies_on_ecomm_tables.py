source_configs = [
    {
        "dag_id": "ecomm_update_rls_for_all_tables_analytics",
        "schedule_interval": '0 4 * * *',
        "modeling_steps": {
            "ad_check": [{
                "task_id": "validate_ad_groups_and_update_security_tables",
                "bigquery_conn_id": "bigquery_ecomm_analytics",
                "source_dataset": "processed",
                "source_table": "ecomm_common_security_details",
                "destination_project_variable": "ecomm-analytics",
                "destination_dataset": "testing",
                "destination_table": "ecomm_common_security_details",
                "sql": "rls/ad_security_check.sql"
            }],
            "load": [{
                "task_id": "update_policies_on_ecomm_analytics_tables",
                "bigquery_conn_id": "bigquery_ecomm_analytics",
                "source_dataset": "processed",
                "source_table": "ecomm_common_customer_info",
                "destination_project_variable": "ecomm-analytics",
                "destination_dataset": "output",
                "destination_table": "ecomm_common_customer_info",
                "sql": "rls/apply_rls_policies_on_ecomm_tables.sql",
                "target_project": "ecomm-analytics",
            }]
        }
    },
    {
        "dag_id": "ecomm_update_rls_for_all_tables_edw",
        "schedule_interval": '0 4 * * *',
        "modeling_steps": {
            "load": [{
                "task_id": "update_policies_on_edw_ecomm_tables",
                "bigquery_conn_id": "bigquery_edw",
                "destination_project_variable": "ecomm-edw",
                "source_dataset": "ecomm",
                "source_table": "ecomm_common_customer_info",
                "destination_dataset": "ecomm",
                "destination_table": "ecomm_common_customer_info",
                "sql": "rls/apply_rls_policies_on_ecomm_tables.sql",
                "target_project": "ecomm-edw",
            }]
        }
    }
]
